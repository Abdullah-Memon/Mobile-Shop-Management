﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.ShopRegistration
{
    public partial class AdminAccount_uc : UserControl
    {
        public AdminAccount_uc()
        {
            InitializeComponent();
        }

        SqlCommand cmd;
        public int AccountState = 0;

        private void registerbtn_Click(object sender, EventArgs e)
        {
            // checing provided information
            if (string.IsNullOrEmpty(name.Text) || string.IsNullOrEmpty(cnic.Text) || string.IsNullOrEmpty(contact.Text) || string.IsNullOrEmpty(address.Text) || string.IsNullOrEmpty(username.Text) || string.IsNullOrEmpty(password.Text) || profile.Image == null)
            {
                if (name.Text == string.Empty)
                {
                    name.Focus();
                }
                else if (cnic.Text == string.Empty)
                {
                    cnic.Focus();
                }
                else if (contact.Text == string.Empty)
                {
                    contact.Focus();
                }

                else if (address.Text == string.Empty)
                {
                    address.Focus();
                }
                else if (username.Text == string.Empty)
                {
                    username.Focus();
                }
                else if (password.Text == string.Empty)
                {
                    password.Focus();
                }
                else
                {
                    MessageBox.Show("Please enter Profile picture or restart the application", "Error");
                }

            }
            // Adding information to database
            else
            {
                    // adding new data
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        int def_value = 0;

                        ImageConverter img = new ImageConverter();
                        byte[] pic = (byte[])img.ConvertTo(profile.Image, Type.GetType("System.Byte[]"));

                        cmd = new SqlCommand("AddEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@picture", pic));
                        cmd.Parameters.Add(new SqlParameter("@name", name.Text));
                        cmd.Parameters.Add(new SqlParameter("@role", def_value));
                        cmd.Parameters.Add(new SqlParameter("@CNIC", cnic.Text));
                        cmd.Parameters.Add(new SqlParameter("@Mobile", contact.Text));
                        cmd.Parameters.Add(new SqlParameter("@email", email.Text));
                        cmd.Parameters.Add(new SqlParameter("@address", address.Text));
                        cmd.Parameters.Add(new SqlParameter("@username", username.Text));
                        cmd.Parameters.Add(new SqlParameter("@password", password.Text));
                        cmd.Parameters.Add(new SqlParameter("@sqid", def_value));
                        cmd.Parameters.Add(new SqlParameter("@sqans", def_value));
                        cmd.Parameters.Add(new SqlParameter("@salary", Convert.ToDecimal(def_value)));

                        int chk = cmd.ExecuteNonQuery();
                        DB.con.Close();

                        if (chk > 0)
                        {
                            //clearing all information
                            name.Text = string.Empty;
                            cnic.Text = string.Empty;
                            contact.Text = string.Empty;
                            username.Text = string.Empty;
                            password.Text = string.Empty;
                            email.Text = string.Empty;
                            address.Text = string.Empty;
                            profile.Image = null;

                            AccountState = 1;

                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while Adding new Employee account Please try again " + ex.ToString(), "Error");
                    }

                    

                }
        }

        private void uploadpicbtn_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.Filter = "Image file (*.jpg; *.jpeg; *.png; *.bmp; *.gif;) | *.jpg; *.jpeg; *.png; *.bmp; *.gif;";
                opf.Multiselect = false;

                if (opf.ShowDialog() == DialogResult.OK)
                {
                    profile.Image = Image.FromFile(opf.FileName);
                }

            }
        }
        
    }
}
