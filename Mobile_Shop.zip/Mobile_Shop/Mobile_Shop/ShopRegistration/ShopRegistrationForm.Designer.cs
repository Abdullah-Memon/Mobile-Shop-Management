﻿namespace Mobile_Shop.ShopRegistration
{
    partial class ShopRegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.background = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.registerbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label7 = new System.Windows.Forms.Label();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GroupBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.aggrementbtn = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.uploadpicbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.picturebox = new Guna.UI2.WinForms.Guna2PictureBox();
            this.address = new Guna.UI2.WinForms.Guna2TextBox();
            this.contact2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.contact1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.shoptitle = new Guna.UI2.WinForms.Guna2TextBox();
            this.shopname = new Guna.UI2.WinForms.Guna2TextBox();
            this.ownername = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.label9 = new System.Windows.Forms.Label();
            this.finish_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.background.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            this.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this;
            // 
            // background
            // 
            this.background.BackColor = System.Drawing.Color.Transparent;
            this.background.BorderRadius = 10;
            this.background.Controls.Add(this.label9);
            this.background.Controls.Add(this.guna2GradientPanel1);
            this.background.Controls.Add(this.registerbtn);
            this.background.Controls.Add(this.ContentPanel);
            this.background.Controls.Add(this.finish_btn);
            this.background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background.FillColor = System.Drawing.Color.Indigo;
            this.background.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.background.Location = new System.Drawing.Point(7, 6);
            this.background.Margin = new System.Windows.Forms.Padding(4);
            this.background.Name = "background";
            this.background.Padding = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.background.ShadowDecoration.Parent = this.background;
            this.background.Size = new System.Drawing.Size(593, 626);
            this.background.TabIndex = 1;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BorderRadius = 25;
            this.guna2GradientPanel1.Controls.Add(this.crossbtn);
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(495, -28);
            this.guna2GradientPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(69, 86);
            this.guna2GradientPanel1.TabIndex = 12;
            // 
            // crossbtn
            // 
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.Indigo;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.White;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(11, 32);
            this.crossbtn.Margin = new System.Windows.Forms.Padding(4);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(47, 43);
            this.crossbtn.TabIndex = 1;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // registerbtn
            // 
            this.registerbtn.BorderColor = System.Drawing.Color.White;
            this.registerbtn.BorderRadius = 10;
            this.registerbtn.BorderThickness = 2;
            this.registerbtn.CheckedState.Parent = this.registerbtn;
            this.registerbtn.CustomImages.Parent = this.registerbtn;
            this.registerbtn.Enabled = false;
            this.registerbtn.FillColor = System.Drawing.Color.Indigo;
            this.registerbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.registerbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.registerbtn.ForeColor = System.Drawing.Color.White;
            this.registerbtn.HoverState.Parent = this.registerbtn;
            this.registerbtn.Location = new System.Drawing.Point(187, 561);
            this.registerbtn.Margin = new System.Windows.Forms.Padding(4);
            this.registerbtn.Name = "registerbtn";
            this.registerbtn.ShadowDecoration.Parent = this.registerbtn;
            this.registerbtn.Size = new System.Drawing.Size(217, 53);
            this.registerbtn.TabIndex = 0;
            this.registerbtn.Text = "Next";
            this.registerbtn.Click += new System.EventHandler(this.registerbtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(20, 16);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(184, 23);
            this.label7.TabIndex = 11;
            this.label7.Text = "Shop Registration";
            // 
            // ContentPanel
            // 
            this.ContentPanel.BorderRadius = 10;
            this.ContentPanel.Controls.Add(this.linkLabel1);
            this.ContentPanel.Controls.Add(this.aggrementbtn);
            this.ContentPanel.Controls.Add(this.label7);
            this.ContentPanel.Controls.Add(this.uploadpicbtn);
            this.ContentPanel.Controls.Add(this.picturebox);
            this.ContentPanel.Controls.Add(this.address);
            this.ContentPanel.Controls.Add(this.contact2);
            this.ContentPanel.Controls.Add(this.contact1);
            this.ContentPanel.Controls.Add(this.shoptitle);
            this.ContentPanel.Controls.Add(this.shopname);
            this.ContentPanel.Controls.Add(this.ownername);
            this.ContentPanel.Controls.Add(this.label6);
            this.ContentPanel.Controls.Add(this.label5);
            this.ContentPanel.Controls.Add(this.label4);
            this.ContentPanel.Controls.Add(this.label2);
            this.ContentPanel.Controls.Add(this.label8);
            this.ContentPanel.Controls.Add(this.label1);
            this.ContentPanel.Controls.Add(this.label3);
            this.ContentPanel.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ContentPanel.Location = new System.Drawing.Point(23, 71);
            this.ContentPanel.Margin = new System.Windows.Forms.Padding(4);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(545, 482);
            this.ContentPanel.TabIndex = 10;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(151, 431);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(152, 20);
            this.linkLabel1.TabIndex = 14;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Terms and Conditions";
            // 
            // aggrementbtn
            // 
            this.aggrementbtn.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.aggrementbtn.CheckedState.BorderRadius = 2;
            this.aggrementbtn.CheckedState.BorderThickness = 0;
            this.aggrementbtn.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.aggrementbtn.CheckedState.Parent = this.aggrementbtn;
            this.aggrementbtn.Location = new System.Drawing.Point(25, 430);
            this.aggrementbtn.Margin = new System.Windows.Forms.Padding(4);
            this.aggrementbtn.Name = "aggrementbtn";
            this.aggrementbtn.ShadowDecoration.Parent = this.aggrementbtn;
            this.aggrementbtn.Size = new System.Drawing.Size(27, 25);
            this.aggrementbtn.TabIndex = 7;
            this.aggrementbtn.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.aggrementbtn.UncheckedState.BorderRadius = 2;
            this.aggrementbtn.UncheckedState.BorderThickness = 0;
            this.aggrementbtn.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.aggrementbtn.UncheckedState.Parent = this.aggrementbtn;
            this.aggrementbtn.CheckedChanged += new System.EventHandler(this.guna2CustomCheckBox1_CheckedChanged);
            // 
            // uploadpicbtn
            // 
            this.uploadpicbtn.BorderColor = System.Drawing.Color.White;
            this.uploadpicbtn.BorderRadius = 10;
            this.uploadpicbtn.BorderThickness = 2;
            this.uploadpicbtn.CheckedState.Parent = this.uploadpicbtn;
            this.uploadpicbtn.CustomImages.Parent = this.uploadpicbtn;
            this.uploadpicbtn.FillColor = System.Drawing.Color.Indigo;
            this.uploadpicbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.uploadpicbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.uploadpicbtn.ForeColor = System.Drawing.Color.White;
            this.uploadpicbtn.HoverState.Parent = this.uploadpicbtn;
            this.uploadpicbtn.Location = new System.Drawing.Point(383, 178);
            this.uploadpicbtn.Margin = new System.Windows.Forms.Padding(4);
            this.uploadpicbtn.Name = "uploadpicbtn";
            this.uploadpicbtn.ShadowDecoration.Parent = this.uploadpicbtn;
            this.uploadpicbtn.Size = new System.Drawing.Size(97, 44);
            this.uploadpicbtn.TabIndex = 6;
            this.uploadpicbtn.Text = "Upload";
            this.uploadpicbtn.Click += new System.EventHandler(this.uploadpicbtn_Click);
            // 
            // picturebox
            // 
            this.picturebox.BackColor = System.Drawing.Color.Transparent;
            this.picturebox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picturebox.Location = new System.Drawing.Point(360, 16);
            this.picturebox.Margin = new System.Windows.Forms.Padding(4);
            this.picturebox.Name = "picturebox";
            this.picturebox.ShadowDecoration.Parent = this.picturebox;
            this.picturebox.Size = new System.Drawing.Size(150, 157);
            this.picturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picturebox.TabIndex = 11;
            this.picturebox.TabStop = false;
            // 
            // address
            // 
            this.address.BorderRadius = 10;
            this.address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.address.DefaultText = "";
            this.address.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.address.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.address.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.address.DisabledState.Parent = this.address;
            this.address.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.address.FillColor = System.Drawing.Color.WhiteSmoke;
            this.address.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.address.FocusedState.Parent = this.address;
            this.address.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.address.HoverState.Parent = this.address;
            this.address.Location = new System.Drawing.Point(25, 380);
            this.address.Margin = new System.Windows.Forms.Padding(4, 9, 4, 9);
            this.address.Name = "address";
            this.address.PasswordChar = '\0';
            this.address.PlaceholderText = "";
            this.address.SelectedText = "";
            this.address.ShadowDecoration.Parent = this.address;
            this.address.Size = new System.Drawing.Size(485, 38);
            this.address.TabIndex = 5;
            this.address.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // contact2
            // 
            this.contact2.BorderRadius = 10;
            this.contact2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.contact2.DefaultText = "";
            this.contact2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.contact2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.contact2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.contact2.DisabledState.Parent = this.contact2;
            this.contact2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.contact2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.contact2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.contact2.FocusedState.Parent = this.contact2;
            this.contact2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.contact2.HoverState.Parent = this.contact2;
            this.contact2.Location = new System.Drawing.Point(284, 305);
            this.contact2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.contact2.Name = "contact2";
            this.contact2.PasswordChar = '\0';
            this.contact2.PlaceholderText = "";
            this.contact2.SelectedText = "";
            this.contact2.ShadowDecoration.Parent = this.contact2;
            this.contact2.Size = new System.Drawing.Size(227, 38);
            this.contact2.TabIndex = 4;
            this.contact2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.contact2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.contact1_KeyPress);
            // 
            // contact1
            // 
            this.contact1.BorderRadius = 10;
            this.contact1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.contact1.DefaultText = "";
            this.contact1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.contact1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.contact1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.contact1.DisabledState.Parent = this.contact1;
            this.contact1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.contact1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.contact1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.contact1.FocusedState.Parent = this.contact1;
            this.contact1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.contact1.HoverState.Parent = this.contact1;
            this.contact1.Location = new System.Drawing.Point(25, 305);
            this.contact1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.contact1.Name = "contact1";
            this.contact1.PasswordChar = '\0';
            this.contact1.PlaceholderText = "";
            this.contact1.SelectedText = "";
            this.contact1.ShadowDecoration.Parent = this.contact1;
            this.contact1.Size = new System.Drawing.Size(227, 38);
            this.contact1.TabIndex = 3;
            this.contact1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.contact1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.contact1_KeyPress);
            // 
            // shoptitle
            // 
            this.shoptitle.BorderRadius = 10;
            this.shoptitle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.shoptitle.DefaultText = "";
            this.shoptitle.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.shoptitle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.shoptitle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.shoptitle.DisabledState.Parent = this.shoptitle;
            this.shoptitle.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.shoptitle.FillColor = System.Drawing.Color.WhiteSmoke;
            this.shoptitle.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.shoptitle.FocusedState.Parent = this.shoptitle;
            this.shoptitle.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.shoptitle.HoverState.Parent = this.shoptitle;
            this.shoptitle.Location = new System.Drawing.Point(25, 233);
            this.shoptitle.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.shoptitle.Name = "shoptitle";
            this.shoptitle.PasswordChar = '\0';
            this.shoptitle.PlaceholderText = "";
            this.shoptitle.SelectedText = "";
            this.shoptitle.ShadowDecoration.Parent = this.shoptitle;
            this.shoptitle.Size = new System.Drawing.Size(485, 38);
            this.shoptitle.TabIndex = 2;
            this.shoptitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // shopname
            // 
            this.shopname.BorderRadius = 10;
            this.shopname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.shopname.DefaultText = "";
            this.shopname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.shopname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.shopname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.shopname.DisabledState.Parent = this.shopname;
            this.shopname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.shopname.FillColor = System.Drawing.Color.WhiteSmoke;
            this.shopname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.shopname.FocusedState.Parent = this.shopname;
            this.shopname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.shopname.HoverState.Parent = this.shopname;
            this.shopname.Location = new System.Drawing.Point(25, 160);
            this.shopname.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.shopname.Name = "shopname";
            this.shopname.PasswordChar = '\0';
            this.shopname.PlaceholderText = "";
            this.shopname.SelectedText = "";
            this.shopname.ShadowDecoration.Parent = this.shopname;
            this.shopname.Size = new System.Drawing.Size(315, 38);
            this.shopname.TabIndex = 1;
            this.shopname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ownername
            // 
            this.ownername.BorderRadius = 10;
            this.ownername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ownername.DefaultText = "";
            this.ownername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ownername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ownername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ownername.DisabledState.Parent = this.ownername;
            this.ownername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ownername.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ownername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ownername.FocusedState.Parent = this.ownername;
            this.ownername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ownername.HoverState.Parent = this.ownername;
            this.ownername.Location = new System.Drawing.Point(25, 89);
            this.ownername.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ownername.Name = "ownername";
            this.ownername.PasswordChar = '\0';
            this.ownername.PlaceholderText = "";
            this.ownername.SelectedText = "";
            this.ownername.ShadowDecoration.Parent = this.ownername;
            this.ownername.Size = new System.Drawing.Size(315, 38);
            this.ownername.TabIndex = 0;
            this.ownername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(20, 348);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(279, 276);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Contact 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(20, 276);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Contact 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(20, 203);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Shop Title";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(60, 430);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "I accept all ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(20, 130);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Shop Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(20, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Owner Name";
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.background;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(19, 24);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(397, 23);
            this.label9.TabIndex = 15;
            this.label9.Text = "Mobilie Shop Management Registration";
            // 
            // finish_btn
            // 
            this.finish_btn.BorderColor = System.Drawing.Color.White;
            this.finish_btn.BorderRadius = 10;
            this.finish_btn.BorderThickness = 2;
            this.finish_btn.CheckedState.Parent = this.finish_btn;
            this.finish_btn.CustomImages.Parent = this.finish_btn;
            this.finish_btn.FillColor = System.Drawing.Color.Indigo;
            this.finish_btn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.finish_btn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.finish_btn.ForeColor = System.Drawing.Color.White;
            this.finish_btn.HoverState.Parent = this.finish_btn;
            this.finish_btn.Location = new System.Drawing.Point(187, 561);
            this.finish_btn.Margin = new System.Windows.Forms.Padding(4);
            this.finish_btn.Name = "finish_btn";
            this.finish_btn.ShadowDecoration.Parent = this.finish_btn;
            this.finish_btn.Size = new System.Drawing.Size(217, 53);
            this.finish_btn.TabIndex = 15;
            this.finish_btn.Text = "Finish";
            // 
            // ShopRegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(607, 638);
            this.Controls.Add(this.background);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ShopRegistrationForm";
            this.Padding = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShopRegistrationForm";
            this.Load += new System.EventHandler(this.ShopRegistrationForm_Load);
            this.background.ResumeLayout(false);
            this.background.PerformLayout();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picturebox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GradientPanel background;
        private Guna.UI2.WinForms.Guna2GradientButton uploadpicbtn;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2GroupBox ContentPanel;
        private Guna.UI2.WinForms.Guna2TextBox address;
        private Guna.UI2.WinForms.Guna2TextBox contact2;
        private Guna.UI2.WinForms.Guna2TextBox contact1;
        private Guna.UI2.WinForms.Guna2TextBox shoptitle;
        private Guna.UI2.WinForms.Guna2TextBox shopname;
        private Guna.UI2.WinForms.Guna2TextBox ownername;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2PictureBox picturebox;
        private Guna.UI2.WinForms.Guna2GradientButton registerbtn;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private Guna.UI2.WinForms.Guna2CustomCheckBox aggrementbtn;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GradientButton finish_btn;
    }
}