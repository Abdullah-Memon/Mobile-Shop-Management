﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Mobile_Shop.ShopRegistration
{
    public partial class ShopRegistrationForm : Form
    {
        public ShopRegistrationForm()
        {
            InitializeComponent();
        }

        // closing button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Aggrement on Terms and Conditionss
        private void guna2CustomCheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (aggrementbtn.Checked)
            {
                registerbtn.Enabled = true;
            }
            else
                registerbtn.Enabled = false;
        }

        // uploading shop picture coding
        private void uploadpicbtn_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.Filter = "Image.File (*jpg; *jpeg; *.png; *.gif; *.bmp)|*jpg; *jpeg; *.png; *.gif; *.bmp;";

                if (opf.ShowDialog() == DialogResult.OK)
                {
                    picturebox.Image = Image.FromFile(opf.FileName);
                }
            }
        }

        // registering new shop and saving all the data in database
        private void registerbtn_Click(object sender, EventArgs e)
        {
            int chk=0;
            // when all the information is provided completely.
            if (ownername.Text != "" && shopname.Text != "" && shoptitle.Text != "" && (contact2.Text != "" || contact1.Text != "") && address.Text != "" && picturebox.Image != null)
            {
                // converiting picture in byte
                ImageConverter img = new ImageConverter();
                byte[] pic = (byte[])img.ConvertTo(picturebox.Image, Type.GetType("System.Byte[]"));

                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }

                // Saving data to the database
                try
                {
                    SqlCommand cmd = new SqlCommand("shopRegistration", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@pic", pic));
                    cmd.Parameters.Add(new SqlParameter("@s_owner", ownername.Text));
                    cmd.Parameters.Add(new SqlParameter("@s_name", shopname.Text));
                    cmd.Parameters.Add(new SqlParameter("@s_title", shoptitle.Text));
                    cmd.Parameters.Add(new SqlParameter("@s_contact1", contact1.Text));
                    cmd.Parameters.Add(new SqlParameter("@s_contact2", contact2.Text));
                    cmd.Parameters.Add(new SqlParameter("@s_address", address.Text));
                    
                    chk = cmd.ExecuteNonQuery();
                    DB.con.Close();

                 
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error while registration!", ex.ToString(), MessageBoxButtons.OK);
                }
            }

            // focusing on unfilled boxes for registration
            if (ownername.Text == "")
                ownername.Focus();
            else if (shopname.Text == "")
                shopname.Focus();
            else if (shoptitle.Text == "")
                shoptitle.Focus();
            else if (contact1.Text == "")
                contact1.Focus();
            else if (address.Text == "")
                address.Focus();

            if (picturebox.Image == null)
                MessageBox.Show("Please select the image for the shop! Thank you");

            if (chk > 0)
            {
                try
                {
                    AdminAccount_uc uc = new AdminAccount_uc();
                    background.Controls.Clear();
                    background.Controls.Add(uc);
                    uc.Dock = DockStyle.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show("Error! You cant register your shop please contact FIDX Acadmey. Thank you");
        }

        private void ShopRegistrationForm_Load(object sender, EventArgs e)
        {
            finish_btn.Hide();
            registerbtn.Show();
        }

        private void contact1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '-'))
            {
                e.Handled = true;
            }
        }
    }
}
