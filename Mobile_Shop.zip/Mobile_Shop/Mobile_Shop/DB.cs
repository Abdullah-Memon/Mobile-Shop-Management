﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Mobile_Shop
{
    public class DB
    {
        public static SqlConnection con = null;
        public static void connect()
        {
            con = new SqlConnection("server= 127.0.0.1; database = MSMS; integrated security = true;");
        }
    }
}
