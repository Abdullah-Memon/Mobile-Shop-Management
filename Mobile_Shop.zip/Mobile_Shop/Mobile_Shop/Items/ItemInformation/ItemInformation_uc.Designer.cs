﻿namespace Mobile_Shop.ItemInformation
{
    partial class ItemInformation_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.addbrand = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Brandbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.brandGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Brand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BrandID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updatebrand = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteBrand = new System.Windows.Forms.DataGridViewButtonColumn();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.addcompany = new Guna.UI2.WinForms.Guna2GradientButton();
            this.CompanyBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.companyGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompanyID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updatecompany = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteCompany = new System.Windows.Forms.DataGridViewButtonColumn();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.addcatagory = new Guna.UI2.WinForms.Guna2GradientButton();
            this.CatagoryBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.catagoryGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatagoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updatecatagory = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteCatagory = new System.Windows.Forms.DataGridViewButtonColumn();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.brandGridView)).BeginInit();
            this.guna2GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.companyGridView)).BeginInit();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.catagoryGridView)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.BorderRadius = 10;
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.Controls.Add(this.addbrand);
            this.guna2GroupBox1.Controls.Add(this.Brandbox);
            this.guna2GroupBox1.Controls.Add(this.brandGridView);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(3, 3);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(343, 492);
            this.guna2GroupBox1.TabIndex = 0;
            this.guna2GroupBox1.Text = "Brands Information";
            this.guna2GroupBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(10, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "Brand Already Exist";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 10F);
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(10, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Brand Added !";
            // 
            // addbrand
            // 
            this.addbrand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addbrand.BackColor = System.Drawing.Color.Transparent;
            this.addbrand.BorderColor = System.Drawing.Color.White;
            this.addbrand.BorderRadius = 10;
            this.addbrand.BorderThickness = 2;
            this.addbrand.CheckedState.Parent = this.addbrand;
            this.addbrand.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addbrand.CustomImages.Parent = this.addbrand;
            this.addbrand.FillColor = System.Drawing.Color.Indigo;
            this.addbrand.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.addbrand.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addbrand.ForeColor = System.Drawing.Color.White;
            this.addbrand.HoverState.Parent = this.addbrand;
            this.addbrand.Location = new System.Drawing.Point(219, 115);
            this.addbrand.Name = "addbrand";
            this.addbrand.ShadowDecoration.Parent = this.addbrand;
            this.addbrand.Size = new System.Drawing.Size(116, 45);
            this.addbrand.TabIndex = 14;
            this.addbrand.Text = "Save";
            this.addbrand.Click += new System.EventHandler(this.addbrand_Click);
            // 
            // Brandbox
            // 
            this.Brandbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Brandbox.BorderRadius = 10;
            this.Brandbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Brandbox.DefaultText = "";
            this.Brandbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Brandbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Brandbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.DisabledState.Parent = this.Brandbox;
            this.Brandbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Brandbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.FocusedState.Parent = this.Brandbox;
            this.Brandbox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Brandbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.HoverState.Parent = this.Brandbox;
            this.Brandbox.Location = new System.Drawing.Point(13, 48);
            this.Brandbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Brandbox.Name = "Brandbox";
            this.Brandbox.PasswordChar = '\0';
            this.Brandbox.PlaceholderText = "";
            this.Brandbox.SelectedText = "";
            this.Brandbox.ShadowDecoration.Parent = this.Brandbox;
            this.Brandbox.Size = new System.Drawing.Size(322, 50);
            this.Brandbox.TabIndex = 1;
            this.Brandbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // brandGridView
            // 
            this.brandGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.brandGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.brandGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.brandGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.brandGridView.BackgroundColor = System.Drawing.Color.White;
            this.brandGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.brandGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.brandGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.brandGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.brandGridView.ColumnHeadersHeight = 25;
            this.brandGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Brand,
            this.BrandID,
            this.updatebrand,
            this.DeleteBrand});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.brandGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.brandGridView.EnableHeadersVisualStyles = false;
            this.brandGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.brandGridView.Location = new System.Drawing.Point(13, 171);
            this.brandGridView.Name = "brandGridView";
            this.brandGridView.RowHeadersVisible = false;
            this.brandGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.792453F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brandGridView.RowTemplate.Height = 30;
            this.brandGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.brandGridView.Size = new System.Drawing.Size(323, 306);
            this.brandGridView.TabIndex = 0;
            this.brandGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.brandGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.brandGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.brandGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.brandGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.brandGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.brandGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.brandGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.brandGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.brandGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.brandGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.brandGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.brandGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.brandGridView.ThemeStyle.HeaderStyle.Height = 25;
            this.brandGridView.ThemeStyle.ReadOnly = false;
            this.brandGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.brandGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.brandGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.brandGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.brandGridView.ThemeStyle.RowsStyle.Height = 30;
            this.brandGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.brandGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.brandGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.brandGridView_CellContentClick);
            // 
            // Brand
            // 
            this.Brand.DataPropertyName = "B_Name";
            this.Brand.FillWeight = 131.7479F;
            this.Brand.HeaderText = "Brands";
            this.Brand.Name = "Brand";
            // 
            // BrandID
            // 
            this.BrandID.DataPropertyName = "BID";
            this.BrandID.HeaderText = "BrandID";
            this.BrandID.Name = "BrandID";
            this.BrandID.Visible = false;
            // 
            // updatebrand
            // 
            this.updatebrand.FillWeight = 63.45178F;
            this.updatebrand.HeaderText = "Updates";
            this.updatebrand.Name = "updatebrand";
            this.updatebrand.Text = "update";
            this.updatebrand.UseColumnTextForButtonValue = true;
            // 
            // DeleteBrand
            // 
            this.DeleteBrand.FillWeight = 54.80032F;
            this.DeleteBrand.HeaderText = "Delete";
            this.DeleteBrand.Name = "DeleteBrand";
            this.DeleteBrand.Text = "Delete";
            this.DeleteBrand.UseColumnTextForButtonValue = true;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.BorderRadius = 10;
            this.guna2GroupBox2.Controls.Add(this.label4);
            this.guna2GroupBox2.Controls.Add(this.label3);
            this.guna2GroupBox2.Controls.Add(this.addcompany);
            this.guna2GroupBox2.Controls.Add(this.CompanyBox);
            this.guna2GroupBox2.Controls.Add(this.companyGridView);
            this.guna2GroupBox2.CustomBorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox2.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox2.Location = new System.Drawing.Point(352, 3);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(349, 492);
            this.guna2GroupBox2.TabIndex = 1;
            this.guna2GroupBox2.Text = "Company\'s Information";
            this.guna2GroupBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(12, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "Company Already Exist";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(12, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "Company Added !";
            // 
            // addcompany
            // 
            this.addcompany.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addcompany.BackColor = System.Drawing.Color.Transparent;
            this.addcompany.BorderColor = System.Drawing.Color.White;
            this.addcompany.BorderRadius = 10;
            this.addcompany.BorderThickness = 2;
            this.addcompany.CheckedState.Parent = this.addcompany;
            this.addcompany.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addcompany.CustomImages.Parent = this.addcompany;
            this.addcompany.FillColor = System.Drawing.Color.Indigo;
            this.addcompany.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.addcompany.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addcompany.ForeColor = System.Drawing.Color.White;
            this.addcompany.HoverState.Parent = this.addcompany;
            this.addcompany.Location = new System.Drawing.Point(218, 115);
            this.addcompany.Name = "addcompany";
            this.addcompany.ShadowDecoration.Parent = this.addcompany;
            this.addcompany.Size = new System.Drawing.Size(116, 45);
            this.addcompany.TabIndex = 14;
            this.addcompany.Text = "Save";
            this.addcompany.Click += new System.EventHandler(this.addcompany_Click);
            // 
            // CompanyBox
            // 
            this.CompanyBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CompanyBox.BorderRadius = 10;
            this.CompanyBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CompanyBox.DefaultText = "";
            this.CompanyBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.CompanyBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.CompanyBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CompanyBox.DisabledState.Parent = this.CompanyBox;
            this.CompanyBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CompanyBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.CompanyBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CompanyBox.FocusedState.Parent = this.CompanyBox;
            this.CompanyBox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CompanyBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CompanyBox.HoverState.Parent = this.CompanyBox;
            this.CompanyBox.Location = new System.Drawing.Point(15, 48);
            this.CompanyBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CompanyBox.Name = "CompanyBox";
            this.CompanyBox.PasswordChar = '\0';
            this.CompanyBox.PlaceholderText = "";
            this.CompanyBox.SelectedText = "";
            this.CompanyBox.ShadowDecoration.Parent = this.CompanyBox;
            this.CompanyBox.Size = new System.Drawing.Size(319, 50);
            this.CompanyBox.TabIndex = 1;
            this.CompanyBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // companyGridView
            // 
            this.companyGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.companyGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.companyGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.companyGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.companyGridView.BackgroundColor = System.Drawing.Color.White;
            this.companyGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.companyGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.companyGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.companyGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.companyGridView.ColumnHeadersHeight = 25;
            this.companyGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.company,
            this.CompanyID,
            this.updatecompany,
            this.DeleteCompany});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.companyGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.companyGridView.EnableHeadersVisualStyles = false;
            this.companyGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.companyGridView.Location = new System.Drawing.Point(15, 171);
            this.companyGridView.Name = "companyGridView";
            this.companyGridView.RowHeadersVisible = false;
            this.companyGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.792453F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyGridView.RowTemplate.Height = 30;
            this.companyGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.companyGridView.Size = new System.Drawing.Size(319, 306);
            this.companyGridView.TabIndex = 0;
            this.companyGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.companyGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.companyGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.companyGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.companyGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.companyGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.companyGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.companyGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.companyGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.companyGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.companyGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.companyGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.companyGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.companyGridView.ThemeStyle.HeaderStyle.Height = 25;
            this.companyGridView.ThemeStyle.ReadOnly = false;
            this.companyGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.companyGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.companyGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.companyGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.companyGridView.ThemeStyle.RowsStyle.Height = 30;
            this.companyGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.companyGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.companyGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.companyGridView_CellContentClick);
            // 
            // company
            // 
            this.company.DataPropertyName = "COM_Name";
            this.company.FillWeight = 128.1389F;
            this.company.HeaderText = "Company";
            this.company.Name = "company";
            // 
            // CompanyID
            // 
            this.CompanyID.DataPropertyName = "COMID";
            this.CompanyID.HeaderText = "CompanyID";
            this.CompanyID.Name = "CompanyID";
            this.CompanyID.Visible = false;
            // 
            // updatecompany
            // 
            this.updatecompany.FillWeight = 63.45178F;
            this.updatecompany.HeaderText = "Updates";
            this.updatecompany.Name = "updatecompany";
            this.updatecompany.Text = "Update";
            this.updatecompany.UseColumnTextForButtonValue = true;
            // 
            // DeleteCompany
            // 
            this.DeleteCompany.FillWeight = 58.40936F;
            this.DeleteCompany.HeaderText = "Delete";
            this.DeleteCompany.Name = "DeleteCompany";
            this.DeleteCompany.Text = "Delete";
            this.DeleteCompany.UseColumnTextForButtonValue = true;
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.BorderRadius = 10;
            this.guna2GroupBox3.Controls.Add(this.label6);
            this.guna2GroupBox3.Controls.Add(this.label5);
            this.guna2GroupBox3.Controls.Add(this.addcatagory);
            this.guna2GroupBox3.Controls.Add(this.CatagoryBox);
            this.guna2GroupBox3.Controls.Add(this.catagoryGridView);
            this.guna2GroupBox3.CustomBorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox3.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox3.Location = new System.Drawing.Point(707, 3);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(344, 492);
            this.guna2GroupBox3.TabIndex = 1;
            this.guna2GroupBox3.Text = "Catagorires";
            this.guna2GroupBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial", 10F);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(10, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "Catagory Already Exist";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial", 10F);
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(10, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "Catagory Added !";
            // 
            // addcatagory
            // 
            this.addcatagory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addcatagory.BackColor = System.Drawing.Color.Transparent;
            this.addcatagory.BorderColor = System.Drawing.Color.White;
            this.addcatagory.BorderRadius = 10;
            this.addcatagory.BorderThickness = 2;
            this.addcatagory.CheckedState.Parent = this.addcatagory;
            this.addcatagory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addcatagory.CustomImages.Parent = this.addcatagory;
            this.addcatagory.FillColor = System.Drawing.Color.Indigo;
            this.addcatagory.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.addcatagory.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addcatagory.ForeColor = System.Drawing.Color.White;
            this.addcatagory.HoverState.Parent = this.addcatagory;
            this.addcatagory.Location = new System.Drawing.Point(220, 115);
            this.addcatagory.Name = "addcatagory";
            this.addcatagory.ShadowDecoration.Parent = this.addcatagory;
            this.addcatagory.Size = new System.Drawing.Size(116, 45);
            this.addcatagory.TabIndex = 14;
            this.addcatagory.Text = "Save";
            this.addcatagory.Click += new System.EventHandler(this.addcatagory_Click);
            // 
            // CatagoryBox
            // 
            this.CatagoryBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CatagoryBox.BorderRadius = 10;
            this.CatagoryBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CatagoryBox.DefaultText = "";
            this.CatagoryBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.CatagoryBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.CatagoryBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CatagoryBox.DisabledState.Parent = this.CatagoryBox;
            this.CatagoryBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CatagoryBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.CatagoryBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CatagoryBox.FocusedState.Parent = this.CatagoryBox;
            this.CatagoryBox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CatagoryBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CatagoryBox.HoverState.Parent = this.CatagoryBox;
            this.CatagoryBox.Location = new System.Drawing.Point(13, 48);
            this.CatagoryBox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.CatagoryBox.Name = "CatagoryBox";
            this.CatagoryBox.PasswordChar = '\0';
            this.CatagoryBox.PlaceholderText = "";
            this.CatagoryBox.SelectedText = "";
            this.CatagoryBox.ShadowDecoration.Parent = this.CatagoryBox;
            this.CatagoryBox.Size = new System.Drawing.Size(323, 50);
            this.CatagoryBox.TabIndex = 1;
            this.CatagoryBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // catagoryGridView
            // 
            this.catagoryGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.catagoryGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.catagoryGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.catagoryGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.catagoryGridView.BackgroundColor = System.Drawing.Color.White;
            this.catagoryGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.catagoryGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.catagoryGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.catagoryGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.catagoryGridView.ColumnHeadersHeight = 25;
            this.catagoryGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.catagory,
            this.CatagoryID,
            this.updatecatagory,
            this.DeleteCatagory});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.catagoryGridView.DefaultCellStyle = dataGridViewCellStyle9;
            this.catagoryGridView.EnableHeadersVisualStyles = false;
            this.catagoryGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.catagoryGridView.Location = new System.Drawing.Point(12, 171);
            this.catagoryGridView.Name = "catagoryGridView";
            this.catagoryGridView.RowHeadersVisible = false;
            this.catagoryGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.792453F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catagoryGridView.RowTemplate.Height = 30;
            this.catagoryGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.catagoryGridView.Size = new System.Drawing.Size(324, 306);
            this.catagoryGridView.TabIndex = 0;
            this.catagoryGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.catagoryGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.catagoryGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.catagoryGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.catagoryGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.catagoryGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.catagoryGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.catagoryGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.catagoryGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.catagoryGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.catagoryGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.catagoryGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.catagoryGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.catagoryGridView.ThemeStyle.HeaderStyle.Height = 25;
            this.catagoryGridView.ThemeStyle.ReadOnly = false;
            this.catagoryGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.catagoryGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.catagoryGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.catagoryGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.catagoryGridView.ThemeStyle.RowsStyle.Height = 30;
            this.catagoryGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.catagoryGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.catagoryGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.catagoryGridView_CellContentClick);
            // 
            // catagory
            // 
            this.catagory.DataPropertyName = "C_Name";
            this.catagory.FillWeight = 128.1389F;
            this.catagory.HeaderText = "Catagory";
            this.catagory.Name = "catagory";
            // 
            // CatagoryID
            // 
            this.CatagoryID.DataPropertyName = "CID";
            this.CatagoryID.HeaderText = "CatagoryID";
            this.CatagoryID.Name = "CatagoryID";
            this.CatagoryID.Visible = false;
            // 
            // updatecatagory
            // 
            this.updatecatagory.FillWeight = 63.45178F;
            this.updatecatagory.HeaderText = "Updates";
            this.updatecatagory.Name = "updatecatagory";
            this.updatecatagory.Text = "Update";
            this.updatecatagory.UseColumnTextForButtonValue = true;
            // 
            // DeleteCatagory
            // 
            this.DeleteCatagory.FillWeight = 58.40936F;
            this.DeleteCatagory.HeaderText = "Delete";
            this.DeleteCatagory.Name = "DeleteCatagory";
            this.DeleteCatagory.Text = "Delete";
            this.DeleteCatagory.UseColumnTextForButtonValue = true;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this.brandGridView;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 10;
            this.guna2Elipse2.TargetControl = this.catagoryGridView;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.BorderRadius = 10;
            this.guna2Elipse3.TargetControl = this.companyGridView;
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(951, 3);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton1.TabIndex = 20;
            this.guna2CircleButton1.Text = "♻️";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(3, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(397, 31);
            this.label7.TabIndex = 21;
            this.label7.Text = "Items Dealing Informations";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.11445F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.77111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.11445F));
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox3, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 56);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1054, 498);
            this.tableLayoutPanel1.TabIndex = 24;
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.FillColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.ForeColor = System.Drawing.Color.Indigo;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(1007, 3);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 23;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // ItemInformation_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.Backbtn);
            this.Controls.Add(this.guna2CircleButton1);
            this.Name = "ItemInformation_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ItemInformation_uc_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.brandGridView)).EndInit();
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.companyGridView)).EndInit();
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.catagoryGridView)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2DataGridView brandGridView;
        private Guna.UI2.WinForms.Guna2TextBox Brandbox;
        private Guna.UI2.WinForms.Guna2TextBox CompanyBox;
        private Guna.UI2.WinForms.Guna2TextBox CatagoryBox;
        private Guna.UI2.WinForms.Guna2GradientButton addbrand;
        private Guna.UI2.WinForms.Guna2GradientButton addcompany;
        private Guna.UI2.WinForms.Guna2GradientButton addcatagory;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2DataGridView companyGridView;
        private Guna.UI2.WinForms.Guna2DataGridView catagoryGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Brand;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandID;
        private System.Windows.Forms.DataGridViewButtonColumn updatebrand;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteBrand;
        private System.Windows.Forms.DataGridViewTextBoxColumn company;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompanyID;
        private System.Windows.Forms.DataGridViewButtonColumn updatecompany;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatagoryID;
        private System.Windows.Forms.DataGridViewButtonColumn updatecatagory;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCatagory;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}
