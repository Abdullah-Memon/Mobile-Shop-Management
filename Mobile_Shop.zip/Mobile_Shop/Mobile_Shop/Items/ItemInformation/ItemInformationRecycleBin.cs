﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.ItemInformation
{
    public partial class ItemInformationRecycleBin : UserControl
    {
        public ItemInformationRecycleBin()
        {
            InitializeComponent();
        }

        SqlCommand cmd;
        
        void getdeleteddata()
        {
            DataTable catagorydata, companydata, branddata;

            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                // retriving deleted Catagory data
                catagorydata = new DataTable();
                cmd = new SqlCommand("CatagoryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                catagorydata.Load(cmd.ExecuteReader());

                //retriving deleted Company data
                companydata = new DataTable();
                cmd = new SqlCommand("CompanyDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                companydata.Load(cmd.ExecuteReader());

                //retriving deleted Brands data
                branddata = new DataTable();
                cmd = new SqlCommand("BrandDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                branddata.Load(cmd.ExecuteReader());

                DB.con.Close();

                // setting deleted data to datagrid views
                DeletedCatagoryGridView.DataSource = catagorydata;
                DeletedCompanyGridView.DataSource = companydata;
                DeletedBrandGridView.DataSource = branddata;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading the data Please try again!" + ex.ToString(), "ERROR", MessageBoxButtons.OK);
            }
        }
        private void DeletedBrandGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // comprasing coding limite (using condition)
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
            {
                //Restore button from gridview coding
                if (e.ColumnIndex == 0)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("UpdateBrand", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", DeletedBrandGridView.Rows[e.RowIndex].Cells["BrandID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@name", DeletedBrandGridView.Rows[e.RowIndex].Cells["Brand"].Value));
                        cmd.Parameters.Add(new SqlParameter("@status", 0));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating the selected Brand Please try again!" + ex.ToString(), "ERROR");
                    }

                }
                //Delete button from girdview coding
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure? You want to Permanantly delete selected Brand", "Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        if (DB.con.State == ConnectionState.Closed)
                        {
                            DB.con.Open();
                        }
                        try
                        {
                            cmd = new SqlCommand("RemoveBrand", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", DeletedBrandGridView.Rows[e.RowIndex].Cells["BrandID"].Value));
                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting selected Brand Please try again" + ex.ToString(), "Error", MessageBoxButtons.OK);
                        }
                    }
                }
                // refreshing all deleted data
                getdeleteddata();
            }
        }

        private void contentPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ItemInformationRecycleBin_Load(object sender, EventArgs e)
        {
            getdeleteddata();
        }

        private void DeletedCompanyGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // comprasing coding limite (using condition)
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
            {
                //Restore button from gridview coding
                if (e.ColumnIndex == 0)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("UpdateCompany", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", DeletedCompanyGridView.Rows[e.RowIndex].Cells["CompanyID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@name", DeletedCompanyGridView.Rows[e.RowIndex].Cells["Company"].Value));
                        cmd.Parameters.Add(new SqlParameter("@status", 0));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating the selected Brand Please try again!" + ex.ToString(), "ERROR");
                    }

                }
                //Delete button from girdview coding
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure? You want to Permanantly delete selected Company", "Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        if (DB.con.State == ConnectionState.Closed)
                        {
                            DB.con.Open();
                        }
                        try
                        {
                            cmd = new SqlCommand("RemoveCompany", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", DeletedCompanyGridView.Rows[e.RowIndex].Cells["CompanyID"].Value));
                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting selected Brand Please try again" + ex.ToString(), "Error", MessageBoxButtons.OK);
                        }
                    }
                }
                // refreshing all deleted data
                getdeleteddata();
            }
        }

        private void DeletedCatagoryGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // comprasing coding limite (using condition)
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
            {
                //Restore button from gridview coding
                if (e.ColumnIndex == 0)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("UpdateCatagory", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", DeletedCatagoryGridView.Rows[e.RowIndex].Cells["CatagoryID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@name", DeletedCatagoryGridView.Rows[e.RowIndex].Cells["Catagory"].Value));
                        cmd.Parameters.Add(new SqlParameter("@status", 0));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating the selected Brand Please try again!" + ex.ToString(), "ERROR");
                    }
                    // refreshing all deleted data
                    getdeleteddata();
                }
                //Delete button from girdview coding
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure? You want to Permanantly delete selected Catagory", "Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        if (DB.con.State == ConnectionState.Closed)
                        {
                            DB.con.Open();
                        }
                        try
                        {
                            cmd = new SqlCommand("RemoveCatagory", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", DeletedCatagoryGridView.Rows[e.RowIndex].Cells["CatagoryID"].Value));
                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting selected Brand Please try again" + ex.ToString(), "Error", MessageBoxButtons.OK);
                        }
                        // refreshing all deleted data
                        getdeleteddata();
                    }
                }
                
            }
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(Items.ItemDashboard_uc.ii);
        }

        private void guna2GroupBox3_Click(object sender, EventArgs e)
        {

        }
    }
}
