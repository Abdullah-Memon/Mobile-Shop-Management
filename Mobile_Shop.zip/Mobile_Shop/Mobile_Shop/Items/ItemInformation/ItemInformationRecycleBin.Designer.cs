﻿namespace Mobile_Shop.ItemInformation
{
    partial class ItemInformationRecycleBin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.DeletedBrandGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Brand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BrandID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.restorebrand = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteBrand = new System.Windows.Forms.DataGridViewButtonColumn();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.DeletedCatagoryGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatagoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.restorecatagory = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteCatagory = new System.Windows.Forms.DataGridViewButtonColumn();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.DeletedCompanyGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompanyID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.restorecompany = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteCompany = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletedBrandGridView)).BeginInit();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletedCatagoryGridView)).BeginInit();
            this.guna2GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletedCompanyGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.19249F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.61502F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.19249F));
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox2, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 56);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1054, 495);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.BorderRadius = 10;
            this.guna2GroupBox1.Controls.Add(this.DeletedBrandGridView);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(3, 3);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(343, 489);
            this.guna2GroupBox1.TabIndex = 0;
            this.guna2GroupBox1.Text = "Deleted Brands";
            this.guna2GroupBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DeletedBrandGridView
            // 
            this.DeletedBrandGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedBrandGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DeletedBrandGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DeletedBrandGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeletedBrandGridView.BackgroundColor = System.Drawing.Color.White;
            this.DeletedBrandGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DeletedBrandGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedBrandGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DeletedBrandGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.DeletedBrandGridView.ColumnHeadersHeight = 25;
            this.DeletedBrandGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Brand,
            this.BrandID,
            this.restorebrand,
            this.DeleteBrand});
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DeletedBrandGridView.DefaultCellStyle = dataGridViewCellStyle12;
            this.DeletedBrandGridView.EnableHeadersVisualStyles = false;
            this.DeletedBrandGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedBrandGridView.Location = new System.Drawing.Point(7, 45);
            this.DeletedBrandGridView.Name = "DeletedBrandGridView";
            this.DeletedBrandGridView.RowHeadersVisible = false;
            this.DeletedBrandGridView.RowTemplate.Height = 30;
            this.DeletedBrandGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DeletedBrandGridView.Size = new System.Drawing.Size(329, 439);
            this.DeletedBrandGridView.TabIndex = 0;
            this.DeletedBrandGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.DeletedBrandGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedBrandGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DeletedBrandGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DeletedBrandGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DeletedBrandGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DeletedBrandGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DeletedBrandGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedBrandGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.DeletedBrandGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DeletedBrandGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.DeletedBrandGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedBrandGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DeletedBrandGridView.ThemeStyle.HeaderStyle.Height = 25;
            this.DeletedBrandGridView.ThemeStyle.ReadOnly = false;
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.Height = 30;
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.DeletedBrandGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DeletedBrandGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DeletedBrandGridView_CellContentClick);
            // 
            // Brand
            // 
            this.Brand.DataPropertyName = "B_Name";
            this.Brand.FillWeight = 131.7479F;
            this.Brand.HeaderText = "Brands";
            this.Brand.Name = "Brand";
            // 
            // BrandID
            // 
            this.BrandID.DataPropertyName = "BID";
            this.BrandID.HeaderText = "BrandID";
            this.BrandID.Name = "BrandID";
            this.BrandID.Visible = false;
            // 
            // restorebrand
            // 
            this.restorebrand.FillWeight = 63.45178F;
            this.restorebrand.HeaderText = "Restore";
            this.restorebrand.Name = "restorebrand";
            this.restorebrand.Text = "Restore";
            this.restorebrand.UseColumnTextForButtonValue = true;
            // 
            // DeleteBrand
            // 
            this.DeleteBrand.FillWeight = 54.80032F;
            this.DeleteBrand.HeaderText = "Delete";
            this.DeleteBrand.Name = "DeleteBrand";
            this.DeleteBrand.Text = "Delete";
            this.DeleteBrand.UseColumnTextForButtonValue = true;
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.BorderRadius = 10;
            this.guna2GroupBox3.Controls.Add(this.DeletedCatagoryGridView);
            this.guna2GroupBox3.CustomBorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox3.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox3.Location = new System.Drawing.Point(352, 3);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(348, 489);
            this.guna2GroupBox3.TabIndex = 1;
            this.guna2GroupBox3.Text = "Deleted Catagorires";
            this.guna2GroupBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2GroupBox3.Click += new System.EventHandler(this.guna2GroupBox3_Click);
            // 
            // DeletedCatagoryGridView
            // 
            this.DeletedCatagoryGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedCatagoryGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.DeletedCatagoryGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DeletedCatagoryGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeletedCatagoryGridView.BackgroundColor = System.Drawing.Color.White;
            this.DeletedCatagoryGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DeletedCatagoryGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedCatagoryGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DeletedCatagoryGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.DeletedCatagoryGridView.ColumnHeadersHeight = 25;
            this.DeletedCatagoryGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.catagory,
            this.CatagoryID,
            this.restorecatagory,
            this.DeleteCatagory});
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DeletedCatagoryGridView.DefaultCellStyle = dataGridViewCellStyle15;
            this.DeletedCatagoryGridView.EnableHeadersVisualStyles = false;
            this.DeletedCatagoryGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedCatagoryGridView.Location = new System.Drawing.Point(3, 45);
            this.DeletedCatagoryGridView.Name = "DeletedCatagoryGridView";
            this.DeletedCatagoryGridView.RowHeadersVisible = false;
            this.DeletedCatagoryGridView.RowTemplate.Height = 30;
            this.DeletedCatagoryGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DeletedCatagoryGridView.Size = new System.Drawing.Size(344, 439);
            this.DeletedCatagoryGridView.TabIndex = 0;
            this.DeletedCatagoryGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.DeletedCatagoryGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedCatagoryGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DeletedCatagoryGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DeletedCatagoryGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DeletedCatagoryGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DeletedCatagoryGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DeletedCatagoryGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedCatagoryGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.DeletedCatagoryGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DeletedCatagoryGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.DeletedCatagoryGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedCatagoryGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DeletedCatagoryGridView.ThemeStyle.HeaderStyle.Height = 25;
            this.DeletedCatagoryGridView.ThemeStyle.ReadOnly = false;
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.Height = 30;
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.DeletedCatagoryGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DeletedCatagoryGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DeletedCatagoryGridView_CellContentClick);
            // 
            // catagory
            // 
            this.catagory.DataPropertyName = "C_Name";
            this.catagory.FillWeight = 128.1389F;
            this.catagory.HeaderText = "Catagory";
            this.catagory.Name = "catagory";
            // 
            // CatagoryID
            // 
            this.CatagoryID.DataPropertyName = "CID";
            this.CatagoryID.HeaderText = "CatagoryID";
            this.CatagoryID.Name = "CatagoryID";
            this.CatagoryID.Visible = false;
            // 
            // restorecatagory
            // 
            this.restorecatagory.FillWeight = 63.45178F;
            this.restorecatagory.HeaderText = "Restore";
            this.restorecatagory.Name = "restorecatagory";
            this.restorecatagory.Text = "Restore";
            this.restorecatagory.UseColumnTextForButtonValue = true;
            // 
            // DeleteCatagory
            // 
            this.DeleteCatagory.FillWeight = 58.40936F;
            this.DeleteCatagory.HeaderText = "Delete";
            this.DeleteCatagory.Name = "DeleteCatagory";
            this.DeleteCatagory.Text = "Delete";
            this.DeleteCatagory.UseColumnTextForButtonValue = true;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.BorderRadius = 10;
            this.guna2GroupBox2.Controls.Add(this.DeletedCompanyGridView);
            this.guna2GroupBox2.CustomBorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox2.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox2.Location = new System.Drawing.Point(706, 3);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(345, 489);
            this.guna2GroupBox2.TabIndex = 1;
            this.guna2GroupBox2.Text = "Deleted Companies";
            this.guna2GroupBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DeletedCompanyGridView
            // 
            this.DeletedCompanyGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedCompanyGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.DeletedCompanyGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DeletedCompanyGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeletedCompanyGridView.BackgroundColor = System.Drawing.Color.White;
            this.DeletedCompanyGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DeletedCompanyGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedCompanyGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DeletedCompanyGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.DeletedCompanyGridView.ColumnHeadersHeight = 25;
            this.DeletedCompanyGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.company,
            this.CompanyID,
            this.restorecompany,
            this.DeleteCompany});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DeletedCompanyGridView.DefaultCellStyle = dataGridViewCellStyle18;
            this.DeletedCompanyGridView.EnableHeadersVisualStyles = false;
            this.DeletedCompanyGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedCompanyGridView.Location = new System.Drawing.Point(3, 45);
            this.DeletedCompanyGridView.Name = "DeletedCompanyGridView";
            this.DeletedCompanyGridView.RowHeadersVisible = false;
            this.DeletedCompanyGridView.RowTemplate.Height = 30;
            this.DeletedCompanyGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DeletedCompanyGridView.Size = new System.Drawing.Size(335, 439);
            this.DeletedCompanyGridView.TabIndex = 0;
            this.DeletedCompanyGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.DeletedCompanyGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedCompanyGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DeletedCompanyGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DeletedCompanyGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DeletedCompanyGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DeletedCompanyGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DeletedCompanyGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedCompanyGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.DeletedCompanyGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DeletedCompanyGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.DeletedCompanyGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedCompanyGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DeletedCompanyGridView.ThemeStyle.HeaderStyle.Height = 25;
            this.DeletedCompanyGridView.ThemeStyle.ReadOnly = false;
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Calligraphy", 12F);
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.Height = 30;
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.DeletedCompanyGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DeletedCompanyGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DeletedCompanyGridView_CellContentClick);
            // 
            // company
            // 
            this.company.DataPropertyName = "COM_Name";
            this.company.FillWeight = 128.1389F;
            this.company.HeaderText = "Company";
            this.company.Name = "company";
            // 
            // CompanyID
            // 
            this.CompanyID.DataPropertyName = "COMID";
            this.CompanyID.HeaderText = "CompanyID";
            this.CompanyID.Name = "CompanyID";
            this.CompanyID.Visible = false;
            // 
            // restorecompany
            // 
            this.restorecompany.FillWeight = 63.45178F;
            this.restorecompany.HeaderText = "Restore";
            this.restorecompany.Name = "restorecompany";
            this.restorecompany.Text = "Restore";
            this.restorecompany.UseColumnTextForButtonValue = true;
            // 
            // DeleteCompany
            // 
            this.DeleteCompany.FillWeight = 58.40936F;
            this.DeleteCompany.HeaderText = "Delete";
            this.DeleteCompany.Name = "DeleteCompany";
            this.DeleteCompany.Text = "Delete";
            this.DeleteCompany.UseColumnTextForButtonValue = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(3, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 31);
            this.label7.TabIndex = 21;
            this.label7.Text = "Recycle Bin";
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.FillColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.ForeColor = System.Drawing.Color.Indigo;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(1007, 3);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 20;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // ItemInformationRecycleBin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Backbtn);
            this.Name = "ItemInformationRecycleBin";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ItemInformationRecycleBin_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DeletedBrandGridView)).EndInit();
            this.guna2GroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DeletedCatagoryGridView)).EndInit();
            this.guna2GroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DeletedCompanyGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2DataGridView DeletedBrandGridView;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2DataGridView DeletedCompanyGridView;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2DataGridView DeletedCatagoryGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Brand;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandID;
        private System.Windows.Forms.DataGridViewButtonColumn restorebrand;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteBrand;
        private System.Windows.Forms.DataGridViewTextBoxColumn company;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompanyID;
        private System.Windows.Forms.DataGridViewButtonColumn restorecompany;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatagoryID;
        private System.Windows.Forms.DataGridViewButtonColumn restorecatagory;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCatagory;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}
