﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.ItemInformation
{
    public partial class ItemInformation_uc : UserControl
    {
        public ItemInformation_uc()
        {
            InitializeComponent();
        }
        // Screen To Load
        ItemInformationRecycleBin iirb;

        // global variables
        SqlCommand cmd;
        int chk=0;
        
        //getting all data from database
        private void getdata()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable catagoryDetail, companyDetail, brandDetail;

                // retriving Catagory data
                catagoryDetail = new DataTable();
                cmd = new SqlCommand("CatagoryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                catagoryDetail.Load(cmd.ExecuteReader());

                //retriving Company data
                companyDetail = new DataTable();
                cmd = new SqlCommand("CompanyDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                companyDetail.Load(cmd.ExecuteReader());

                //retriving Brands data
                brandDetail = new DataTable();
                cmd = new SqlCommand("BrandDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                brandDetail.Load(cmd.ExecuteReader());

                DB.con.Close();

                // setting data to datagrid views
                catagoryGridView.DataSource = catagoryDetail;
                companyGridView.DataSource = companyDetail;
                brandGridView.DataSource = brandDetail;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading the data Please try again!"+ ex.ToString(),"ERROR", MessageBoxButtons.OK);
            }
        }
        
        //Adding new data in Company
        private void addcompany_Click(object sender, EventArgs e)
        {
            if (CompanyBox.Text != string.Empty)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("AddCompany", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@newcompany", CompanyBox.Text));
                    chk = cmd.ExecuteNonQuery();

                    DB.con.Close();

                    // when data is already available (warning messages)
                    if (chk > 0)
                    {
                        label3.Show();
                        label4.Hide();
                    }
                    // when new data has been added
                    else
                    {
                        label3.Hide();
                        label4.Show();
                        // refreshing all Data
                        getdata();
                    }

                    // clearing text box
                    CompanyBox.Text = string.Empty;
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding new company Please try again!" + ex.ToString(), "ERROR", MessageBoxButtons.OK);
                }

                // refreshing all data
                getdata();
            }
            else
                CompanyBox.Focus();
        }
        
        // Adding new Catagory
        private void addcatagory_Click(object sender, EventArgs e)
        {
            if (CatagoryBox.Text != string.Empty)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("AddCatagory", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@newcatagory", CatagoryBox.Text));
                    chk = cmd.ExecuteNonQuery();

                    DB.con.Close();

                    // when data is already avaiable (warning messages)
                    if (chk > 0)
                    {
                        label6.Hide();
                        label5.Show();
                    }
                    else
                    {
                        label5.Hide();
                        label6.Show();
                    }
                    // clearing catagory text box
                    CatagoryBox.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding new catagory Please try again!" + ex.ToString(), "ERROR", MessageBoxButtons.OK);
                }

                // refreshing all data
                getdata();
            }
            else
                CatagoryBox.Focus();
        }

        //Brand grid view button codings
        private void brandGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // comprasing coding limite (using condition)
            if (e.ColumnIndex == 0 || e.ColumnIndex ==1)
            {
                //Update button from gridview coding
                if (e.ColumnIndex == 0)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("UpdateBrand", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", brandGridView.Rows[e.RowIndex].Cells["BrandID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@name", brandGridView.Rows[e.RowIndex].Cells["Brand"].Value));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating the selected Brand Please try again!" + ex.ToString(), "ERROR");
                    }
                    getdata();

                }
                //Delete button from girdview coding
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure? You want to delete selected Brand", "Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        if (DB.con.State == ConnectionState.Closed)
                        {
                            DB.con.Open();
                        }
                        try
                        {
                            cmd = new SqlCommand("RemoveBrand", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", brandGridView.Rows[e.RowIndex].Cells["BrandID"].Value));
                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting selected Brand Please try again" + ex.ToString(), "Error", MessageBoxButtons.OK);
                        }
                    }
                    // refreshing all data
                    getdata();
                }
            }
        }

        // Main load function coding
        private void ItemInformation_uc_Load(object sender, EventArgs e)
        {
            //getting all data
            getdata();
            //hiding brand messages
            label1.Hide();
            label2.Hide();
            // hiding company messages
            label3.Hide();
            label4.Hide();
            //hiding brand messages
            label5.Hide();
            label6.Hide();
            
        }

        //catagory Grid View Button Codings
        private void companyGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //comprasing Coding to implement only on Buttons (Using conditions)
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
            {
                //Update button coding in gridview
                if (e.ColumnIndex == 0)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("UpdateCompany", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", companyGridView.Rows[e.RowIndex].Cells["CompanyID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@name", companyGridView.Rows[e.RowIndex].Cells["company"].Value));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating the selected Company Please try again!" + ex.ToString(), "ERROR");
                    }
                }

                //delete button coding in gridview
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure? You want to delete selected Company", "Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        if (DB.con.State == ConnectionState.Closed)
                        {
                            DB.con.Open();
                        }
                        try
                        {
                            cmd = new SqlCommand("RemoveCompany", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", companyGridView.Rows[e.RowIndex].Cells["CompanyID"].Value));
                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting selected Company Please try again" + ex.ToString(), "Error", MessageBoxButtons.OK);
                        }
                    }
                }
                //refresing all data
                getdata();
            }
        }

        // Catagory Grid View Button Codings
        private void catagoryGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (catagoryGridView.Rows[e.RowIndex].Cells["CatagoryID"].Value.ToString() != "1")
            {
                //Comprasing Coding to implement only on Buttons (Using Condtions)
                if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
                {
                    // UPdate button coding in gridview
                    if (e.ColumnIndex == 0)
                    {
                        if (DB.con.State == ConnectionState.Closed)
                        {
                            DB.con.Open();
                        }
                        try
                        {
                            cmd = new SqlCommand("UpdateCatagory", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", catagoryGridView.Rows[e.RowIndex].Cells["CatagoryID"].Value));
                            cmd.Parameters.Add(new SqlParameter("@name", catagoryGridView.Rows[e.RowIndex].Cells["catagory"].Value));
                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while updating the selected Catagory Please try again!" + ex.ToString(), "ERROR");
                        }
                    }
                    //Delete button coding in gridview
                    if (e.ColumnIndex == 1)
                    {
                        if (MessageBox.Show("Are you sure? You want to delete selected Company", "Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            try
                            {
                                if (DB.con.State == ConnectionState.Closed)
                                    DB.con.Open();

                                cmd = new SqlCommand("RemoveCatagory", DB.con) { CommandType = CommandType.StoredProcedure };
                                cmd.Parameters.Add(new SqlParameter("@id", catagoryGridView.Rows[e.RowIndex].Cells["CatagoryID"].Value));
                                cmd.ExecuteNonQuery();
                                DB.con.Close();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error while deleting selected Company Please try again" + ex.ToString(), "Error", MessageBoxButtons.OK);
                            }
                        }
                    }
                }
            }
            // refreshing all data
            getdata();
            
        }

        // Adding new Brand coding
        private void addbrand_Click(object sender, EventArgs e)
        {
            if (Brandbox.Text != string.Empty)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("AddBrand", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@newbrand", Brandbox.Text));
                    chk = cmd.ExecuteNonQuery();
                    DB.con.Close();
                    // when data is already available 
                    if (chk > 0)
                    {
                        label2.Hide();
                        label1.Show();
                    }
                    else // when new data has been added
                    {
                        label1.Hide();
                        label2.Show();
                    }

                    Brandbox.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding new Brand Please try again!" + ex.ToString(), "ERROR", MessageBoxButtons.OK);
                }

                // refreshing all data
                getdata();
            }
            else
                Brandbox.Focus();
        }

        // Recycle Bin Button Coding
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if(iirb == null)
                iirb = new ItemInformationRecycleBin();

            LoginForm.LoginScreen.ms.addusercontrol(iirb);
        }

        // Back Button Coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.id);
        }
    }
}
