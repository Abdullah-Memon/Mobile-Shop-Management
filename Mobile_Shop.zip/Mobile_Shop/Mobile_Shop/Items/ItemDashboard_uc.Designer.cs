﻿namespace Mobile_Shop.Items
{
    partial class ItemDashboard_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.AddCatagorybtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.guna2GradientButton3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.AddCatagorybtn, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GradientButton1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GradientButton2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1060, 554);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // AddCatagorybtn
            // 
            this.AddCatagorybtn.BackColor = System.Drawing.Color.Transparent;
            this.AddCatagorybtn.BorderColor = System.Drawing.Color.Indigo;
            this.AddCatagorybtn.BorderRadius = 20;
            this.AddCatagorybtn.BorderThickness = 2;
            this.AddCatagorybtn.CheckedState.Parent = this.AddCatagorybtn;
            this.AddCatagorybtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddCatagorybtn.CustomImages.Parent = this.AddCatagorybtn;
            this.AddCatagorybtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddCatagorybtn.FillColor = System.Drawing.Color.Transparent;
            this.AddCatagorybtn.FillColor2 = System.Drawing.Color.Transparent;
            this.AddCatagorybtn.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.AddCatagorybtn.ForeColor = System.Drawing.Color.Indigo;
            this.AddCatagorybtn.HoverState.Parent = this.AddCatagorybtn;
            this.AddCatagorybtn.Location = new System.Drawing.Point(533, 3);
            this.AddCatagorybtn.Name = "AddCatagorybtn";
            this.AddCatagorybtn.ShadowDecoration.Parent = this.AddCatagorybtn;
            this.AddCatagorybtn.Size = new System.Drawing.Size(524, 271);
            this.AddCatagorybtn.TabIndex = 14;
            this.AddCatagorybtn.Text = "Add Catagory";
            this.AddCatagorybtn.Click += new System.EventHandler(this.AddCatagorybtn_Click);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.BorderRadius = 20;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(3, 3);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(524, 271);
            this.guna2GradientButton1.TabIndex = 14;
            this.guna2GradientButton1.Text = "Show Items";
            this.guna2GradientButton1.Click += new System.EventHandler(this.ShowItemsbtn_Click);
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.BorderRadius = 20;
            this.guna2GradientButton2.BorderThickness = 2;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(3, 280);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(524, 271);
            this.guna2GradientButton2.TabIndex = 14;
            this.guna2GradientButton2.Text = "Add Items";
            this.guna2GradientButton2.Click += new System.EventHandler(this.additembtn_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton3.BorderRadius = 10;
            this.guna2GradientButton3.BorderThickness = 2;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(533, 280);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(524, 271);
            this.guna2GradientButton3.TabIndex = 15;
            this.guna2GradientButton3.Text = "Generate Report";
            this.guna2GradientButton3.Click += new System.EventHandler(this.guna2GradientButton3_Click);
            // 
            // ItemDashboard_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ItemDashboard_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ItemDashboard_uc_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton AddCatagorybtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
    }
}
