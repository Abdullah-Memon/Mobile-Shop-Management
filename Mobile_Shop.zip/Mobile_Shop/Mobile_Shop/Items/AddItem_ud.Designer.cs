﻿namespace Mobile_Shop.Items
{
    partial class AddItem_ud
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.AddItemsDetailsBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.Additem = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.newitempic = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.catagorybox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.brandbox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.companybox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.barcodebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.itemnamebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.AllAddedItems = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.Barcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.catagory = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Company = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Brand = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.updateItems = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.AddItemsDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.newitempic)).BeginInit();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AllAddedItems)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.Controls.Add(this.AddItemsDetailsBox, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.ShowAddedItemsDetailBox, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1060, 554);
            this.tableLayoutPanel1.TabIndex = 21;
            // 
            // AddItemsDetailsBox
            // 
            this.AddItemsDetailsBox.BorderRadius = 10;
            this.AddItemsDetailsBox.Controls.Add(this.Additem);
            this.AddItemsDetailsBox.Controls.Add(this.guna2GradientButton1);
            this.AddItemsDetailsBox.Controls.Add(this.newitempic);
            this.AddItemsDetailsBox.Controls.Add(this.label8);
            this.AddItemsDetailsBox.Controls.Add(this.label3);
            this.AddItemsDetailsBox.Controls.Add(this.label2);
            this.AddItemsDetailsBox.Controls.Add(this.label5);
            this.AddItemsDetailsBox.Controls.Add(this.label6);
            this.AddItemsDetailsBox.Controls.Add(this.label4);
            this.AddItemsDetailsBox.Controls.Add(this.catagorybox);
            this.AddItemsDetailsBox.Controls.Add(this.brandbox);
            this.AddItemsDetailsBox.Controls.Add(this.companybox);
            this.AddItemsDetailsBox.Controls.Add(this.barcodebox);
            this.AddItemsDetailsBox.Controls.Add(this.itemnamebox);
            this.AddItemsDetailsBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AddItemsDetailsBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddItemsDetailsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddItemsDetailsBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AddItemsDetailsBox.Location = new System.Drawing.Point(3, 3);
            this.AddItemsDetailsBox.Name = "AddItemsDetailsBox";
            this.AddItemsDetailsBox.ShadowDecoration.Parent = this.AddItemsDetailsBox;
            this.AddItemsDetailsBox.Size = new System.Drawing.Size(259, 548);
            this.AddItemsDetailsBox.TabIndex = 2;
            // 
            // Additem
            // 
            this.Additem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Additem.BackColor = System.Drawing.Color.Transparent;
            this.Additem.BorderColor = System.Drawing.Color.White;
            this.Additem.BorderRadius = 10;
            this.Additem.BorderThickness = 2;
            this.Additem.CheckedState.Parent = this.Additem;
            this.Additem.CustomImages.Parent = this.Additem;
            this.Additem.FillColor = System.Drawing.Color.Indigo;
            this.Additem.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Additem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Additem.ForeColor = System.Drawing.Color.White;
            this.Additem.HoverState.Parent = this.Additem;
            this.Additem.Location = new System.Drawing.Point(77, 502);
            this.Additem.Name = "Additem";
            this.Additem.ShadowDecoration.Parent = this.Additem;
            this.Additem.Size = new System.Drawing.Size(106, 36);
            this.Additem.TabIndex = 15;
            this.Additem.Text = "ADD";
            this.Additem.Click += new System.EventHandler(this.Additem_Click);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(77, 153);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(106, 36);
            this.guna2GradientButton1.TabIndex = 15;
            this.guna2GradientButton1.Text = "Upload";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // newitempic
            // 
            this.newitempic.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.newitempic.BorderRadius = 10;
            this.newitempic.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newitempic.Location = new System.Drawing.Point(73, 32);
            this.newitempic.Name = "newitempic";
            this.newitempic.ShadowDecoration.Parent = this.newitempic;
            this.newitempic.Size = new System.Drawing.Size(115, 115);
            this.newitempic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.newitempic.TabIndex = 4;
            this.newitempic.TabStop = false;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(100, 192);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Barcode";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(94, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Item Name";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(92, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item Picture";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(108, 438);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Brand";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(99, 316);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Catagory";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(97, 377);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Company";
            // 
            // catagorybox
            // 
            this.catagorybox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.catagorybox.BackColor = System.Drawing.Color.Transparent;
            this.catagorybox.BorderRadius = 10;
            this.catagorybox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.catagorybox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.catagorybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.catagorybox.FocusedColor = System.Drawing.Color.Empty;
            this.catagorybox.FocusedState.Parent = this.catagorybox;
            this.catagorybox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.catagorybox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.catagorybox.FormattingEnabled = true;
            this.catagorybox.HoverState.Parent = this.catagorybox;
            this.catagorybox.ItemHeight = 30;
            this.catagorybox.ItemsAppearance.Parent = this.catagorybox;
            this.catagorybox.Location = new System.Drawing.Point(31, 338);
            this.catagorybox.Name = "catagorybox";
            this.catagorybox.ShadowDecoration.Parent = this.catagorybox;
            this.catagorybox.Size = new System.Drawing.Size(199, 36);
            this.catagorybox.TabIndex = 2;
            this.catagorybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // brandbox
            // 
            this.brandbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.brandbox.BackColor = System.Drawing.Color.Transparent;
            this.brandbox.BorderRadius = 10;
            this.brandbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.brandbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.brandbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.brandbox.FocusedColor = System.Drawing.Color.Empty;
            this.brandbox.FocusedState.Parent = this.brandbox;
            this.brandbox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.brandbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.brandbox.FormattingEnabled = true;
            this.brandbox.HoverState.Parent = this.brandbox;
            this.brandbox.ItemHeight = 30;
            this.brandbox.ItemsAppearance.Parent = this.brandbox;
            this.brandbox.Location = new System.Drawing.Point(31, 460);
            this.brandbox.Name = "brandbox";
            this.brandbox.ShadowDecoration.Parent = this.brandbox;
            this.brandbox.Size = new System.Drawing.Size(199, 36);
            this.brandbox.TabIndex = 2;
            this.brandbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // companybox
            // 
            this.companybox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.companybox.BackColor = System.Drawing.Color.Transparent;
            this.companybox.BorderRadius = 10;
            this.companybox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.companybox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.companybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.companybox.FocusedColor = System.Drawing.Color.Empty;
            this.companybox.FocusedState.Parent = this.companybox;
            this.companybox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.companybox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.companybox.FormattingEnabled = true;
            this.companybox.HoverState.Parent = this.companybox;
            this.companybox.ItemHeight = 30;
            this.companybox.ItemsAppearance.Parent = this.companybox;
            this.companybox.Location = new System.Drawing.Point(31, 399);
            this.companybox.Name = "companybox";
            this.companybox.ShadowDecoration.Parent = this.companybox;
            this.companybox.Size = new System.Drawing.Size(199, 36);
            this.companybox.TabIndex = 2;
            this.companybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // barcodebox
            // 
            this.barcodebox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.barcodebox.BorderRadius = 10;
            this.barcodebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.barcodebox.DefaultText = "";
            this.barcodebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.barcodebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.barcodebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.barcodebox.DisabledState.Parent = this.barcodebox;
            this.barcodebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.barcodebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.barcodebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.barcodebox.FocusedState.Parent = this.barcodebox;
            this.barcodebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.barcodebox.HoverState.Parent = this.barcodebox;
            this.barcodebox.Location = new System.Drawing.Point(31, 214);
            this.barcodebox.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.barcodebox.Name = "barcodebox";
            this.barcodebox.PasswordChar = '\0';
            this.barcodebox.PlaceholderText = "";
            this.barcodebox.SelectedText = "";
            this.barcodebox.ShadowDecoration.Parent = this.barcodebox;
            this.barcodebox.Size = new System.Drawing.Size(199, 36);
            this.barcodebox.TabIndex = 3;
            this.barcodebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.barcodebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.barcodebox_KeyPress);
            // 
            // itemnamebox
            // 
            this.itemnamebox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.itemnamebox.BorderRadius = 10;
            this.itemnamebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.itemnamebox.DefaultText = "";
            this.itemnamebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.itemnamebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.itemnamebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.itemnamebox.DisabledState.Parent = this.itemnamebox;
            this.itemnamebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.itemnamebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.itemnamebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.itemnamebox.FocusedState.Parent = this.itemnamebox;
            this.itemnamebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.itemnamebox.HoverState.Parent = this.itemnamebox;
            this.itemnamebox.Location = new System.Drawing.Point(31, 276);
            this.itemnamebox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.itemnamebox.Name = "itemnamebox";
            this.itemnamebox.PasswordChar = '\0';
            this.itemnamebox.PlaceholderText = "";
            this.itemnamebox.SelectedText = "";
            this.itemnamebox.ShadowDecoration.Parent = this.itemnamebox;
            this.itemnamebox.Size = new System.Drawing.Size(199, 36);
            this.itemnamebox.TabIndex = 3;
            this.itemnamebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.AllAddedItems);
            this.ShowAddedItemsDetailBox.Controls.Add(this.Backbtn);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label7);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label1);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(268, 3);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(789, 548);
            this.ShowAddedItemsDetailBox.TabIndex = 3;
            // 
            // AllAddedItems
            // 
            this.AllAddedItems.AllowUserToAddRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AllAddedItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.AllAddedItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AllAddedItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AllAddedItems.BackgroundColor = System.Drawing.Color.White;
            this.AllAddedItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AllAddedItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AllAddedItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AllAddedItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.AllAddedItems.ColumnHeadersHeight = 21;
            this.AllAddedItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemID,
            this.Picture,
            this.Barcode,
            this.catagory,
            this.ItemName,
            this.Company,
            this.Brand,
            this.updateItems});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AllAddedItems.DefaultCellStyle = dataGridViewCellStyle13;
            this.AllAddedItems.EnableHeadersVisualStyles = false;
            this.AllAddedItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AllAddedItems.Location = new System.Drawing.Point(18, 65);
            this.AllAddedItems.Name = "AllAddedItems";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AllAddedItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.AllAddedItems.RowHeadersVisible = false;
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            this.AllAddedItems.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.AllAddedItems.RowTemplate.Height = 40;
            this.AllAddedItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AllAddedItems.Size = new System.Drawing.Size(759, 463);
            this.AllAddedItems.TabIndex = 20;
            this.AllAddedItems.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.AllAddedItems.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AllAddedItems.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.AllAddedItems.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.AllAddedItems.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.AllAddedItems.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.AllAddedItems.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.AllAddedItems.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AllAddedItems.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.AllAddedItems.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AllAddedItems.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AllAddedItems.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.AllAddedItems.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.AllAddedItems.ThemeStyle.HeaderStyle.Height = 21;
            this.AllAddedItems.ThemeStyle.ReadOnly = false;
            this.AllAddedItems.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.AllAddedItems.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AllAddedItems.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AllAddedItems.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.AllAddedItems.ThemeStyle.RowsStyle.Height = 40;
            this.AllAddedItems.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.AllAddedItems.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.AllAddedItems.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AllAddedItems_CellContentClick);
            // 
            // ItemID
            // 
            this.ItemID.DataPropertyName = "IID";
            this.ItemID.HeaderText = "ItemID";
            this.ItemID.Name = "ItemID";
            this.ItemID.Visible = false;
            // 
            // Picture
            // 
            this.Picture.DataPropertyName = "Item_Picture";
            this.Picture.FillWeight = 25.66341F;
            this.Picture.HeaderText = "Picture";
            this.Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Picture.Name = "Picture";
            // 
            // Barcode
            // 
            this.Barcode.DataPropertyName = "Barcode";
            this.Barcode.FillWeight = 88.55515F;
            this.Barcode.HeaderText = "Barcode";
            this.Barcode.Name = "Barcode";
            // 
            // catagory
            // 
            this.catagory.DataPropertyName = "CID";
            this.catagory.FillWeight = 88.55515F;
            this.catagory.HeaderText = "Catagory";
            this.catagory.Name = "catagory";
            this.catagory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.catagory.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // ItemName
            // 
            this.ItemName.DataPropertyName = "Item_Name";
            this.ItemName.FillWeight = 99.11879F;
            this.ItemName.HeaderText = "Item Name";
            this.ItemName.Name = "ItemName";
            // 
            // Company
            // 
            this.Company.DataPropertyName = "COMID";
            this.Company.FillWeight = 88.55515F;
            this.Company.HeaderText = "Company";
            this.Company.Name = "Company";
            this.Company.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Company.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Brand
            // 
            this.Brand.DataPropertyName = "BID";
            this.Brand.FillWeight = 88.55515F;
            this.Brand.HeaderText = "Brand";
            this.Brand.Name = "Brand";
            this.Brand.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Brand.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // updateItems
            // 
            this.updateItems.FillWeight = 50F;
            this.updateItems.HeaderText = "Update";
            this.updateItems.Name = "updateItems";
            this.updateItems.Text = "Update";
            this.updateItems.UseColumnTextForButtonValue = true;
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(727, 9);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(14, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "Search";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(341, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 22);
            this.label1.TabIndex = 17;
            this.label1.Text = "Added Items";
            // 
            // AddItem_ud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "AddItem_ud";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.AddItem_ud_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.AddItemsDetailsBox.ResumeLayout(false);
            this.AddItemsDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.newitempic)).EndInit();
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AllAddedItems)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2DataGridView AllAddedItems;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GroupBox AddItemsDetailsBox;
        private Guna.UI2.WinForms.Guna2GradientButton Additem;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2PictureBox newitempic;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2ComboBox catagorybox;
        private Guna.UI2.WinForms.Guna2ComboBox brandbox;
        private Guna.UI2.WinForms.Guna2ComboBox companybox;
        private Guna.UI2.WinForms.Guna2TextBox barcodebox;
        private Guna.UI2.WinForms.Guna2TextBox itemnamebox;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemID;
        private System.Windows.Forms.DataGridViewImageColumn Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn Barcode;
        private System.Windows.Forms.DataGridViewComboBoxColumn catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewComboBoxColumn Company;
        private System.Windows.Forms.DataGridViewComboBoxColumn Brand;
        private System.Windows.Forms.DataGridViewButtonColumn updateItems;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}
