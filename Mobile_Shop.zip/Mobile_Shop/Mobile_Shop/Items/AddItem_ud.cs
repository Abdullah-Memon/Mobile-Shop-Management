﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Mobile_Shop.Items
{
    public partial class AddItem_ud : UserControl
    {
        public AddItem_ud()
        {
            InitializeComponent();
        }
        // global variable
        SqlCommand cmd;
        byte[] pic;
        ImageConverter img;

        //retriving all avaiable items data
        private void getallitemsdata()
        {
            DataTable gridviewdata;

            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                gridviewdata = new DataTable();
                //getting items data
                cmd = new SqlCommand("ShowItems", DB.con) { CommandType = CommandType.StoredProcedure };
                gridviewdata.Load(cmd.ExecuteReader());
                AllAddedItems.DataSource = gridviewdata;
                
                DB.con.Close();

        }
            catch (Exception ex)
            {
                MessageBox.Show("Error while showing all data Please try again" + ex.ToString(), "ERROR");
            }
}
        private void getcombodata()
        {
            DataTable ComboBoxData;
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                //getting brands data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("BrandDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                Brand.DataSource = ComboBoxData;
                Brand.DisplayMember = "B_Name";
                Brand.ValueMember = "BID";


                //getting Company data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("CompanyDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                Company.DataSource = ComboBoxData;
                Company.DisplayMember = "COM_Name";
                Company.ValueMember = "COMID";


                //getting catagory data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("CatagoryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                catagory.DataSource = ComboBoxData;
                catagory.DisplayMember = "C_Name";
                catagory.ValueMember = "CID";

                DB.con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while getting combo box data" + ex.ToString(), "Error");
            }
        }

        // retriving all available "item inforamation" data
        private void getItemdInfoData()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable branddata, catagorydata, companydata;

                // retriving brands data
                branddata = new DataTable();
                cmd = new SqlCommand("BrandDetails",DB.con) { CommandType = CommandType.StoredProcedure };
                branddata.Load(cmd.ExecuteReader());

                // retriving catagories data
                catagorydata = new DataTable();
                cmd = new SqlCommand("CatagoryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                catagorydata.Load(cmd.ExecuteReader());

                //retriving companies data
                companydata = new DataTable();
                cmd = new SqlCommand("CompanyDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                companydata.Load(cmd.ExecuteReader());

                DB.con.Close();
                
                // showing brands data
                brandbox.DataSource = branddata;
                brandbox.ValueMember = "BID";
                brandbox.DisplayMember = "B_Name"; 

                //showing companies data
                companybox.DataSource = companydata;
                companybox.ValueMember = "COMID";
                companybox.DisplayMember = "COM_Name";

                //showing catagories data
                catagorybox.DataSource = catagorydata;
                catagorybox.ValueMember = "CID";
                catagorybox.DisplayMember = "C_Name";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting items infromation data. Please restart the software" + ex.ToString(), "Error");
            }
        }

        //Main load function
        private void AddItem_ud_Load(object sender, EventArgs e)
        {
            // getting combo box data
            getcombodata();
            //getting all items data
            getallitemsdata();
            //getting all "Items information" data
            getItemdInfoData();
        }

        //back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.id);
        }

        // Upload image button coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.Filter = "Image.File (*.jpg; *.jpeg; *.png; *.bmp; *.gif)|*.jpg; *.jpeg; *.png; *.bmp; *.gif";
                if (opf.ShowDialog()==DialogResult.OK)
                {
                    newitempic.Image = Image.FromFile(opf.FileName);
                }
            }
        }

        // Add button coding
        private void Additem_Click(object sender, EventArgs e)
        {
            int chk = 0;
            if (newitempic.Image != null && barcodebox.Text != string.Empty && itemnamebox.Text != string.Empty)
            {
                // converting picture into byte in order to save it
                img = new ImageConverter();
                pic = (byte[])img.ConvertTo(newitempic.Image, Type.GetType("System.Byte[]"));

                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    //sending all the information to database
                    cmd = new SqlCommand("AddItems", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@barcode", barcodebox.Text));
                    cmd.Parameters.Add(new SqlParameter("@catagory", catagorybox.SelectedValue));
                    cmd.Parameters.Add(new SqlParameter("@company", companybox.SelectedValue));
                    cmd.Parameters.Add(new SqlParameter("@itemName", itemnamebox.Text));
                    cmd.Parameters.Add(new SqlParameter("@brand", brandbox.SelectedValue));
                    cmd.Parameters.Add(new SqlParameter("@itemPic", pic));

                    chk = cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding new data. Please try again Thank you" + ex.ToString(), "Error");
                }

                if (chk>0)
                {
                    MessageBox.Show("Item Added");
                }
                else
                {
                    MessageBox.Show("Item not Added");
                }
                // refresing all data
                getallitemsdata();

                //clearing screen
                barcodebox.Text = string.Empty;
                itemnamebox.Text = string.Empty;
            }
            else if (barcodebox.Text == string.Empty)
                barcodebox.Focus();
            else if (itemnamebox.Text == string.Empty)
                itemnamebox.Focus();
            else
                MessageBox.Show("Please Enter the product image or restart the application", "ERROR");
        }

        // Grid View Coding
        private void AllAddedItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Update Coding
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("UpdateItems", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", AllAddedItems.Rows[e.RowIndex].Cells["ItemID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@barcode", AllAddedItems.Rows[e.RowIndex].Cells["Barcode"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@catagory", AllAddedItems.Rows[e.RowIndex].Cells["catagory"].Value));
                    cmd.Parameters.Add(new SqlParameter("@company", AllAddedItems.Rows[e.RowIndex].Cells["Company"].Value));
                    cmd.Parameters.Add(new SqlParameter("@itemName", AllAddedItems.Rows[e.RowIndex].Cells["ItemName"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@brand", AllAddedItems.Rows[e.RowIndex].Cells["brand"].Value));

                    pic = (byte[])AllAddedItems.Rows[e.RowIndex].Cells["Picture"].Value;
                    cmd.Parameters.Add(new SqlParameter("@itemPic", pic));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating selected data please try again" + ex.ToString(), "Error");
                }
            }

            // Update Picture Coding
            if (e.ColumnIndex == 2)
            {
                using (OpenFileDialog opf = new OpenFileDialog())
                {
                    opf.Filter = "Image.File (*.jpg; *.jpeg; *.png; *.bmp; *.gif)|*.jpg; *.jpeg; *.png; *.bmp; *.gif";
                    if (opf.ShowDialog() == DialogResult.OK)
                    {
                        AllAddedItems.Rows[e.RowIndex].Cells["Picture"].Value = Image.FromFile(opf.FileName);
                    }
                }
            }
        }

        // Boundig User Input
        private void barcodebox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
    }
}
