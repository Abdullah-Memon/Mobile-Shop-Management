﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.Items
{
    public partial class ItemDashboard_uc : UserControl
    {
        public ItemDashboard_uc()
        {
            InitializeComponent();
        }
        // Screens To Load
        public static Items_uc i;
        AddItem_ud ai;
        public static ItemInformation.ItemInformation_uc ii;

        // showing all items user control
        private void ShowItemsbtn_Click(object sender, EventArgs e)
        {
            if(i == null)
                i= new Items_uc();

            LoginForm.LoginScreen.ms.addusercontrol(i);
        }
        // showing add item usercontrol
        private void additembtn_Click(object sender, EventArgs e)
        {
            if(ai == null)
                ai = new AddItem_ud();

            LoginForm.LoginScreen.ms.addusercontrol(ai);
        }

        // Generate Report Button coding
        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            Reporting.GenerateReportForm gr = new Reporting.GenerateReportForm();
            gr.Show();
        }

        private void AddCatagorybtn_Click(object sender, EventArgs e)
        {
            if (ii == null)
                ii = new ItemInformation.ItemInformation_uc();

            LoginForm.LoginScreen.ms.addusercontrol(ii);
        }

        private void ItemDashboard_uc_Load(object sender, EventArgs e)
        {

        }
    }
}
