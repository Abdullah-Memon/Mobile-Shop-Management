﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Items
{
    public partial class ItemsRecycleBin_uc : UserControl
    {
        public ItemsRecycleBin_uc()
        {
            InitializeComponent();
        }
        // Global Vairable
        SqlCommand cmd;
        
        // Getting Deleted Data
        private void getDeletedData()
        {
            DataTable ComboBoxData, gridviewdata;
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("BrandDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                Brand.DataSource = ComboBoxData;
                Brand.DisplayMember = "B_Name";
                Brand.ValueMember = "BID";


                //getting Company data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("CompanyDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                Company.DataSource = ComboBoxData;
                Company.DisplayMember = "COM_Name";
                Company.ValueMember = "COMID";


                //getting catagory data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("CatagoryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                catagory.DataSource = ComboBoxData;
                catagory.DisplayMember = "C_Name";
                catagory.ValueMember = "CID";

                // getting all other data of item
                gridviewdata = new DataTable();
                cmd = new SqlCommand("ShowItems", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                gridviewdata.Load(cmd.ExecuteReader());

                DeletedItemsGridView.DataSource = gridviewdata;
                
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while getting deleted data Please try again" + ex.ToString(), "Error");
            }
        }
        private void getiteminformationdata()
        {
            DataTable ii;
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                ii = new DataTable();
                cmd = new SqlCommand("BrandDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ii.Load(cmd.ExecuteReader());
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error" + ex.ToString(), "Error");
            }
        }
        
        // Back Button Coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(ItemDashboard_uc.i);
        }

        // Main Load Function
        private void ItemsRecycleBin_uc_Load(object sender, EventArgs e)
        {
            getDeletedData();
        }

        // Grid View Button Coding
        private void DeletedItemsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 0==restore 1 == permanat delete
            if (e.ColumnIndex == 0 || e.ColumnIndex ==1)
            {
                if (e.ColumnIndex == 0)
                {
                    try
                    {
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        cmd = new SqlCommand("RestoreDeletedItems", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", DeletedItemsGridView.Rows[e.RowIndex].Cells["ItemID"].Value));
                        
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating selected data please try again" + ex.ToString(), "Error");
                    }
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure you want to Permanantly delete the selected item","Confirmation",MessageBoxButtons.YesNo)==DialogResult.Yes)
                    {
                        try
                        {
                            if (DB.con.State == ConnectionState.Closed)
                                DB.con.Open();

                            cmd = new SqlCommand("RemoveItems", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@id", DeletedItemsGridView.Rows[e.RowIndex].Cells["ItemID"].Value));
                            cmd.ExecuteNonQuery();

                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting selected item please try again" + ex.ToString(), "ERROR");
                        }
                    }
                }
                // Refresh data list
                getDeletedData();
            }
        }
    }
}
