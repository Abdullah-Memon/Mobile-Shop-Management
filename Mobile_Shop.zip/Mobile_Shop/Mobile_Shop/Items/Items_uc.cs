﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Items
{
    public partial class Items_uc : UserControl
    {
        public Items_uc()
        {
            InitializeComponent();
        }

        // Screens to Load
        ItemsRecycleBin_uc irb;

        // Global Variables
        SqlCommand cmd;

        // back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.id);
        }

        // Requesting all items data
        private void getgridviewdata()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable gridviewdata = new DataTable();
                cmd = new SqlCommand("ShowItems", DB.con) { CommandType = CommandType.StoredProcedure };
                
                gridviewdata.Load(cmd.ExecuteReader());
                DB.con.Close();

                gridview.DataSource = gridviewdata;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while showing all data Please try again" + ex.ToString(), "ERROR");
            }
        }
        private void getcombodata()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                //getting brands data
                DataTable ComboBoxData = new DataTable();
                cmd = new SqlCommand("BrandDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                Brand.DataSource = ComboBoxData;
                Brand.DisplayMember = "B_Name";
                Brand.ValueMember = "BID";


                //getting Company data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("CompanyDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                Company.DataSource = ComboBoxData;
                Company.DisplayMember = "COM_Name";
                Company.ValueMember = "COMID";


                //getting catagory data
                ComboBoxData = new DataTable();
                cmd = new SqlCommand("CatagoryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                ComboBoxData.Load(cmd.ExecuteReader());
                catagory.DataSource = ComboBoxData;
                catagory.DisplayMember = "C_Name";
                catagory.ValueMember = "CID";

                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting combo box data" + ex.ToString(), "Error");
            }
        }
        
        // Main load function
        private void Items_uc_Load(object sender, EventArgs e)
        {
            // getting combo box data for grid view
            getcombodata();
            // getting all items data
            getgridviewdata();
        }

        // Grid View Button Coding
        private void gridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // update coding from grid view
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("UpdateItems", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", gridview.Rows[e.RowIndex].Cells["ItemID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@barcode", gridview.Rows[e.RowIndex].Cells["Barcode"].Value));
                    cmd.Parameters.Add(new SqlParameter("@catagory", gridview.Rows[e.RowIndex].Cells["catagory"].Value));
                    cmd.Parameters.Add(new SqlParameter("@company", gridview.Rows[e.RowIndex].Cells["Company"].Value));
                    cmd.Parameters.Add(new SqlParameter("@itemName", gridview.Rows[e.RowIndex].Cells["ItemName"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@brand", gridview.Rows[e.RowIndex].Cells["Brand"].Value));

                    byte[] pic = (byte[])gridview.Rows[e.RowIndex].Cells["Picture"].Value;
                    cmd.Parameters.Add(new SqlParameter("@itemPic", pic));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    getgridviewdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating selected data please try again" + ex.ToString(), "Error");
                }
            }

            //delete coding from grid view
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure you want to delete selected item? ","Confirmation",MessageBoxButtons.YesNo)==DialogResult.Yes)
                {
                    try
                    {
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        cmd = new SqlCommand("RemoveItems", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", gridview.Rows[e.RowIndex].Cells["ItemID"].Value));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                        getgridviewdata();
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while deleting selected item Please try again" + ex.ToString(), "ERROR");
                    }
                }
            }
            
            // changing picture coding from grid view
            if (e.ColumnIndex == 3)
            {
                using (OpenFileDialog opf = new OpenFileDialog())
                {
                    opf.Filter = "Image.File (*.jpg; *.jpeg; *.png; *.bmp; *.gif)|*.jpg; *.jpeg; *.png; *.bmp; *.gif";
                    if (opf.ShowDialog() == DialogResult.OK)
                    {
                        gridview.Rows[e.RowIndex].Cells["Picture"].Value = Image.FromFile(opf.FileName);
                    }
                }
            }
        }

        // Recycle Bin Button Coding
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if(irb == null)
                irb= new ItemsRecycleBin_uc();

            LoginForm.LoginScreen.ms.addusercontrol(irb);
        }
    }
}
