﻿namespace Mobile_Shop.Items.Reporting
{
    partial class GenerateReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.upperpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.minimizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.lowerpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.reportViewer1 = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.maximizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.upperpanel.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            this.lowerpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // upperpanel
            // 
            this.upperpanel.BackColor = System.Drawing.Color.Transparent;
            this.upperpanel.Controls.Add(this.guna2GradientPanel3);
            this.upperpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.upperpanel.Location = new System.Drawing.Point(0, 0);
            this.upperpanel.Name = "upperpanel";
            this.upperpanel.ShadowDecoration.Parent = this.upperpanel;
            this.upperpanel.Size = new System.Drawing.Size(665, 65);
            this.upperpanel.TabIndex = 0;
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderRadius = 15;
            this.guna2GradientPanel3.Controls.Add(this.guna2CircleButton1);
            this.guna2GradientPanel3.Controls.Add(this.maximizebtn);
            this.guna2GradientPanel3.Controls.Add(this.minimizebtn);
            this.guna2GradientPanel3.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientPanel3.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientPanel3.Location = new System.Drawing.Point(511, -19);
            this.guna2GradientPanel3.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.ShadowDecoration.Parent = this.guna2GradientPanel3;
            this.guna2GradientPanel3.Size = new System.Drawing.Size(140, 78);
            this.guna2GradientPanel3.TabIndex = 2;
            // 
            // minimizebtn
            // 
            this.minimizebtn.CheckedState.Parent = this.minimizebtn;
            this.minimizebtn.CustomImages.Parent = this.minimizebtn;
            this.minimizebtn.FillColor = System.Drawing.Color.White;
            this.minimizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.minimizebtn.ForeColor = System.Drawing.Color.Indigo;
            this.minimizebtn.HoverState.Parent = this.minimizebtn;
            this.minimizebtn.Location = new System.Drawing.Point(5, 32);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.minimizebtn.ShadowDecoration.Parent = this.minimizebtn;
            this.minimizebtn.Size = new System.Drawing.Size(40, 40);
            this.minimizebtn.TabIndex = 13;
            this.minimizebtn.Text = "_";
            this.minimizebtn.Click += new System.EventHandler(this.minimizebtn_Click);
            // 
            // lowerpanel
            // 
            this.lowerpanel.BackColor = System.Drawing.Color.Transparent;
            this.lowerpanel.Controls.Add(this.reportViewer1);
            this.lowerpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lowerpanel.Location = new System.Drawing.Point(0, 65);
            this.lowerpanel.Name = "lowerpanel";
            this.lowerpanel.ShadowDecoration.Parent = this.lowerpanel;
            this.lowerpanel.Size = new System.Drawing.Size(665, 637);
            this.lowerpanel.TabIndex = 1;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(665, 565);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ViewMode = Telerik.ReportViewer.WinForms.ViewMode.PrintPreview;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.upperpanel;
            // 
            // maximizebtn
            // 
            this.maximizebtn.CheckedState.Parent = this.maximizebtn;
            this.maximizebtn.CustomImages.Parent = this.maximizebtn;
            this.maximizebtn.FillColor = System.Drawing.Color.White;
            this.maximizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.maximizebtn.ForeColor = System.Drawing.Color.Indigo;
            this.maximizebtn.HoverState.Parent = this.maximizebtn;
            this.maximizebtn.Location = new System.Drawing.Point(51, 32);
            this.maximizebtn.Name = "maximizebtn";
            this.maximizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.maximizebtn.ShadowDecoration.Parent = this.maximizebtn;
            this.maximizebtn.Size = new System.Drawing.Size(40, 40);
            this.maximizebtn.TabIndex = 13;
            this.maximizebtn.Text = "|=|";
            this.maximizebtn.Click += new System.EventHandler(this.maximizebtn_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(97, 32);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.TabIndex = 13;
            this.guna2CircleButton1.Text = "X";
            this.guna2CircleButton1.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // GenerateReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(665, 702);
            this.Controls.Add(this.lowerpanel);
            this.Controls.Add(this.upperpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GenerateReportForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "GenerateReportForm";
            this.Load += new System.EventHandler(this.GenerateReportForm_Load);
            this.upperpanel.ResumeLayout(false);
            this.guna2GradientPanel3.ResumeLayout(false);
            this.lowerpanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel upperpanel;
        private Guna.UI2.WinForms.Guna2GradientPanel lowerpanel;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2CircleButton minimizebtn;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Telerik.ReportViewer.WinForms.ReportViewer reportViewer1;
        private Guna.UI2.WinForms.Guna2CircleButton maximizebtn;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
    }
}