﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.Items.Reporting
{
    class ItemListData
    {
        public string C_Name { set; get; }
        public string COM_Name { set; get; }
        public string Item_Name { set; get; }
        public string B_Name { set; get; }
        public byte[] Item_Picture { set; get; }
    }
}
