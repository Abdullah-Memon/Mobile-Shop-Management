﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.Reporting;

namespace Mobile_Shop.Items.Reporting
{
    public partial class GenerateReportForm : Form
    {
        public GenerateReportForm()
        {
            InitializeComponent();
            DB.connect();
        }

        private void getData() 
        {
            DataTable dt = new DataTable();

            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }

            try
            {
                SqlCommand cmd = new SqlCommand("GenerateItemsReport", DB.con) { CommandType = CommandType.StoredProcedure };
                dt.Load(cmd.ExecuteReader());
                DB.con.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

            Reporting.ItemsReportPage x = new Reporting.ItemsReportPage();
            x.DataSource = dt;
            InstanceReportSource sx = new InstanceReportSource() { ReportDocument = x };
            reportViewer1.ReportSource = sx;
            reportViewer1.RefreshReport();
        }

        private void GenerateReportForm_Load(object sender, EventArgs e)
        {
            getData();
            WindowState = FormWindowState.Maximized;
        }

        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void minimizebtn_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void maximizebtn_Click(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
                WindowState = FormWindowState.Normal;
        }
    }
}
