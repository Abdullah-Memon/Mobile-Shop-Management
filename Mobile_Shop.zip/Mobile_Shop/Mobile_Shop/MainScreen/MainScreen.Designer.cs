﻿namespace Mobile_Shop.MainScreen
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.footerbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2CircleButton8 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.navigationbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.logoutbtn = new Guna.UI2.WinForms.Guna2Button();
            this.aboutbtn = new Guna.UI2.WinForms.Guna2Button();
            this.settingbtn = new Guna.UI2.WinForms.Guna2Button();
            this.Emp_Managementbtn = new Guna.UI2.WinForms.Guna2Button();
            this.expensebtn = new Guna.UI2.WinForms.Guna2Button();
            this.accountbtn = new Guna.UI2.WinForms.Guna2Button();
            this.stockbtn = new Guna.UI2.WinForms.Guna2Button();
            this.itembtn = new Guna.UI2.WinForms.Guna2Button();
            this.purchasebtn = new Guna.UI2.WinForms.Guna2Button();
            this.Sellbtn = new Guna.UI2.WinForms.Guna2Button();
            this.Dashboardbtn = new Guna.UI2.WinForms.Guna2Button();
            this.shoplogo = new Guna.UI2.WinForms.Guna2PictureBox();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.controlbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.minimizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.maximizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.time = new System.Windows.Forms.Label();
            this.shoptitle = new System.Windows.Forms.Label();
            this.shopname = new System.Windows.Forms.Label();
            this.footerbox.SuspendLayout();
            this.navigationbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shoplogo)).BeginInit();
            this.controlbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // footerbox
            // 
            this.footerbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.footerbox.BackColor = System.Drawing.Color.Transparent;
            this.footerbox.BorderColor = System.Drawing.Color.Indigo;
            this.footerbox.Controls.Add(this.label2);
            this.footerbox.Controls.Add(this.label1);
            this.footerbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.footerbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.footerbox.ForeColor = System.Drawing.Color.White;
            this.footerbox.Location = new System.Drawing.Point(-1, 651);
            this.footerbox.Name = "footerbox";
            this.footerbox.ShadowDecoration.Parent = this.footerbox;
            this.footerbox.Size = new System.Drawing.Size(1288, 62);
            this.footerbox.TabIndex = 17;
            this.footerbox.UseTransparentBackground = true;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(1113, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 18);
            this.label2.TabIndex = 18;
            this.label2.Text = "contact # 0300-0000000";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(3, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(453, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "All copyright has been reserved to Fidx Software House Nawabshah";
            // 
            // guna2CircleButton8
            // 
            this.guna2CircleButton8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton8.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton8.CheckedState.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.CustomImages.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton8.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton8.HoverState.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.Location = new System.Drawing.Point(1103, 5);
            this.guna2CircleButton8.Name = "guna2CircleButton8";
            this.guna2CircleButton8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton8.ShadowDecoration.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.Size = new System.Drawing.Size(43, 45);
            this.guna2CircleButton8.TabIndex = 16;
            this.guna2CircleButton8.Text = "N";
            this.guna2CircleButton8.Click += new System.EventHandler(this.guna2CircleButton8_Click);
            // 
            // navigationbox
            // 
            this.navigationbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.navigationbox.BackColor = System.Drawing.Color.Transparent;
            this.navigationbox.BorderColor = System.Drawing.Color.Indigo;
            this.navigationbox.BorderRadius = 15;
            this.navigationbox.Controls.Add(this.logoutbtn);
            this.navigationbox.Controls.Add(this.aboutbtn);
            this.navigationbox.Controls.Add(this.settingbtn);
            this.navigationbox.Controls.Add(this.Emp_Managementbtn);
            this.navigationbox.Controls.Add(this.expensebtn);
            this.navigationbox.Controls.Add(this.accountbtn);
            this.navigationbox.Controls.Add(this.stockbtn);
            this.navigationbox.Controls.Add(this.itembtn);
            this.navigationbox.Controls.Add(this.purchasebtn);
            this.navigationbox.Controls.Add(this.Sellbtn);
            this.navigationbox.Controls.Add(this.Dashboardbtn);
            this.navigationbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.navigationbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.navigationbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.navigationbox.Location = new System.Drawing.Point(-14, 69);
            this.navigationbox.Name = "navigationbox";
            this.navigationbox.ShadowDecoration.Parent = this.navigationbox;
            this.navigationbox.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(5, 5, 15, 5);
            this.navigationbox.Size = new System.Drawing.Size(226, 576);
            this.navigationbox.TabIndex = 14;
            this.navigationbox.UseTransparentBackground = true;
            this.navigationbox.Click += new System.EventHandler(this.navigationbox_Click);
            // 
            // logoutbtn
            // 
            this.logoutbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logoutbtn.BackColor = System.Drawing.Color.Transparent;
            this.logoutbtn.BorderRadius = 10;
            this.logoutbtn.CheckedState.Parent = this.logoutbtn;
            this.logoutbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoutbtn.CustomImages.Parent = this.logoutbtn;
            this.logoutbtn.FillColor = System.Drawing.Color.Indigo;
            this.logoutbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutbtn.ForeColor = System.Drawing.Color.White;
            this.logoutbtn.HoverState.FillColor = System.Drawing.Color.White;
            this.logoutbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutbtn.HoverState.ForeColor = System.Drawing.Color.Indigo;
            this.logoutbtn.HoverState.Parent = this.logoutbtn;
            this.logoutbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.logoutbtn.Location = new System.Drawing.Point(27, 522);
            this.logoutbtn.Name = "logoutbtn";
            this.logoutbtn.ShadowDecoration.Parent = this.logoutbtn;
            this.logoutbtn.Size = new System.Drawing.Size(171, 51);
            this.logoutbtn.TabIndex = 0;
            this.logoutbtn.Text = "Logout";
            this.logoutbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.logoutbtn.Click += new System.EventHandler(this.logoutbtn_Click);
            // 
            // aboutbtn
            // 
            this.aboutbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.aboutbtn.BackColor = System.Drawing.Color.Transparent;
            this.aboutbtn.BorderRadius = 10;
            this.aboutbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.aboutbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.aboutbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.aboutbtn.CheckedState.Parent = this.aboutbtn;
            this.aboutbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.aboutbtn.CustomImages.Parent = this.aboutbtn;
            this.aboutbtn.FillColor = System.Drawing.Color.Transparent;
            this.aboutbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutbtn.ForeColor = System.Drawing.Color.Indigo;
            this.aboutbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.aboutbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.aboutbtn.HoverState.Parent = this.aboutbtn;
            this.aboutbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.aboutbtn.Location = new System.Drawing.Point(36, 471);
            this.aboutbtn.Name = "aboutbtn";
            this.aboutbtn.ShadowDecoration.Parent = this.aboutbtn;
            this.aboutbtn.Size = new System.Drawing.Size(171, 45);
            this.aboutbtn.TabIndex = 0;
            this.aboutbtn.Text = "About";
            this.aboutbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.aboutbtn.Click += new System.EventHandler(this.aboutbtn_Click);
            // 
            // settingbtn
            // 
            this.settingbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.settingbtn.BackColor = System.Drawing.Color.Transparent;
            this.settingbtn.BorderRadius = 10;
            this.settingbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.settingbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.settingbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.settingbtn.CheckedState.Parent = this.settingbtn;
            this.settingbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.settingbtn.CustomImages.Parent = this.settingbtn;
            this.settingbtn.FillColor = System.Drawing.Color.Transparent;
            this.settingbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingbtn.ForeColor = System.Drawing.Color.Indigo;
            this.settingbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.settingbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.settingbtn.HoverState.Parent = this.settingbtn;
            this.settingbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.settingbtn.Location = new System.Drawing.Point(36, 420);
            this.settingbtn.Name = "settingbtn";
            this.settingbtn.ShadowDecoration.Parent = this.settingbtn;
            this.settingbtn.Size = new System.Drawing.Size(171, 45);
            this.settingbtn.TabIndex = 0;
            this.settingbtn.Text = "Settings";
            this.settingbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.settingbtn.Click += new System.EventHandler(this.settingbtn_Click);
            // 
            // Emp_Managementbtn
            // 
            this.Emp_Managementbtn.BackColor = System.Drawing.Color.Transparent;
            this.Emp_Managementbtn.BorderRadius = 10;
            this.Emp_Managementbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.Emp_Managementbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.Emp_Managementbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.Emp_Managementbtn.CheckedState.Parent = this.Emp_Managementbtn;
            this.Emp_Managementbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Emp_Managementbtn.CustomImages.Parent = this.Emp_Managementbtn;
            this.Emp_Managementbtn.FillColor = System.Drawing.Color.Transparent;
            this.Emp_Managementbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emp_Managementbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Emp_Managementbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.Emp_Managementbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emp_Managementbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.Emp_Managementbtn.HoverState.Parent = this.Emp_Managementbtn;
            this.Emp_Managementbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Emp_Managementbtn.Location = new System.Drawing.Point(36, 369);
            this.Emp_Managementbtn.Name = "Emp_Managementbtn";
            this.Emp_Managementbtn.ShadowDecoration.Parent = this.Emp_Managementbtn;
            this.Emp_Managementbtn.Size = new System.Drawing.Size(171, 45);
            this.Emp_Managementbtn.TabIndex = 0;
            this.Emp_Managementbtn.Text = "Employee Management";
            this.Emp_Managementbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Emp_Managementbtn.Click += new System.EventHandler(this.Emp_Managementbtn_Click);
            // 
            // expensebtn
            // 
            this.expensebtn.BackColor = System.Drawing.Color.Transparent;
            this.expensebtn.BorderRadius = 10;
            this.expensebtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.expensebtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.expensebtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.expensebtn.CheckedState.Parent = this.expensebtn;
            this.expensebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.expensebtn.CustomImages.Parent = this.expensebtn;
            this.expensebtn.FillColor = System.Drawing.Color.Transparent;
            this.expensebtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expensebtn.ForeColor = System.Drawing.Color.Indigo;
            this.expensebtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.expensebtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expensebtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.expensebtn.HoverState.Parent = this.expensebtn;
            this.expensebtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.expensebtn.Location = new System.Drawing.Point(36, 318);
            this.expensebtn.Name = "expensebtn";
            this.expensebtn.ShadowDecoration.Parent = this.expensebtn;
            this.expensebtn.Size = new System.Drawing.Size(171, 45);
            this.expensebtn.TabIndex = 0;
            this.expensebtn.Text = "Expense";
            this.expensebtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.expensebtn.Click += new System.EventHandler(this.expensebtn_Click);
            // 
            // accountbtn
            // 
            this.accountbtn.BackColor = System.Drawing.Color.Transparent;
            this.accountbtn.BorderRadius = 10;
            this.accountbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.accountbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.accountbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.accountbtn.CheckedState.Parent = this.accountbtn;
            this.accountbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.accountbtn.CustomImages.Parent = this.accountbtn;
            this.accountbtn.FillColor = System.Drawing.Color.Transparent;
            this.accountbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountbtn.ForeColor = System.Drawing.Color.Indigo;
            this.accountbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.accountbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.accountbtn.HoverState.Parent = this.accountbtn;
            this.accountbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.accountbtn.Location = new System.Drawing.Point(36, 267);
            this.accountbtn.Name = "accountbtn";
            this.accountbtn.ShadowDecoration.Parent = this.accountbtn;
            this.accountbtn.Size = new System.Drawing.Size(171, 45);
            this.accountbtn.TabIndex = 0;
            this.accountbtn.Text = "Accounts";
            this.accountbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.accountbtn.Click += new System.EventHandler(this.accountbtn_Click);
            // 
            // stockbtn
            // 
            this.stockbtn.BackColor = System.Drawing.Color.Transparent;
            this.stockbtn.BorderRadius = 10;
            this.stockbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.stockbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.stockbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.stockbtn.CheckedState.Parent = this.stockbtn;
            this.stockbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stockbtn.CustomImages.Parent = this.stockbtn;
            this.stockbtn.FillColor = System.Drawing.Color.Transparent;
            this.stockbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockbtn.ForeColor = System.Drawing.Color.Indigo;
            this.stockbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.stockbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.stockbtn.HoverState.Parent = this.stockbtn;
            this.stockbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.stockbtn.Location = new System.Drawing.Point(36, 216);
            this.stockbtn.Name = "stockbtn";
            this.stockbtn.ShadowDecoration.Parent = this.stockbtn;
            this.stockbtn.Size = new System.Drawing.Size(171, 45);
            this.stockbtn.TabIndex = 0;
            this.stockbtn.Text = "Stock";
            this.stockbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.stockbtn.Click += new System.EventHandler(this.stockbtn_Click);
            // 
            // itembtn
            // 
            this.itembtn.BackColor = System.Drawing.Color.Transparent;
            this.itembtn.BorderRadius = 10;
            this.itembtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.itembtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.itembtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.itembtn.CheckedState.Parent = this.itembtn;
            this.itembtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.itembtn.CustomImages.Parent = this.itembtn;
            this.itembtn.FillColor = System.Drawing.Color.Transparent;
            this.itembtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itembtn.ForeColor = System.Drawing.Color.Indigo;
            this.itembtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.itembtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itembtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.itembtn.HoverState.Parent = this.itembtn;
            this.itembtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.itembtn.Location = new System.Drawing.Point(36, 165);
            this.itembtn.Name = "itembtn";
            this.itembtn.ShadowDecoration.Parent = this.itembtn;
            this.itembtn.Size = new System.Drawing.Size(171, 45);
            this.itembtn.TabIndex = 0;
            this.itembtn.Text = "Items";
            this.itembtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.itembtn.Click += new System.EventHandler(this.itembtn_Click);
            // 
            // purchasebtn
            // 
            this.purchasebtn.BackColor = System.Drawing.Color.Transparent;
            this.purchasebtn.BorderRadius = 10;
            this.purchasebtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.purchasebtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.purchasebtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.purchasebtn.CheckedState.Parent = this.purchasebtn;
            this.purchasebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.purchasebtn.CustomImages.Parent = this.purchasebtn;
            this.purchasebtn.FillColor = System.Drawing.Color.Transparent;
            this.purchasebtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.purchasebtn.ForeColor = System.Drawing.Color.Indigo;
            this.purchasebtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.purchasebtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.purchasebtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.purchasebtn.HoverState.Parent = this.purchasebtn;
            this.purchasebtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.purchasebtn.Location = new System.Drawing.Point(36, 114);
            this.purchasebtn.Name = "purchasebtn";
            this.purchasebtn.ShadowDecoration.Parent = this.purchasebtn;
            this.purchasebtn.Size = new System.Drawing.Size(171, 45);
            this.purchasebtn.TabIndex = 0;
            this.purchasebtn.Text = "Purchase";
            this.purchasebtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.purchasebtn.Click += new System.EventHandler(this.purchasebtn_Click);
            // 
            // Sellbtn
            // 
            this.Sellbtn.BackColor = System.Drawing.Color.Transparent;
            this.Sellbtn.BorderRadius = 10;
            this.Sellbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.Sellbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.Sellbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.Sellbtn.CheckedState.Parent = this.Sellbtn;
            this.Sellbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Sellbtn.CustomImages.Parent = this.Sellbtn;
            this.Sellbtn.FillColor = System.Drawing.Color.Transparent;
            this.Sellbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sellbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Sellbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.Sellbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sellbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.Sellbtn.HoverState.Parent = this.Sellbtn;
            this.Sellbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Sellbtn.Location = new System.Drawing.Point(36, 63);
            this.Sellbtn.Name = "Sellbtn";
            this.Sellbtn.ShadowDecoration.Parent = this.Sellbtn;
            this.Sellbtn.Size = new System.Drawing.Size(171, 45);
            this.Sellbtn.TabIndex = 0;
            this.Sellbtn.Text = "Sell";
            this.Sellbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Sellbtn.Click += new System.EventHandler(this.Sellbtn_Click);
            // 
            // Dashboardbtn
            // 
            this.Dashboardbtn.BackColor = System.Drawing.Color.Transparent;
            this.Dashboardbtn.BorderRadius = 10;
            this.Dashboardbtn.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.Dashboardbtn.Checked = true;
            this.Dashboardbtn.CheckedState.FillColor = System.Drawing.Color.Indigo;
            this.Dashboardbtn.CheckedState.ForeColor = System.Drawing.Color.White;
            this.Dashboardbtn.CheckedState.Parent = this.Dashboardbtn;
            this.Dashboardbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dashboardbtn.CustomImages.Parent = this.Dashboardbtn;
            this.Dashboardbtn.FillColor = System.Drawing.Color.Transparent;
            this.Dashboardbtn.Font = new System.Drawing.Font("Segoe UI", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashboardbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Dashboardbtn.HoverState.FillColor = System.Drawing.Color.Indigo;
            this.Dashboardbtn.HoverState.Font = new System.Drawing.Font("Segoe UI Emoji", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashboardbtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.Dashboardbtn.HoverState.Parent = this.Dashboardbtn;
            this.Dashboardbtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Dashboardbtn.Location = new System.Drawing.Point(36, 12);
            this.Dashboardbtn.Name = "Dashboardbtn";
            this.Dashboardbtn.ShadowDecoration.Parent = this.Dashboardbtn;
            this.Dashboardbtn.Size = new System.Drawing.Size(171, 45);
            this.Dashboardbtn.TabIndex = 0;
            this.Dashboardbtn.Text = "Dashboard";
            this.Dashboardbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Dashboardbtn.Click += new System.EventHandler(this.Dashboardbtn_Click);
            // 
            // shoplogo
            // 
            this.shoplogo.BackColor = System.Drawing.Color.Transparent;
            this.shoplogo.BorderRadius = 10;
            this.shoplogo.FillColor = System.Drawing.Color.White;
            this.shoplogo.Location = new System.Drawing.Point(13, 13);
            this.shoplogo.Name = "shoplogo";
            this.shoplogo.ShadowDecoration.Parent = this.shoplogo;
            this.shoplogo.Size = new System.Drawing.Size(50, 50);
            this.shoplogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.shoplogo.TabIndex = 0;
            this.shoplogo.TabStop = false;
            // 
            // crossbtn
            // 
            this.crossbtn.BackColor = System.Drawing.Color.Transparent;
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.Indigo;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.White;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(87, 6);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 15;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentPanel.BackColor = System.Drawing.Color.White;
            this.ContentPanel.BorderRadius = 10;
            this.ContentPanel.FillColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Location = new System.Drawing.Point(218, 81);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Padding = new System.Windows.Forms.Padding(5);
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this;
            // 
            // controlbox
            // 
            this.controlbox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.controlbox.BackColor = System.Drawing.Color.Transparent;
            this.controlbox.BorderColor = System.Drawing.Color.FloralWhite;
            this.controlbox.BorderRadius = 15;
            this.controlbox.BorderThickness = 3;
            this.controlbox.Controls.Add(this.minimizebtn);
            this.controlbox.Controls.Add(this.maximizebtn);
            this.controlbox.Controls.Add(this.crossbtn);
            this.controlbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.controlbox.FillColor = System.Drawing.Color.Indigo;
            this.controlbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.controlbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.controlbox.Location = new System.Drawing.Point(1152, 5);
            this.controlbox.Name = "controlbox";
            this.controlbox.ShadowDecoration.Parent = this.controlbox;
            this.controlbox.Size = new System.Drawing.Size(126, 45);
            this.controlbox.TabIndex = 17;
            // 
            // minimizebtn
            // 
            this.minimizebtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizebtn.CheckedState.Parent = this.minimizebtn;
            this.minimizebtn.CustomImages.Parent = this.minimizebtn;
            this.minimizebtn.FillColor = System.Drawing.Color.Indigo;
            this.minimizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.minimizebtn.ForeColor = System.Drawing.Color.White;
            this.minimizebtn.HoverState.Parent = this.minimizebtn;
            this.minimizebtn.Location = new System.Drawing.Point(5, 6);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.minimizebtn.ShadowDecoration.Parent = this.minimizebtn;
            this.minimizebtn.Size = new System.Drawing.Size(35, 35);
            this.minimizebtn.TabIndex = 15;
            this.minimizebtn.Text = "_";
            this.minimizebtn.Click += new System.EventHandler(this.minimizebtn_Click);
            // 
            // maximizebtn
            // 
            this.maximizebtn.BackColor = System.Drawing.Color.Transparent;
            this.maximizebtn.CheckedState.Parent = this.maximizebtn;
            this.maximizebtn.CustomImages.Parent = this.maximizebtn;
            this.maximizebtn.FillColor = System.Drawing.Color.Indigo;
            this.maximizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.maximizebtn.ForeColor = System.Drawing.Color.White;
            this.maximizebtn.HoverState.Parent = this.maximizebtn;
            this.maximizebtn.Location = new System.Drawing.Point(46, 6);
            this.maximizebtn.Name = "maximizebtn";
            this.maximizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.maximizebtn.ShadowDecoration.Parent = this.maximizebtn;
            this.maximizebtn.Size = new System.Drawing.Size(35, 35);
            this.maximizebtn.TabIndex = 15;
            this.maximizebtn.Text = "|=|";
            this.maximizebtn.Click += new System.EventHandler(this.maximizebtn_Click);
            // 
            // time
            // 
            this.time.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.time.AutoSize = true;
            this.time.BackColor = System.Drawing.Color.Transparent;
            this.time.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.ForeColor = System.Drawing.Color.Indigo;
            this.time.Location = new System.Drawing.Point(600, 28);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(80, 22);
            this.time.TabIndex = 18;
            this.time.Text = "00/00/00";
            // 
            // shoptitle
            // 
            this.shoptitle.AutoSize = true;
            this.shoptitle.BackColor = System.Drawing.Color.Transparent;
            this.shoptitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoptitle.ForeColor = System.Drawing.Color.Indigo;
            this.shoptitle.Location = new System.Drawing.Point(73, 45);
            this.shoptitle.Name = "shoptitle";
            this.shoptitle.Size = new System.Drawing.Size(74, 18);
            this.shoptitle.TabIndex = 18;
            this.shoptitle.Text = "Shop Title";
            // 
            // shopname
            // 
            this.shopname.AutoSize = true;
            this.shopname.BackColor = System.Drawing.Color.Transparent;
            this.shopname.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shopname.ForeColor = System.Drawing.Color.Indigo;
            this.shopname.Location = new System.Drawing.Point(69, 8);
            this.shopname.Name = "shopname";
            this.shopname.Size = new System.Drawing.Size(207, 40);
            this.shopname.TabIndex = 18;
            this.shopname.Text = "Shop Name";
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1288, 715);
            this.ControlBox = false;
            this.Controls.Add(this.time);
            this.Controls.Add(this.guna2CircleButton8);
            this.Controls.Add(this.shoplogo);
            this.Controls.Add(this.shoptitle);
            this.Controls.Add(this.footerbox);
            this.Controls.Add(this.shopname);
            this.Controls.Add(this.controlbox);
            this.Controls.Add(this.ContentPanel);
            this.Controls.Add(this.navigationbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainScreen";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.footerbox.ResumeLayout(false);
            this.footerbox.PerformLayout();
            this.navigationbox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.shoplogo)).EndInit();
            this.controlbox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel ContentPanel;
        private Guna.UI2.WinForms.Guna2PictureBox shoplogo;
        private Guna.UI2.WinForms.Guna2GroupBox navigationbox;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton8;
        private System.Windows.Forms.Timer timer1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GroupBox footerbox;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private Guna.UI2.WinForms.Guna2GroupBox controlbox;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Label shopname;
        private System.Windows.Forms.Label shoptitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2CircleButton minimizebtn;
        private Guna.UI2.WinForms.Guna2Button Dashboardbtn;
        private Guna.UI2.WinForms.Guna2Button Sellbtn;
        private Guna.UI2.WinForms.Guna2Button itembtn;
        private Guna.UI2.WinForms.Guna2Button purchasebtn;
        private Guna.UI2.WinForms.Guna2Button expensebtn;
        private Guna.UI2.WinForms.Guna2Button accountbtn;
        private Guna.UI2.WinForms.Guna2Button settingbtn;
        private Guna.UI2.WinForms.Guna2Button logoutbtn;
        private Guna.UI2.WinForms.Guna2Button aboutbtn;
        private Guna.UI2.WinForms.Guna2Button stockbtn;
        public Guna.UI2.WinForms.Guna2CircleButton maximizebtn;
        private Guna.UI2.WinForms.Guna2Button Emp_Managementbtn;
    }
}