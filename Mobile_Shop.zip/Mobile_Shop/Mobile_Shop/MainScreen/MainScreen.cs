﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Mobile_Shop.MainScreen
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        // Function to Load Screens
        public void addusercontrol(UserControl uc)
        {
            try
            {
                ContentPanel.Controls.Clear();
                ContentPanel.Controls.Add(uc);
                uc.Dock = DockStyle.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Screens to Load
        DashBoardScreenForm dbsf;
        StockScreen.StockScreenForm ssf;
        public static PurchaseScreen.PurchaseDashboard_uc pd;
        public static Items.ItemDashboard_uc id;
        public static Emp_Management.Emp_Management_Dashboard_uc emd;
        SellScreen.SellScreen_uc sc;
        public static Expense.ExpenseDashboard_uc ed;
        // Function to Get Shop Details
        void shopdetails()
        {
            // getting shop logo

            if (Form1.shopDetails.Rows.Count > 0)
            {
                byte[] pic = (byte[])Form1.shopDetails.Rows[0][0];
                MemoryStream ms = new MemoryStream(pic);
                shoplogo.Image = Image.FromStream(ms);

                //getting shop name
                shopname.Text = Form1.shopDetails.Rows[0][1].ToString();
                shoptitle.Text = Form1.shopDetails.Rows[0][2].ToString();
                //gettinng shop title
                time.Text = Form1.shopDetails.Rows[0][2].ToString();
            }
            
        }
        
        // Main Load function
        private void MainScreen_Load(object sender, EventArgs e)
        {
            // Loading Dashboard Screen
            if(dbsf == null)
                dbsf = new DashBoardScreenForm();

            addusercontrol(dbsf);
            
            // Getting shop Detailss
            shopdetails();
            
            // Activavte Minimixebtn
            maximizebtn.Enabled = true;

            // Maximizing the Form size
            WindowState = FormWindowState.Maximized;

        }

        // Cross button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Loading sell Screen
        private void Sellbtn_Click(object sender, EventArgs e)
        {
            if (sc == null)
                sc = new SellScreen.SellScreen_uc();

            LoginForm.LoginScreen.ms.addusercontrol(sc);

            if (WindowState != FormWindowState.Maximized)
                WindowState = FormWindowState.Maximized;

            maximizebtn.Enabled = false;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = true;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;
        }

        // Loading Purchase screen
        private void purchasebtn_Click(object sender, EventArgs e)
        {
            if (pd == null)
                pd = new PurchaseScreen.PurchaseDashboard_uc();

            addusercontrol(pd);

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = true;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;

            maximizebtn.Enabled = true;
        }

        // Loading Dashboard Screen
        private void Dashboardbtn_Click(object sender, EventArgs e)
        {
            // Loading Dashboard
            if(dbsf == null)
                dbsf = new DashBoardScreenForm();
            addusercontrol(dbsf);
            
            // Activate Maximiebtn
            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = true;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;        
        }

        // Loading Stock Screen
        private void stockbtn_Click(object sender, EventArgs e)
        {
            // Loading Stock
            if(ssf == null)
                ssf = new StockScreen.StockScreenForm();
            addusercontrol(ssf);
            
            //Activate Maximizebtn
            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = true;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;            
        }

        // Showing time coding
        private void timer1_Tick(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
        }

        // Logout button coding
        private void logoutbtn_Click(object sender, EventArgs e)
        {
            this.Close();
            Program.l.Show();
        }

        // Loading items screen 
        private void itembtn_Click(object sender, EventArgs e)
        {
            // Loading Items
            if(id == null)
                id = new Items.ItemDashboard_uc();
            
            addusercontrol(id);
            
            // Activate Maximizebtn
            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = true;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;
        }

        // Loading Expense Screen
        private void expensebtn_Click(object sender, EventArgs e)
        {
            if(ed == null)
                ed = new Expense.ExpenseDashboard_uc();
            addusercontrol(ed);

            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = true;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;
        }

        // Loading Accounts Screen
        private void accountbtn_Click(object sender, EventArgs e)
        {
            Account.AccountsDashoboard_uc ad = new Account.AccountsDashoboard_uc();
            addusercontrol(ad);
            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = true;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;
        }
        // Notification button coding
        private void guna2CircleButton8_Click(object sender, EventArgs e)
        {
            Notification.NotificationReporting.NotificationReport_Form nrf = new Notification.NotificationReporting.NotificationReport_Form();
            nrf.Show();
        }

        //Loading Setting Scree
        private void settingbtn_Click(object sender, EventArgs e)
        {
            Settings.Settings_uc s = new Settings.Settings_uc();
            addusercontrol(s);
            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = true;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = false;
        }

        // Minimize button coding
        private void minimizebtn_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        // About Button Coding
        private void aboutbtn_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        // Maximize button coding
        private void maximizebtn_Click(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
                WindowState = FormWindowState.Normal;
        }

        private void navigationbox_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        // Employee Management button Coding
        private void Emp_Managementbtn_Click(object sender, EventArgs e)
        {
            if(emd == null)
                emd = new Emp_Management.Emp_Management_Dashboard_uc();
            
            addusercontrol(emd);

            maximizebtn.Enabled = true;

            Dashboardbtn.Checked = false;
            Sellbtn.Checked = false;
            purchasebtn.Checked = false;
            itembtn.Checked = false;
            stockbtn.Checked = false;
            accountbtn.Checked = false;
            expensebtn.Checked = false;
            settingbtn.Checked = false;
            aboutbtn.Checked = false;
            Emp_Managementbtn.Checked = true;
        }


    }
}
