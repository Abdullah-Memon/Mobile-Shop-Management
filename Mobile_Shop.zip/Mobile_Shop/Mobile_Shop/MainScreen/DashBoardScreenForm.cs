﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Mobile_Shop.MainScreen
{
    public partial class DashBoardScreenForm : UserControl
    {
        public DashBoardScreenForm()
        {
            InitializeComponent();
        }
        void getuserinfo()
        {
            if (LoginForm.LoginScreen.personal_info.Rows.Count > 0)
            {
                empname.Text = LoginForm.LoginScreen.personal_info.Rows[0][1].ToString();
                empnumber.Text = LoginForm.LoginScreen.personal_info.Rows[0][2].ToString();
                
                //if (LoginForm.LoginScreen.personal_info.Rows[0][5] != null)
                //{
                //    byte[] pic = (byte[])LoginForm.LoginScreen.personal_info.Rows[0][5];
                //    MemoryStream ms = new MemoryStream(pic);
                //    emppic.Image = Image.FromStream(ms);
                //}
                
                emprole.Text = LoginForm.LoginScreen.personal_info.Rows[0][6].ToString();
            }

        }
        private void DashBoardScreenForm_Load(object sender, EventArgs e)
        {
            getuserinfo();
        }

        // upload pic functionality (Incomplete)
        private void Uploadpicbtn_Click(object sender, EventArgs e)
        {
            //using (OpenFileDialog opf = new OpenFileDialog())
            //{
            //    opf.Filter = "Image.File (*.jpg; *.jpeg; *.png; *.gif; *.bmp) | *.jpg; *.jpeg; *.png; *.gif; *.bmp";
            //    emppic.Image = Image.FromFile(opf.FileName);
            //    if (MessageBox.Show("Are you sure you want to change your profile picture?","Confirmation",MessageBoxButtons.YesNo) == DialogResult.Yes)
            //    {
                    
            //    }
            //}
        }
    }
}
