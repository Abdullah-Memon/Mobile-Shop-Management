﻿namespace Mobile_Shop.MainScreen
{
    partial class DashBoardScreenForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CircleProgressBar4 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.guna2CircleProgressBar3 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.guna2CircleProgressBar5 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.guna2CircleProgressBar1 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.userinfo = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.Uploadpicbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.empnumber = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.empname = new System.Windows.Forms.Label();
            this.emprole = new System.Windows.Forms.Label();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.emppic = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2GroupBox2.SuspendLayout();
            this.userinfo.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emppic)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.BorderRadius = 10;
            this.guna2GroupBox3.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(327, 183);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(730, 369);
            this.guna2GroupBox3.TabIndex = 21;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox2.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.BorderRadius = 10;
            this.guna2GroupBox2.Controls.Add(this.guna2CircleProgressBar4);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleProgressBar3);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleProgressBar5);
            this.guna2GroupBox2.Controls.Add(this.label10);
            this.guna2GroupBox2.Controls.Add(this.label9);
            this.guna2GroupBox2.Controls.Add(this.label8);
            this.guna2GroupBox2.Controls.Add(this.label7);
            this.guna2GroupBox2.Controls.Add(this.label3);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleProgressBar2);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleProgressBar1);
            this.guna2GroupBox2.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(327, 4);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(730, 176);
            this.guna2GroupBox2.TabIndex = 20;
            // 
            // guna2CircleProgressBar4
            // 
            this.guna2CircleProgressBar4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleProgressBar4.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2CircleProgressBar4.Location = new System.Drawing.Point(595, 21);
            this.guna2CircleProgressBar4.Name = "guna2CircleProgressBar4";
            this.guna2CircleProgressBar4.ProgressColor = System.Drawing.Color.SteelBlue;
            this.guna2CircleProgressBar4.ProgressColor2 = System.Drawing.Color.Cyan;
            this.guna2CircleProgressBar4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar4.ShadowDecoration.Parent = this.guna2CircleProgressBar4;
            this.guna2CircleProgressBar4.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar4.TabIndex = 0;
            // 
            // guna2CircleProgressBar3
            // 
            this.guna2CircleProgressBar3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2CircleProgressBar3.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2CircleProgressBar3.Location = new System.Drawing.Point(468, 20);
            this.guna2CircleProgressBar3.Name = "guna2CircleProgressBar3";
            this.guna2CircleProgressBar3.ProgressColor = System.Drawing.Color.SteelBlue;
            this.guna2CircleProgressBar3.ProgressColor2 = System.Drawing.Color.Cyan;
            this.guna2CircleProgressBar3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar3.ShadowDecoration.Parent = this.guna2CircleProgressBar3;
            this.guna2CircleProgressBar3.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar3.TabIndex = 0;
            // 
            // guna2CircleProgressBar5
            // 
            this.guna2CircleProgressBar5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2CircleProgressBar5.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2CircleProgressBar5.Location = new System.Drawing.Point(304, 20);
            this.guna2CircleProgressBar5.Name = "guna2CircleProgressBar5";
            this.guna2CircleProgressBar5.ProgressColor = System.Drawing.Color.SteelBlue;
            this.guna2CircleProgressBar5.ProgressColor2 = System.Drawing.Color.Cyan;
            this.guna2CircleProgressBar5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar5.ShadowDecoration.Parent = this.guna2CircleProgressBar5;
            this.guna2CircleProgressBar5.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar5.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label10.ForeColor = System.Drawing.Color.Indigo;
            this.label10.Location = new System.Drawing.Point(623, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 18);
            this.label10.TabIndex = 16;
            this.label10.Text = "Name";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.ForeColor = System.Drawing.Color.Indigo;
            this.label9.Location = new System.Drawing.Point(493, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 18);
            this.label9.TabIndex = 16;
            this.label9.Text = "Name";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(326, 142);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 18);
            this.label8.TabIndex = 16;
            this.label8.Text = "Name";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(159, 142);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 18);
            this.label7.TabIndex = 16;
            this.label7.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(28, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "Name";
            // 
            // guna2CircleProgressBar2
            // 
            this.guna2CircleProgressBar2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2CircleProgressBar2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2CircleProgressBar2.Location = new System.Drawing.Point(140, 20);
            this.guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            this.guna2CircleProgressBar2.ProgressColor = System.Drawing.Color.SteelBlue;
            this.guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.Cyan;
            this.guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar2.ShadowDecoration.Parent = this.guna2CircleProgressBar2;
            this.guna2CircleProgressBar2.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar2.TabIndex = 0;
            // 
            // guna2CircleProgressBar1
            // 
            this.guna2CircleProgressBar1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2CircleProgressBar1.Location = new System.Drawing.Point(12, 21);
            this.guna2CircleProgressBar1.Name = "guna2CircleProgressBar1";
            this.guna2CircleProgressBar1.ProgressColor = System.Drawing.Color.SteelBlue;
            this.guna2CircleProgressBar1.ProgressColor2 = System.Drawing.Color.Cyan;
            this.guna2CircleProgressBar1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar1.ShadowDecoration.Parent = this.guna2CircleProgressBar1;
            this.guna2CircleProgressBar1.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar1.TabIndex = 0;
            // 
            // userinfo
            // 
            this.userinfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.userinfo.BackColor = System.Drawing.Color.Transparent;
            this.userinfo.BorderColor = System.Drawing.Color.Indigo;
            this.userinfo.BorderRadius = 10;
            this.userinfo.BorderThickness = 1;
            this.userinfo.Controls.Add(this.Uploadpicbtn);
            this.userinfo.Controls.Add(this.guna2GroupBox1);
            this.userinfo.Controls.Add(this.guna2GradientButton1);
            this.userinfo.Controls.Add(this.emppic);
            this.userinfo.FillColor = System.Drawing.Color.White;
            this.userinfo.FillColor2 = System.Drawing.Color.White;
            this.userinfo.Location = new System.Drawing.Point(8, 0);
            this.userinfo.Name = "userinfo";
            this.userinfo.ShadowDecoration.Parent = this.userinfo;
            this.userinfo.Size = new System.Drawing.Size(313, 552);
            this.userinfo.TabIndex = 19;
            // 
            // Uploadpicbtn
            // 
            this.Uploadpicbtn.CheckedState.Parent = this.Uploadpicbtn;
            this.Uploadpicbtn.CustomImages.Parent = this.Uploadpicbtn;
            this.Uploadpicbtn.FillColor = System.Drawing.Color.Indigo;
            this.Uploadpicbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Uploadpicbtn.ForeColor = System.Drawing.Color.White;
            this.Uploadpicbtn.HoverState.Parent = this.Uploadpicbtn;
            this.Uploadpicbtn.Location = new System.Drawing.Point(191, 132);
            this.Uploadpicbtn.Name = "Uploadpicbtn";
            this.Uploadpicbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Uploadpicbtn.ShadowDecoration.Parent = this.Uploadpicbtn;
            this.Uploadpicbtn.Size = new System.Drawing.Size(50, 50);
            this.Uploadpicbtn.TabIndex = 23;
            this.Uploadpicbtn.Text = "U";
            this.Uploadpicbtn.UseTransparentBackground = true;
            this.Uploadpicbtn.Click += new System.EventHandler(this.Uploadpicbtn_Click);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.BorderRadius = 10;
            this.guna2GroupBox1.Controls.Add(this.empnumber);
            this.guna2GroupBox1.Controls.Add(this.label13);
            this.guna2GroupBox1.Controls.Add(this.label14);
            this.guna2GroupBox1.Controls.Add(this.label15);
            this.guna2GroupBox1.Controls.Add(this.empname);
            this.guna2GroupBox1.Controls.Add(this.emprole);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 201);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(295, 246);
            this.guna2GroupBox1.TabIndex = 22;
            // 
            // empnumber
            // 
            this.empnumber.AutoSize = true;
            this.empnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.empnumber.ForeColor = System.Drawing.Color.Indigo;
            this.empnumber.Location = new System.Drawing.Point(100, 113);
            this.empnumber.Name = "empnumber";
            this.empnumber.Size = new System.Drawing.Size(23, 18);
            this.empnumber.TabIndex = 16;
            this.empnumber.Text = "---";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label13.ForeColor = System.Drawing.Color.Indigo;
            this.label13.Location = new System.Drawing.Point(14, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 18);
            this.label13.TabIndex = 16;
            this.label13.Text = "Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(14, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(39, 18);
            this.label14.TabIndex = 16;
            this.label14.Text = "Role";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label15.ForeColor = System.Drawing.Color.Indigo;
            this.label15.Location = new System.Drawing.Point(14, 113);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 18);
            this.label15.TabIndex = 16;
            this.label15.Text = "Mobile #";
            // 
            // empname
            // 
            this.empname.AutoSize = true;
            this.empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.empname.ForeColor = System.Drawing.Color.Indigo;
            this.empname.Location = new System.Drawing.Point(100, 64);
            this.empname.Name = "empname";
            this.empname.Size = new System.Drawing.Size(23, 18);
            this.empname.TabIndex = 16;
            this.empname.Text = "---";
            // 
            // emprole
            // 
            this.emprole.AutoSize = true;
            this.emprole.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.emprole.ForeColor = System.Drawing.Color.Indigo;
            this.emprole.Location = new System.Drawing.Point(100, 15);
            this.emprole.Name = "emprole";
            this.emprole.Size = new System.Drawing.Size(23, 18);
            this.emprole.TabIndex = 16;
            this.emprole.Text = "---";
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(87, 479);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(150, 45);
            this.guna2GradientButton1.TabIndex = 13;
            this.guna2GradientButton1.Text = "Setting";
            // 
            // emppic
            // 
            this.emppic.BackColor = System.Drawing.Color.Transparent;
            this.emppic.FillColor = System.Drawing.Color.WhiteSmoke;
            this.emppic.Location = new System.Drawing.Point(91, 15);
            this.emppic.Name = "emppic";
            this.emppic.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.emppic.ShadowDecoration.Parent = this.emppic;
            this.emppic.Size = new System.Drawing.Size(150, 150);
            this.emppic.TabIndex = 15;
            this.emppic.TabStop = false;
            // 
            // DashBoardScreenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.guna2GroupBox3);
            this.Controls.Add(this.guna2GroupBox2);
            this.Controls.Add(this.userinfo);
            this.Name = "DashBoardScreenForm";
            this.Size = new System.Drawing.Size(1060, 555);
            this.Load += new System.EventHandler(this.DashBoardScreenForm_Load);
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            this.userinfo.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emppic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar4;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar3;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar1;
        private Guna.UI2.WinForms.Guna2GradientPanel userinfo;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox emppic;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Label empnumber;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label empname;
        private System.Windows.Forms.Label emprole;
        private Guna.UI2.WinForms.Guna2CircleButton Uploadpicbtn;
    }
}
