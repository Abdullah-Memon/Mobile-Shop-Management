﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Emp_Management.EMP_Promotion
{
    public partial class Promotion_uc : UserControl
    {
        public Promotion_uc()
        {
            InitializeComponent();
        }

        // Function to show account need promotion
        private void GetData(int a = 1)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable data = new DataTable();

                SqlCommand cmd = new SqlCommand("findEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@role", a));

                data.Load(cmd.ExecuteReader());

                DB.con.Close();

                //setting up new data
                if (a != 1)
                    PromoteList.DataSource = data;
                else
                    DowngradeList.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while founding accounts please try again " + ex.ToString(), "ERROR");
            }
        }

        private void Promotion_uc_Load(object sender, EventArgs e)
        {
            GetData(2);
            DowngradeList.Hide();
        }

        private void downgrade_Click(object sender, EventArgs e)
        {
            PromoteList.Hide();
            DowngradeList.Show();
            GetData(1);
        }

        private void promote_Click(object sender, EventArgs e)
        {
            DowngradeList.Hide();
            PromoteList.Show();
            GetData(2);
        }

        // promotion button coding
        private void PromoteList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                if (PromoteList.Rows[e.RowIndex].Cells["EmployeeID"].Value.ToString() == LoginForm.LoginScreen.personal_info.Rows[0][0].ToString())
                    MessageBox.Show("You cannot change your account type");
                else
                {
                    try
                    {
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        SqlCommand cmd = new SqlCommand("UpdatePromotion", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@data", 0));
                        cmd.Parameters.Add(new SqlParameter("@empid", PromoteList.Rows[e.RowIndex].Cells["EmployeeID"].Value));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();

                        //refreshList
                        GetData(2);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        // Downgrade button Coding
        private void DowngradeList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 )
            {
                if (DowngradeList.Rows[e.RowIndex].Cells["downgradeid"].Value.ToString() == LoginForm.LoginScreen.personal_info.Rows[0][0].ToString())
                    MessageBox.Show("You cannot change your account type");
                else
                {
                    try
                    {
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        SqlCommand cmd = new SqlCommand("UpdatePromotion", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@data", 1));
                        cmd.Parameters.Add(new SqlParameter("@empid", DowngradeList.Rows[e.RowIndex].Cells["downgradeid"].Value));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();

                        //refreshList
                        GetData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.emd);
        }
    }
}
