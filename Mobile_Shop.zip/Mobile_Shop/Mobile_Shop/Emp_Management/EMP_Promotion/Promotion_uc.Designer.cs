﻿namespace Mobile_Shop.Emp_Management.EMP_Promotion
{
    partial class Promotion_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.backbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.downgrade = new Guna.UI2.WinForms.Guna2GradientButton();
            this.promote = new Guna.UI2.WinForms.Guna2GradientButton();
            this.PromoteList = new Guna.UI2.WinForms.Guna2DataGridView();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.E_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Promotebtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DowngradeList = new Guna.UI2.WinForms.Guna2DataGridView();
            this.downgradeid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Username1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Downgradebtn = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.PromoteList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DowngradeList)).BeginInit();
            this.SuspendLayout();
            // 
            // backbtn
            // 
            this.backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.BorderColor = System.Drawing.Color.White;
            this.backbtn.BorderRadius = 10;
            this.backbtn.BorderThickness = 2;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(966, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(91, 36);
            this.backbtn.TabIndex = 20;
            this.backbtn.Text = "back";
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // downgrade
            // 
            this.downgrade.BackColor = System.Drawing.Color.Transparent;
            this.downgrade.BorderColor = System.Drawing.Color.White;
            this.downgrade.BorderRadius = 10;
            this.downgrade.BorderThickness = 2;
            this.downgrade.CheckedState.Parent = this.downgrade;
            this.downgrade.CustomImages.Parent = this.downgrade;
            this.downgrade.FillColor = System.Drawing.Color.Indigo;
            this.downgrade.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.downgrade.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.downgrade.ForeColor = System.Drawing.Color.White;
            this.downgrade.HoverState.Parent = this.downgrade;
            this.downgrade.Location = new System.Drawing.Point(156, 3);
            this.downgrade.Name = "downgrade";
            this.downgrade.ShadowDecoration.Parent = this.downgrade;
            this.downgrade.Size = new System.Drawing.Size(150, 36);
            this.downgrade.TabIndex = 19;
            this.downgrade.Text = "Down Grade";
            this.downgrade.Click += new System.EventHandler(this.downgrade_Click);
            // 
            // promote
            // 
            this.promote.BackColor = System.Drawing.Color.Transparent;
            this.promote.BorderColor = System.Drawing.Color.White;
            this.promote.BorderRadius = 10;
            this.promote.BorderThickness = 2;
            this.promote.CheckedState.Parent = this.promote;
            this.promote.CustomImages.Parent = this.promote;
            this.promote.FillColor = System.Drawing.Color.Indigo;
            this.promote.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.promote.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.promote.ForeColor = System.Drawing.Color.White;
            this.promote.HoverState.Parent = this.promote;
            this.promote.Location = new System.Drawing.Point(0, 3);
            this.promote.Name = "promote";
            this.promote.ShadowDecoration.Parent = this.promote;
            this.promote.Size = new System.Drawing.Size(150, 36);
            this.promote.TabIndex = 18;
            this.promote.Text = "Promote";
            this.promote.Click += new System.EventHandler(this.promote_Click);
            // 
            // PromoteList
            // 
            this.PromoteList.AllowUserToAddRows = false;
            this.PromoteList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.PromoteList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.PromoteList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PromoteList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PromoteList.BackgroundColor = System.Drawing.Color.White;
            this.PromoteList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PromoteList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.PromoteList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PromoteList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.PromoteList.ColumnHeadersHeight = 21;
            this.PromoteList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.E_Picture,
            this.E_Name,
            this.E_CNIC,
            this.E_Role,
            this.E_Mobile,
            this.E_Email,
            this.E_Address,
            this.Username,
            this.Password,
            this.Promotebtn});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PromoteList.DefaultCellStyle = dataGridViewCellStyle3;
            this.PromoteList.EnableHeadersVisualStyles = false;
            this.PromoteList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.PromoteList.Location = new System.Drawing.Point(3, 45);
            this.PromoteList.Name = "PromoteList";
            this.PromoteList.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PromoteList.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.PromoteList.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.PromoteList.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.PromoteList.RowTemplate.Height = 70;
            this.PromoteList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PromoteList.Size = new System.Drawing.Size(1054, 506);
            this.PromoteList.TabIndex = 30;
            this.PromoteList.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.PromoteList.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.PromoteList.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.PromoteList.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.PromoteList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.PromoteList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.PromoteList.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.PromoteList.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.PromoteList.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.PromoteList.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.PromoteList.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PromoteList.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.PromoteList.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.PromoteList.ThemeStyle.HeaderStyle.Height = 21;
            this.PromoteList.ThemeStyle.ReadOnly = true;
            this.PromoteList.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.PromoteList.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.PromoteList.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PromoteList.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.PromoteList.ThemeStyle.RowsStyle.Height = 70;
            this.PromoteList.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.PromoteList.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.PromoteList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PromoteList_CellContentClick);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EMPID";
            this.EmployeeID.HeaderText = "ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.ReadOnly = true;
            this.EmployeeID.Visible = false;
            // 
            // E_Picture
            // 
            this.E_Picture.DataPropertyName = "EMP_Picture";
            this.E_Picture.HeaderText = "Picture";
            this.E_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.E_Picture.Name = "E_Picture";
            this.E_Picture.ReadOnly = true;
            // 
            // E_Name
            // 
            this.E_Name.DataPropertyName = "EMP_Name";
            this.E_Name.HeaderText = "Name";
            this.E_Name.Name = "E_Name";
            this.E_Name.ReadOnly = true;
            // 
            // E_CNIC
            // 
            this.E_CNIC.DataPropertyName = "EMP_CNIC";
            this.E_CNIC.HeaderText = "CNIC";
            this.E_CNIC.Name = "E_CNIC";
            this.E_CNIC.ReadOnly = true;
            // 
            // E_Role
            // 
            this.E_Role.DataPropertyName = "EMP_Role";
            this.E_Role.HeaderText = "Role";
            this.E_Role.Name = "E_Role";
            this.E_Role.ReadOnly = true;
            // 
            // E_Mobile
            // 
            this.E_Mobile.DataPropertyName = "EMP_Mobile";
            this.E_Mobile.HeaderText = "Mobile";
            this.E_Mobile.Name = "E_Mobile";
            this.E_Mobile.ReadOnly = true;
            // 
            // E_Email
            // 
            this.E_Email.DataPropertyName = "EMP_EmailAddress";
            this.E_Email.HeaderText = "Email";
            this.E_Email.Name = "E_Email";
            this.E_Email.ReadOnly = true;
            // 
            // E_Address
            // 
            this.E_Address.DataPropertyName = "EMP_Address";
            this.E_Address.HeaderText = "Address";
            this.E_Address.Name = "E_Address";
            this.E_Address.ReadOnly = true;
            // 
            // Username
            // 
            this.Username.DataPropertyName = "EMP_Username";
            this.Username.HeaderText = "Username";
            this.Username.Name = "Username";
            this.Username.ReadOnly = true;
            this.Username.Visible = false;
            // 
            // Password
            // 
            this.Password.DataPropertyName = "EMP_Password";
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            this.Password.Visible = false;
            // 
            // Promotebtn
            // 
            this.Promotebtn.FillWeight = 50F;
            this.Promotebtn.HeaderText = "Promote";
            this.Promotebtn.Name = "Promotebtn";
            this.Promotebtn.ReadOnly = true;
            this.Promotebtn.Text = "Promote";
            this.Promotebtn.UseColumnTextForButtonValue = true;
            // 
            // DowngradeList
            // 
            this.DowngradeList.AllowUserToAddRows = false;
            this.DowngradeList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DowngradeList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DowngradeList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DowngradeList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DowngradeList.BackgroundColor = System.Drawing.Color.White;
            this.DowngradeList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DowngradeList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DowngradeList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DowngradeList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.DowngradeList.ColumnHeadersHeight = 21;
            this.DowngradeList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.downgradeid,
            this.dataGridViewImageColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.Username1,
            this.Password1,
            this.Downgradebtn});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DowngradeList.DefaultCellStyle = dataGridViewCellStyle8;
            this.DowngradeList.EnableHeadersVisualStyles = false;
            this.DowngradeList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DowngradeList.Location = new System.Drawing.Point(3, 45);
            this.DowngradeList.Name = "DowngradeList";
            this.DowngradeList.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DowngradeList.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.DowngradeList.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.DowngradeList.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DowngradeList.RowTemplate.Height = 70;
            this.DowngradeList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DowngradeList.Size = new System.Drawing.Size(1054, 509);
            this.DowngradeList.TabIndex = 31;
            this.DowngradeList.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.DowngradeList.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DowngradeList.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DowngradeList.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DowngradeList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DowngradeList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DowngradeList.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DowngradeList.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DowngradeList.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.DowngradeList.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DowngradeList.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DowngradeList.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DowngradeList.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DowngradeList.ThemeStyle.HeaderStyle.Height = 21;
            this.DowngradeList.ThemeStyle.ReadOnly = true;
            this.DowngradeList.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.DowngradeList.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DowngradeList.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DowngradeList.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DowngradeList.ThemeStyle.RowsStyle.Height = 70;
            this.DowngradeList.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.DowngradeList.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DowngradeList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DowngradeList_CellContentClick);
            // 
            // downgradeid
            // 
            this.downgradeid.DataPropertyName = "EMPID";
            this.downgradeid.HeaderText = "ID";
            this.downgradeid.Name = "downgradeid";
            this.downgradeid.ReadOnly = true;
            this.downgradeid.Visible = false;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.DataPropertyName = "EMP_Picture";
            this.dataGridViewImageColumn1.HeaderText = "Picture";
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "EMP_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "EMP_CNIC";
            this.dataGridViewTextBoxColumn3.HeaderText = "CNIC";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "EMP_Role";
            this.dataGridViewTextBoxColumn4.HeaderText = "Role";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "EMP_Mobile";
            this.dataGridViewTextBoxColumn5.HeaderText = "Mobile";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "EMP_EmailAddress";
            this.dataGridViewTextBoxColumn6.HeaderText = "Email";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "EMP_Address";
            this.dataGridViewTextBoxColumn7.HeaderText = "Address";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // Username1
            // 
            this.Username1.DataPropertyName = "EMP_Username";
            this.Username1.HeaderText = "Username";
            this.Username1.Name = "Username1";
            this.Username1.ReadOnly = true;
            this.Username1.Visible = false;
            // 
            // Password1
            // 
            this.Password1.DataPropertyName = "EMP_Password";
            this.Password1.HeaderText = "Password";
            this.Password1.Name = "Password1";
            this.Password1.ReadOnly = true;
            this.Password1.Visible = false;
            // 
            // Downgradebtn
            // 
            this.Downgradebtn.FillWeight = 50F;
            this.Downgradebtn.HeaderText = "Downgrade";
            this.Downgradebtn.Name = "Downgradebtn";
            this.Downgradebtn.ReadOnly = true;
            this.Downgradebtn.Text = "Downgrade";
            this.Downgradebtn.UseColumnTextForButtonValue = true;
            // 
            // Promotion_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.DowngradeList);
            this.Controls.Add(this.PromoteList);
            this.Controls.Add(this.promote);
            this.Controls.Add(this.downgrade);
            this.Controls.Add(this.backbtn);
            this.Name = "Promotion_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.Promotion_uc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PromoteList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DowngradeList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientButton backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton downgrade;
        private Guna.UI2.WinForms.Guna2GradientButton promote;
        private Guna.UI2.WinForms.Guna2DataGridView DowngradeList;
        private Guna.UI2.WinForms.Guna2DataGridView PromoteList;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewImageColumn E_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewButtonColumn Promotebtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn downgradeid;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password1;
        private System.Windows.Forms.DataGridViewButtonColumn Downgradebtn;
    }
}
