﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Emp_Management.EMP_Salary
{
    public partial class Salary_uc : UserControl
    {
        public Salary_uc()
        {
            InitializeComponent();
        }
        // Global Variables
        SqlCommand cmd;
        DataTable data;

        // Function to get Payment type information
        private void GetPaymentType()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));

                dt.Load(cmd.ExecuteReader());

                PaymentTypebox.DataSource = dt;
                PaymentTypebox.ValueMember = "PID";
                PaymentTypebox.DisplayMember = "P_Type";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }
        
        // Function to get none Salary Paid Staff
        private void GetData(int a = 0)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                data = new DataTable();

                cmd = new SqlCommand("SalaryDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data",a));
                cmd.Parameters.Add(new SqlParameter("@date", salaryDate.Text));
                data.Load(cmd.ExecuteReader());
                DB.con.Close();

                if (a != 0)
                    SalaryList.DataSource = data;
                else
                    SalaryPaidList.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Function to get Month Name
        private void GetMonth(string month)
        {
            if (!string.IsNullOrEmpty(month) || !string.IsNullOrWhiteSpace(month))
            {
                switch (month)
                {
                    case "1":
                        label1.Text = "January";
                        break;
                    case "2":
                        label1.Text = "February";
                        break;
                    case "3":
                        label1.Text = "March";
                        break;
                    case "4":
                        label1.Text = "April";
                        break;
                    case "5":
                        label1.Text = "May";
                        break;
                    case "6":
                        label1.Text = "June";
                        break;
                    case "7":
                        label1.Text = "July";
                        break;
                    case "8":
                        label1.Text = "August";
                        break;
                    case "9":
                        label1.Text = "September";
                        break;
                    case "10":
                        label1.Text = "October";
                        break;
                    case "11":
                        label1.Text = "November";
                        break;
                    case "12":
                        label1.Text = "December";
                        break;
                    default:
                        label1.Text = "Error";
                        break;
                }
            }
        }

        // Main Load Function
        private void Salary_uc_Load(object sender, EventArgs e)
        {
            salaryDate.CustomFormat = "MM/yyyy";
            salaryDate.Text = DateTime.Now.ToString("MM/yyyy");
            GetMonth(DateTime.Now.Month.ToString());

            GetData(1);
            GetPaymentType();

            SalaryPaidList.Hide();
            SalaryList.Focus();

        }

        // salary giving list
        private void salarylistbtn_Click(object sender, EventArgs e)
        {
            SalaryPaidList.Hide();
            SalaryList.Show();

            //refreshlist
            GetData(1);
        }

        // salary already paid salary list
        private void paidSalarybtn_Click(object sender, EventArgs e)
        {
            SalaryList.Hide();
            SalaryPaidList.Show();
            
            // Refresh List
            GetData();
        }

        // Grid view button Coding
        private void SalaryList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("AddSalary", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@empid", SalaryList.Rows[e.RowIndex].Cells["EmployeeID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@date", salaryDate.Text));
                    cmd.Parameters.Add(new SqlParameter("@salary", Convert.ToDecimal(SalaryList.Rows[e.RowIndex].Cells["Salary"].Value)));
                    cmd.Parameters.Add(new SqlParameter("@pid", PaymentTypebox.SelectedValue));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // Refresh List
                    GetData(1);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // Back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.emd);
        }

        // salary already paid list coding
        private void SalaryPaidList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("RemoveSalary", DB.con) { CommandType = CommandType.StoredProcedure};
                    cmd.Parameters.Add(new SqlParameter("@empid", SalaryPaidList.Rows[e.RowIndex].Cells["EMPID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@date", salaryDate.Text));
                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // Refreshing list
                    GetData();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // changing data coding
        private void salaryDate_ValueChanged(object sender, EventArgs e)
        {
            GetData();
            GetData(1);
            GetMonth(salaryDate.Value.Month.ToString());
        }
    }
}
