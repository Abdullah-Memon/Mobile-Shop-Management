﻿namespace Mobile_Shop.Emp_Management.EMP_Salary
{
    partial class Salary_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PaymentTypebox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.salaryDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.SalaryList = new Guna.UI2.WinForms.Guna2DataGridView();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.E_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Paybtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.backbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.paidSalarybtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.salarylistbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.SalaryPaidList = new Guna.UI2.WinForms.Guna2DataGridView();
            this.EMPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salaryPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reset = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryPaidList)).BeginInit();
            this.SuspendLayout();
            // 
            // PaymentTypebox
            // 
            this.PaymentTypebox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PaymentTypebox.BackColor = System.Drawing.Color.Transparent;
            this.PaymentTypebox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.PaymentTypebox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypebox.FocusedColor = System.Drawing.Color.Empty;
            this.PaymentTypebox.FocusedState.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PaymentTypebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.PaymentTypebox.FormattingEnabled = true;
            this.PaymentTypebox.HoverState.Parent = this.PaymentTypebox;
            this.PaymentTypebox.ItemHeight = 30;
            this.PaymentTypebox.ItemsAppearance.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Location = new System.Drawing.Point(486, 3);
            this.PaymentTypebox.Name = "PaymentTypebox";
            this.PaymentTypebox.ShadowDecoration.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Size = new System.Drawing.Size(206, 36);
            this.PaymentTypebox.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(412, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Pay Via";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(329, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 33;
            this.label1.Text = "month";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(698, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 25);
            this.label2.TabIndex = 33;
            this.label2.Text = "Date";
            // 
            // salaryDate
            // 
            this.salaryDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.salaryDate.CheckedState.Parent = this.salaryDate;
            this.salaryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.salaryDate.HoverState.Parent = this.salaryDate;
            this.salaryDate.Location = new System.Drawing.Point(753, 4);
            this.salaryDate.MaxDate = new System.DateTime(2200, 1, 1, 0, 0, 0, 0);
            this.salaryDate.MinDate = new System.DateTime(1990, 1, 1, 0, 0, 0, 0);
            this.salaryDate.Name = "salaryDate";
            this.salaryDate.ShadowDecoration.Parent = this.salaryDate;
            this.salaryDate.Size = new System.Drawing.Size(200, 35);
            this.salaryDate.TabIndex = 32;
            this.salaryDate.Value = new System.DateTime(2022, 10, 30, 0, 0, 0, 0);
            this.salaryDate.ValueChanged += new System.EventHandler(this.salaryDate_ValueChanged);
            // 
            // SalaryList
            // 
            this.SalaryList.AllowUserToAddRows = false;
            this.SalaryList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SalaryList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.SalaryList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SalaryList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SalaryList.BackgroundColor = System.Drawing.Color.White;
            this.SalaryList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalaryList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SalaryList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalaryList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.SalaryList.ColumnHeadersHeight = 21;
            this.SalaryList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.E_Picture,
            this.E_Name,
            this.E_CNIC,
            this.E_Role,
            this.E_Mobile,
            this.E_Email,
            this.E_Address,
            this.Salary,
            this.Paybtn});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SalaryList.DefaultCellStyle = dataGridViewCellStyle13;
            this.SalaryList.EnableHeadersVisualStyles = false;
            this.SalaryList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SalaryList.Location = new System.Drawing.Point(0, 45);
            this.SalaryList.Name = "SalaryList";
            this.SalaryList.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalaryList.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.SalaryList.RowHeadersVisible = false;
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            this.SalaryList.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.SalaryList.RowTemplate.Height = 70;
            this.SalaryList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SalaryList.Size = new System.Drawing.Size(1060, 509);
            this.SalaryList.TabIndex = 30;
            this.SalaryList.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.SalaryList.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SalaryList.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.SalaryList.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.SalaryList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.SalaryList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.SalaryList.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.SalaryList.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SalaryList.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.SalaryList.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SalaryList.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SalaryList.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.SalaryList.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.SalaryList.ThemeStyle.HeaderStyle.Height = 21;
            this.SalaryList.ThemeStyle.ReadOnly = true;
            this.SalaryList.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.SalaryList.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SalaryList.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SalaryList.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.SalaryList.ThemeStyle.RowsStyle.Height = 70;
            this.SalaryList.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.SalaryList.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.SalaryList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SalaryList_CellContentClick);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EMPID";
            this.EmployeeID.HeaderText = "ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.ReadOnly = true;
            this.EmployeeID.Visible = false;
            // 
            // E_Picture
            // 
            this.E_Picture.DataPropertyName = "EMP_Picture";
            this.E_Picture.FillWeight = 60F;
            this.E_Picture.HeaderText = "Picture";
            this.E_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.E_Picture.Name = "E_Picture";
            this.E_Picture.ReadOnly = true;
            // 
            // E_Name
            // 
            this.E_Name.DataPropertyName = "EMP_Name";
            this.E_Name.HeaderText = "Name";
            this.E_Name.Name = "E_Name";
            this.E_Name.ReadOnly = true;
            // 
            // E_CNIC
            // 
            this.E_CNIC.DataPropertyName = "EMP_CNIC";
            this.E_CNIC.HeaderText = "CNIC";
            this.E_CNIC.Name = "E_CNIC";
            this.E_CNIC.ReadOnly = true;
            // 
            // E_Role
            // 
            this.E_Role.DataPropertyName = "EMP_Role";
            this.E_Role.HeaderText = "Role";
            this.E_Role.Name = "E_Role";
            this.E_Role.ReadOnly = true;
            // 
            // E_Mobile
            // 
            this.E_Mobile.DataPropertyName = "EMP_Mobile";
            this.E_Mobile.HeaderText = "Mobile";
            this.E_Mobile.Name = "E_Mobile";
            this.E_Mobile.ReadOnly = true;
            // 
            // E_Email
            // 
            this.E_Email.DataPropertyName = "EMP_EmailAddress";
            this.E_Email.HeaderText = "Email";
            this.E_Email.Name = "E_Email";
            this.E_Email.ReadOnly = true;
            // 
            // E_Address
            // 
            this.E_Address.DataPropertyName = "EMP_Address";
            this.E_Address.HeaderText = "Address";
            this.E_Address.Name = "E_Address";
            this.E_Address.ReadOnly = true;
            // 
            // Salary
            // 
            this.Salary.DataPropertyName = "EMP_Salary";
            this.Salary.HeaderText = "Salary";
            this.Salary.Name = "Salary";
            this.Salary.ReadOnly = true;
            // 
            // Paybtn
            // 
            this.Paybtn.FillWeight = 50F;
            this.Paybtn.HeaderText = "Pay Salary";
            this.Paybtn.Name = "Paybtn";
            this.Paybtn.ReadOnly = true;
            this.Paybtn.Text = "Pay";
            this.Paybtn.UseColumnTextForButtonValue = true;
            // 
            // backbtn
            // 
            this.backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.BorderColor = System.Drawing.Color.White;
            this.backbtn.BorderRadius = 10;
            this.backbtn.BorderThickness = 2;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(966, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(91, 36);
            this.backbtn.TabIndex = 20;
            this.backbtn.Text = "back";
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // paidSalarybtn
            // 
            this.paidSalarybtn.BackColor = System.Drawing.Color.Transparent;
            this.paidSalarybtn.BorderColor = System.Drawing.Color.White;
            this.paidSalarybtn.BorderRadius = 10;
            this.paidSalarybtn.BorderThickness = 2;
            this.paidSalarybtn.CheckedState.Parent = this.paidSalarybtn;
            this.paidSalarybtn.CustomImages.Parent = this.paidSalarybtn;
            this.paidSalarybtn.FillColor = System.Drawing.Color.Indigo;
            this.paidSalarybtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.paidSalarybtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.paidSalarybtn.ForeColor = System.Drawing.Color.White;
            this.paidSalarybtn.HoverState.Parent = this.paidSalarybtn;
            this.paidSalarybtn.Location = new System.Drawing.Point(159, 3);
            this.paidSalarybtn.Name = "paidSalarybtn";
            this.paidSalarybtn.ShadowDecoration.Parent = this.paidSalarybtn;
            this.paidSalarybtn.Size = new System.Drawing.Size(150, 36);
            this.paidSalarybtn.TabIndex = 19;
            this.paidSalarybtn.Text = "Paid Salary";
            this.paidSalarybtn.Click += new System.EventHandler(this.paidSalarybtn_Click);
            // 
            // salarylistbtn
            // 
            this.salarylistbtn.BackColor = System.Drawing.Color.Transparent;
            this.salarylistbtn.BorderColor = System.Drawing.Color.White;
            this.salarylistbtn.BorderRadius = 10;
            this.salarylistbtn.BorderThickness = 2;
            this.salarylistbtn.CheckedState.Parent = this.salarylistbtn;
            this.salarylistbtn.CustomImages.Parent = this.salarylistbtn;
            this.salarylistbtn.FillColor = System.Drawing.Color.Indigo;
            this.salarylistbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.salarylistbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.salarylistbtn.ForeColor = System.Drawing.Color.White;
            this.salarylistbtn.HoverState.Parent = this.salarylistbtn;
            this.salarylistbtn.Location = new System.Drawing.Point(3, 3);
            this.salarylistbtn.Name = "salarylistbtn";
            this.salarylistbtn.ShadowDecoration.Parent = this.salarylistbtn;
            this.salarylistbtn.Size = new System.Drawing.Size(150, 36);
            this.salarylistbtn.TabIndex = 18;
            this.salarylistbtn.Text = "Pay Salary";
            this.salarylistbtn.Click += new System.EventHandler(this.salarylistbtn_Click);
            // 
            // SalaryPaidList
            // 
            this.SalaryPaidList.AllowUserToAddRows = false;
            this.SalaryPaidList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SalaryPaidList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.SalaryPaidList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SalaryPaidList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SalaryPaidList.BackgroundColor = System.Drawing.Color.White;
            this.SalaryPaidList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalaryPaidList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SalaryPaidList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalaryPaidList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.SalaryPaidList.ColumnHeadersHeight = 21;
            this.SalaryPaidList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EMPID,
            this.dataGridViewImageColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.salaryPaid,
            this.Reset});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SalaryPaidList.DefaultCellStyle = dataGridViewCellStyle18;
            this.SalaryPaidList.EnableHeadersVisualStyles = false;
            this.SalaryPaidList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SalaryPaidList.Location = new System.Drawing.Point(0, 45);
            this.SalaryPaidList.Name = "SalaryPaidList";
            this.SalaryPaidList.ReadOnly = true;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalaryPaidList.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.SalaryPaidList.RowHeadersVisible = false;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            this.SalaryPaidList.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.SalaryPaidList.RowTemplate.Height = 70;
            this.SalaryPaidList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SalaryPaidList.Size = new System.Drawing.Size(1060, 509);
            this.SalaryPaidList.TabIndex = 31;
            this.SalaryPaidList.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.SalaryPaidList.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SalaryPaidList.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.SalaryPaidList.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.SalaryPaidList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.SalaryPaidList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.SalaryPaidList.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.SalaryPaidList.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SalaryPaidList.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.SalaryPaidList.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SalaryPaidList.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SalaryPaidList.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.SalaryPaidList.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.SalaryPaidList.ThemeStyle.HeaderStyle.Height = 21;
            this.SalaryPaidList.ThemeStyle.ReadOnly = true;
            this.SalaryPaidList.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.SalaryPaidList.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SalaryPaidList.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SalaryPaidList.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.SalaryPaidList.ThemeStyle.RowsStyle.Height = 70;
            this.SalaryPaidList.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.SalaryPaidList.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.SalaryPaidList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SalaryPaidList_CellContentClick);
            // 
            // EMPID
            // 
            this.EMPID.DataPropertyName = "EMPID";
            this.EMPID.HeaderText = "ID";
            this.EMPID.Name = "EMPID";
            this.EMPID.ReadOnly = true;
            this.EMPID.Visible = false;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.DataPropertyName = "EMP_Picture";
            this.dataGridViewImageColumn1.FillWeight = 60F;
            this.dataGridViewImageColumn1.HeaderText = "Picture";
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "EMP_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "EMP_CNIC";
            this.dataGridViewTextBoxColumn3.HeaderText = "CNIC";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "EMP_Role";
            this.dataGridViewTextBoxColumn4.HeaderText = "Role";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "EMP_Mobile";
            this.dataGridViewTextBoxColumn5.HeaderText = "Mobile";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "EMP_EmailAddress";
            this.dataGridViewTextBoxColumn6.HeaderText = "Email";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "EMP_Address";
            this.dataGridViewTextBoxColumn7.HeaderText = "Address";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // salaryPaid
            // 
            this.salaryPaid.DataPropertyName = "SalaryPaid";
            this.salaryPaid.FillWeight = 50F;
            this.salaryPaid.HeaderText = "Paid";
            this.salaryPaid.Name = "salaryPaid";
            this.salaryPaid.ReadOnly = true;
            this.salaryPaid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.salaryPaid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Reset
            // 
            this.Reset.FillWeight = 50F;
            this.Reset.HeaderText = "Reset";
            this.Reset.Name = "Reset";
            this.Reset.ReadOnly = true;
            this.Reset.Text = "Reset";
            this.Reset.UseColumnTextForButtonValue = true;
            // 
            // Salary_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.SalaryPaidList);
            this.Controls.Add(this.SalaryList);
            this.Controls.Add(this.salaryDate);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PaymentTypebox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.salarylistbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.paidSalarybtn);
            this.Name = "Salary_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.Salary_uc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SalaryList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryPaidList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2DateTimePicker salaryDate;
        private Guna.UI2.WinForms.Guna2DataGridView SalaryList;
        private Guna.UI2.WinForms.Guna2GradientButton backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton paidSalarybtn;
        private Guna.UI2.WinForms.Guna2GradientButton salarylistbtn;
        private Guna.UI2.WinForms.Guna2DataGridView SalaryPaidList;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPID;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn salaryPaid;
        private System.Windows.Forms.DataGridViewButtonColumn Reset;
        private Guna.UI2.WinForms.Guna2ComboBox PaymentTypebox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewImageColumn E_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salary;
        private System.Windows.Forms.DataGridViewButtonColumn Paybtn;
    }
}
