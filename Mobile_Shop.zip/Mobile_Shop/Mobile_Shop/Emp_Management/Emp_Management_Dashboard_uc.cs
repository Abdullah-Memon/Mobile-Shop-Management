﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.Emp_Management
{
    public partial class Emp_Management_Dashboard_uc : UserControl
    {
        public Emp_Management_Dashboard_uc()
        {
            InitializeComponent();
        }
        // Screens to Load
        EMP_Promotion.Promotion_uc p;
        EMP_Salary.Salary_uc s;
        EMP_Attendence.Attendence_uc a;

        private void Attendecebtn_Click(object sender, EventArgs e)
        {
            if(a == null)
                a = new EMP_Attendence.Attendence_uc();
            LoginForm.LoginScreen.ms.addusercontrol(a);
        }

        private void salarybtn_Click(object sender, EventArgs e)
        {
            if (s == null)
                s = new EMP_Salary.Salary_uc();
            LoginForm.LoginScreen.ms.addusercontrol(s);
        }

        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            if(p == null)
                p = new EMP_Promotion.Promotion_uc();
            LoginForm.LoginScreen.ms.addusercontrol(p);
        }

        private void Emp_Management_Dashboard_uc_Load(object sender, EventArgs e)
        {
            Attendecebtn.Focus();
        }
    }
}
