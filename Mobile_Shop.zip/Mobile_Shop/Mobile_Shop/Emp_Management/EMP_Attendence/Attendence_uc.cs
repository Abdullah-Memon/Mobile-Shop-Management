﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Emp_Management.EMP_Attendence
{
    public partial class Attendence_uc : UserControl
    {
        public Attendence_uc()
        {
            InitializeComponent();
        }

        // Function to Get Not Attendenced Employees data
        private void GetData(int a = 0)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();
                SqlCommand cmd = new SqlCommand("AttendenceDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data",a));
                cmd.Parameters.Add(new SqlParameter("@date", AttendenceDate.Value));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                if (a != 0)
                    Attendence.DataSource = dt;
                else
                    ViewAttendence.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Back Button Coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.emd);
        }

        // Main Load Function
        private void Attendence_uc_Load(object sender, EventArgs e)
        {
            AttendenceDate.MaxDate = DateTime.Now; 
            AttendenceDate.Text = DateTime.Now.ToShortDateString();

            GetData(1);

            ViewAttendence.Hide();
            Attendence.Focus();
        }

        // View Attendence Button Coding
        private void ViewAttendecebtn_Click(object sender, EventArgs e)
        {
            GetData();
            ViewAttendence.Show();
            Attendence.Hide();
        }

        // Attendence Button Coding
        private void Attendecebtn_Click(object sender, EventArgs e)
        {
            GetData(1);
            Attendence.Show();
            ViewAttendence.Hide();
        }

        // Attendence Grid View Buttons Coding (P|L|A)
        private void Attendence_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Prensent button coding
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1 || e.ColumnIndex == 2)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();
                    SqlCommand cmd = new SqlCommand("AddAttendence", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@empid", Attendence.Rows[e.RowIndex].Cells["EmployeeID"].Value));

                    if (e.ColumnIndex == 0)
                        cmd.Parameters.Add(new SqlParameter("@state", 'P'));
                    if (e.ColumnIndex == 1)
                        cmd.Parameters.Add(new SqlParameter("@state", 'L')); 
                    if (e.ColumnIndex == 2)
                        cmd.Parameters.Add(new SqlParameter("@state", 'A'));

                    cmd.Parameters.Add(new SqlParameter("@date", AttendenceDate.Value));
                    cmd.Parameters.Add(new SqlParameter("@time", Convert.ToDateTime(DateTime.Now.ToShortTimeString())));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //refresh employee list
                GetData(1);
            }
        }

        // Reset Attendence Coding
        private void ViewAttendence_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Reset Attendence
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    SqlCommand cmd = new SqlCommand("RemoveAttendence", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@empid", ViewAttendence.Rows[e.RowIndex].Cells["EMPID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@date", AttendenceDate.Value));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //refresh list
                GetData();
            }
        }

        // updating Date coding
        private void AttendenceDate_ValueChanged(object sender, EventArgs e)
        {
            GetData();
            GetData(1);

            if (AttendenceDate.Value.ToShortDateString() == DateTime.Now.ToShortDateString())
                label1.Show();
            else
                label1.Hide();
        }
    }
}
