﻿namespace Mobile_Shop.Emp_Management.EMP_Attendence
{
    partial class Attendence_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AttendenceDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.Attendence = new Guna.UI2.WinForms.Guna2DataGridView();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.E_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Present = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Leave = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Absent = new System.Windows.Forms.DataGridViewButtonColumn();
            this.backbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ViewAttendecebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Attendecebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ViewAttendence = new Guna.UI2.WinForms.Guna2DataGridView();
            this.EMPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reset = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Attendence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewAttendence)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(447, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 25);
            this.label1.TabIndex = 33;
            this.label1.Text = "Todays Attendence";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(694, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 25);
            this.label2.TabIndex = 33;
            this.label2.Text = "Date";
            // 
            // AttendenceDate
            // 
            this.AttendenceDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AttendenceDate.CheckedState.Parent = this.AttendenceDate;
            this.AttendenceDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.AttendenceDate.HoverState.Parent = this.AttendenceDate;
            this.AttendenceDate.Location = new System.Drawing.Point(760, 3);
            this.AttendenceDate.MaxDate = new System.DateTime(2022, 10, 30, 0, 0, 0, 0);
            this.AttendenceDate.MinDate = new System.DateTime(1990, 1, 1, 0, 0, 0, 0);
            this.AttendenceDate.Name = "AttendenceDate";
            this.AttendenceDate.ShadowDecoration.Parent = this.AttendenceDate;
            this.AttendenceDate.Size = new System.Drawing.Size(200, 45);
            this.AttendenceDate.TabIndex = 32;
            this.AttendenceDate.Value = new System.DateTime(2022, 10, 30, 0, 0, 0, 0);
            this.AttendenceDate.ValueChanged += new System.EventHandler(this.AttendenceDate_ValueChanged);
            // 
            // Attendence
            // 
            this.Attendence.AllowUserToAddRows = false;
            this.Attendence.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.Attendence.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.Attendence.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Attendence.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Attendence.BackgroundColor = System.Drawing.Color.White;
            this.Attendence.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Attendence.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Attendence.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Attendence.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.Attendence.ColumnHeadersHeight = 21;
            this.Attendence.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.E_Picture,
            this.E_Name,
            this.E_CNIC,
            this.E_Role,
            this.E_Mobile,
            this.E_Email,
            this.E_Address,
            this.Present,
            this.Leave,
            this.Absent});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Attendence.DefaultCellStyle = dataGridViewCellStyle13;
            this.Attendence.EnableHeadersVisualStyles = false;
            this.Attendence.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.Attendence.Location = new System.Drawing.Point(3, 54);
            this.Attendence.Name = "Attendence";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Attendence.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.Attendence.RowHeadersVisible = false;
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            this.Attendence.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.Attendence.RowTemplate.Height = 70;
            this.Attendence.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Attendence.Size = new System.Drawing.Size(1054, 497);
            this.Attendence.TabIndex = 30;
            this.Attendence.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.Attendence.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.Attendence.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Attendence.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Attendence.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Attendence.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Attendence.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Attendence.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.Attendence.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.Attendence.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Attendence.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Attendence.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Attendence.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Attendence.ThemeStyle.HeaderStyle.Height = 21;
            this.Attendence.ThemeStyle.ReadOnly = false;
            this.Attendence.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.Attendence.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Attendence.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Attendence.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.Attendence.ThemeStyle.RowsStyle.Height = 70;
            this.Attendence.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.Attendence.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Attendence.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Attendence_CellContentClick);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EMPID";
            this.EmployeeID.HeaderText = "ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.Visible = false;
            // 
            // E_Picture
            // 
            this.E_Picture.DataPropertyName = "EMP_Picture";
            this.E_Picture.FillWeight = 60F;
            this.E_Picture.HeaderText = "Picture";
            this.E_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.E_Picture.Name = "E_Picture";
            // 
            // E_Name
            // 
            this.E_Name.DataPropertyName = "EMP_Name";
            this.E_Name.HeaderText = "Name";
            this.E_Name.Name = "E_Name";
            // 
            // E_CNIC
            // 
            this.E_CNIC.DataPropertyName = "EMP_CNIC";
            this.E_CNIC.HeaderText = "CNIC";
            this.E_CNIC.Name = "E_CNIC";
            // 
            // E_Role
            // 
            this.E_Role.DataPropertyName = "EMP_Role";
            this.E_Role.HeaderText = "Role";
            this.E_Role.Name = "E_Role";
            // 
            // E_Mobile
            // 
            this.E_Mobile.DataPropertyName = "EMP_Mobile";
            this.E_Mobile.HeaderText = "Mobile";
            this.E_Mobile.Name = "E_Mobile";
            // 
            // E_Email
            // 
            this.E_Email.DataPropertyName = "EMP_EmailAddress";
            this.E_Email.HeaderText = "Email";
            this.E_Email.Name = "E_Email";
            // 
            // E_Address
            // 
            this.E_Address.DataPropertyName = "EMP_Address";
            this.E_Address.HeaderText = "Address";
            this.E_Address.Name = "E_Address";
            // 
            // Present
            // 
            this.Present.FillWeight = 50F;
            this.Present.HeaderText = "Present";
            this.Present.Name = "Present";
            this.Present.Text = "Present";
            this.Present.UseColumnTextForButtonValue = true;
            // 
            // Leave
            // 
            this.Leave.FillWeight = 50F;
            this.Leave.HeaderText = "Leave";
            this.Leave.Name = "Leave";
            this.Leave.Text = "Leave";
            this.Leave.UseColumnTextForButtonValue = true;
            // 
            // Absent
            // 
            this.Absent.FillWeight = 50F;
            this.Absent.HeaderText = "Absent";
            this.Absent.Name = "Absent";
            this.Absent.Text = "Absent";
            this.Absent.UseColumnTextForButtonValue = true;
            // 
            // backbtn
            // 
            this.backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.BorderColor = System.Drawing.Color.White;
            this.backbtn.BorderRadius = 10;
            this.backbtn.BorderThickness = 2;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(966, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(91, 45);
            this.backbtn.TabIndex = 20;
            this.backbtn.Text = "back";
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // ViewAttendecebtn
            // 
            this.ViewAttendecebtn.BackColor = System.Drawing.Color.Transparent;
            this.ViewAttendecebtn.BorderColor = System.Drawing.Color.White;
            this.ViewAttendecebtn.BorderRadius = 10;
            this.ViewAttendecebtn.BorderThickness = 2;
            this.ViewAttendecebtn.CheckedState.Parent = this.ViewAttendecebtn;
            this.ViewAttendecebtn.CustomImages.Parent = this.ViewAttendecebtn;
            this.ViewAttendecebtn.FillColor = System.Drawing.Color.Indigo;
            this.ViewAttendecebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ViewAttendecebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ViewAttendecebtn.ForeColor = System.Drawing.Color.White;
            this.ViewAttendecebtn.HoverState.Parent = this.ViewAttendecebtn;
            this.ViewAttendecebtn.Location = new System.Drawing.Point(159, 3);
            this.ViewAttendecebtn.Name = "ViewAttendecebtn";
            this.ViewAttendecebtn.ShadowDecoration.Parent = this.ViewAttendecebtn;
            this.ViewAttendecebtn.Size = new System.Drawing.Size(150, 45);
            this.ViewAttendecebtn.TabIndex = 19;
            this.ViewAttendecebtn.Text = "View Attendence";
            this.ViewAttendecebtn.Click += new System.EventHandler(this.ViewAttendecebtn_Click);
            // 
            // Attendecebtn
            // 
            this.Attendecebtn.BackColor = System.Drawing.Color.Transparent;
            this.Attendecebtn.BorderColor = System.Drawing.Color.White;
            this.Attendecebtn.BorderRadius = 10;
            this.Attendecebtn.BorderThickness = 2;
            this.Attendecebtn.CheckedState.Parent = this.Attendecebtn;
            this.Attendecebtn.CustomImages.Parent = this.Attendecebtn;
            this.Attendecebtn.FillColor = System.Drawing.Color.Indigo;
            this.Attendecebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Attendecebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Attendecebtn.ForeColor = System.Drawing.Color.White;
            this.Attendecebtn.HoverState.Parent = this.Attendecebtn;
            this.Attendecebtn.Location = new System.Drawing.Point(3, 3);
            this.Attendecebtn.Name = "Attendecebtn";
            this.Attendecebtn.ShadowDecoration.Parent = this.Attendecebtn;
            this.Attendecebtn.Size = new System.Drawing.Size(150, 45);
            this.Attendecebtn.TabIndex = 18;
            this.Attendecebtn.Text = "Attendence";
            this.Attendecebtn.Click += new System.EventHandler(this.Attendecebtn_Click);
            // 
            // ViewAttendence
            // 
            this.ViewAttendence.AllowUserToAddRows = false;
            this.ViewAttendence.AllowUserToDeleteRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.ViewAttendence.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.ViewAttendence.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ViewAttendence.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ViewAttendence.BackgroundColor = System.Drawing.Color.White;
            this.ViewAttendence.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ViewAttendence.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ViewAttendence.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ViewAttendence.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.ViewAttendence.ColumnHeadersHeight = 21;
            this.ViewAttendence.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EMPID,
            this.dataGridViewImageColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewButtonColumn1,
            this.Reset});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ViewAttendence.DefaultCellStyle = dataGridViewCellStyle18;
            this.ViewAttendence.EnableHeadersVisualStyles = false;
            this.ViewAttendence.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.ViewAttendence.Location = new System.Drawing.Point(3, 54);
            this.ViewAttendence.Name = "ViewAttendence";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ViewAttendence.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.ViewAttendence.RowHeadersVisible = false;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            this.ViewAttendence.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.ViewAttendence.RowTemplate.Height = 70;
            this.ViewAttendence.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ViewAttendence.Size = new System.Drawing.Size(1054, 497);
            this.ViewAttendence.TabIndex = 31;
            this.ViewAttendence.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.ViewAttendence.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.ViewAttendence.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.ViewAttendence.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.ViewAttendence.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.ViewAttendence.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.ViewAttendence.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.ViewAttendence.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.ViewAttendence.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.ViewAttendence.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ViewAttendence.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ViewAttendence.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.ViewAttendence.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ViewAttendence.ThemeStyle.HeaderStyle.Height = 21;
            this.ViewAttendence.ThemeStyle.ReadOnly = false;
            this.ViewAttendence.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.ViewAttendence.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ViewAttendence.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ViewAttendence.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.ViewAttendence.ThemeStyle.RowsStyle.Height = 70;
            this.ViewAttendence.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.ViewAttendence.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.ViewAttendence.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ViewAttendence_CellContentClick);
            // 
            // EMPID
            // 
            this.EMPID.DataPropertyName = "EMPID";
            this.EMPID.HeaderText = "ID";
            this.EMPID.Name = "EMPID";
            this.EMPID.Visible = false;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.DataPropertyName = "EMP_Picture";
            this.dataGridViewImageColumn1.FillWeight = 60F;
            this.dataGridViewImageColumn1.HeaderText = "Picture";
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "EMP_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "EMP_CNIC";
            this.dataGridViewTextBoxColumn3.HeaderText = "CNIC";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "EMP_Role";
            this.dataGridViewTextBoxColumn4.HeaderText = "Role";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "EMP_Mobile";
            this.dataGridViewTextBoxColumn5.HeaderText = "Mobile";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "EMP_EmailAddress";
            this.dataGridViewTextBoxColumn6.HeaderText = "Email";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "EMP_Address";
            this.dataGridViewTextBoxColumn7.HeaderText = "Address";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.DataPropertyName = "AT_State";
            this.dataGridViewButtonColumn1.FillWeight = 50F;
            this.dataGridViewButtonColumn1.HeaderText = "Status";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewButtonColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Reset
            // 
            this.Reset.FillWeight = 50F;
            this.Reset.HeaderText = "Reset";
            this.Reset.Name = "Reset";
            this.Reset.Text = "Reset";
            this.Reset.UseColumnTextForButtonValue = true;
            // 
            // Attendence_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.Attendecebtn);
            this.Controls.Add(this.ViewAttendecebtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Attendence);
            this.Controls.Add(this.AttendenceDate);
            this.Controls.Add(this.ViewAttendence);
            this.Controls.Add(this.backbtn);
            this.Name = "Attendence_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.Attendence_uc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Attendence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewAttendence)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientButton ViewAttendecebtn;
        private Guna.UI2.WinForms.Guna2GradientButton Attendecebtn;
        private Guna.UI2.WinForms.Guna2GradientButton backbtn;
        private Guna.UI2.WinForms.Guna2DataGridView Attendence;
        private Guna.UI2.WinForms.Guna2DataGridView ViewAttendence;
        private Guna.UI2.WinForms.Guna2DateTimePicker AttendenceDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewImageColumn E_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Address;
        private System.Windows.Forms.DataGridViewButtonColumn Present;
        private System.Windows.Forms.DataGridViewButtonColumn Leave;
        private System.Windows.Forms.DataGridViewButtonColumn Absent;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPID;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn Reset;
        private System.Windows.Forms.Label label1;
    }
}
