﻿namespace Mobile_Shop.Emp_Management
{
    partial class Emp_Management_Dashboard_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ReportGroupBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PromotionGroupBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SalaryGroupBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.salarybtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AttendenceGroupBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.Attendecebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.ReportGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            this.PromotionGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.SalaryGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.AttendenceGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.ReportGroupBox, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.PromotionGroupBox, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.SalaryGroupBox, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.AttendenceGroupBox, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1060, 554);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // ReportGroupBox
            // 
            this.ReportGroupBox.Controls.Add(this.guna2GradientButton3);
            this.ReportGroupBox.Controls.Add(this.guna2PictureBox4);
            this.ReportGroupBox.Controls.Add(this.label4);
            this.ReportGroupBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ReportGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ReportGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ReportGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ReportGroupBox.Location = new System.Drawing.Point(533, 280);
            this.ReportGroupBox.Name = "ReportGroupBox";
            this.ReportGroupBox.ShadowDecoration.Parent = this.ReportGroupBox;
            this.ReportGroupBox.Size = new System.Drawing.Size(524, 271);
            this.ReportGroupBox.TabIndex = 3;
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2GradientButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton3.BorderRadius = 10;
            this.guna2GradientButton3.BorderThickness = 2;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(187, 206);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(150, 45);
            this.guna2GradientButton3.TabIndex = 17;
            this.guna2GradientButton3.Text = "Report";
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox4.Location = new System.Drawing.Point(188, 47);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(150, 139);
            this.guna2PictureBox4.TabIndex = 16;
            this.guna2PictureBox4.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(190, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "Employee Report";
            // 
            // PromotionGroupBox
            // 
            this.PromotionGroupBox.Controls.Add(this.guna2GradientButton2);
            this.PromotionGroupBox.Controls.Add(this.guna2PictureBox3);
            this.PromotionGroupBox.Controls.Add(this.label3);
            this.PromotionGroupBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.PromotionGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PromotionGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PromotionGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.PromotionGroupBox.Location = new System.Drawing.Point(3, 280);
            this.PromotionGroupBox.Name = "PromotionGroupBox";
            this.PromotionGroupBox.ShadowDecoration.Parent = this.PromotionGroupBox;
            this.PromotionGroupBox.Size = new System.Drawing.Size(524, 271);
            this.PromotionGroupBox.TabIndex = 2;
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2GradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton2.BorderRadius = 10;
            this.guna2GradientButton2.BorderThickness = 2;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(187, 206);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(150, 45);
            this.guna2GradientButton2.TabIndex = 17;
            this.guna2GradientButton2.Text = "Promotion";
            this.guna2GradientButton2.Click += new System.EventHandler(this.guna2GradientButton2_Click);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox3.Location = new System.Drawing.Point(188, 47);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(150, 139);
            this.guna2PictureBox3.TabIndex = 16;
            this.guna2PictureBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(171, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Employee Promotion";
            // 
            // SalaryGroupBox
            // 
            this.SalaryGroupBox.Controls.Add(this.salarybtn);
            this.SalaryGroupBox.Controls.Add(this.guna2PictureBox1);
            this.SalaryGroupBox.Controls.Add(this.label1);
            this.SalaryGroupBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.SalaryGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SalaryGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SalaryGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.SalaryGroupBox.Location = new System.Drawing.Point(533, 3);
            this.SalaryGroupBox.Name = "SalaryGroupBox";
            this.SalaryGroupBox.ShadowDecoration.Parent = this.SalaryGroupBox;
            this.SalaryGroupBox.Size = new System.Drawing.Size(524, 271);
            this.SalaryGroupBox.TabIndex = 1;
            // 
            // salarybtn
            // 
            this.salarybtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.salarybtn.BackColor = System.Drawing.Color.Transparent;
            this.salarybtn.BorderColor = System.Drawing.Color.White;
            this.salarybtn.BorderRadius = 10;
            this.salarybtn.BorderThickness = 2;
            this.salarybtn.CheckedState.Parent = this.salarybtn;
            this.salarybtn.CustomImages.Parent = this.salarybtn;
            this.salarybtn.FillColor = System.Drawing.Color.Indigo;
            this.salarybtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.salarybtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.salarybtn.ForeColor = System.Drawing.Color.White;
            this.salarybtn.HoverState.Parent = this.salarybtn;
            this.salarybtn.Location = new System.Drawing.Point(187, 206);
            this.salarybtn.Name = "salarybtn";
            this.salarybtn.ShadowDecoration.Parent = this.salarybtn;
            this.salarybtn.Size = new System.Drawing.Size(150, 45);
            this.salarybtn.TabIndex = 17;
            this.salarybtn.Text = "Salary";
            this.salarybtn.Click += new System.EventHandler(this.salarybtn_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox1.Location = new System.Drawing.Point(188, 47);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(150, 139);
            this.guna2PictureBox1.TabIndex = 16;
            this.guna2PictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(195, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 25);
            this.label1.TabIndex = 15;
            this.label1.Text = "Employee Salary";
            // 
            // AttendenceGroupBox
            // 
            this.AttendenceGroupBox.Controls.Add(this.Attendecebtn);
            this.AttendenceGroupBox.Controls.Add(this.guna2PictureBox2);
            this.AttendenceGroupBox.Controls.Add(this.label2);
            this.AttendenceGroupBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AttendenceGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AttendenceGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AttendenceGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AttendenceGroupBox.Location = new System.Drawing.Point(3, 3);
            this.AttendenceGroupBox.Name = "AttendenceGroupBox";
            this.AttendenceGroupBox.ShadowDecoration.Parent = this.AttendenceGroupBox;
            this.AttendenceGroupBox.Size = new System.Drawing.Size(524, 271);
            this.AttendenceGroupBox.TabIndex = 0;
            // 
            // Attendecebtn
            // 
            this.Attendecebtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Attendecebtn.BackColor = System.Drawing.Color.Transparent;
            this.Attendecebtn.BorderColor = System.Drawing.Color.White;
            this.Attendecebtn.BorderRadius = 10;
            this.Attendecebtn.BorderThickness = 2;
            this.Attendecebtn.CheckedState.Parent = this.Attendecebtn;
            this.Attendecebtn.CustomImages.Parent = this.Attendecebtn;
            this.Attendecebtn.FillColor = System.Drawing.Color.Indigo;
            this.Attendecebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Attendecebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Attendecebtn.ForeColor = System.Drawing.Color.White;
            this.Attendecebtn.HoverState.Parent = this.Attendecebtn;
            this.Attendecebtn.Location = new System.Drawing.Point(187, 206);
            this.Attendecebtn.Name = "Attendecebtn";
            this.Attendecebtn.ShadowDecoration.Parent = this.Attendecebtn;
            this.Attendecebtn.Size = new System.Drawing.Size(150, 45);
            this.Attendecebtn.TabIndex = 17;
            this.Attendecebtn.Text = "Attendence";
            this.Attendecebtn.Click += new System.EventHandler(this.Attendecebtn_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox2.Location = new System.Drawing.Point(188, 47);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(150, 139);
            this.guna2PictureBox2.TabIndex = 16;
            this.guna2PictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(171, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 25);
            this.label2.TabIndex = 15;
            this.label2.Text = "Employee Attendence";
            // 
            // Emp_Management_Dashboard_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Emp_Management_Dashboard_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.Emp_Management_Dashboard_uc_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ReportGroupBox.ResumeLayout(false);
            this.ReportGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            this.PromotionGroupBox.ResumeLayout(false);
            this.PromotionGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.SalaryGroupBox.ResumeLayout(false);
            this.SalaryGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.AttendenceGroupBox.ResumeLayout(false);
            this.AttendenceGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2GroupBox AttendenceGroupBox;
        private Guna.UI2.WinForms.Guna2GradientButton Attendecebtn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GroupBox ReportGroupBox;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2GroupBox PromotionGroupBox;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GroupBox SalaryGroupBox;
        private Guna.UI2.WinForms.Guna2GradientButton salarybtn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label1;
    }
}
