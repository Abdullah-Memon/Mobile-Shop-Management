﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen
{
    public partial class SelectCustomerAccounts_Form : Form
    {
        // Global variables
        SqlCommand cmd;
        int type;
        public static string Customer_name = string.Empty, Customer_id = string.Empty, Customer_email = string.Empty, Customer_mobile = string.Empty;
        public static byte[] Customer_pic = null;

        public SelectCustomerAccounts_Form(int a = 0)
        {
            InitializeComponent();
            type = a;
        }
       

        // getting suppliers account
        private void GetCustomerAccounts()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();
                cmd = new SqlCommand("AccountsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@type", 2));
                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                CustomerAccountsGridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while geting accounts information " + ex.ToString(), "Error");
            }
        }
        // Main Load Function
        private void SelectCustomerAccounts_Form_Load(object sender, EventArgs e)
        {
            GetCustomerAccounts();
            if (type != 0)
                localCustomerbox.Hide();
            else
                localCustomerbox.Show();
        }

        // Grid view button coding
        private void CustomerAccountsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //select button coding from grid view
            if (e.ColumnIndex == 0)
            {
                Customer_id = CustomerAccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value.ToString();
                Customer_name = CustomerAccountsGridView.Rows[e.RowIndex].Cells["ACC_Name"].Value.ToString();

                Customer_pic = (byte[])CustomerAccountsGridView.Rows[e.RowIndex].Cells["ACC_Picture"].Value;

                this.Close();
            }
        }

        //local Supplier Selection Button Coding
        private void localselectbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(localCustomerName.Text) || string.IsNullOrWhiteSpace(localCustomerName.Text))
            {
                localCustomerName.Focus();
            }
            else if (string.IsNullOrWhiteSpace(localCustomerMobile.Text) || string.IsNullOrEmpty(localCustomerMobile.Text))
            {
                localCustomerMobile.Focus();
            }
            else
            {
                Customer_id = "1";
                Customer_name = localCustomerName.Text;
                Customer_mobile = localCustomerMobile.Text;
                Customer_email = localCustomerEmailAddress.Text;

                localCustomerName.Text = string.Empty;
                localCustomerMobile.Text = string.Empty;
                localCustomerEmailAddress.Text = string.Empty;

                this.Close();
            }
        }

        private void localSupplierMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '-'))
            {
                e.Handled = true;
            }
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
