﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.SellScreen.Selling.BillRecipt
{
    public partial class BillRecipt_Form : Form
    {
        int type; 
        decimal invoice;

        public BillRecipt_Form(int a = 0, decimal i = 0)
        {
            InitializeComponent();
            type = 0;
            invoice = i;
        }

        private void BillRecipt_Form_Load(object sender, EventArgs e)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("PrintLastSellBill", DB.con) { CommandType = CommandType.StoredProcedure };

                if (type == 1)
                {
                    cmd.Parameters.Add(new SqlParameter("@data", type));
                    cmd.Parameters.Add(new SqlParameter("@invoice", invoice));
                }

                dt.Load(cmd.ExecuteReader());
                
                DB.con.Close();

                BillRecipt_Page brp = new BillRecipt_Page();
                brp.DataSource = dt;

                InstanceReportSource irs = new InstanceReportSource() { ReportDocument = brp };

                reportViewer1.ReportSource = irs;
                reportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                WindowState = FormWindowState.Normal;
            else
                WindowState = FormWindowState.Maximized;
        }

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

    }
}
