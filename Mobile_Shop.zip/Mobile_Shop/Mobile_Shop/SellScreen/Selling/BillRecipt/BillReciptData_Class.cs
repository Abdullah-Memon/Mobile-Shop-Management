﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.SellScreen.Selling.BillRecipt
{
    class BillReciptData_Class
    {
        public static string Date {set; get;}
        public static string EMP_Name {set; get;}
        public static string Customer_Name {set; get;}
        public static string Customer_Mobile {set; get;}
        public static decimal Pay {set;get;}
        public static decimal TCS {set; get;}
        public static decimal InvoiceNumber {set;get;}
        public static string Payment_Type {set; get;}
        public static decimal Item_Total_Bill {set; get;}
        public static string ItemDetail{set;get;}
    }
}
