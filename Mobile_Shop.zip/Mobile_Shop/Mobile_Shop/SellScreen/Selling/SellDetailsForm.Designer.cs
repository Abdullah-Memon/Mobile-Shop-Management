﻿namespace Mobile_Shop.SellScreen
{
    partial class SellDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.AddItemsDetailsBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.GridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.sid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IMEIID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IMEI1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IMEI2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Color = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Box = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Warranty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ADD = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Searchbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Quantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.Catagorybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Brandbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Companybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ItemPicture = new Guna.UI2.WinForms.Guna2PictureBox();
            this.RemainIMEILabel = new System.Windows.Forms.Label();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ItemName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.AddItemsDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // AddItemsDetailsBox
            // 
            this.AddItemsDetailsBox.BorderRadius = 10;
            this.AddItemsDetailsBox.Controls.Add(this.GridView);
            this.AddItemsDetailsBox.Controls.Add(this.label2);
            this.AddItemsDetailsBox.Controls.Add(this.label5);
            this.AddItemsDetailsBox.Controls.Add(this.label3);
            this.AddItemsDetailsBox.Controls.Add(this.Searchbox);
            this.AddItemsDetailsBox.Controls.Add(this.Quantity);
            this.AddItemsDetailsBox.Controls.Add(this.Catagorybox);
            this.AddItemsDetailsBox.Controls.Add(this.label4);
            this.AddItemsDetailsBox.Controls.Add(this.label1);
            this.AddItemsDetailsBox.Controls.Add(this.Brandbox);
            this.AddItemsDetailsBox.Controls.Add(this.Companybox);
            this.AddItemsDetailsBox.Controls.Add(this.Backbtn);
            this.AddItemsDetailsBox.Controls.Add(this.guna2GradientButton1);
            this.AddItemsDetailsBox.Controls.Add(this.ItemPicture);
            this.AddItemsDetailsBox.Controls.Add(this.RemainIMEILabel);
            this.AddItemsDetailsBox.Controls.Add(this.warning2);
            this.AddItemsDetailsBox.Controls.Add(this.warning1);
            this.AddItemsDetailsBox.Controls.Add(this.label8);
            this.AddItemsDetailsBox.Controls.Add(this.ItemName);
            this.AddItemsDetailsBox.Controls.Add(this.label11);
            this.AddItemsDetailsBox.Controls.Add(this.label13);
            this.AddItemsDetailsBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AddItemsDetailsBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddItemsDetailsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddItemsDetailsBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AddItemsDetailsBox.Location = new System.Drawing.Point(10, 10);
            this.AddItemsDetailsBox.Name = "AddItemsDetailsBox";
            this.AddItemsDetailsBox.ShadowDecoration.Parent = this.AddItemsDetailsBox;
            this.AddItemsDetailsBox.Size = new System.Drawing.Size(1011, 562);
            this.AddItemsDetailsBox.TabIndex = 2;
            // 
            // GridView
            // 
            this.GridView.AllowUserToAddRows = false;
            this.GridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.GridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.GridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridView.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.GridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.GridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridView.ColumnHeadersHeight = 17;
            this.GridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sid,
            this.IMEIID,
            this.IMEI1,
            this.IMEI2,
            this.Color,
            this.SP,
            this.Box,
            this.Warranty,
            this.ADD});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.GridView.EnableHeadersVisualStyles = false;
            this.GridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.GridView.Location = new System.Drawing.Point(275, 63);
            this.GridView.Name = "GridView";
            this.GridView.ReadOnly = true;
            this.GridView.RowHeadersVisible = false;
            this.GridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridView.Size = new System.Drawing.Size(725, 491);
            this.GridView.TabIndex = 3;
            this.GridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.GridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.GridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.GridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.GridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.GridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.GridView.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.GridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.GridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.GridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.GridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.GridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.GridView.ThemeStyle.HeaderStyle.Height = 17;
            this.GridView.ThemeStyle.ReadOnly = true;
            this.GridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.GridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.GridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.GridView.ThemeStyle.RowsStyle.Height = 22;
            this.GridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.GridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.GridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridView_CellContentClick);
            // 
            // sid
            // 
            this.sid.DataPropertyName = "SID";
            this.sid.HeaderText = "SID";
            this.sid.Name = "sid";
            this.sid.ReadOnly = true;
            this.sid.Visible = false;
            // 
            // IMEIID
            // 
            this.IMEIID.DataPropertyName = "IMEIID";
            this.IMEIID.HeaderText = "IMEIID";
            this.IMEIID.Name = "IMEIID";
            this.IMEIID.ReadOnly = true;
            this.IMEIID.Visible = false;
            // 
            // IMEI1
            // 
            this.IMEI1.DataPropertyName = "IMEI_1";
            this.IMEI1.HeaderText = "IMEI 1";
            this.IMEI1.Name = "IMEI1";
            this.IMEI1.ReadOnly = true;
            // 
            // IMEI2
            // 
            this.IMEI2.DataPropertyName = "IMEI_2";
            this.IMEI2.HeaderText = "IMEI 2";
            this.IMEI2.Name = "IMEI2";
            this.IMEI2.ReadOnly = true;
            // 
            // Color
            // 
            this.Color.DataPropertyName = "Color";
            this.Color.HeaderText = "Color";
            this.Color.Name = "Color";
            this.Color.ReadOnly = true;
            // 
            // SP
            // 
            this.SP.DataPropertyName = "SP";
            this.SP.HeaderText = "Price";
            this.SP.Name = "SP";
            this.SP.ReadOnly = true;
            // 
            // Box
            // 
            this.Box.DataPropertyName = "Box";
            this.Box.HeaderText = "Box";
            this.Box.Name = "Box";
            this.Box.ReadOnly = true;
            // 
            // Warranty
            // 
            this.Warranty.DataPropertyName = "Warranty";
            this.Warranty.HeaderText = "Warranty";
            this.Warranty.Name = "Warranty";
            this.Warranty.ReadOnly = true;
            // 
            // ADD
            // 
            this.ADD.FillWeight = 50F;
            this.ADD.HeaderText = "ADD";
            this.ADD.Name = "ADD";
            this.ADD.ReadOnly = true;
            this.ADD.Text = "ADD";
            this.ADD.UseColumnTextForButtonValue = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(454, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 22;
            this.label2.Text = "Search";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(20, 445);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(20, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 22;
            this.label3.Text = "Catagory";
            // 
            // Searchbox
            // 
            this.Searchbox.BackColor = System.Drawing.Color.Transparent;
            this.Searchbox.BorderRadius = 10;
            this.Searchbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Searchbox.DefaultText = "";
            this.Searchbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Searchbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Searchbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Searchbox.DisabledState.Parent = this.Searchbox;
            this.Searchbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Searchbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Searchbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Searchbox.FocusedState.Parent = this.Searchbox;
            this.Searchbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Searchbox.HoverState.Parent = this.Searchbox;
            this.Searchbox.Location = new System.Drawing.Point(523, 15);
            this.Searchbox.Margin = new System.Windows.Forms.Padding(3, 21, 3, 21);
            this.Searchbox.Name = "Searchbox";
            this.Searchbox.PasswordChar = '\0';
            this.Searchbox.PlaceholderText = "";
            this.Searchbox.SelectedText = "";
            this.Searchbox.ShadowDecoration.Parent = this.Searchbox;
            this.Searchbox.Size = new System.Drawing.Size(253, 38);
            this.Searchbox.TabIndex = 1;
            this.Searchbox.Tag = "info";
            this.Searchbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Searchbox.TextChanged += new System.EventHandler(this.Searchbox_TextChanged);
            // 
            // Quantity
            // 
            this.Quantity.BackColor = System.Drawing.Color.Transparent;
            this.Quantity.BorderRadius = 10;
            this.Quantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Quantity.DefaultText = "";
            this.Quantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Quantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Quantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Quantity.DisabledState.Parent = this.Quantity;
            this.Quantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Quantity.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Quantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Quantity.FocusedState.Parent = this.Quantity;
            this.Quantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Quantity.HoverState.Parent = this.Quantity;
            this.Quantity.Location = new System.Drawing.Point(103, 436);
            this.Quantity.Margin = new System.Windows.Forms.Padding(3, 16, 3, 16);
            this.Quantity.Name = "Quantity";
            this.Quantity.PasswordChar = '\0';
            this.Quantity.PlaceholderText = "";
            this.Quantity.SelectedText = "";
            this.Quantity.ShadowDecoration.Parent = this.Quantity;
            this.Quantity.Size = new System.Drawing.Size(154, 37);
            this.Quantity.TabIndex = 0;
            this.Quantity.Tag = "info";
            this.Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Catagorybox
            // 
            this.Catagorybox.BackColor = System.Drawing.Color.Transparent;
            this.Catagorybox.BorderRadius = 10;
            this.Catagorybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Catagorybox.DefaultText = "";
            this.Catagorybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Catagorybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Catagorybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Catagorybox.DisabledState.Parent = this.Catagorybox;
            this.Catagorybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Catagorybox.Enabled = false;
            this.Catagorybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Catagorybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Catagorybox.FocusedState.Parent = this.Catagorybox;
            this.Catagorybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Catagorybox.HoverState.Parent = this.Catagorybox;
            this.Catagorybox.Location = new System.Drawing.Point(103, 311);
            this.Catagorybox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.Catagorybox.Name = "Catagorybox";
            this.Catagorybox.PasswordChar = '\0';
            this.Catagorybox.PlaceholderText = "";
            this.Catagorybox.SelectedText = "";
            this.Catagorybox.ShadowDecoration.Parent = this.Catagorybox;
            this.Catagorybox.Size = new System.Drawing.Size(154, 37);
            this.Catagorybox.TabIndex = 23;
            this.Catagorybox.Tag = "info";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(20, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Brand";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(20, 271);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 19);
            this.label1.TabIndex = 20;
            this.label1.Text = "Company";
            // 
            // Brandbox
            // 
            this.Brandbox.BackColor = System.Drawing.Color.Transparent;
            this.Brandbox.BorderRadius = 10;
            this.Brandbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Brandbox.DefaultText = "";
            this.Brandbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Brandbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Brandbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.DisabledState.Parent = this.Brandbox;
            this.Brandbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.Enabled = false;
            this.Brandbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Brandbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.FocusedState.Parent = this.Brandbox;
            this.Brandbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.HoverState.Parent = this.Brandbox;
            this.Brandbox.Location = new System.Drawing.Point(103, 361);
            this.Brandbox.Margin = new System.Windows.Forms.Padding(3, 16, 3, 16);
            this.Brandbox.Name = "Brandbox";
            this.Brandbox.PasswordChar = '\0';
            this.Brandbox.PlaceholderText = "";
            this.Brandbox.SelectedText = "";
            this.Brandbox.ShadowDecoration.Parent = this.Brandbox;
            this.Brandbox.Size = new System.Drawing.Size(154, 37);
            this.Brandbox.TabIndex = 21;
            this.Brandbox.Tag = "info";
            // 
            // Companybox
            // 
            this.Companybox.BackColor = System.Drawing.Color.Transparent;
            this.Companybox.BorderRadius = 10;
            this.Companybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Companybox.DefaultText = "";
            this.Companybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Companybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Companybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Companybox.DisabledState.Parent = this.Companybox;
            this.Companybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Companybox.Enabled = false;
            this.Companybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Companybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Companybox.FocusedState.Parent = this.Companybox;
            this.Companybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Companybox.HoverState.Parent = this.Companybox;
            this.Companybox.Location = new System.Drawing.Point(103, 262);
            this.Companybox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.Companybox.Name = "Companybox";
            this.Companybox.PasswordChar = '\0';
            this.Companybox.PlaceholderText = "";
            this.Companybox.SelectedText = "";
            this.Companybox.ShadowDecoration.Parent = this.Companybox;
            this.Companybox.Size = new System.Drawing.Size(154, 37);
            this.Companybox.TabIndex = 21;
            this.Companybox.Tag = "info";
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(965, 8);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(35, 35);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "X";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(782, 15);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(105, 38);
            this.guna2GradientButton1.TabIndex = 2;
            this.guna2GradientButton1.Text = "Search";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // ItemPicture
            // 
            this.ItemPicture.BackColor = System.Drawing.Color.Transparent;
            this.ItemPicture.BorderRadius = 10;
            this.ItemPicture.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ItemPicture.Location = new System.Drawing.Point(64, 24);
            this.ItemPicture.Name = "ItemPicture";
            this.ItemPicture.ShadowDecoration.Parent = this.ItemPicture;
            this.ItemPicture.Size = new System.Drawing.Size(150, 150);
            this.ItemPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ItemPicture.TabIndex = 4;
            this.ItemPicture.TabStop = false;
            // 
            // RemainIMEILabel
            // 
            this.RemainIMEILabel.AutoSize = true;
            this.RemainIMEILabel.BackColor = System.Drawing.Color.Transparent;
            this.RemainIMEILabel.ForeColor = System.Drawing.Color.Red;
            this.RemainIMEILabel.Location = new System.Drawing.Point(8, 519);
            this.RemainIMEILabel.Name = "RemainIMEILabel";
            this.RemainIMEILabel.Size = new System.Drawing.Size(30, 19);
            this.RemainIMEILabel.TabIndex = 1;
            this.RemainIMEILabel.Text = "0/0";
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.BackColor = System.Drawing.Color.Transparent;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(152, 513);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(117, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Invalid Quantity";
            // 
            // warning1
            // 
            this.warning1.AutoSize = true;
            this.warning1.BackColor = System.Drawing.Color.Transparent;
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(123, 475);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(146, 19);
            this.warning1.TabIndex = 1;
            this.warning1.Text = "* Please Enter Quanity";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(20, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Item Name";
            // 
            // ItemName
            // 
            this.ItemName.BackColor = System.Drawing.Color.Transparent;
            this.ItemName.BorderRadius = 10;
            this.ItemName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ItemName.DefaultText = "";
            this.ItemName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ItemName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ItemName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ItemName.DisabledState.Parent = this.ItemName;
            this.ItemName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ItemName.Enabled = false;
            this.ItemName.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ItemName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ItemName.FocusedState.Parent = this.ItemName;
            this.ItemName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ItemName.HoverState.Parent = this.ItemName;
            this.ItemName.Location = new System.Drawing.Point(103, 204);
            this.ItemName.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.ItemName.Name = "ItemName";
            this.ItemName.PasswordChar = '\0';
            this.ItemName.PlaceholderText = "";
            this.ItemName.SelectedText = "";
            this.ItemName.ShadowDecoration.Parent = this.ItemName;
            this.ItemName.Size = new System.Drawing.Size(154, 37);
            this.ItemName.TabIndex = 1;
            this.ItemName.Tag = "info";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.ForeColor = System.Drawing.Color.Silver;
            this.label11.Location = new System.Drawing.Point(14, 398);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(243, 19);
            this.label11.TabIndex = 28;
            this.label11.Text = "_______________________________________";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.Color.Silver;
            this.label13.Location = new System.Drawing.Point(19, 494);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(243, 19);
            this.label13.TabIndex = 28;
            this.label13.Text = "_______________________________________";
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.AddItemsDetailsBox;
            // 
            // SellDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(1031, 582);
            this.Controls.Add(this.AddItemsDetailsBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SellDetailsForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellDetailsForm";
            this.Load += new System.EventHandler(this.SellDetailsForm_Load);
            this.AddItemsDetailsBox.ResumeLayout(false);
            this.AddItemsDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox AddItemsDetailsBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox Quantity;
        private Guna.UI2.WinForms.Guna2TextBox Catagorybox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox Brandbox;
        private Guna.UI2.WinForms.Guna2TextBox Companybox;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2PictureBox ItemPicture;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox ItemName;
        private Guna.UI2.WinForms.Guna2DataGridView GridView;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox Searchbox;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private System.Windows.Forms.Label RemainIMEILabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn sid;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMEIID;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMEI1;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMEI2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Color;
        private System.Windows.Forms.DataGridViewTextBoxColumn SP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Box;
        private System.Windows.Forms.DataGridViewTextBoxColumn Warranty;
        private System.Windows.Forms.DataGridViewButtonColumn ADD;
        private System.Windows.Forms.Label warning2;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
    }
}