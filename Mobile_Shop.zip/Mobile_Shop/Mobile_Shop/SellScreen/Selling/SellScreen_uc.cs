﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Mobile_Shop.SellScreen
{
    public partial class SellScreen_uc : UserControl
    {
        // Global Variables
        SqlCommand cmd;
        DataTable data;
        string search;
        public static DataTable SellDetailsData;
        decimal previousdues;
        int min, sec;
        int Searchby;

        // Constructor
        public SellScreen_uc()
        {
            InitializeComponent();
            if (LoginForm.LoginScreen.personal_info.Rows[0][6].ToString() != "Admin")
            {
                LoginForm.LoginScreen.ssf.WindowState = FormWindowState.Maximized;
                LoginForm.LoginScreen.ssf.maximizebtn.Enabled = false;
            }
        }

        // Function getting payment types data
        private void getpaymentTypeData()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable paymentTypeData = new DataTable();
                cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                paymentTypeData.Load(cmd.ExecuteReader());

                PaymentTypebox.DataSource = paymentTypeData;
                PaymentTypebox.DisplayMember = "P_Type";
                PaymentTypebox.ValueMember = "PID";

                DB.con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting payment Types " + ex.ToString(), "Error");
            }
        }

        // Function getting searched items details
        private void GetSearch(string a, int search)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                data = new DataTable();

                cmd = new SqlCommand("SellItemsDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                if (search == 0)
                    cmd.Parameters.Add(new SqlParameter("@data", 1));
                else if (search == 1)
                    cmd.Parameters.Add(new SqlParameter("@data", 2));

                cmd.Parameters.Add(new SqlParameter("@search", a));
                data.Load(cmd.ExecuteReader());

                AllItems.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching item please try again " + ex.Message, "Error");
            }
        }

        // Function changing data into number
        private string ConvertNumber(string a)
        {
            string number = null;
            if (a == "D1" || a == "NumPad1")
                number = "1";
            else if (a == "D2" || a == "NumPad2")
                number = "2";
            else if (a == "D3" || a == "NumPad3")
                number = "3";
            else if (a == "D4" || a == "NumPad4")
                number = "4";
            else if (a == "D5" || a == "NumPad5")
                number = "5";
            else if (a == "D6" || a == "NumPad6")
                number = "6";
            else if (a == "D7" || a == "NumPad7")
                number = "7";
            else if (a == "D8" || a == "NumPad8")
                number = "8";
            else if (a == "D9" || a == "NumPad9")
                number = "9";
            else if (a == "D0" || a == "NumPad0")
                number = "0";
            else
                number = a;
            return number;
        }

        // Function to calculate bill
        private Decimal CalculateBill()
        {
            Decimal a = 0;
            for (int i = 0; i < SelectedItems.Rows.Count; i++)
                a += Convert.ToDecimal(SelectedItems.Rows[i].Cells["SelectedPrice"].Value);

            return a;
        }

        // Function to send data with new information
        private void SendSelectedData()
        {
            SellDetailsData = new DataTable();
            SellDetailsData.Columns.Add("SelectedSID");
            SellDetailsData.Columns.Add("SelectedID");
            SellDetailsData.Columns.Add("SelectedPicture");
            SellDetailsData.Columns.Add("SelectedName");
            SellDetailsData.Columns.Add("SelectedCatagory");
            SellDetailsData.Columns.Add("SelectedCompany");
            SellDetailsData.Columns.Add("SelectedBrands");
            SellDetailsData.Columns.Add("SelectedQuantity");
            SellDetailsData.Columns.Add("SelectedIMEI1");
            SellDetailsData.Columns.Add("SelectedIMEI2");
            SellDetailsData.Columns.Add("SelectedSell");
            SellDetailsData.Columns.Add("SelectedPrice");
            SellDetailsData.Columns.Add("SelectedColor");
            SellDetailsData.Columns.Add("SelectedBox");
            SellDetailsData.Columns.Add("SelectedWarranty");
            SellDetailsData.Columns.Add("SelectedIMEIID");
        }

        // Function to manage Invoice Numbers
        private void InvoiceNumbers()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("GetInvoiceNumber", DB.con) { CommandType = CommandType.StoredProcedure };
                dt.Load(cmd.ExecuteReader());

                if (dt.Rows.Count > 0)
                {
                    invoicetxt.Text = dt.Rows[0][0].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        // Function to send InvoiceDetails
        private int setSellInvoiceDetails()
        {
            try
            {
                cmd = new SqlCommand("AddSellInvoiceDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                cmd.Parameters.Add(new SqlParameter("@aid", SelectCustomerAccounts_Form.Customer_id));
                cmd.Parameters.Add(new SqlParameter("@EMPID", (int)LoginForm.LoginScreen.personal_info.Rows[0][0]));
                cmd.Parameters.Add(new SqlParameter("@mobile", SelectCustomerAccounts_Form.Customer_mobile));
                cmd.Parameters.Add(new SqlParameter("@date", Convert.ToDateTime(DateTime.Now.ToShortDateString())));
                cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(paying.Text)));
                cmd.Parameters.Add(new SqlParameter("@tcs", Convert.ToDecimal(TCSbox.Text)));

                if (SelectCustomerAccounts_Form.Customer_id == "1")
                    cmd.Parameters.Add(new SqlParameter("@customername", SelectCustomerBox.Text));

                if (Convert.ToDecimal(dues.Text) != 0)
                    cmd.Parameters.Add(new SqlParameter("@pid", 2));
                else
                    cmd.Parameters.Add(new SqlParameter("@pid", PaymentTypebox.SelectedValue));

                return cmd.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }
        }

        //Function to Get Todays Customer
        private void getTodaysCustomersList()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();
                cmd = new SqlCommand("TodaySell", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                cmd.Parameters.Add(new SqlParameter("@date", Convert.ToDateTime(DateTime.Now.ToShortDateString())));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                TodaysSell.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        // Main Load Function
        private void SellScreen_uc_Load(object sender, EventArgs e)
        {
            //Retriving all Required Data
            InvoiceNumbers();
            getpaymentTypeData();
            getTodaysCustomersList();

            // Setting up selected Items Display
            SendSelectedData();
            SelectedItems.DataSource = SellDetailsData;
            SelectedItems.Focus();
            AllItems.Visible = false;

            SelectCustomerBox.ReadOnly = true;

            Searchby = 0;
            // Initiallizing Time out Values
            Timeout.Stop();
            sec = 00;
            min = 15;
            TimeoutMinutes.Text = min.ToString();
            TimeoutSec.Text = sec.ToString();

            LocalCustomerChkBox.Checked = true;
            SelectCustomerAccounts_Form.Customer_id = "1";
            SelectCustomerAccounts_Form.Customer_mobile = "0000-0000000";
            SelectCustomerAccounts_Form.Customer_email = "LocalCustomer@MobileShop";
            SelectCustomerAccounts_Form.Customer_name = "Local";
            SelectCustomerBox.Text = SelectCustomerAccounts_Form.Customer_name;

        }

        // Searching coding in grid view
        private void SelectedItems_KeyDown(object sender, KeyEventArgs e)
        {
           
                if (Char.IsLetter((char)e.KeyData))
                {
                    search += ConvertNumber(e.KeyData.ToString());
                    Searchtxt.Text = search.ToString();
                    GetSearch(search, Searchby);
                    AllItems.Visible = true;
                }

                if (char.IsNumber((char)e.KeyData))
                {
                    search += ConvertNumber(e.KeyData.ToString());
                    Searchtxt.Text = search;
                    GetSearch(search,Searchby);
                    AllItems.Visible = true;
                }

                if (e.KeyData == Keys.Back || e.KeyData == Keys.Escape)
                {
                    search = string.Empty;
                    Searchtxt.Text = search;
                    AllItems.Visible = false;
                }

                if (e.KeyData == Keys.Down || e.KeyData == Keys.Enter)
                    AllItems.Focus();
        }
        private void AllItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Escape)
            {
                AllItems.Visible = false;
                SelectedItems.Focus();
            }

            if (e.KeyData == Keys.Enter)
            {
                // Start Timer
                Timeout.Start();

                DataGridViewRow dgvr = AllItems.CurrentRow;

                SellDetailsForm sdf = new SellDetailsForm(dgvr);
                sdf.ShowDialog();

                if (SellDetailsData.Rows.Count > 0)
                    SelectedItems.DataSource = SellDetailsData;

                AllItems.Visible = false;
                search = string.Empty;
                Searchtxt.Text = search;

                Totalpayment.Text = CalculateBill().ToString();
                

                if (string.IsNullOrWhiteSpace(TCSbox.Text) || string.IsNullOrEmpty(TCSbox.Text))
                    TCSbox.Text = "0";

                if (string.IsNullOrEmpty(dues.Text) || string.IsNullOrWhiteSpace(dues.Text))
                    dues.Text = "0";
                dues.Text = (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(TCSbox.Text)).ToString();
                predues.Text = (Convert.ToDecimal(dues.Text) + previousdues).ToString();

            }
        }

        // After Removing Items Coding
        private void SelectedItems_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            //if (SelectedItems.Rows.Count > 0)
            {
                Totalpayment.Text = CalculateBill().ToString();
                predues.Text = CalculateBill().ToString();
            }
        }

        // Selecting Customer Coding
        private void SelectCustomerBox_DoubleClick(object sender, EventArgs e)
        {
            previousdues = 0;

            SelectCustomerAccounts_Form scaf = new SelectCustomerAccounts_Form();
            scaf.ShowDialog();

            SelectCustomerBox.Text = SelectCustomerAccounts_Form.Customer_name;

            if (SelectCustomerAccounts_Form.Customer_id == "1")
            {
                SelectCustomerBox.ReadOnly = false;
                LocalCustomerChkBox.Checked = true;
            }
            else
            {
                SelectCustomerBox.ReadOnly = true;
                LocalCustomerChkBox.Checked = false;
            }

            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                if (SelectCustomerAccounts_Form.Customer_id != "1")
                {
                    DataTable dt = new DataTable();

                    cmd = new SqlCommand("GetSellDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 2));
                    cmd.Parameters.Add(new SqlParameter("@aid", SelectCustomerAccounts_Form.Customer_id));

                    dt.Load(cmd.ExecuteReader());

                    if (dt.Rows.Count > 0)
                    {
                        previousdues = (decimal)dt.Rows[0][0];
                    }
                    else
                        previousdues = 0;
                }
                else
                {
                    previousdues = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (string.IsNullOrWhiteSpace(TCSbox.Text) || string.IsNullOrEmpty(TCSbox.Text))
                TCSbox.Text = "0";

            if (string.IsNullOrEmpty(dues.Text) || string.IsNullOrWhiteSpace(dues.Text))
                dues.Text = "0";

            predues.Text = (Convert.ToDecimal(dues.Text) + previousdues).ToString();
        }

        // Adding payment Coding
        private void paying_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(paying.Text) || !string.IsNullOrEmpty(paying.Text))
            {
                if (string.IsNullOrEmpty(dues.Text) || string.IsNullOrWhiteSpace(dues.Text))
                    dues.Text = "0";

                if (string.IsNullOrWhiteSpace(TCSbox.Text) || string.IsNullOrEmpty(TCSbox.Text))
                    TCSbox.Text = "0";

                if (string.IsNullOrWhiteSpace(Totalpayment.Text) || string.IsNullOrEmpty(Totalpayment.Text))
                    Totalpayment.Text = "0";

                try
                {
                    if (Convert.ToDecimal(Totalpayment.Text) - Convert.ToDecimal(paying.Text) >= 0)
                        dues.Text = (Convert.ToDecimal(Totalpayment.Text) - Convert.ToDecimal(paying.Text)).ToString();
                    else
                        dues.Text = "0.00";
                    if ((Convert.ToDecimal(Totalpayment.Text) + previousdues) - Convert.ToDecimal(paying.Text) >= 0)
                    {
                        predues.Text = ((Convert.ToDecimal(Totalpayment.Text) + previousdues) - Convert.ToDecimal(paying.Text)).ToString();
                        returnbox.Text = "0.00";
                    }
                    else
                    {
                        returnbox.Text = ((Convert.ToDecimal(Totalpayment.Text) + previousdues) - Convert.ToDecimal(paying.Text)).ToString();
                        predues.Text = "0.00";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    dues.Text = (Convert.ToDecimal(Totalpayment.Text)).ToString();
                    predues.Text = (Convert.ToDecimal(dues.Text) + previousdues).ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // Adding Transport Coding
        private void TCSbox_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TCSbox.Text) || !string.IsNullOrEmpty(TCSbox.Text))
            {
                if (string.IsNullOrEmpty(dues.Text) || string.IsNullOrWhiteSpace(dues.Text))
                    dues.Text = "0";

                if (string.IsNullOrWhiteSpace(paying.Text) || string.IsNullOrEmpty(paying.Text))
                    paying.Text = "0";

                if (string.IsNullOrWhiteSpace(Totalpayment.Text) || string.IsNullOrEmpty(Totalpayment.Text))
                    Totalpayment.Text = "0";

                try
                {
                    Totalpayment.Text = (CalculateBill() + Convert.ToDecimal(TCSbox.Text)).ToString();
                    dues.Text = (Convert.ToDecimal(Totalpayment.Text) - Convert.ToDecimal(paying.Text)).ToString();
                    predues.Text = (Convert.ToDecimal(dues.Text) + previousdues).ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(paying.Text) || string.IsNullOrEmpty(paying.Text))
                        paying.Text = "0";

                    Totalpayment.Text = (CalculateBill()).ToString();
                    dues.Text = (Convert.ToDecimal(Totalpayment.Text) - Convert.ToDecimal(paying.Text)).ToString();
                    predues.Text = (Convert.ToDecimal(dues.Text) + previousdues).ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // Cancel Button Coding
        private void cancelbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ClearTemp();
            SendSelectedData();
            SelectedItems.DataSource = SellDetailsData;
            Totalpayment.Text = CalculateBill().ToString();

        }

        // Deleting particular item
        private void SelectedItems_RowStateChanged_1(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            //try
            //{
            //    if (DB.con.State == ConnectionState.Closed)
            //        DB.con.Open();

            //    cmd = new SqlCommand("RemoveTimebyTimetemp", DB.con) { CommandType = CommandType.StoredProcedure };
            //    cmd.Parameters.Add(new SqlParameter("@data", 2));
            //    cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
            //    cmd.Parameters.Add(new SqlParameter("@sid", SelectedItems.Rows[].Cells["SelectedSID"].Value));

            //    cmd.ExecuteNonQuery();
            //    DB.con.Close();

            //    Totalpayment.Text = CalculateBill().ToString();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        // Time out coding
        private void Timeout_Tick(object sender, EventArgs e)
        {
            if (sec == 0)
            {
                sec = 60;
                min--;
            }
            if (min == 0 && sec == 0)
            {
                min = 15;
                sec = 60;
            }
            TimeoutMinutes.Text = min.ToString();
            TimeoutSec.Text = sec.ToString();
            sec--;
        }

        // Refresh Button Coding
        private void refreshbtn_Click(object sender, EventArgs e)
        {
            object a = new object();
            EventArgs b = new EventArgs();

            SellScreen_uc_Load(a, b);
        }

        // Checkout button coding
        private void Checkoutbtn_Click(object sender, EventArgs e)
        {
            // when any item is selected
            if (SelectedItems.Rows.Count > 0)
            {
                if (string.IsNullOrWhiteSpace(SelectCustomerBox.Text) || string.IsNullOrEmpty(SelectCustomerBox.Text))
                {
                    LocalCustomerChkBox.Checked = true;
                    SelectCustomerAccounts_Form.Customer_id = "1";
                    SelectCustomerAccounts_Form.Customer_mobile = "0000-0000000";
                    SelectCustomerAccounts_Form.Customer_email = "LocalCustomer@MobileShop";
                    SelectCustomerAccounts_Form.Customer_name = "Local";
                    SelectCustomerBox.Text = SelectCustomerAccounts_Form.Customer_name;
                }

                // checking provided information
                if (string.IsNullOrEmpty(SelectCustomerBox.Text) || string.IsNullOrWhiteSpace(SelectCustomerBox.Text))
                    SelectCustomerBox.Focus();
                else if (string.IsNullOrEmpty(paying.Text) || string.IsNullOrWhiteSpace(paying.Text))
                    paying.Text = "0";
                else if (string.IsNullOrWhiteSpace(TCSbox.Text) || string.IsNullOrEmpty(TCSbox.Text))
                    TCSbox.Text = "0";
                else if (SelectCustomerAccounts_Form.Customer_id == "1" && dues.Text != "0.00")
                    paying.Focus();
                
                // Checkout coding
                else
                {
                    try
                    {
                        int chk = 0;

                        // DAtabase connections status
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        // using loop to add all the items data in database
                        for (int i = 0; i < SelectedItems.Rows.Count; i++)
                        {
                            cmd = new SqlCommand("AddSellDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                            cmd.Parameters.Add(new SqlParameter("@aid", SelectCustomerAccounts_Form.Customer_id));
                            cmd.Parameters.Add(new SqlParameter("@EMPID", (int)LoginForm.LoginScreen.personal_info.Rows[0][0]));
                            cmd.Parameters.Add(new SqlParameter("@mobile", SelectCustomerAccounts_Form.Customer_mobile));
                            cmd.Parameters.Add(new SqlParameter("@date", Convert.ToDateTime(DateTime.Now.ToShortDateString())));
                            cmd.Parameters.Add(new SqlParameter("@qty", SelectedItems.Rows[i].Cells["SelectedQuantity"].Value));
                            cmd.Parameters.Add(new SqlParameter("@sell", Convert.ToDecimal(SelectedItems.Rows[i].Cells["SelectedPurchase"].Value)));
                            cmd.Parameters.Add(new SqlParameter("@itemid", SelectedItems.Rows[i].Cells["SelectedID"].Value));
                            cmd.Parameters.Add(new SqlParameter("@imei1", SelectedItems.Rows[i].Cells["SelectedIMEI1"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@imei2", SelectedItems.Rows[i].Cells["SelectedIMEI2"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@email", SelectCustomerAccounts_Form.Customer_email));
                            cmd.Parameters.Add(new SqlParameter("@color", SelectedItems.Rows[i].Cells["SelectedColor"].Value.ToString()));

                            if (SelectCustomerAccounts_Form.Customer_id == "1")
                                cmd.Parameters.Add(new SqlParameter("@customername", SelectCustomerBox.Text));

                            if (SelectedItems.Rows[i].Cells["SelectedCatagory"].Value.ToString() == "Mobile")
                                cmd.Parameters.Add(new SqlParameter("@catagory", 1));
                            else
                                cmd.Parameters.Add(new SqlParameter("@catagory", 2));

                            //variable to change string notation into integer notation 
                            if (SelectedItems.Rows[i].Cells["SelectedBox"].Value.ToString() == "Box")
                                cmd.Parameters.Add(new SqlParameter("@box", 1));
                            else
                                cmd.Parameters.Add(new SqlParameter("@box", 0));

                            cmd.Parameters.Add(new SqlParameter("@Warranty", SelectedItems.Rows[i].Cells["SelectedWarranty"].Value.ToString()));

                            chk = cmd.ExecuteNonQuery();
                        }

                        if (chk > 0)
                        {
                            chk = setSellInvoiceDetails();
                        }

                        DB.con.Close();

                        if (chk > 0)
                        {
                            MessageBox.Show("Purchasement successful");
                            SellScreen_uc_Load(null, null);
                            Totalpayment.Text = "0.00";
                            SelectCustomerBox.Text = string.Empty;
                            paying.Text = "0.00";
                            dues.Text = "0.00";
                            predues.Text = "0.00";
                            TCSbox.Text = "0.00";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

                // Refreshing new list
                getTodaysCustomersList();
            }
            else
                MessageBox.Show("Please select Purchaement first");
        }

        // Direct Local Customer
        private void LocalCustomerChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (LocalCustomerChkBox.Checked)
            {
                SelectCustomerAccounts_Form.Customer_id = "1";
                SelectCustomerAccounts_Form.Customer_mobile = "0000-0000000";
                SelectCustomerAccounts_Form.Customer_email = "LocalCustomer@MobileShop";
                SelectCustomerAccounts_Form.Customer_name = "Local";
                SelectCustomerBox.Text = SelectCustomerAccounts_Form.Customer_name;
                predues.Text = "0.00";
            }
        }

        // Bounding User inputs
        private void TCSbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-'))
                e.Handled = true;
        }
        private void paying_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-'))
                e.Handled = true;
        }

        // Toggle search Button
        private void SearchIMEI_Click(object sender, EventArgs e)
        {
            if (Searchby == 0)
                Searchby = 1;
            else
                Searchby = 0;

            SelectedItems.Focus();
        }

        // Select Items on Click
        private void AllItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Start Timer
            Timeout.Start();

            DataGridViewRow dgvr = AllItems.CurrentRow;

            SellDetailsForm sdf = new SellDetailsForm(dgvr);
            sdf.ShowDialog();

            if (SellDetailsData.Rows.Count > 0)
                SelectedItems.DataSource = SellDetailsData;

            AllItems.Visible = false;
            search = string.Empty;
            Searchtxt.Text = search;

            Totalpayment.Text = CalculateBill().ToString();


            if (string.IsNullOrWhiteSpace(TCSbox.Text) || string.IsNullOrEmpty(TCSbox.Text))
                TCSbox.Text = "0";

            if (string.IsNullOrEmpty(dues.Text) || string.IsNullOrWhiteSpace(dues.Text))
                dues.Text = "0";
            dues.Text = (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(TCSbox.Text)).ToString();
            predues.Text = (Convert.ToDecimal(dues.Text) + previousdues).ToString();
        } 
    }
}
