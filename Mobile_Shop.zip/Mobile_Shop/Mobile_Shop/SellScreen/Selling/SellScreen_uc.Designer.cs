﻿namespace Mobile_Shop.SellScreen
{
    partial class SellScreen_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contentPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.AllItems = new Guna.UI2.WinForms.Guna2DataGridView();
            this.sid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Brands = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quanitity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedItems = new Guna.UI2.WinForms.Guna2DataGridView();
            this.SelectedSID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedPicture = new System.Windows.Forms.DataGridViewImageColumn();
            this.SelectedCatagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedBrand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedIMEI1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedIMEI2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedPurchase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedBox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedWarranty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IMEIID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SearchIMEI = new Guna.UI2.WinForms.Guna2GradientButton();
            this.invoicetxt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cancelbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.refreshbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.Checkoutbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GroupBox4 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.LocalCustomerChkBox = new Guna.UI2.WinForms.Guna2CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PaymentTypebox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.SelectCustomerBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.TodaysSell = new Guna.UI2.WinForms.Guna2DataGridView();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bill = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.predues = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Totalpayment = new Guna.UI2.WinForms.Guna2TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dues = new Guna.UI2.WinForms.Guna2TextBox();
            this.paying = new Guna.UI2.WinForms.Guna2TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.TCSbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Searchtxt = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TimeoutSec = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TimeoutMinutes = new System.Windows.Forms.Label();
            this.Timeout = new System.Windows.Forms.Timer(this.components);
            this.contentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AllItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SelectedItems)).BeginInit();
            this.guna2Panel2.SuspendLayout();
            this.guna2GroupBox4.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TodaysSell)).BeginInit();
            this.SuspendLayout();
            // 
            // contentPanel
            // 
            this.contentPanel.BorderRadius = 10;
            this.contentPanel.Controls.Add(this.AllItems);
            this.contentPanel.Controls.Add(this.SelectedItems);
            this.contentPanel.Controls.Add(this.SearchIMEI);
            this.contentPanel.Controls.Add(this.invoicetxt);
            this.contentPanel.Controls.Add(this.label3);
            this.contentPanel.Controls.Add(this.cancelbtn);
            this.contentPanel.Controls.Add(this.refreshbtn);
            this.contentPanel.Controls.Add(this.guna2Panel2);
            this.contentPanel.Controls.Add(this.label1);
            this.contentPanel.Controls.Add(this.Searchtxt);
            this.contentPanel.Controls.Add(this.label4);
            this.contentPanel.Controls.Add(this.label2);
            this.contentPanel.Controls.Add(this.TimeoutSec);
            this.contentPanel.Controls.Add(this.label5);
            this.contentPanel.Controls.Add(this.TimeoutMinutes);
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentPanel.FillColor = System.Drawing.Color.Transparent;
            this.contentPanel.Location = new System.Drawing.Point(0, 0);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Padding = new System.Windows.Forms.Padding(5);
            this.contentPanel.ShadowDecoration.Parent = this.contentPanel;
            this.contentPanel.Size = new System.Drawing.Size(1060, 554);
            this.contentPanel.TabIndex = 20;
            // 
            // AllItems
            // 
            this.AllItems.AllowUserToAddRows = false;
            this.AllItems.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AllItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.AllItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AllItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AllItems.BackgroundColor = System.Drawing.Color.White;
            this.AllItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AllItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AllItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AllItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.AllItems.ColumnHeadersHeight = 40;
            this.AllItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sid,
            this.ItemID,
            this.Picture,
            this.catagory,
            this.ItemName,
            this.Company,
            this.Brands,
            this.Quanitity});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AllItems.DefaultCellStyle = dataGridViewCellStyle3;
            this.AllItems.EnableHeadersVisualStyles = false;
            this.AllItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AllItems.Location = new System.Drawing.Point(8, 65);
            this.AllItems.Name = "AllItems";
            this.AllItems.ReadOnly = true;
            this.AllItems.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AllItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.AllItems.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.AllItems.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.AllItems.RowTemplate.Height = 80;
            this.AllItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AllItems.Size = new System.Drawing.Size(784, 481);
            this.AllItems.TabIndex = 20;
            this.AllItems.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AllItems.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.AllItems.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.AllItems.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AllItems.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.AllItems.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AllItems.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllItems.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.AllItems.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.AllItems.ThemeStyle.HeaderStyle.Height = 40;
            this.AllItems.ThemeStyle.ReadOnly = true;
            this.AllItems.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.AllItems.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AllItems.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllItems.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.AllItems.ThemeStyle.RowsStyle.Height = 80;
            this.AllItems.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.AllItems.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.AllItems.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AllItems_CellContentClick);
            this.AllItems.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AllItems_KeyDown);
            // 
            // sid
            // 
            this.sid.DataPropertyName = "SID";
            this.sid.HeaderText = "SID";
            this.sid.Name = "sid";
            this.sid.ReadOnly = true;
            this.sid.Visible = false;
            // 
            // ItemID
            // 
            this.ItemID.DataPropertyName = "IID";
            this.ItemID.HeaderText = "ItemID";
            this.ItemID.Name = "ItemID";
            this.ItemID.ReadOnly = true;
            this.ItemID.Visible = false;
            // 
            // Picture
            // 
            this.Picture.DataPropertyName = "Item_Picture";
            this.Picture.FillWeight = 25F;
            this.Picture.HeaderText = "Picture";
            this.Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Picture.Name = "Picture";
            this.Picture.ReadOnly = true;
            // 
            // catagory
            // 
            this.catagory.DataPropertyName = "C_Name";
            this.catagory.FillWeight = 112.4398F;
            this.catagory.HeaderText = "Catagory";
            this.catagory.Name = "catagory";
            this.catagory.ReadOnly = true;
            this.catagory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ItemName
            // 
            this.ItemName.DataPropertyName = "Item_Name";
            this.ItemName.FillWeight = 125.8526F;
            this.ItemName.HeaderText = "Item Name";
            this.ItemName.Name = "ItemName";
            this.ItemName.ReadOnly = true;
            // 
            // Company
            // 
            this.Company.DataPropertyName = "COM_Name";
            this.Company.FillWeight = 112.4398F;
            this.Company.HeaderText = "Company";
            this.Company.Name = "Company";
            this.Company.ReadOnly = true;
            this.Company.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Brands
            // 
            this.Brands.DataPropertyName = "B_Name";
            this.Brands.HeaderText = "Brand";
            this.Brands.Name = "Brands";
            this.Brands.ReadOnly = true;
            // 
            // Quanitity
            // 
            this.Quanitity.DataPropertyName = "Qty";
            this.Quanitity.HeaderText = "Qty";
            this.Quanitity.Name = "Quanitity";
            this.Quanitity.ReadOnly = true;
            this.Quanitity.Visible = false;
            // 
            // SelectedItems
            // 
            this.SelectedItems.AllowUserToAddRows = false;
            this.SelectedItems.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SelectedItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.SelectedItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SelectedItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SelectedItems.BackgroundColor = System.Drawing.Color.White;
            this.SelectedItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SelectedItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SelectedItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.SelectedItems.ColumnHeadersHeight = 40;
            this.SelectedItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectedSID,
            this.SelectedID,
            this.SelectedPicture,
            this.SelectedCatagory,
            this.SelectedName,
            this.SelectedCompany,
            this.SelectedBrand,
            this.SelectedQuantity,
            this.SelectedIMEI1,
            this.SelectedIMEI2,
            this.SelectedColor,
            this.SelectedPurchase,
            this.SelectedPrice,
            this.SelectedBox,
            this.SelectedWarranty,
            this.IMEIID});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SelectedItems.DefaultCellStyle = dataGridViewCellStyle8;
            this.SelectedItems.EnableHeadersVisualStyles = false;
            this.SelectedItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SelectedItems.Location = new System.Drawing.Point(8, 65);
            this.SelectedItems.Name = "SelectedItems";
            this.SelectedItems.ReadOnly = true;
            this.SelectedItems.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 8F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.SelectedItems.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.SelectedItems.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.SelectedItems.RowTemplate.Height = 80;
            this.SelectedItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SelectedItems.Size = new System.Drawing.Size(784, 481);
            this.SelectedItems.TabIndex = 21;
            this.SelectedItems.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.SelectedItems.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.SelectedItems.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SelectedItems.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.SelectedItems.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SelectedItems.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.SelectedItems.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.SelectedItems.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.SelectedItems.ThemeStyle.HeaderStyle.Height = 40;
            this.SelectedItems.ThemeStyle.ReadOnly = true;
            this.SelectedItems.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.SelectedItems.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SelectedItems.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.SelectedItems.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.SelectedItems.ThemeStyle.RowsStyle.Height = 80;
            this.SelectedItems.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.SelectedItems.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.SelectedItems.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.SelectedItems_RowStateChanged_1);
            this.SelectedItems.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SelectedItems_KeyDown);
            // 
            // SelectedSID
            // 
            this.SelectedSID.DataPropertyName = "SelectedSID";
            this.SelectedSID.HeaderText = "SID";
            this.SelectedSID.Name = "SelectedSID";
            this.SelectedSID.ReadOnly = true;
            this.SelectedSID.Visible = false;
            // 
            // SelectedID
            // 
            this.SelectedID.DataPropertyName = "SelectedID";
            this.SelectedID.HeaderText = "ItemID";
            this.SelectedID.Name = "SelectedID";
            this.SelectedID.ReadOnly = true;
            this.SelectedID.Visible = false;
            // 
            // SelectedPicture
            // 
            this.SelectedPicture.DataPropertyName = "SelectedPicture";
            this.SelectedPicture.FillWeight = 50F;
            this.SelectedPicture.HeaderText = "Picture";
            this.SelectedPicture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.SelectedPicture.Name = "SelectedPicture";
            this.SelectedPicture.ReadOnly = true;
            // 
            // SelectedCatagory
            // 
            this.SelectedCatagory.DataPropertyName = "SelectedCatagory";
            this.SelectedCatagory.FillWeight = 112.4398F;
            this.SelectedCatagory.HeaderText = "Catagory";
            this.SelectedCatagory.Name = "SelectedCatagory";
            this.SelectedCatagory.ReadOnly = true;
            this.SelectedCatagory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SelectedName
            // 
            this.SelectedName.DataPropertyName = "SelectedName";
            this.SelectedName.FillWeight = 125.8526F;
            this.SelectedName.HeaderText = "Item Name";
            this.SelectedName.Name = "SelectedName";
            this.SelectedName.ReadOnly = true;
            // 
            // SelectedCompany
            // 
            this.SelectedCompany.DataPropertyName = "SelectedCompany";
            this.SelectedCompany.FillWeight = 112.4398F;
            this.SelectedCompany.HeaderText = "Company";
            this.SelectedCompany.Name = "SelectedCompany";
            this.SelectedCompany.ReadOnly = true;
            this.SelectedCompany.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SelectedBrand
            // 
            this.SelectedBrand.DataPropertyName = "SelectedBrands";
            this.SelectedBrand.HeaderText = "Brand";
            this.SelectedBrand.Name = "SelectedBrand";
            this.SelectedBrand.ReadOnly = true;
            // 
            // SelectedQuantity
            // 
            this.SelectedQuantity.DataPropertyName = "SelectedQuantity";
            this.SelectedQuantity.FillWeight = 50F;
            this.SelectedQuantity.HeaderText = "Qty";
            this.SelectedQuantity.Name = "SelectedQuantity";
            this.SelectedQuantity.ReadOnly = true;
            // 
            // SelectedIMEI1
            // 
            this.SelectedIMEI1.DataPropertyName = "SelectedIMEI1";
            this.SelectedIMEI1.HeaderText = "IMEI1";
            this.SelectedIMEI1.Name = "SelectedIMEI1";
            this.SelectedIMEI1.ReadOnly = true;
            // 
            // SelectedIMEI2
            // 
            this.SelectedIMEI2.DataPropertyName = "SelectedIMEI2";
            this.SelectedIMEI2.HeaderText = "IMEI2";
            this.SelectedIMEI2.Name = "SelectedIMEI2";
            this.SelectedIMEI2.ReadOnly = true;
            // 
            // SelectedColor
            // 
            this.SelectedColor.DataPropertyName = "SelectedColor";
            this.SelectedColor.HeaderText = "Color";
            this.SelectedColor.Name = "SelectedColor";
            this.SelectedColor.ReadOnly = true;
            // 
            // SelectedPurchase
            // 
            this.SelectedPurchase.DataPropertyName = "SelectedSell";
            this.SelectedPurchase.HeaderText = "Rate";
            this.SelectedPurchase.Name = "SelectedPurchase";
            this.SelectedPurchase.ReadOnly = true;
            // 
            // SelectedPrice
            // 
            this.SelectedPrice.DataPropertyName = "SelectedPrice";
            this.SelectedPrice.HeaderText = "Total";
            this.SelectedPrice.Name = "SelectedPrice";
            this.SelectedPrice.ReadOnly = true;
            // 
            // SelectedBox
            // 
            this.SelectedBox.DataPropertyName = "SelectedBox";
            this.SelectedBox.FillWeight = 50F;
            this.SelectedBox.HeaderText = "Box";
            this.SelectedBox.Name = "SelectedBox";
            this.SelectedBox.ReadOnly = true;
            // 
            // SelectedWarranty
            // 
            this.SelectedWarranty.DataPropertyName = "SelectedWarranty";
            this.SelectedWarranty.HeaderText = "Warranty";
            this.SelectedWarranty.Name = "SelectedWarranty";
            this.SelectedWarranty.ReadOnly = true;
            // 
            // IMEIID
            // 
            this.IMEIID.DataPropertyName = "SelectedIMEIID";
            this.IMEIID.HeaderText = "IMEIID";
            this.IMEIID.Name = "IMEIID";
            this.IMEIID.ReadOnly = true;
            this.IMEIID.Visible = false;
            // 
            // SearchIMEI
            // 
            this.SearchIMEI.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchIMEI.BorderColor = System.Drawing.Color.White;
            this.SearchIMEI.BorderRadius = 10;
            this.SearchIMEI.BorderThickness = 2;
            this.SearchIMEI.CheckedState.Parent = this.SearchIMEI;
            this.SearchIMEI.CustomImages.Parent = this.SearchIMEI;
            this.SearchIMEI.FillColor = System.Drawing.Color.Indigo;
            this.SearchIMEI.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.SearchIMEI.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SearchIMEI.ForeColor = System.Drawing.Color.White;
            this.SearchIMEI.HoverState.Parent = this.SearchIMEI;
            this.SearchIMEI.Location = new System.Drawing.Point(700, 5);
            this.SearchIMEI.Name = "SearchIMEI";
            this.SearchIMEI.ShadowDecoration.Parent = this.SearchIMEI;
            this.SearchIMEI.Size = new System.Drawing.Size(91, 31);
            this.SearchIMEI.TabIndex = 15;
            this.SearchIMEI.Text = "IMEI Reader";
            this.SearchIMEI.Click += new System.EventHandler(this.SearchIMEI_Click);
            // 
            // invoicetxt
            // 
            this.invoicetxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.invoicetxt.AutoSize = true;
            this.invoicetxt.BackColor = System.Drawing.Color.Transparent;
            this.invoicetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.invoicetxt.ForeColor = System.Drawing.Color.Indigo;
            this.invoicetxt.Location = new System.Drawing.Point(372, 40);
            this.invoicetxt.Name = "invoicetxt";
            this.invoicetxt.Size = new System.Drawing.Size(55, 22);
            this.invoicetxt.TabIndex = 17;
            this.invoicetxt.Text = "00.00";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(354, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 31);
            this.label3.TabIndex = 17;
            this.label3.Text = "Bill No:";
            // 
            // cancelbtn
            // 
            this.cancelbtn.BorderColor = System.Drawing.Color.White;
            this.cancelbtn.BorderRadius = 10;
            this.cancelbtn.BorderThickness = 2;
            this.cancelbtn.CheckedState.Parent = this.cancelbtn;
            this.cancelbtn.CustomImages.Parent = this.cancelbtn;
            this.cancelbtn.FillColor = System.Drawing.Color.Indigo;
            this.cancelbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.cancelbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cancelbtn.ForeColor = System.Drawing.Color.White;
            this.cancelbtn.HoverState.Parent = this.cancelbtn;
            this.cancelbtn.Location = new System.Drawing.Point(105, 3);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.ShadowDecoration.Parent = this.cancelbtn;
            this.cancelbtn.Size = new System.Drawing.Size(91, 33);
            this.cancelbtn.TabIndex = 15;
            this.cancelbtn.Text = "Rest";
            this.cancelbtn.Click += new System.EventHandler(this.cancelbtn_Click);
            // 
            // refreshbtn
            // 
            this.refreshbtn.BorderColor = System.Drawing.Color.White;
            this.refreshbtn.BorderRadius = 10;
            this.refreshbtn.BorderThickness = 2;
            this.refreshbtn.CheckedState.Parent = this.refreshbtn;
            this.refreshbtn.CustomImages.Parent = this.refreshbtn;
            this.refreshbtn.FillColor = System.Drawing.Color.Indigo;
            this.refreshbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.refreshbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.refreshbtn.ForeColor = System.Drawing.Color.White;
            this.refreshbtn.HoverState.Parent = this.refreshbtn;
            this.refreshbtn.Location = new System.Drawing.Point(8, 3);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.ShadowDecoration.Parent = this.refreshbtn;
            this.refreshbtn.Size = new System.Drawing.Size(91, 33);
            this.refreshbtn.TabIndex = 15;
            this.refreshbtn.Text = "Refresh";
            this.refreshbtn.Click += new System.EventHandler(this.refreshbtn_Click);
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BorderRadius = 10;
            this.guna2Panel2.Controls.Add(this.Checkoutbtn);
            this.guna2Panel2.Controls.Add(this.guna2GroupBox4);
            this.guna2Panel2.Controls.Add(this.guna2GroupBox3);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel2.FillColor = System.Drawing.Color.Indigo;
            this.guna2Panel2.Location = new System.Drawing.Point(798, 5);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(257, 544);
            this.guna2Panel2.TabIndex = 2;
            // 
            // Checkoutbtn
            // 
            this.Checkoutbtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Checkoutbtn.BackColor = System.Drawing.Color.Transparent;
            this.Checkoutbtn.BorderColor = System.Drawing.Color.White;
            this.Checkoutbtn.BorderRadius = 10;
            this.Checkoutbtn.BorderThickness = 2;
            this.Checkoutbtn.CheckedState.Parent = this.Checkoutbtn;
            this.Checkoutbtn.CustomImages.Parent = this.Checkoutbtn;
            this.Checkoutbtn.FillColor = System.Drawing.Color.Indigo;
            this.Checkoutbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Checkoutbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Checkoutbtn.ForeColor = System.Drawing.Color.White;
            this.Checkoutbtn.HoverState.Parent = this.Checkoutbtn;
            this.Checkoutbtn.Location = new System.Drawing.Point(28, 495);
            this.Checkoutbtn.Name = "Checkoutbtn";
            this.Checkoutbtn.ShadowDecoration.Parent = this.Checkoutbtn;
            this.Checkoutbtn.Size = new System.Drawing.Size(200, 46);
            this.Checkoutbtn.TabIndex = 15;
            this.Checkoutbtn.Text = "Check Out";
            this.Checkoutbtn.Click += new System.EventHandler(this.Checkoutbtn_Click);
            // 
            // guna2GroupBox4
            // 
            this.guna2GroupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GroupBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox4.BorderColor = System.Drawing.Color.DarkOrchid;
            this.guna2GroupBox4.BorderRadius = 10;
            this.guna2GroupBox4.Controls.Add(this.LocalCustomerChkBox);
            this.guna2GroupBox4.Controls.Add(this.label12);
            this.guna2GroupBox4.Controls.Add(this.label8);
            this.guna2GroupBox4.Controls.Add(this.PaymentTypebox);
            this.guna2GroupBox4.Controls.Add(this.SelectCustomerBox);
            this.guna2GroupBox4.CustomBorderColor = System.Drawing.Color.DarkTurquoise;
            this.guna2GroupBox4.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox4.Location = new System.Drawing.Point(13, 4);
            this.guna2GroupBox4.Name = "guna2GroupBox4";
            this.guna2GroupBox4.ShadowDecoration.Parent = this.guna2GroupBox4;
            this.guna2GroupBox4.Size = new System.Drawing.Size(231, 146);
            this.guna2GroupBox4.TabIndex = 18;
            // 
            // LocalCustomerChkBox
            // 
            this.LocalCustomerChkBox.AutoSize = true;
            this.LocalCustomerChkBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.LocalCustomerChkBox.CheckedState.BorderRadius = 2;
            this.LocalCustomerChkBox.CheckedState.BorderThickness = 0;
            this.LocalCustomerChkBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.LocalCustomerChkBox.Location = new System.Drawing.Point(48, 5);
            this.LocalCustomerChkBox.Name = "LocalCustomerChkBox";
            this.LocalCustomerChkBox.Size = new System.Drawing.Size(123, 23);
            this.LocalCustomerChkBox.TabIndex = 18;
            this.LocalCustomerChkBox.Text = "Local Customer";
            this.LocalCustomerChkBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.LocalCustomerChkBox.UncheckedState.BorderRadius = 2;
            this.LocalCustomerChkBox.UncheckedState.BorderThickness = 0;
            this.LocalCustomerChkBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.LocalCustomerChkBox.UseVisualStyleBackColor = true;
            this.LocalCustomerChkBox.CheckedChanged += new System.EventHandler(this.LocalCustomerChkBox_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label12.ForeColor = System.Drawing.Color.Indigo;
            this.label12.Location = new System.Drawing.Point(79, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 18);
            this.label12.TabIndex = 17;
            this.label12.Text = "Account/s";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(59, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "Payment Type";
            // 
            // PaymentTypebox
            // 
            this.PaymentTypebox.BackColor = System.Drawing.Color.Transparent;
            this.PaymentTypebox.BorderRadius = 10;
            this.PaymentTypebox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.PaymentTypebox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PaymentTypebox.FocusedColor = System.Drawing.Color.Empty;
            this.PaymentTypebox.FocusedState.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PaymentTypebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.PaymentTypebox.FormattingEnabled = true;
            this.PaymentTypebox.HoverState.Parent = this.PaymentTypebox;
            this.PaymentTypebox.ItemHeight = 30;
            this.PaymentTypebox.ItemsAppearance.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Location = new System.Drawing.Point(18, 105);
            this.PaymentTypebox.Name = "PaymentTypebox";
            this.PaymentTypebox.ShadowDecoration.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Size = new System.Drawing.Size(200, 36);
            this.PaymentTypebox.TabIndex = 4;
            this.PaymentTypebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SelectCustomerBox
            // 
            this.SelectCustomerBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectCustomerBox.BorderRadius = 10;
            this.SelectCustomerBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SelectCustomerBox.DefaultText = "";
            this.SelectCustomerBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SelectCustomerBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SelectCustomerBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SelectCustomerBox.DisabledState.Parent = this.SelectCustomerBox;
            this.SelectCustomerBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SelectCustomerBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SelectCustomerBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SelectCustomerBox.FocusedState.Parent = this.SelectCustomerBox;
            this.SelectCustomerBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SelectCustomerBox.HoverState.Parent = this.SelectCustomerBox;
            this.SelectCustomerBox.Location = new System.Drawing.Point(15, 49);
            this.SelectCustomerBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SelectCustomerBox.Name = "SelectCustomerBox";
            this.SelectCustomerBox.PasswordChar = '\0';
            this.SelectCustomerBox.PlaceholderText = "";
            this.SelectCustomerBox.SelectedText = "";
            this.SelectCustomerBox.ShadowDecoration.Parent = this.SelectCustomerBox;
            this.SelectCustomerBox.Size = new System.Drawing.Size(200, 31);
            this.SelectCustomerBox.TabIndex = 3;
            this.SelectCustomerBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SelectCustomerBox.DoubleClick += new System.EventHandler(this.SelectCustomerBox_DoubleClick);
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.DarkOrchid;
            this.guna2GroupBox3.BorderRadius = 10;
            this.guna2GroupBox3.Controls.Add(this.TodaysSell);
            this.guna2GroupBox3.Controls.Add(this.returnbox);
            this.guna2GroupBox3.Controls.Add(this.predues);
            this.guna2GroupBox3.Controls.Add(this.label6);
            this.guna2GroupBox3.Controls.Add(this.Totalpayment);
            this.guna2GroupBox3.Controls.Add(this.label13);
            this.guna2GroupBox3.Controls.Add(this.label7);
            this.guna2GroupBox3.Controls.Add(this.dues);
            this.guna2GroupBox3.Controls.Add(this.paying);
            this.guna2GroupBox3.Controls.Add(this.label9);
            this.guna2GroupBox3.Controls.Add(this.label10);
            this.guna2GroupBox3.Controls.Add(this.TCSbox);
            this.guna2GroupBox3.Controls.Add(this.label11);
            this.guna2GroupBox3.CustomBorderColor = System.Drawing.Color.DarkTurquoise;
            this.guna2GroupBox3.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(13, 151);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(231, 341);
            this.guna2GroupBox3.TabIndex = 15;
            // 
            // TodaysSell
            // 
            this.TodaysSell.AllowUserToAddRows = false;
            this.TodaysSell.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            this.TodaysSell.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.TodaysSell.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TodaysSell.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TodaysSell.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.TodaysSell.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TodaysSell.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.TodaysSell.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TodaysSell.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.TodaysSell.ColumnHeadersHeight = 40;
            this.TodaysSell.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerName,
            this.Bill});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.TodaysSell.DefaultCellStyle = dataGridViewCellStyle13;
            this.TodaysSell.EnableHeadersVisualStyles = false;
            this.TodaysSell.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.TodaysSell.Location = new System.Drawing.Point(7, 5);
            this.TodaysSell.Name = "TodaysSell";
            this.TodaysSell.ReadOnly = true;
            this.TodaysSell.RowHeadersVisible = false;
            this.TodaysSell.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TodaysSell.Size = new System.Drawing.Size(217, 91);
            this.TodaysSell.TabIndex = 18;
            this.TodaysSell.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.TodaysSell.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.TodaysSell.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.TodaysSell.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.TodaysSell.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.TodaysSell.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.TodaysSell.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TodaysSell.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.TodaysSell.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TodaysSell.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.TodaysSell.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TodaysSell.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.TodaysSell.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.TodaysSell.ThemeStyle.HeaderStyle.Height = 40;
            this.TodaysSell.ThemeStyle.ReadOnly = true;
            this.TodaysSell.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.TodaysSell.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.TodaysSell.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TodaysSell.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.TodaysSell.ThemeStyle.RowsStyle.Height = 22;
            this.TodaysSell.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.TodaysSell.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "Customer";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            // 
            // Bill
            // 
            this.Bill.DataPropertyName = "InvoiceNumber";
            this.Bill.FillWeight = 30F;
            this.Bill.HeaderText = "Bill #";
            this.Bill.Name = "Bill";
            this.Bill.ReadOnly = true;
            // 
            // returnbox
            // 
            this.returnbox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.returnbox.BorderRadius = 10;
            this.returnbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.returnbox.DefaultText = "0";
            this.returnbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.returnbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.returnbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.returnbox.DisabledState.Parent = this.returnbox;
            this.returnbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.returnbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.returnbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.returnbox.FocusedState.Parent = this.returnbox;
            this.returnbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.returnbox.HoverState.Parent = this.returnbox;
            this.returnbox.Location = new System.Drawing.Point(82, 307);
            this.returnbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.returnbox.Name = "returnbox";
            this.returnbox.PasswordChar = '\0';
            this.returnbox.PlaceholderText = "";
            this.returnbox.ReadOnly = true;
            this.returnbox.SelectedText = "";
            this.returnbox.SelectionStart = 1;
            this.returnbox.ShadowDecoration.Parent = this.returnbox;
            this.returnbox.Size = new System.Drawing.Size(136, 30);
            this.returnbox.TabIndex = 3;
            // 
            // predues
            // 
            this.predues.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.predues.BorderRadius = 10;
            this.predues.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.predues.DefaultText = "0";
            this.predues.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.predues.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.predues.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.predues.DisabledState.Parent = this.predues;
            this.predues.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.predues.FillColor = System.Drawing.Color.WhiteSmoke;
            this.predues.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.predues.FocusedState.Parent = this.predues;
            this.predues.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.predues.HoverState.Parent = this.predues;
            this.predues.Location = new System.Drawing.Point(15, 269);
            this.predues.Name = "predues";
            this.predues.PasswordChar = '\0';
            this.predues.PlaceholderText = "";
            this.predues.ReadOnly = true;
            this.predues.SelectedText = "";
            this.predues.SelectionStart = 1;
            this.predues.ShadowDecoration.Parent = this.predues;
            this.predues.Size = new System.Drawing.Size(203, 30);
            this.predues.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(16, 313);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 18);
            this.label6.TabIndex = 17;
            this.label6.Text = "Return";
            // 
            // Totalpayment
            // 
            this.Totalpayment.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Totalpayment.BorderRadius = 10;
            this.Totalpayment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Totalpayment.DefaultText = "0";
            this.Totalpayment.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Totalpayment.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Totalpayment.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Totalpayment.DisabledState.Parent = this.Totalpayment;
            this.Totalpayment.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Totalpayment.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Totalpayment.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Totalpayment.FocusedState.Parent = this.Totalpayment;
            this.Totalpayment.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Totalpayment.HoverState.Parent = this.Totalpayment;
            this.Totalpayment.Location = new System.Drawing.Point(82, 138);
            this.Totalpayment.Name = "Totalpayment";
            this.Totalpayment.PasswordChar = '\0';
            this.Totalpayment.PlaceholderText = "";
            this.Totalpayment.ReadOnly = true;
            this.Totalpayment.SelectedText = "";
            this.Totalpayment.SelectionStart = 1;
            this.Totalpayment.ShadowDecoration.Parent = this.Totalpayment;
            this.Totalpayment.Size = new System.Drawing.Size(136, 30);
            this.Totalpayment.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label13.ForeColor = System.Drawing.Color.Indigo;
            this.label13.Location = new System.Drawing.Point(22, 249);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(189, 18);
            this.label13.TabIndex = 17;
            this.label13.Text = "Pervious + Current Balance";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(16, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 18);
            this.label7.TabIndex = 17;
            this.label7.Text = "Transport Fee";
            // 
            // dues
            // 
            this.dues.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.dues.BorderRadius = 10;
            this.dues.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.dues.DefaultText = "0";
            this.dues.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.dues.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.dues.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.dues.DisabledState.Parent = this.dues;
            this.dues.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.dues.FillColor = System.Drawing.Color.WhiteSmoke;
            this.dues.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.dues.FocusedState.Parent = this.dues;
            this.dues.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.dues.HoverState.Parent = this.dues;
            this.dues.Location = new System.Drawing.Point(82, 212);
            this.dues.Name = "dues";
            this.dues.PasswordChar = '\0';
            this.dues.PlaceholderText = "";
            this.dues.ReadOnly = true;
            this.dues.SelectedText = "";
            this.dues.SelectionStart = 1;
            this.dues.ShadowDecoration.Parent = this.dues;
            this.dues.Size = new System.Drawing.Size(136, 30);
            this.dues.TabIndex = 3;
            // 
            // paying
            // 
            this.paying.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.paying.BorderRadius = 10;
            this.paying.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.paying.DefaultText = "0";
            this.paying.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.paying.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.paying.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.paying.DisabledState.Parent = this.paying;
            this.paying.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.paying.FillColor = System.Drawing.Color.WhiteSmoke;
            this.paying.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.paying.FocusedState.Parent = this.paying;
            this.paying.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.paying.HoverState.Parent = this.paying;
            this.paying.Location = new System.Drawing.Point(82, 175);
            this.paying.Name = "paying";
            this.paying.PasswordChar = '\0';
            this.paying.PlaceholderText = "";
            this.paying.SelectedText = "";
            this.paying.SelectionStart = 1;
            this.paying.ShadowDecoration.Parent = this.paying;
            this.paying.Size = new System.Drawing.Size(136, 30);
            this.paying.TabIndex = 3;
            this.paying.TextChanged += new System.EventHandler(this.paying_TextChanged);
            this.paying.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.paying_KeyPress);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.ForeColor = System.Drawing.Color.Indigo;
            this.label9.Location = new System.Drawing.Point(15, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 18);
            this.label9.TabIndex = 17;
            this.label9.Text = "Total";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label10.ForeColor = System.Drawing.Color.Indigo;
            this.label10.Location = new System.Drawing.Point(16, 181);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 18);
            this.label10.TabIndex = 17;
            this.label10.Text = "Paying";
            // 
            // TCSbox
            // 
            this.TCSbox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.TCSbox.BorderRadius = 10;
            this.TCSbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TCSbox.DefaultText = "0";
            this.TCSbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TCSbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TCSbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TCSbox.DisabledState.Parent = this.TCSbox;
            this.TCSbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TCSbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TCSbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TCSbox.FocusedState.Parent = this.TCSbox;
            this.TCSbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TCSbox.HoverState.Parent = this.TCSbox;
            this.TCSbox.Location = new System.Drawing.Point(122, 102);
            this.TCSbox.Name = "TCSbox";
            this.TCSbox.PasswordChar = '\0';
            this.TCSbox.PlaceholderText = "";
            this.TCSbox.SelectedText = "";
            this.TCSbox.SelectionStart = 1;
            this.TCSbox.ShadowDecoration.Parent = this.TCSbox;
            this.TCSbox.Size = new System.Drawing.Size(94, 30);
            this.TCSbox.TabIndex = 3;
            this.TCSbox.TextChanged += new System.EventHandler(this.TCSbox_TextChanged);
            this.TCSbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TCSbox_KeyPress);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.ForeColor = System.Drawing.Color.Indigo;
            this.label11.Location = new System.Drawing.Point(16, 218);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 18);
            this.label11.TabIndex = 17;
            this.label11.Text = "Due";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(8, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 22);
            this.label1.TabIndex = 17;
            this.label1.Text = "Search";
            // 
            // Searchtxt
            // 
            this.Searchtxt.AutoSize = true;
            this.Searchtxt.BackColor = System.Drawing.Color.Transparent;
            this.Searchtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Searchtxt.ForeColor = System.Drawing.Color.Indigo;
            this.Searchtxt.Location = new System.Drawing.Point(81, 40);
            this.Searchtxt.Name = "Searchtxt";
            this.Searchtxt.Size = new System.Drawing.Size(15, 22);
            this.Searchtxt.TabIndex = 17;
            this.Searchtxt.Text = ".";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(753, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 22);
            this.label4.TabIndex = 17;
            this.label4.Text = ":";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(617, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 22);
            this.label2.TabIndex = 17;
            this.label2.Text = "Time Out:";
            // 
            // TimeoutSec
            // 
            this.TimeoutSec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TimeoutSec.AutoSize = true;
            this.TimeoutSec.BackColor = System.Drawing.Color.Transparent;
            this.TimeoutSec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.TimeoutSec.ForeColor = System.Drawing.Color.Indigo;
            this.TimeoutSec.Location = new System.Drawing.Point(763, 40);
            this.TimeoutSec.Name = "TimeoutSec";
            this.TimeoutSec.Size = new System.Drawing.Size(28, 22);
            this.TimeoutSec.TabIndex = 17;
            this.TimeoutSec.Text = "ss";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(617, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 22);
            this.label5.TabIndex = 17;
            this.label5.Text = "Barcode";
            // 
            // TimeoutMinutes
            // 
            this.TimeoutMinutes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TimeoutMinutes.AutoSize = true;
            this.TimeoutMinutes.BackColor = System.Drawing.Color.Transparent;
            this.TimeoutMinutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.TimeoutMinutes.ForeColor = System.Drawing.Color.Indigo;
            this.TimeoutMinutes.Location = new System.Drawing.Point(720, 40);
            this.TimeoutMinutes.Name = "TimeoutMinutes";
            this.TimeoutMinutes.Size = new System.Drawing.Size(38, 22);
            this.TimeoutMinutes.TabIndex = 17;
            this.TimeoutMinutes.Text = "mm";
            // 
            // Timeout
            // 
            this.Timeout.Enabled = true;
            this.Timeout.Interval = 1000;
            this.Timeout.Tick += new System.EventHandler(this.Timeout_Tick);
            // 
            // SellScreen_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentPanel);
            this.Name = "SellScreen_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.SellScreen_uc_Load);
            this.contentPanel.ResumeLayout(false);
            this.contentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AllItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SelectedItems)).EndInit();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2GroupBox4.ResumeLayout(false);
            this.guna2GroupBox4.PerformLayout();
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TodaysSell)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel contentPanel;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2GradientButton Checkoutbtn;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox4;
        private Guna.UI2.WinForms.Guna2TextBox predues;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2TextBox Totalpayment;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox dues;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox paying;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2TextBox TCSbox;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2ComboBox PaymentTypebox;
        private System.Windows.Forms.Label invoicetxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2GradientButton refreshbtn;
        private Guna.UI2.WinForms.Guna2DataGridView AllItems;
        private Guna.UI2.WinForms.Guna2DataGridView SelectedItems;
        private System.Windows.Forms.Label Searchtxt;
        private Guna.UI2.WinForms.Guna2GradientButton SearchIMEI;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox SelectCustomerBox;
        private Guna.UI2.WinForms.Guna2GradientButton cancelbtn;
        private System.Windows.Forms.Label TimeoutMinutes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn sid;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemID;
        private System.Windows.Forms.DataGridViewImageColumn Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Company;
        private System.Windows.Forms.DataGridViewTextBoxColumn Brands;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quanitity;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedSID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedID;
        private System.Windows.Forms.DataGridViewImageColumn SelectedPicture;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedCatagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedBrand;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedIMEI1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedIMEI2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedColor;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedPurchase;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedWarranty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMEIID;
        private Guna.UI2.WinForms.Guna2DataGridView TodaysSell;
        private System.Windows.Forms.Label TimeoutSec;
        private System.Windows.Forms.Timer Timeout;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bill;
        private Guna.UI2.WinForms.Guna2CheckBox LocalCustomerChkBox;
        private Guna.UI2.WinForms.Guna2TextBox returnbox;
        private System.Windows.Forms.Label label6;
    }
}
