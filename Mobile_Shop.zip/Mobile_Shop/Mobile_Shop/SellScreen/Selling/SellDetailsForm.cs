﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen
{
    public partial class SellDetailsForm : Form
    {
        // Global Variables
        DataGridViewRow dgvr;
        int totalqty;
        SqlCommand cmd;

        //Constructor
        public SellDetailsForm(DataGridViewRow SelectedItemData)
        {
            InitializeComponent();
            dgvr = new DataGridViewRow();
            dgvr = SelectedItemData;
        }

        // Function to Load selected Items data
        private void selectedIteminfo()
        {
            byte[] pic = (byte[])dgvr.Cells["Picture"].Value;
            MemoryStream ms = new MemoryStream(pic);
            ItemPicture.Image = Image.FromStream(ms);

            ItemName.Text = dgvr.Cells["ItemName"].Value.ToString();
            Catagorybox.Text = dgvr.Cells["Catagory"].Value.ToString();
            Companybox.Text = dgvr.Cells["Company"].Value.ToString();
            Brandbox.Text = dgvr.Cells["Brands"].Value.ToString();
        }

        // Function to get Items Details
        private void GetItemsDetails()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("SellItemsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@sid", dgvr.Cells["sid"].Value));

                dt.Load(cmd.ExecuteReader());

                DB.con.Close();

                GridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Cross button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Main Load Function
        private void SellDetailsForm_Load(object sender, EventArgs e)
        {
            Quantity.Text = string.Empty;
            Quantity.Focus();

            // Retriving Selected Items Details
            GetItemsDetails();
            selectedIteminfo();

            totalqty = -1;
            warning1.Hide();
            warning2.Hide();
        }

        private void GridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(Quantity.Text) || !string.IsNullOrWhiteSpace(Quantity.Text))
            {
                warning2.Hide();
                warning1.Hide();

                if (Convert.ToInt32(Quantity.Text) <= (int)dgvr.Cells["Quanitity"].Value && Convert.ToInt32(Quantity.Text) > 0)
                {
                    if (totalqty == -1)
                        totalqty = Convert.ToInt32(Quantity.Text);

                    if (e.ColumnIndex == 0)
                    {
                        try
                        {
                            DataRow dr = SellScreen_uc.SellDetailsData.NewRow();

                            dr[0] = dgvr.Cells["sid"].Value;
                            dr[1] = dgvr.Cells["itemID"].Value;
                            // dr[2] = dgvr.Cells["Picture"].Value;
                            dr[3] = dgvr.Cells["ItemName"].Value.ToString();
                            dr[4] = dgvr.Cells["Catagory"].Value.ToString();
                            dr[5] = dgvr.Cells["Company"].Value.ToString();
                            dr[6] = dgvr.Cells["Brands"].Value.ToString();

                            if (Catagorybox.Text != "Mobile")
                            {
                                dr[7] = Convert.ToInt32(Quantity.Text);
                                dr[11] = (Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(GridView.Rows[e.RowIndex].Cells["SP"].Value));
                            }
                            else
                            {
                                dr[7] = 1;
                                dr[11] = GridView.Rows[e.RowIndex].Cells["SP"].Value;
                            }

                            dr[8] = GridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString();
                            dr[9] = GridView.Rows[e.RowIndex].Cells["IMEI2"].Value.ToString();
                            dr[10] = GridView.Rows[e.RowIndex].Cells["SP"].Value;
                            dr[12] = GridView.Rows[e.RowIndex].Cells["Color"].Value.ToString();
                            dr[13] = GridView.Rows[e.RowIndex].Cells["Box"].Value.ToString();
                            dr[14] = GridView.Rows[e.RowIndex].Cells["Warranty"].Value.ToString();
                            dr[15] = GridView.Rows[e.RowIndex].Cells["IMEIID"].Value;

                            int chk = 0;
                            if(Catagorybox.Text == "Mobile")
                            {
                                SellScreen_uc.SellDetailsData.Rows.Add(dr);
                            }
                            else
                            {
                                for (int i = 0; i < SellScreen_uc.SellDetailsData.Rows.Count; i++)
			                    {
                                    if (GridView.Rows[e.RowIndex].Cells["IMEIID"].Value.ToString() == SellScreen_uc.SellDetailsData.Rows[i][15].ToString())
                                    {
                                        chk = 1;
                                        SellScreen_uc.SellDetailsData.Rows[i][7] = Convert.ToInt32(SellScreen_uc.SellDetailsData.Rows[i][7]) + Convert.ToInt32(Quantity.Text);
                                        SellScreen_uc.SellDetailsData.Rows[i][11] = Convert.ToDecimal(SellScreen_uc.SellDetailsData.Rows[i][11]) + (Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(GridView.Rows[e.RowIndex].Cells["SP"].Value));
                                        break;
                                    }
			                    }
                                if (chk == 0)
                                {
                                    SellScreen_uc.SellDetailsData.Rows.Add(dr);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Error");
                        }

                        // holding dataRecord
                        try
                        {
                            if (DB.con.State == ConnectionState.Closed)
                                DB.con.Open();

                            cmd = new SqlCommand("TempData", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@emp", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                            cmd.Parameters.Add(new SqlParameter("@sid", dgvr.Cells["sid"].Value));
                            cmd.Parameters.Add(new SqlParameter("@imeiid", GridView.Rows[e.RowIndex].Cells["IMEIID"].Value));

                            if (Catagorybox.Text != "Mobile")
                                cmd.Parameters.Add(new SqlParameter("@qty", Quantity.Text));
                            else
                                cmd.Parameters.Add(new SqlParameter("@qty", 1));

                            cmd.Parameters.Add(new SqlParameter("@catagory", Catagorybox.Text));
                            cmd.Parameters.Add(new SqlParameter("@time", 20));

                            cmd.ExecuteNonQuery();
                            DB.con.Close();

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                        // When Catagory is mobile
                        if (Catagorybox.Text == "Mobile")
                        {
                            Quantity.Enabled = false;

                            totalqty = totalqty - 1;
                            if (totalqty == 0)
                            {
                                this.Close();
                            }

                            RemainIMEILabel.Show();
                            RemainIMEILabel.Text = (totalqty.ToString() + " / " + Quantity.Text);
                        }
                        else
                        {
                            
                            this.Close();
                        }

                        //refreshing
                        GetItemsDetails();
                    }
                    else
                    {
                        warning1.Show();
                        Quantity.Focus();
                    }
                }

                else
                {
                    Quantity.Focus();
                    warning2.Show();
                }
            }
        }

        //Search button Coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Searchbox.Text) || !string.IsNullOrWhiteSpace(Searchbox.Text))
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    cmd = new SqlCommand("SellItemsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 2));
                    cmd.Parameters.Add(new SqlParameter("@sid", dgvr.Cells["sid"].Value));
                    cmd.Parameters.Add(new SqlParameter("@search", Searchbox.Text));

                    dt.Load(cmd.ExecuteReader());

                    GridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                Searchbox.Focus();
        }

        // All Items Data Coding
        private void Searchbox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Searchbox.Text) || string.IsNullOrEmpty(Searchbox.Text))
            {
                GetItemsDetails();
            }
        }
    }
}
