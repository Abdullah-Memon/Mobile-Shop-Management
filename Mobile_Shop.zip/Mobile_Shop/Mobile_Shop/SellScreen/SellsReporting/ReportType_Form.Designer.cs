﻿namespace Mobile_Shop.SellScreen.SellsReporting
{
    partial class ReportType_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Createbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.ReportType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2GradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(153, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Report Type";
            // 
            // Createbtn
            // 
            this.Createbtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Createbtn.BorderColor = System.Drawing.Color.White;
            this.Createbtn.BorderRadius = 10;
            this.Createbtn.BorderThickness = 2;
            this.Createbtn.CheckedState.Parent = this.Createbtn;
            this.Createbtn.CustomImages.Parent = this.Createbtn;
            this.Createbtn.FillColor = System.Drawing.Color.Indigo;
            this.Createbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Createbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Createbtn.ForeColor = System.Drawing.Color.White;
            this.Createbtn.HoverState.Parent = this.Createbtn;
            this.Createbtn.Location = new System.Drawing.Point(280, 126);
            this.Createbtn.Name = "Createbtn";
            this.Createbtn.ShadowDecoration.Parent = this.Createbtn;
            this.Createbtn.Size = new System.Drawing.Size(88, 36);
            this.Createbtn.TabIndex = 18;
            this.Createbtn.Text = "Generate";
            this.Createbtn.Click += new System.EventHandler(this.Createbtn_Click);
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.Controls.Add(this.crossbtn);
            this.guna2GradientPanel3.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientPanel3.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientPanel3.Location = new System.Drawing.Point(327, -9);
            this.guna2GradientPanel3.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.ShadowDecoration.Parent = this.guna2GradientPanel3;
            this.guna2GradientPanel3.Size = new System.Drawing.Size(41, 56);
            this.guna2GradientPanel3.TabIndex = 17;
            // 
            // crossbtn
            // 
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.White;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.Indigo;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(3, 16);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 13;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 12);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(138, 149);
            this.guna2PictureBox1.TabIndex = 19;
            this.guna2PictureBox1.TabStop = false;
            // 
            // ReportType
            // 
            this.ReportType.BackColor = System.Drawing.Color.Transparent;
            this.ReportType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ReportType.FocusedColor = System.Drawing.Color.Empty;
            this.ReportType.FocusedState.Parent = this.ReportType;
            this.ReportType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.ReportType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.ReportType.FormattingEnabled = true;
            this.ReportType.HoverState.Parent = this.ReportType;
            this.ReportType.ItemHeight = 30;
            this.ReportType.Items.AddRange(new object[] {
            "All Accounts",
            "Clearance only",
            "Dues only",
            "Custom"});
            this.ReportType.ItemsAppearance.Parent = this.ReportType;
            this.ReportType.Location = new System.Drawing.Point(157, 84);
            this.ReportType.Name = "ReportType";
            this.ReportType.ShadowDecoration.Parent = this.ReportType;
            this.ReportType.Size = new System.Drawing.Size(211, 36);
            this.ReportType.TabIndex = 20;
            // 
            // ReportType_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(377, 176);
            this.Controls.Add(this.ReportType);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.Createbtn);
            this.Controls.Add(this.guna2GradientPanel3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ReportType_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReportType_Form";
            this.Load += new System.EventHandler(this.ReportType_Form_Load);
            this.guna2GradientPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientButton Createbtn;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2ComboBox ReportType;
    }
}