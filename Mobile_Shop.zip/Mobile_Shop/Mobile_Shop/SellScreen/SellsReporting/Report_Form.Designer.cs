﻿namespace Mobile_Shop.SellScreen.SellsReporting
{
    partial class Report_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.upperpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Customebox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.selectcatagorybox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.selectAccountbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Createbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.todate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.fromdate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.reportViewer1 = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.lowerpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.upperpanel.SuspendLayout();
            this.guna2GradientPanel3.SuspendLayout();
            this.Customebox.SuspendLayout();
            this.lowerpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.upperpanel;
            // 
            // upperpanel
            // 
            this.upperpanel.BackColor = System.Drawing.Color.Transparent;
            this.upperpanel.Controls.Add(this.guna2GradientPanel3);
            this.upperpanel.Controls.Add(this.Customebox);
            this.upperpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.upperpanel.Location = new System.Drawing.Point(0, 0);
            this.upperpanel.Name = "upperpanel";
            this.upperpanel.ShadowDecoration.Parent = this.upperpanel;
            this.upperpanel.Size = new System.Drawing.Size(1002, 108);
            this.upperpanel.TabIndex = 6;
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.Controls.Add(this.guna2CircleButton2);
            this.guna2GradientPanel3.Controls.Add(this.guna2CircleButton1);
            this.guna2GradientPanel3.Controls.Add(this.crossbtn);
            this.guna2GradientPanel3.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientPanel3.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientPanel3.Location = new System.Drawing.Point(876, 0);
            this.guna2GradientPanel3.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.ShadowDecoration.Parent = this.guna2GradientPanel3;
            this.guna2GradientPanel3.Size = new System.Drawing.Size(127, 50);
            this.guna2GradientPanel3.TabIndex = 2;
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.CheckedState.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.CustomImages.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton2.HoverState.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.Location = new System.Drawing.Point(5, 8);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.ShadowDecoration.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.Size = new System.Drawing.Size(35, 35);
            this.guna2CircleButton2.TabIndex = 15;
            this.guna2CircleButton2.Text = "--";
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(46, 8);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(35, 35);
            this.guna2CircleButton1.TabIndex = 14;
            this.guna2CircleButton1.Text = "|=|";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // crossbtn
            // 
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.White;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.Indigo;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(87, 8);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 13;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // Customebox
            // 
            this.Customebox.BorderThickness = 0;
            this.Customebox.Controls.Add(this.selectcatagorybox);
            this.Customebox.Controls.Add(this.label1);
            this.Customebox.Controls.Add(this.selectAccountbox);
            this.Customebox.Controls.Add(this.Createbtn);
            this.Customebox.Controls.Add(this.todate);
            this.Customebox.Controls.Add(this.fromdate);
            this.Customebox.Controls.Add(this.label3);
            this.Customebox.Controls.Add(this.label4);
            this.Customebox.Controls.Add(this.label2);
            this.Customebox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.Customebox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Customebox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customebox.ForeColor = System.Drawing.Color.Indigo;
            this.Customebox.Location = new System.Drawing.Point(0, 46);
            this.Customebox.Name = "Customebox";
            this.Customebox.ShadowDecoration.Parent = this.Customebox;
            this.Customebox.Size = new System.Drawing.Size(1002, 62);
            this.Customebox.TabIndex = 3;
            this.Customebox.Text = "";
            // 
            // selectcatagorybox
            // 
            this.selectcatagorybox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.selectcatagorybox.BackColor = System.Drawing.Color.Transparent;
            this.selectcatagorybox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.selectcatagorybox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectcatagorybox.FocusedColor = System.Drawing.Color.Empty;
            this.selectcatagorybox.FocusedState.Parent = this.selectcatagorybox;
            this.selectcatagorybox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.selectcatagorybox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.selectcatagorybox.FormattingEnabled = true;
            this.selectcatagorybox.HoverState.Parent = this.selectcatagorybox;
            this.selectcatagorybox.ItemHeight = 30;
            this.selectcatagorybox.Items.AddRange(new object[] {
            "All",
            "After Clearance"});
            this.selectcatagorybox.ItemsAppearance.Parent = this.selectcatagorybox;
            this.selectcatagorybox.Location = new System.Drawing.Point(234, 24);
            this.selectcatagorybox.Name = "selectcatagorybox";
            this.selectcatagorybox.ShadowDecoration.Parent = this.selectcatagorybox;
            this.selectcatagorybox.Size = new System.Drawing.Size(220, 36);
            this.selectcatagorybox.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(234, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "Select Catagory";
            // 
            // selectAccountbox
            // 
            this.selectAccountbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.selectAccountbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.selectAccountbox.DefaultText = "";
            this.selectAccountbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.selectAccountbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.selectAccountbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.selectAccountbox.DisabledState.Parent = this.selectAccountbox;
            this.selectAccountbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.selectAccountbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.selectAccountbox.FocusedState.Parent = this.selectAccountbox;
            this.selectAccountbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.selectAccountbox.HoverState.Parent = this.selectAccountbox;
            this.selectAccountbox.Location = new System.Drawing.Point(12, 26);
            this.selectAccountbox.Name = "selectAccountbox";
            this.selectAccountbox.PasswordChar = '\0';
            this.selectAccountbox.PlaceholderText = "";
            this.selectAccountbox.SelectedText = "";
            this.selectAccountbox.ShadowDecoration.Parent = this.selectAccountbox;
            this.selectAccountbox.Size = new System.Drawing.Size(215, 36);
            this.selectAccountbox.TabIndex = 17;
            this.selectAccountbox.DoubleClick += new System.EventHandler(this.selectAccountbox_DoubleClick);
            // 
            // Createbtn
            // 
            this.Createbtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Createbtn.BorderColor = System.Drawing.Color.White;
            this.Createbtn.BorderRadius = 10;
            this.Createbtn.BorderThickness = 2;
            this.Createbtn.CheckedState.Parent = this.Createbtn;
            this.Createbtn.CustomImages.Parent = this.Createbtn;
            this.Createbtn.FillColor = System.Drawing.Color.Indigo;
            this.Createbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Createbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Createbtn.ForeColor = System.Drawing.Color.White;
            this.Createbtn.HoverState.Parent = this.Createbtn;
            this.Createbtn.Location = new System.Drawing.Point(900, 26);
            this.Createbtn.Name = "Createbtn";
            this.Createbtn.ShadowDecoration.Parent = this.Createbtn;
            this.Createbtn.Size = new System.Drawing.Size(88, 36);
            this.Createbtn.TabIndex = 16;
            this.Createbtn.Text = "Generate";
            this.Createbtn.Click += new System.EventHandler(this.Createbtn_Click);
            // 
            // todate
            // 
            this.todate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.todate.CheckedState.Parent = this.todate;
            this.todate.FillColor = System.Drawing.Color.Indigo;
            this.todate.ForeColor = System.Drawing.Color.White;
            this.todate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.todate.HoverState.Parent = this.todate;
            this.todate.Location = new System.Drawing.Point(666, 26);
            this.todate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.todate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.todate.Name = "todate";
            this.todate.ShadowDecoration.Parent = this.todate;
            this.todate.Size = new System.Drawing.Size(200, 36);
            this.todate.TabIndex = 5;
            this.todate.Value = new System.DateTime(2022, 9, 15, 6, 12, 8, 309);
            // 
            // fromdate
            // 
            this.fromdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.fromdate.CheckedState.Parent = this.fromdate;
            this.fromdate.FillColor = System.Drawing.Color.Indigo;
            this.fromdate.ForeColor = System.Drawing.Color.White;
            this.fromdate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.fromdate.HoverState.Parent = this.fromdate;
            this.fromdate.Location = new System.Drawing.Point(460, 26);
            this.fromdate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.fromdate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.fromdate.Name = "fromdate";
            this.fromdate.ShadowDecoration.Parent = this.fromdate;
            this.fromdate.Size = new System.Drawing.Size(200, 36);
            this.fromdate.TabIndex = 5;
            this.fromdate.Value = new System.DateTime(2022, 9, 15, 6, 12, 8, 309);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(662, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Select Account";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(457, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "From";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.reportViewer1.Location = new System.Drawing.Point(0, 112);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1002, 651);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ViewMode = Telerik.ReportViewer.WinForms.ViewMode.PrintPreview;
            // 
            // lowerpanel
            // 
            this.lowerpanel.BackColor = System.Drawing.Color.Transparent;
            this.lowerpanel.Controls.Add(this.reportViewer1);
            this.lowerpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lowerpanel.Location = new System.Drawing.Point(0, 0);
            this.lowerpanel.Name = "lowerpanel";
            this.lowerpanel.ShadowDecoration.Parent = this.lowerpanel;
            this.lowerpanel.Size = new System.Drawing.Size(1002, 763);
            this.lowerpanel.TabIndex = 7;
            // 
            // Report_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1002, 763);
            this.Controls.Add(this.upperpanel);
            this.Controls.Add(this.lowerpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Report_Form";
            this.Text = "Report_Form";
            this.Load += new System.EventHandler(this.Report_Form_Load);
            this.upperpanel.ResumeLayout(false);
            this.guna2GradientPanel3.ResumeLayout(false);
            this.Customebox.ResumeLayout(false);
            this.Customebox.PerformLayout();
            this.lowerpanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GradientPanel upperpanel;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private Guna.UI2.WinForms.Guna2GroupBox Customebox;
        private Guna.UI2.WinForms.Guna2ComboBox selectcatagorybox;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox selectAccountbox;
        private Guna.UI2.WinForms.Guna2GradientButton Createbtn;
        private Guna.UI2.WinForms.Guna2DateTimePicker todate;
        private Guna.UI2.WinForms.Guna2DateTimePicker fromdate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Telerik.ReportViewer.WinForms.ReportViewer reportViewer1;
        private Guna.UI2.WinForms.Guna2GradientPanel lowerpanel;
    }
}