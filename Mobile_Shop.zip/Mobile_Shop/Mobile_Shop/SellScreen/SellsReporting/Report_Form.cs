﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.SellScreen.SellsReporting
{
    public partial class Report_Form : Form
    {
        int ReportType;
        string aid;

        public Report_Form(int type)
        {
            InitializeComponent();
            ReportType = type;
        }

        private void Report_Form_Load(object sender, EventArgs e)
        {
            fromdate.Text = DateTime.Now.ToShortDateString();
            todate.Text = DateTime.Now.ToShortDateString();

            if (ReportType != 3)
            {
                Customebox.Hide();

                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();
                    SqlCommand cmd = new SqlCommand("SellBillsAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    dt.Load(cmd.ExecuteReader());

                    List<ReportingData_Class> li = new List<ReportingData_Class>();

                    if (dt.Rows.Count > 0)
                    {
                        DataTable dt1 = new DataTable();
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            cmd = new SqlCommand("GenerateSellReport", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@data", ReportType));
                            cmd.Parameters.Add(new SqlParameter("@aid", dt.Rows[i][0]));
                            dt1.Load(cmd.ExecuteReader());

                            if (dt1.Rows.Count > 0)
                            {
                                li.Add(new ReportingData_Class()
                                    {
                                        TCS = Convert.ToDecimal(dt1.Rows[0][0]),
                                        A_Name = dt1.Rows[0][1].ToString(),
                                        A_CNIC = dt1.Rows[0][2].ToString(),
                                        A_Mobile = dt1.Rows[0][3].ToString(),
                                        A_EmailAddress = dt1.Rows[0][4].ToString(),
                                        A_Address = dt1.Rows[0][5].ToString(),
                                        Total_Bill = Convert.ToDecimal(dt1.Rows[0][6]),
                                        Total_Paid = Convert.ToDecimal(dt1.Rows[0][7]),
                                    });
                            }
                        }
                    }
                   
                    DB.con.Close();
                    
                    Report_Page rp = new Report_Page();
                    rp.DataSource = li;

                    InstanceReportSource irp = new InstanceReportSource() { ReportDocument = rp };

                    reportViewer1.ReportSource = irp;
                    reportViewer1.RefreshReport();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                Customebox.Show();
                selectcatagorybox.SelectedIndex = 0;
                WindowState = FormWindowState.Maximized;
            }
        }

        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
            }
            else
                WindowState = FormWindowState.Maximized;
        }

        private void selectAccountbox_DoubleClick(object sender, EventArgs e)
        {
            SelectCustomerAccounts_Form scaf = new SelectCustomerAccounts_Form(1);
            scaf.ShowDialog();

            selectAccountbox.Text = SelectCustomerAccounts_Form.Customer_name;
            aid = SelectCustomerAccounts_Form.Customer_id;
        }

        private void Createbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectAccountbox.Text) || string.IsNullOrWhiteSpace(selectAccountbox.Text))
            {
                selectAccountbox.Focus();
            }
            else if (string.IsNullOrEmpty(selectcatagorybox.Text) || string.IsNullOrWhiteSpace(selectcatagorybox.Text))
            {
                selectcatagorybox.Focus();
            }
            else
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    SqlCommand cmd = new SqlCommand("GenerateCustomSellReport", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@aid", aid));
                    cmd.Parameters.Add(new SqlParameter("@type", selectcatagorybox.SelectedIndex));
                    cmd.Parameters.Add(new SqlParameter("@fromdate", fromdate.Value));
                    cmd.Parameters.Add(new SqlParameter("@todate", todate.Value));


                    dt.Load(cmd.ExecuteReader());

                    CustomeReport_Page crp = new CustomeReport_Page();
                    crp.DataSource = dt;

                    InstanceReportSource irp = new InstanceReportSource() { ReportDocument = crp };

                    reportViewer1.ReportSource = irp;
                    reportViewer1.RefreshReport();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
