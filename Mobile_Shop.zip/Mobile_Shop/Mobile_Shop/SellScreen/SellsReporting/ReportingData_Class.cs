﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.SellScreen.SellsReporting
{
    class ReportingData_Class
    {
        public decimal Pre { set; get; }
        public string A_Name { set; get; }
        public string A_CNIC { set; get; }
        public string A_Mobile { set; get; }
        public string A_EmailAddress { set; get; }
        public string A_Address { set; get; }
        public string Date { set; get; }
        public decimal Total_Bill { set; get; }
        public decimal Total_Paid { set; get; }
        public decimal PP { set; get; }
        public string ItemDetail { set; get; }
        public int Qty { set; get; }
        public int C_Qty { set; get; }
        public int R_Qty { set; get; }
        public decimal Item_Total_Bill { set; get; }
        public decimal TCS { set; get; }
        public decimal Pay { set; get; }
    }
}
