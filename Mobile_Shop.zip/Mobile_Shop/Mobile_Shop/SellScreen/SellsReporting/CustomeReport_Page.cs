namespace Mobile_Shop.SellScreen.SellsReporting
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;

    /// <summary>
    /// Summary description for CustomeReport_Page.
    /// </summary>
    public partial class CustomeReport_Page : Telerik.Reporting.Report
    {
        public CustomeReport_Page()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}