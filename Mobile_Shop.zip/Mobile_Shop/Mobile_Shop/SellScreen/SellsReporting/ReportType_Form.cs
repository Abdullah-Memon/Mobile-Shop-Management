﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.SellScreen.SellsReporting
{
    public partial class ReportType_Form : Form
    {
        public ReportType_Form()
        {
            InitializeComponent();
        }

        private void ReportType_Form_Load(object sender, EventArgs e)
        {
            ReportType.SelectedIndex = 0;
        }

        private void Createbtn_Click(object sender, EventArgs e)
        {
            Report_Form rf = new Report_Form(ReportType.SelectedIndex);
            rf.Show();
            this.Close();
        }

        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
