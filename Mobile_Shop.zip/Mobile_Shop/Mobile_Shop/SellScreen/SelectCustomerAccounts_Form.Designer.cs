﻿namespace Mobile_Shop.SellScreen
{
    partial class SelectCustomerAccounts_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.localselectbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.localCustomerEmailAddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.localCustomerName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.local = new System.Windows.Forms.Label();
            this.warning5 = new System.Windows.Forms.Label();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.localCustomerbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.localCustomerMobile = new Guna.UI2.WinForms.Guna2TextBox();
            this.ACC_Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ACC_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.ACC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerAccountsGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.localCustomerbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerAccountsGridView)).BeginInit();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            this.ContentPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // localselectbtn
            // 
            this.localselectbtn.BackColor = System.Drawing.Color.Transparent;
            this.localselectbtn.BorderColor = System.Drawing.Color.White;
            this.localselectbtn.BorderRadius = 10;
            this.localselectbtn.BorderThickness = 2;
            this.localselectbtn.CheckedState.Parent = this.localselectbtn;
            this.localselectbtn.CustomImages.Parent = this.localselectbtn;
            this.localselectbtn.FillColor = System.Drawing.Color.Indigo;
            this.localselectbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.localselectbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.localselectbtn.ForeColor = System.Drawing.Color.White;
            this.localselectbtn.HoverState.Parent = this.localselectbtn;
            this.localselectbtn.Location = new System.Drawing.Point(935, 0);
            this.localselectbtn.Name = "localselectbtn";
            this.localselectbtn.ShadowDecoration.Parent = this.localselectbtn;
            this.localselectbtn.Size = new System.Drawing.Size(99, 36);
            this.localselectbtn.TabIndex = 35;
            this.localselectbtn.Text = "select";
            this.localselectbtn.Click += new System.EventHandler(this.localselectbtn_Click);
            // 
            // localCustomerEmailAddress
            // 
            this.localCustomerEmailAddress.BackColor = System.Drawing.Color.Transparent;
            this.localCustomerEmailAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.localCustomerEmailAddress.DefaultText = "";
            this.localCustomerEmailAddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.localCustomerEmailAddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.localCustomerEmailAddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localCustomerEmailAddress.DisabledState.Parent = this.localCustomerEmailAddress;
            this.localCustomerEmailAddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localCustomerEmailAddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localCustomerEmailAddress.FocusedState.Parent = this.localCustomerEmailAddress;
            this.localCustomerEmailAddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localCustomerEmailAddress.HoverState.Parent = this.localCustomerEmailAddress;
            this.localCustomerEmailAddress.Location = new System.Drawing.Point(706, 4);
            this.localCustomerEmailAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localCustomerEmailAddress.Name = "localCustomerEmailAddress";
            this.localCustomerEmailAddress.PasswordChar = '\0';
            this.localCustomerEmailAddress.PlaceholderText = "";
            this.localCustomerEmailAddress.SelectedText = "";
            this.localCustomerEmailAddress.ShadowDecoration.Parent = this.localCustomerEmailAddress;
            this.localCustomerEmailAddress.Size = new System.Drawing.Size(225, 36);
            this.localCustomerEmailAddress.TabIndex = 33;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(606, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 19);
            this.label3.TabIndex = 34;
            this.label3.Text = "Email Address";
            // 
            // localCustomerName
            // 
            this.localCustomerName.BackColor = System.Drawing.Color.Transparent;
            this.localCustomerName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.localCustomerName.DefaultText = "";
            this.localCustomerName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.localCustomerName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.localCustomerName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localCustomerName.DisabledState.Parent = this.localCustomerName;
            this.localCustomerName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localCustomerName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localCustomerName.FocusedState.Parent = this.localCustomerName;
            this.localCustomerName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localCustomerName.HoverState.Parent = this.localCustomerName;
            this.localCustomerName.Location = new System.Drawing.Point(119, 6);
            this.localCustomerName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localCustomerName.Name = "localCustomerName";
            this.localCustomerName.PasswordChar = '\0';
            this.localCustomerName.PlaceholderText = "";
            this.localCustomerName.SelectedText = "";
            this.localCustomerName.ShadowDecoration.Parent = this.localCustomerName;
            this.localCustomerName.Size = new System.Drawing.Size(206, 36);
            this.localCustomerName.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(331, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 19);
            this.label2.TabIndex = 34;
            this.label2.Text = "Mobile #";
            // 
            // local
            // 
            this.local.AutoSize = true;
            this.local.BackColor = System.Drawing.Color.Transparent;
            this.local.ForeColor = System.Drawing.Color.Indigo;
            this.local.Location = new System.Drawing.Point(4, 6);
            this.local.Name = "local";
            this.local.Size = new System.Drawing.Size(109, 19);
            this.local.TabIndex = 34;
            this.local.Text = "Customer Name";
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning5.ForeColor = System.Drawing.Color.Indigo;
            this.warning5.Location = new System.Drawing.Point(14, 12);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(67, 22);
            this.warning5.TabIndex = 30;
            this.warning5.Text = "Search";
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1006, 5);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(35, 35);
            this.backbtn.TabIndex = 31;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // localCustomerbox
            // 
            this.localCustomerbox.BorderThickness = 0;
            this.localCustomerbox.Controls.Add(this.localselectbtn);
            this.localCustomerbox.Controls.Add(this.localCustomerEmailAddress);
            this.localCustomerbox.Controls.Add(this.label3);
            this.localCustomerbox.Controls.Add(this.localCustomerName);
            this.localCustomerbox.Controls.Add(this.label2);
            this.localCustomerbox.Controls.Add(this.localCustomerMobile);
            this.localCustomerbox.Controls.Add(this.local);
            this.localCustomerbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.localCustomerbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.localCustomerbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.localCustomerbox.Location = new System.Drawing.Point(3, 46);
            this.localCustomerbox.Name = "localCustomerbox";
            this.localCustomerbox.ShadowDecoration.Parent = this.localCustomerbox;
            this.localCustomerbox.Size = new System.Drawing.Size(1041, 43);
            this.localCustomerbox.TabIndex = 36;
            // 
            // localCustomerMobile
            // 
            this.localCustomerMobile.BackColor = System.Drawing.Color.Transparent;
            this.localCustomerMobile.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.localCustomerMobile.DefaultText = "";
            this.localCustomerMobile.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.localCustomerMobile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.localCustomerMobile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localCustomerMobile.DisabledState.Parent = this.localCustomerMobile;
            this.localCustomerMobile.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localCustomerMobile.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localCustomerMobile.FocusedState.Parent = this.localCustomerMobile;
            this.localCustomerMobile.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localCustomerMobile.HoverState.Parent = this.localCustomerMobile;
            this.localCustomerMobile.Location = new System.Drawing.Point(400, 6);
            this.localCustomerMobile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localCustomerMobile.Name = "localCustomerMobile";
            this.localCustomerMobile.PasswordChar = '\0';
            this.localCustomerMobile.PlaceholderText = "";
            this.localCustomerMobile.SelectedText = "";
            this.localCustomerMobile.ShadowDecoration.Parent = this.localCustomerMobile;
            this.localCustomerMobile.Size = new System.Drawing.Size(200, 36);
            this.localCustomerMobile.TabIndex = 33;
            // 
            // ACC_Select
            // 
            this.ACC_Select.FillWeight = 50F;
            this.ACC_Select.HeaderText = "Select";
            this.ACC_Select.Name = "ACC_Select";
            this.ACC_Select.ReadOnly = true;
            this.ACC_Select.Text = "Select";
            this.ACC_Select.UseColumnTextForButtonValue = true;
            // 
            // ACC_Address
            // 
            this.ACC_Address.DataPropertyName = "A_Address";
            this.ACC_Address.HeaderText = "Address";
            this.ACC_Address.Name = "ACC_Address";
            this.ACC_Address.ReadOnly = true;
            // 
            // ACC_Email
            // 
            this.ACC_Email.DataPropertyName = "A_EmailAddress";
            this.ACC_Email.HeaderText = "Email";
            this.ACC_Email.Name = "ACC_Email";
            this.ACC_Email.ReadOnly = true;
            // 
            // ACC_Mobile
            // 
            this.ACC_Mobile.DataPropertyName = "A_Mobile";
            this.ACC_Mobile.HeaderText = "Mobile";
            this.ACC_Mobile.Name = "ACC_Mobile";
            this.ACC_Mobile.ReadOnly = true;
            // 
            // ACC_CNIC
            // 
            this.ACC_CNIC.DataPropertyName = "A_CNIC";
            this.ACC_CNIC.HeaderText = "CNIC";
            this.ACC_CNIC.Name = "ACC_CNIC";
            this.ACC_CNIC.ReadOnly = true;
            // 
            // ACC_Role
            // 
            this.ACC_Role.DataPropertyName = "A_Role";
            this.ACC_Role.HeaderText = "Role";
            this.ACC_Role.Name = "ACC_Role";
            this.ACC_Role.ReadOnly = true;
            // 
            // ACC_Name
            // 
            this.ACC_Name.DataPropertyName = "A_Name";
            this.ACC_Name.HeaderText = "Name";
            this.ACC_Name.Name = "ACC_Name";
            this.ACC_Name.ReadOnly = true;
            // 
            // ACC_Picture
            // 
            this.ACC_Picture.DataPropertyName = "A_Picture";
            this.ACC_Picture.FillWeight = 50F;
            this.ACC_Picture.HeaderText = "Picture";
            this.ACC_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.ACC_Picture.Name = "ACC_Picture";
            this.ACC_Picture.ReadOnly = true;
            // 
            // ACC_ID
            // 
            this.ACC_ID.DataPropertyName = "AID";
            this.ACC_ID.HeaderText = "ID";
            this.ACC_ID.Name = "ACC_ID";
            this.ACC_ID.ReadOnly = true;
            this.ACC_ID.Visible = false;
            // 
            // CustomerAccountsGridView
            // 
            this.CustomerAccountsGridView.AllowUserToAddRows = false;
            this.CustomerAccountsGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.CustomerAccountsGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.CustomerAccountsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CustomerAccountsGridView.BackgroundColor = System.Drawing.Color.White;
            this.CustomerAccountsGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CustomerAccountsGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.CustomerAccountsGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CustomerAccountsGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.CustomerAccountsGridView.ColumnHeadersHeight = 21;
            this.CustomerAccountsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACC_ID,
            this.ACC_Picture,
            this.ACC_Name,
            this.ACC_Role,
            this.ACC_CNIC,
            this.ACC_Mobile,
            this.ACC_Email,
            this.ACC_Address,
            this.ACC_Select});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CustomerAccountsGridView.DefaultCellStyle = dataGridViewCellStyle13;
            this.CustomerAccountsGridView.EnableHeadersVisualStyles = false;
            this.CustomerAccountsGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.CustomerAccountsGridView.Location = new System.Drawing.Point(13, 13);
            this.CustomerAccountsGridView.Name = "CustomerAccountsGridView";
            this.CustomerAccountsGridView.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CustomerAccountsGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.CustomerAccountsGridView.RowHeadersVisible = false;
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            this.CustomerAccountsGridView.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.CustomerAccountsGridView.RowTemplate.Height = 70;
            this.CustomerAccountsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CustomerAccountsGridView.Size = new System.Drawing.Size(1028, 434);
            this.CustomerAccountsGridView.TabIndex = 22;
            this.CustomerAccountsGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.CustomerAccountsGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.CustomerAccountsGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.CustomerAccountsGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.CustomerAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.CustomerAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.CustomerAccountsGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.CustomerAccountsGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.CustomerAccountsGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.CustomerAccountsGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.CustomerAccountsGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CustomerAccountsGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.CustomerAccountsGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.CustomerAccountsGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.CustomerAccountsGridView.ThemeStyle.ReadOnly = true;
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.Height = 70;
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.CustomerAccountsGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.CustomerAccountsGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CustomerAccountsGridView_CellContentClick);
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.BackColor = System.Drawing.Color.Transparent;
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.CustomerAccountsGridView);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(0, 85);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(1045, 459);
            this.ShowAddedItemsDetailBox.TabIndex = 32;
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.White;
            this.ContentPanel.Controls.Add(this.ShowAddedItemsDetailBox);
            this.ContentPanel.Controls.Add(this.warning5);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Controls.Add(this.localCustomerbox);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(5, 5);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1045, 544);
            this.ContentPanel.TabIndex = 2;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.ContentPanel;
            // 
            // SelectCustomerAccounts_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(1055, 554);
            this.Controls.Add(this.ContentPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SelectCustomerAccounts_Form";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectCustomerAccounts_Form";
            this.Load += new System.EventHandler(this.SelectCustomerAccounts_Form_Load);
            this.localCustomerbox.ResumeLayout(false);
            this.localCustomerbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerAccountsGridView)).EndInit();
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientButton localselectbtn;
        private Guna.UI2.WinForms.Guna2TextBox localCustomerEmailAddress;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox localCustomerName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label local;
        private System.Windows.Forms.Label warning5;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private Guna.UI2.WinForms.Guna2GroupBox localCustomerbox;
        private Guna.UI2.WinForms.Guna2TextBox localCustomerMobile;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Name;
        private System.Windows.Forms.DataGridViewImageColumn ACC_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_ID;
        private Guna.UI2.WinForms.Guna2DataGridView CustomerAccountsGridView;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
    }
}