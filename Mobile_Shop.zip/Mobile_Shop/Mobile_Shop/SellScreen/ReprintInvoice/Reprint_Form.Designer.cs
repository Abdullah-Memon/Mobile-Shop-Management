﻿namespace Mobile_Shop.SellScreen.ReprintInvoice
{
    partial class Reprint_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Createbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SelectedBill = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Billno = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GradientPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Createbtn
            // 
            this.Createbtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Createbtn.BorderColor = System.Drawing.Color.White;
            this.Createbtn.BorderRadius = 10;
            this.Createbtn.BorderThickness = 2;
            this.Createbtn.CheckedState.Parent = this.Createbtn;
            this.Createbtn.CustomImages.Parent = this.Createbtn;
            this.Createbtn.FillColor = System.Drawing.Color.Indigo;
            this.Createbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Createbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Createbtn.ForeColor = System.Drawing.Color.White;
            this.Createbtn.HoverState.Parent = this.Createbtn;
            this.Createbtn.Location = new System.Drawing.Point(165, 183);
            this.Createbtn.Name = "Createbtn";
            this.Createbtn.ShadowDecoration.Parent = this.Createbtn;
            this.Createbtn.Size = new System.Drawing.Size(88, 36);
            this.Createbtn.TabIndex = 23;
            this.Createbtn.Text = "Print";
            this.Createbtn.Click += new System.EventHandler(this.Createbtn_Click);
            // 
            // guna2GradientPanel3
            // 
            this.guna2GradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel3.BorderRadius = 10;
            this.guna2GradientPanel3.Controls.Add(this.crossbtn);
            this.guna2GradientPanel3.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientPanel3.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientPanel3.Location = new System.Drawing.Point(226, -9);
            this.guna2GradientPanel3.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel3.Name = "guna2GradientPanel3";
            this.guna2GradientPanel3.ShadowDecoration.Parent = this.guna2GradientPanel3;
            this.guna2GradientPanel3.Size = new System.Drawing.Size(41, 56);
            this.guna2GradientPanel3.TabIndex = 22;
            // 
            // crossbtn
            // 
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.White;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.Indigo;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(3, 16);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 13;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "Bill";
            // 
            // SelectedBill
            // 
            this.SelectedBill.BackColor = System.Drawing.Color.Transparent;
            this.SelectedBill.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedBill.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedBill.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedBill.FocusedState.Parent = this.SelectedBill;
            this.SelectedBill.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedBill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedBill.FormattingEnabled = true;
            this.SelectedBill.HoverState.Parent = this.SelectedBill;
            this.SelectedBill.ItemHeight = 30;
            this.SelectedBill.Items.AddRange(new object[] {
            "Last Bill",
            "Custom"});
            this.SelectedBill.ItemsAppearance.Parent = this.SelectedBill;
            this.SelectedBill.Location = new System.Drawing.Point(42, 87);
            this.SelectedBill.Name = "SelectedBill";
            this.SelectedBill.ShadowDecoration.Parent = this.SelectedBill;
            this.SelectedBill.Size = new System.Drawing.Size(211, 36);
            this.SelectedBill.StartIndex = 0;
            this.SelectedBill.TabIndex = 25;
            this.SelectedBill.SelectedIndexChanged += new System.EventHandler(this.SelectedBill_SelectedIndexChanged);
            // 
            // Billno
            // 
            this.Billno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Billno.DefaultText = "0";
            this.Billno.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Billno.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Billno.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Billno.DisabledState.Parent = this.Billno;
            this.Billno.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Billno.Enabled = false;
            this.Billno.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Billno.FocusedState.Parent = this.Billno;
            this.Billno.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Billno.HoverState.Parent = this.Billno;
            this.Billno.Location = new System.Drawing.Point(94, 129);
            this.Billno.Name = "Billno";
            this.Billno.PasswordChar = '\0';
            this.Billno.PlaceholderText = "";
            this.Billno.SelectedText = "";
            this.Billno.SelectionStart = 1;
            this.Billno.ShadowDecoration.Parent = this.Billno;
            this.Billno.Size = new System.Drawing.Size(159, 36);
            this.Billno.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 21;
            this.label2.Text = "Bill No";
            // 
            // Reprint_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(279, 259);
            this.Controls.Add(this.Billno);
            this.Controls.Add(this.Createbtn);
            this.Controls.Add(this.guna2GradientPanel3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SelectedBill);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Reprint_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Reprint_Form";
            this.Load += new System.EventHandler(this.Reprint_Form_Load);
            this.guna2GradientPanel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientButton Createbtn;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedBill;
        private Guna.UI2.WinForms.Guna2TextBox Billno;
        private System.Windows.Forms.Label label2;
    }
}