﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen.ReprintInvoice
{
    public partial class Reprint_Form : Form
    {
        public Reprint_Form()
        {
            InitializeComponent();
        }

        private void Reprint_Form_Load(object sender, EventArgs e)
        {

        }

        private void SelectedBill_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SelectedBill.SelectedIndex == 0)
                Billno.Enabled = false; 
            else
                Billno.Enabled = true;
        }

        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Print Invoice
        private void Createbtn_Click(object sender, EventArgs e)
        {
            Selling.BillRecipt.BillRecipt_Form brf = new Selling.BillRecipt.BillRecipt_Form(SelectedBill.SelectedIndex, Convert.ToDecimal( Billno.Text));
            brf.Show();
            this.Close();
        }
    }
}
