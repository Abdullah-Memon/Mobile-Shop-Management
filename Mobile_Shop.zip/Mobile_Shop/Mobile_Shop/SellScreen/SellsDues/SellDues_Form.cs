﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Mobile_Shop.SellScreen.SellsDues
{
    public partial class SellDues_Form : Form
    {
        public SellDues_Form()
        {
            InitializeComponent();
        }

        // Global Variables
        SqlCommand cmd;
        decimal total_dues, total_paid, total_bill;
        int chk;

        // getting payment Type
        private void GetPaymentType()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));

                dt.Load(cmd.ExecuteReader());

                PaymentTypeBox.DataSource = dt;
                PaymentTypeBox.ValueMember = "PID";
                PaymentTypeBox.DisplayMember = "P_Type";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        // Function to save new Dues
        private void Save()
        {
            chk = 0;
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                cmd = new SqlCommand("GetSellDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 3));
                cmd.Parameters.Add(new SqlParameter("@date", DateTimePicker1.Value));
                cmd.Parameters.Add(new SqlParameter("@aid", SellScreen.SelectCustomerAccounts_Form.Customer_id));
                cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));

                if (pay.Checked)
                    cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(TakemoneyBox.Text) * -1));
                else
                    cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(TakemoneyBox.Text)));

                cmd.Parameters.Add(new SqlParameter("@pid", PaymentTypeBox.SelectedValue));

                chk = cmd.ExecuteNonQuery();

                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (chk > 0)
                updatemessage.Show();
            else
                updatemessage.Hide();
        }

        // Main Load Function
        private void SellDues_Form_Load(object sender, EventArgs e)
        {
            updatemessage.Hide();
            GetPaymentType();

            DateTimePicker1.Text = System.DateTime.Now.ToShortDateString();

            selectAccountbox.Text = string.Empty;
            TotalBillbox.Text = string.Empty;
            TotalPaidbox.Text = string.Empty;
            TotalDuesbox.Text = string.Empty;
            pay.Checked = false;
            TakemoneyBox.Text = string.Empty;
            remainingbox.Text = string.Empty;
        }

        // Save Button Coding
        private void paybtn_Click(object sender, EventArgs e)
        {
            chk = 0;
            if (!string.IsNullOrEmpty(TakemoneyBox.Text) || !string.IsNullOrWhiteSpace(TakemoneyBox.Text))
            {
                Save();
                object a = new object();
                EventArgs b = new EventArgs();
                SellDues_Form_Load(a, b);
            }
        }

        // Select Customer Account Coding
        private void selectAccountbox_DoubleClick(object sender, EventArgs e)
        {
            SellScreen.SelectCustomerAccounts_Form scaf = new SellScreen.SelectCustomerAccounts_Form(1);
            scaf.ShowDialog();

            if (!string.IsNullOrEmpty(SellScreen.SelectCustomerAccounts_Form.Customer_id))
            {
                selectAccountbox.Text = SellScreen.SelectCustomerAccounts_Form.Customer_name;

                MemoryStream ms = new MemoryStream(SellScreen.SelectCustomerAccounts_Form.Customer_pic);
                profile.Image = Image.FromStream(ms);
            }

            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("GetSellDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));
                cmd.Parameters.Add(new SqlParameter("@aid", SellScreen.SelectCustomerAccounts_Form.Customer_id));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                total_dues = Convert.ToDecimal(dt.Rows[0][0]);
                total_bill = Convert.ToDecimal(dt.Rows[0][1]);
                total_paid = Convert.ToDecimal(dt.Rows[0][2]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            TotalBillbox.Text = total_bill.ToString();
            TotalDuesbox.Text = total_dues.ToString();
            TotalPaidbox.Text = total_paid.ToString();
            remainingbox.Text = TotalDuesbox.Text;

            if (total_dues == 0)
                clearbtn.Enabled = true;
            else
                clearbtn.Enabled = false;
        }

        // Take money box coding
        private void TakemoneyBox_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TakemoneyBox.Text) || !string.IsNullOrWhiteSpace(TakemoneyBox.Text))
            {
                if (pay.Checked)
                    remainingbox.Text = (Convert.ToDecimal(TakemoneyBox.Text) + total_dues).ToString();
                else
                    remainingbox.Text = (total_dues - Convert.ToDecimal(TakemoneyBox.Text)).ToString();
            }
            else
            {
                remainingbox.Text = TotalDuesbox.Text;
                if (total_dues == 0)
                    clearbtn.Enabled = true;
                else
                    clearbtn.Enabled = false;
            }
        }

        // Clearance Button Coding
        private void clearbtn_Click(object sender, EventArgs e)
        {
            chk = 0;
            // when balance become 0
            if (total_dues != 0 && Convert.ToDecimal(remainingbox.Text) == 0)
                Save();

            try
            {
                //secong applyinng clearance
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                cmd = new SqlCommand("GetSellDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 4));
                cmd.Parameters.Add(new SqlParameter("@aid", SellScreen.SelectCustomerAccounts_Form.Customer_id));

                chk = cmd.ExecuteNonQuery();

                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (chk > 0)
                updatemessage.Show();
            else
                updatemessage.Hide();

            // refreshing Form
            object a2 = new object();
            EventArgs b2 = new EventArgs();
            SellDues_Form_Load(a2, b2);
        }

        // Remaining monkey box coding
        private void remainingbox_TextChanged(object sender, EventArgs e)
        {
            // enabling and disabling clearance button
            if (!string.IsNullOrEmpty(TakemoneyBox.Text) || !string.IsNullOrWhiteSpace(TakemoneyBox.Text))
            {
                if (pay.Checked)
                {
                    if (total_dues + Convert.ToDecimal(TakemoneyBox.Text) == 0)
                        clearbtn.Enabled = true;
                    else
                        clearbtn.Enabled = false;
                }
                else
                {
                    if (total_dues - Convert.ToDecimal(TakemoneyBox.Text) == 0)
                        clearbtn.Enabled = true;
                    else
                        clearbtn.Enabled = false;
                }
            }
        }

        // Bounging Usre inputs
        private void TakemoneyBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }

        // Closs Button Coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
