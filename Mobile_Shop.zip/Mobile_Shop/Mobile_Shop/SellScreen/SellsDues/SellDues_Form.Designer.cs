﻿namespace Mobile_Shop.SellScreen.SellsDues
{
    partial class SellDues_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.pay = new System.Windows.Forms.CheckBox();
            this.DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.profile = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.clearbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.paybtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label1 = new System.Windows.Forms.Label();
            this.updatemessage = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.remainingbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.TakemoneyBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.TotalBillbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.selectAccountbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.TotalDuesbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.TotalPaidbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.PaymentTypeBox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.contentpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).BeginInit();
            this.guna2GradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.contentpanel;
            // 
            // contentpanel
            // 
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.pay);
            this.contentpanel.Controls.Add(this.DateTimePicker1);
            this.contentpanel.Controls.Add(this.profile);
            this.contentpanel.Controls.Add(this.guna2GradientPanel1);
            this.contentpanel.Controls.Add(this.clearbtn);
            this.contentpanel.Controls.Add(this.paybtn);
            this.contentpanel.Controls.Add(this.label1);
            this.contentpanel.Controls.Add(this.updatemessage);
            this.contentpanel.Controls.Add(this.label6);
            this.contentpanel.Controls.Add(this.label7);
            this.contentpanel.Controls.Add(this.label);
            this.contentpanel.Controls.Add(this.label5);
            this.contentpanel.Controls.Add(this.label4);
            this.contentpanel.Controls.Add(this.label8);
            this.contentpanel.Controls.Add(this.label2);
            this.contentpanel.Controls.Add(this.remainingbox);
            this.contentpanel.Controls.Add(this.TakemoneyBox);
            this.contentpanel.Controls.Add(this.TotalBillbox);
            this.contentpanel.Controls.Add(this.selectAccountbox);
            this.contentpanel.Controls.Add(this.TotalDuesbox);
            this.contentpanel.Controls.Add(this.TotalPaidbox);
            this.contentpanel.Controls.Add(this.PaymentTypeBox);
            this.contentpanel.Controls.Add(this.label3);
            this.contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentpanel.FillColor = System.Drawing.Color.Indigo;
            this.contentpanel.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.contentpanel.Location = new System.Drawing.Point(10, 10);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(604, 423);
            this.contentpanel.TabIndex = 27;
            // 
            // pay
            // 
            this.pay.AutoSize = true;
            this.pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay.ForeColor = System.Drawing.Color.White;
            this.pay.Location = new System.Drawing.Point(362, 237);
            this.pay.Name = "pay";
            this.pay.Size = new System.Drawing.Size(52, 22);
            this.pay.TabIndex = 29;
            this.pay.Text = "Pay";
            this.pay.UseVisualStyleBackColor = true;
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.BorderColor = System.Drawing.Color.White;
            this.DateTimePicker1.BorderRadius = 10;
            this.DateTimePicker1.BorderThickness = 2;
            this.DateTimePicker1.CheckedState.Parent = this.DateTimePicker1;
            this.DateTimePicker1.FillColor = System.Drawing.Color.Indigo;
            this.DateTimePicker1.ForeColor = System.Drawing.Color.White;
            this.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DateTimePicker1.HoverState.Parent = this.DateTimePicker1;
            this.DateTimePicker1.Location = new System.Drawing.Point(33, 341);
            this.DateTimePicker1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.DateTimePicker1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.ShadowDecoration.Parent = this.DateTimePicker1;
            this.DateTimePicker1.Size = new System.Drawing.Size(198, 45);
            this.DateTimePicker1.TabIndex = 28;
            this.DateTimePicker1.Value = new System.DateTime(2022, 9, 13, 6, 2, 30, 329);
            // 
            // profile
            // 
            this.profile.FillColor = System.Drawing.Color.White;
            this.profile.Location = new System.Drawing.Point(33, 71);
            this.profile.Name = "profile";
            this.profile.ShadowDecoration.Parent = this.profile;
            this.profile.Size = new System.Drawing.Size(110, 123);
            this.profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profile.TabIndex = 27;
            this.profile.TabStop = false;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel1.BorderRadius = 20;
            this.guna2GradientPanel1.Controls.Add(this.Backbtn);
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(504, -26);
            this.guna2GradientPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(50, 75);
            this.guna2GradientPanel1.TabIndex = 25;
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(10, 35);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(30, 30);
            this.Backbtn.TabIndex = 21;
            this.Backbtn.Text = "X";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // clearbtn
            // 
            this.clearbtn.BackColor = System.Drawing.Color.Transparent;
            this.clearbtn.BorderColor = System.Drawing.Color.White;
            this.clearbtn.BorderRadius = 10;
            this.clearbtn.BorderThickness = 2;
            this.clearbtn.CheckedState.Parent = this.clearbtn;
            this.clearbtn.CustomImages.Parent = this.clearbtn;
            this.clearbtn.Enabled = false;
            this.clearbtn.FillColor = System.Drawing.Color.Indigo;
            this.clearbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.clearbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clearbtn.ForeColor = System.Drawing.Color.White;
            this.clearbtn.HoverState.Parent = this.clearbtn;
            this.clearbtn.Location = new System.Drawing.Point(306, 341);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.ShadowDecoration.Parent = this.clearbtn;
            this.clearbtn.Size = new System.Drawing.Size(127, 45);
            this.clearbtn.TabIndex = 23;
            this.clearbtn.Text = "Clearance";
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // paybtn
            // 
            this.paybtn.BackColor = System.Drawing.Color.Transparent;
            this.paybtn.BorderColor = System.Drawing.Color.White;
            this.paybtn.BorderRadius = 10;
            this.paybtn.BorderThickness = 2;
            this.paybtn.CheckedState.Parent = this.paybtn;
            this.paybtn.CustomImages.Parent = this.paybtn;
            this.paybtn.FillColor = System.Drawing.Color.Indigo;
            this.paybtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.paybtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.paybtn.ForeColor = System.Drawing.Color.White;
            this.paybtn.HoverState.Parent = this.paybtn;
            this.paybtn.Location = new System.Drawing.Point(439, 341);
            this.paybtn.Name = "paybtn";
            this.paybtn.ShadowDecoration.Parent = this.paybtn;
            this.paybtn.Size = new System.Drawing.Size(127, 45);
            this.paybtn.TabIndex = 23;
            this.paybtn.Text = "Save";
            this.paybtn.Click += new System.EventHandler(this.paybtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(30, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 31);
            this.label1.TabIndex = 18;
            this.label1.Text = "Dues";
            // 
            // updatemessage
            // 
            this.updatemessage.AutoSize = true;
            this.updatemessage.BackColor = System.Drawing.Color.Transparent;
            this.updatemessage.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatemessage.ForeColor = System.Drawing.Color.White;
            this.updatemessage.Location = new System.Drawing.Point(360, 318);
            this.updatemessage.Name = "updatemessage";
            this.updatemessage.Size = new System.Drawing.Size(206, 20);
            this.updatemessage.TabIndex = 18;
            this.updatemessage.Text = "Dues has been updated";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(164, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "Select Account";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(368, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Total Bill";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.White;
            this.label.Location = new System.Drawing.Point(29, 237);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(126, 20);
            this.label.TabIndex = 18;
            this.label.Text = "Payment Type";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(426, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Remaining";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(242, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Take Money";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(368, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Total Dues";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(165, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Total Paid";
            // 
            // remainingbox
            // 
            this.remainingbox.BorderRadius = 10;
            this.remainingbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.remainingbox.DefaultText = "0.00";
            this.remainingbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.remainingbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.remainingbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.remainingbox.DisabledState.Parent = this.remainingbox;
            this.remainingbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.remainingbox.Enabled = false;
            this.remainingbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.remainingbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.remainingbox.FocusedState.Parent = this.remainingbox;
            this.remainingbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.remainingbox.HoverState.Parent = this.remainingbox;
            this.remainingbox.Location = new System.Drawing.Point(430, 260);
            this.remainingbox.Name = "remainingbox";
            this.remainingbox.PasswordChar = '\0';
            this.remainingbox.PlaceholderText = "";
            this.remainingbox.SelectedText = "";
            this.remainingbox.SelectionStart = 4;
            this.remainingbox.ShadowDecoration.Parent = this.remainingbox;
            this.remainingbox.Size = new System.Drawing.Size(136, 36);
            this.remainingbox.TabIndex = 20;
            this.remainingbox.TextChanged += new System.EventHandler(this.remainingbox_TextChanged);
            // 
            // TakemoneyBox
            // 
            this.TakemoneyBox.BorderRadius = 10;
            this.TakemoneyBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TakemoneyBox.DefaultText = "";
            this.TakemoneyBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TakemoneyBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TakemoneyBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TakemoneyBox.DisabledState.Parent = this.TakemoneyBox;
            this.TakemoneyBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TakemoneyBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TakemoneyBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TakemoneyBox.FocusedState.Parent = this.TakemoneyBox;
            this.TakemoneyBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TakemoneyBox.HoverState.Parent = this.TakemoneyBox;
            this.TakemoneyBox.Location = new System.Drawing.Point(246, 260);
            this.TakemoneyBox.Name = "TakemoneyBox";
            this.TakemoneyBox.PasswordChar = '\0';
            this.TakemoneyBox.PlaceholderText = "";
            this.TakemoneyBox.SelectedText = "";
            this.TakemoneyBox.ShadowDecoration.Parent = this.TakemoneyBox;
            this.TakemoneyBox.Size = new System.Drawing.Size(168, 36);
            this.TakemoneyBox.TabIndex = 20;
            this.TakemoneyBox.TextChanged += new System.EventHandler(this.TakemoneyBox_TextChanged);
            this.TakemoneyBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TakemoneyBox_KeyPress);
            // 
            // TotalBillbox
            // 
            this.TotalBillbox.BorderRadius = 10;
            this.TotalBillbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TotalBillbox.DefaultText = "0.00";
            this.TotalBillbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TotalBillbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TotalBillbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalBillbox.DisabledState.Parent = this.TotalBillbox;
            this.TotalBillbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalBillbox.Enabled = false;
            this.TotalBillbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TotalBillbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalBillbox.FocusedState.Parent = this.TotalBillbox;
            this.TotalBillbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalBillbox.HoverState.Parent = this.TotalBillbox;
            this.TotalBillbox.Location = new System.Drawing.Point(372, 91);
            this.TotalBillbox.Name = "TotalBillbox";
            this.TotalBillbox.PasswordChar = '\0';
            this.TotalBillbox.PlaceholderText = "";
            this.TotalBillbox.ReadOnly = true;
            this.TotalBillbox.SelectedText = "";
            this.TotalBillbox.SelectionStart = 4;
            this.TotalBillbox.ShadowDecoration.Parent = this.TotalBillbox;
            this.TotalBillbox.Size = new System.Drawing.Size(194, 36);
            this.TotalBillbox.TabIndex = 20;
            // 
            // selectAccountbox
            // 
            this.selectAccountbox.BorderRadius = 10;
            this.selectAccountbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.selectAccountbox.DefaultText = "";
            this.selectAccountbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.selectAccountbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.selectAccountbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.selectAccountbox.DisabledState.Parent = this.selectAccountbox;
            this.selectAccountbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.selectAccountbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.selectAccountbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.selectAccountbox.FocusedState.Parent = this.selectAccountbox;
            this.selectAccountbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.selectAccountbox.HoverState.Parent = this.selectAccountbox;
            this.selectAccountbox.Location = new System.Drawing.Point(168, 89);
            this.selectAccountbox.Name = "selectAccountbox";
            this.selectAccountbox.PasswordChar = '\0';
            this.selectAccountbox.PlaceholderText = "";
            this.selectAccountbox.ReadOnly = true;
            this.selectAccountbox.SelectedText = "";
            this.selectAccountbox.ShadowDecoration.Parent = this.selectAccountbox;
            this.selectAccountbox.Size = new System.Drawing.Size(194, 36);
            this.selectAccountbox.TabIndex = 20;
            this.selectAccountbox.DoubleClick += new System.EventHandler(this.selectAccountbox_DoubleClick);
            // 
            // TotalDuesbox
            // 
            this.TotalDuesbox.BorderRadius = 10;
            this.TotalDuesbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TotalDuesbox.DefaultText = "0.00";
            this.TotalDuesbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TotalDuesbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TotalDuesbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalDuesbox.DisabledState.Parent = this.TotalDuesbox;
            this.TotalDuesbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalDuesbox.Enabled = false;
            this.TotalDuesbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TotalDuesbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalDuesbox.FocusedState.Parent = this.TotalDuesbox;
            this.TotalDuesbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalDuesbox.HoverState.Parent = this.TotalDuesbox;
            this.TotalDuesbox.Location = new System.Drawing.Point(372, 158);
            this.TotalDuesbox.Name = "TotalDuesbox";
            this.TotalDuesbox.PasswordChar = '\0';
            this.TotalDuesbox.PlaceholderText = "";
            this.TotalDuesbox.SelectedText = "";
            this.TotalDuesbox.SelectionStart = 4;
            this.TotalDuesbox.ShadowDecoration.Parent = this.TotalDuesbox;
            this.TotalDuesbox.Size = new System.Drawing.Size(194, 36);
            this.TotalDuesbox.TabIndex = 20;
            // 
            // TotalPaidbox
            // 
            this.TotalPaidbox.BorderRadius = 10;
            this.TotalPaidbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TotalPaidbox.DefaultText = "0.00";
            this.TotalPaidbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TotalPaidbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TotalPaidbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalPaidbox.DisabledState.Parent = this.TotalPaidbox;
            this.TotalPaidbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalPaidbox.Enabled = false;
            this.TotalPaidbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TotalPaidbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalPaidbox.FocusedState.Parent = this.TotalPaidbox;
            this.TotalPaidbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalPaidbox.HoverState.Parent = this.TotalPaidbox;
            this.TotalPaidbox.Location = new System.Drawing.Point(169, 158);
            this.TotalPaidbox.Name = "TotalPaidbox";
            this.TotalPaidbox.PasswordChar = '\0';
            this.TotalPaidbox.PlaceholderText = "";
            this.TotalPaidbox.SelectedText = "";
            this.TotalPaidbox.SelectionStart = 4;
            this.TotalPaidbox.ShadowDecoration.Parent = this.TotalPaidbox;
            this.TotalPaidbox.Size = new System.Drawing.Size(193, 36);
            this.TotalPaidbox.TabIndex = 20;
            // 
            // PaymentTypeBox
            // 
            this.PaymentTypeBox.BackColor = System.Drawing.Color.Transparent;
            this.PaymentTypeBox.BorderRadius = 10;
            this.PaymentTypeBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.PaymentTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypeBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PaymentTypeBox.FocusedColor = System.Drawing.Color.Empty;
            this.PaymentTypeBox.FocusedState.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PaymentTypeBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.PaymentTypeBox.FormattingEnabled = true;
            this.PaymentTypeBox.HoverState.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.ItemHeight = 30;
            this.PaymentTypeBox.ItemsAppearance.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Location = new System.Drawing.Point(33, 260);
            this.PaymentTypeBox.Name = "PaymentTypeBox";
            this.PaymentTypeBox.ShadowDecoration.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Size = new System.Drawing.Size(198, 36);
            this.PaymentTypeBox.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Cooper Black", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(13, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(561, 19);
            this.label3.TabIndex = 18;
            this.label3.Text = "_____________________________________________________________________";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            // 
            // SellDues_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(624, 443);
            this.Controls.Add(this.contentpanel);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SellDues_Form";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellDues_Form";
            this.Load += new System.EventHandler(this.SellDues_Form_Load);
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).EndInit();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private System.Windows.Forms.CheckBox pay;
        private Guna.UI2.WinForms.Guna2DateTimePicker DateTimePicker1;
        private Guna.UI2.WinForms.Guna2PictureBox profile;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton clearbtn;
        private Guna.UI2.WinForms.Guna2GradientButton paybtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label updatemessage;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox remainingbox;
        private Guna.UI2.WinForms.Guna2TextBox TakemoneyBox;
        private Guna.UI2.WinForms.Guna2TextBox TotalBillbox;
        private Guna.UI2.WinForms.Guna2TextBox selectAccountbox;
        private Guna.UI2.WinForms.Guna2TextBox TotalDuesbox;
        private Guna.UI2.WinForms.Guna2TextBox TotalPaidbox;
        private Guna.UI2.WinForms.Guna2ComboBox PaymentTypeBox;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}