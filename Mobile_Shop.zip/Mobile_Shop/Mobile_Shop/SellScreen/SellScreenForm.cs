﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen
{
    public partial class SellScreenForm : Form
    {
        public SellScreenForm()
        {
            InitializeComponent();
        }
        //Gloabl Variables
        static int FormsCount = 1;

        // Function to Adding new User Controls
        private void addUserControl(UserControl uc)
        {
            contentPanel.Controls.Clear();
            contentPanel.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }
        
        // Function to Load Shop Details
        void getshopDetails()
        {

            if (Form1.shopDetails.Rows.Count > 0)
            {
                shopname.Text = Form1.shopDetails.Rows[0][1].ToString();
                shoptitle.Text = Form1.shopDetails.Rows[0][2].ToString();

                if (Form1.shopDetails.Rows[0][0] != null)
                {
                    byte[] pic = (byte[])Form1.shopDetails.Rows[0][0];
                    MemoryStream ms = new MemoryStream(pic);
                    shoplogo.Image = Image.FromStream(ms);
                }
            }
        }

        // Closing button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            if (LoginForm.LoginScreen.personal_info.Rows[0][6].ToString() == "Admin")
                this.Close();
            else
                if (FormsCount == 1)
                    Application.Exit();
                else
                {
                    FormsCount--;
                    this.Close();
                }
        }

        // Maximize button coding
        private void maximizebtn_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                WindowState = FormWindowState.Normal;
            else
                WindowState = FormWindowState.Maximized;
        }

        // Minimize button coding
        private void minimizebtn_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        
        // Clock Time Coding
        private void timer1_Tick(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
        }

        //Function to uloadtemp
        private void UnloadTemp(int a = 0)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                SqlCommand cmd = new SqlCommand("RemoveTimebyTimetemp", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.ExecuteNonQuery();
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Main Load Function
        private void SellScreenForm_Load(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Maximized;

            if (LoginForm.LoginScreen.personal_info.Rows[0][6].ToString() == "Admin")
            {
                Logoutbtn.Hide();
                label9.Hide();
            }
            
            getshopDetails();
            SellScreen_uc ss = new SellScreen_uc();
            addUserControl(ss);
        }

        // Loading Sell Screen Button Coding
        private void SellScreenbtn_Click(object sender, EventArgs e)
        {
            SellScreen_uc ss = new SellScreen_uc();
            addUserControl(ss);
        }

        // Loading new Sell Screen Coding
        private void newSellScreenbtn_Click(object sender, EventArgs e)
        {
            SellScreenForm ssf = new SellScreenForm();
            ssf.Show();
            FormsCount++;
        }

        private void itemstimeout_Tick(object sender, EventArgs e)
        {
            UnloadTemp();
        }
        // Loading Return Screen Coding
        private void guna2CircleButton13_Click(object sender, EventArgs e)
        {
            SellScreen.SellsReturn.ViewSellsReturn_uc vsr = new SellsReturn.ViewSellsReturn_uc();
            addUserControl(vsr);
        }

        // Loading Claim Screen Coding
        private void guna2CircleButton4_Click(object sender, EventArgs e)
        {
            SellsReturn.ViewSellClaim_uc vsc = new SellsReturn.ViewSellClaim_uc();
            addUserControl(vsc);
        }

        private void Expensebtn_Click(object sender, EventArgs e)
        {
            Expense.AddExpenseForm aef = new Expense.AddExpenseForm();
            aef.Show();
        }

        private void Duesbtn_Click(object sender, EventArgs e)
        {
            SellsDues.SellDues_Form sdf = new SellsDues.SellDues_Form();
            sdf.ShowDialog();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            SellsReporting.ReportType_Form rtf = new SellsReporting.ReportType_Form();
            rtf.Show();
        }

        private void Reprintbtn_Click(object sender, EventArgs e)
        {
            ReprintInvoice.Reprint_Form rf = new ReprintInvoice.Reprint_Form();
            rf.Show();
        }

        private void Logoutbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen ls = new LoginForm.LoginScreen();
            Program.l.Show();
            Program.l.addusercontrol(ls);
            this.Close();
        }

    }
}
