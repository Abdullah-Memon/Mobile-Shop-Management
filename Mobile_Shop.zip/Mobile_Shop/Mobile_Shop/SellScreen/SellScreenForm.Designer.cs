﻿namespace Mobile_Shop.SellScreen
{
    partial class SellScreenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.SellScreenbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Logoutbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton12 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton13 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton4 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Reprintbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton9 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Duesbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Expensebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2CircleButton8 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.contentPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.shoplogo = new Guna.UI2.WinForms.Guna2PictureBox();
            this.time = new System.Windows.Forms.Label();
            this.shoptitle = new System.Windows.Forms.Label();
            this.shopname = new System.Windows.Forms.Label();
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.guna2GroupBox6 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.minimizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.maximizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2GroupBox5 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.itemstimeout = new System.Windows.Forms.Timer(this.components);
            this.guna2GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shoplogo)).BeginInit();
            this.guna2GroupBox6.SuspendLayout();
            this.guna2GroupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 20;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2GroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox2.BorderRadius = 30;
            this.guna2GroupBox2.Controls.Add(this.SellScreenbtn);
            this.guna2GroupBox2.Controls.Add(this.Logoutbtn);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleButton12);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleButton13);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleButton4);
            this.guna2GroupBox2.Controls.Add(this.Reprintbtn);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleButton1);
            this.guna2GroupBox2.Controls.Add(this.guna2CircleButton9);
            this.guna2GroupBox2.Controls.Add(this.Duesbtn);
            this.guna2GroupBox2.Controls.Add(this.Expensebtn);
            this.guna2GroupBox2.Controls.Add(this.label11);
            this.guna2GroupBox2.Controls.Add(this.label10);
            this.guna2GroupBox2.Controls.Add(this.label7);
            this.guna2GroupBox2.Controls.Add(this.label9);
            this.guna2GroupBox2.Controls.Add(this.label8);
            this.guna2GroupBox2.Controls.Add(this.label6);
            this.guna2GroupBox2.Controls.Add(this.label5);
            this.guna2GroupBox2.Controls.Add(this.label4);
            this.guna2GroupBox2.Controls.Add(this.label3);
            this.guna2GroupBox2.Controls.Add(this.label2);
            this.guna2GroupBox2.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox2.FillColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(-24, 89);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(219, 652);
            this.guna2GroupBox2.TabIndex = 20;
            // 
            // SellScreenbtn
            // 
            this.SellScreenbtn.BackColor = System.Drawing.Color.Transparent;
            this.SellScreenbtn.CheckedState.Parent = this.SellScreenbtn;
            this.SellScreenbtn.CustomImages.Parent = this.SellScreenbtn;
            this.SellScreenbtn.FillColor = System.Drawing.Color.White;
            this.SellScreenbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SellScreenbtn.ForeColor = System.Drawing.Color.Indigo;
            this.SellScreenbtn.HoverState.Parent = this.SellScreenbtn;
            this.SellScreenbtn.Location = new System.Drawing.Point(41, 29);
            this.SellScreenbtn.Name = "SellScreenbtn";
            this.SellScreenbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.SellScreenbtn.ShadowDecoration.Parent = this.SellScreenbtn;
            this.SellScreenbtn.Size = new System.Drawing.Size(50, 50);
            this.SellScreenbtn.TabIndex = 16;
            this.SellScreenbtn.Text = "S";
            this.SellScreenbtn.Click += new System.EventHandler(this.SellScreenbtn_Click);
            // 
            // Logoutbtn
            // 
            this.Logoutbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Logoutbtn.BackColor = System.Drawing.Color.Transparent;
            this.Logoutbtn.CheckedState.Parent = this.Logoutbtn;
            this.Logoutbtn.CustomImages.Parent = this.Logoutbtn;
            this.Logoutbtn.FillColor = System.Drawing.Color.White;
            this.Logoutbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Logoutbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Logoutbtn.HoverState.Parent = this.Logoutbtn;
            this.Logoutbtn.Location = new System.Drawing.Point(41, 554);
            this.Logoutbtn.Name = "Logoutbtn";
            this.Logoutbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Logoutbtn.ShadowDecoration.Parent = this.Logoutbtn;
            this.Logoutbtn.Size = new System.Drawing.Size(50, 50);
            this.Logoutbtn.TabIndex = 16;
            this.Logoutbtn.Text = "LO";
            this.Logoutbtn.Click += new System.EventHandler(this.Logoutbtn_Click);
            // 
            // guna2CircleButton12
            // 
            this.guna2CircleButton12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2CircleButton12.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton12.CheckedState.Parent = this.guna2CircleButton12;
            this.guna2CircleButton12.CustomImages.Parent = this.guna2CircleButton12;
            this.guna2CircleButton12.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton12.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton12.HoverState.Parent = this.guna2CircleButton12;
            this.guna2CircleButton12.Location = new System.Drawing.Point(41, 498);
            this.guna2CircleButton12.Name = "guna2CircleButton12";
            this.guna2CircleButton12.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton12.ShadowDecoration.Parent = this.guna2CircleButton12;
            this.guna2CircleButton12.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton12.TabIndex = 16;
            this.guna2CircleButton12.Text = "SET";
            // 
            // guna2CircleButton13
            // 
            this.guna2CircleButton13.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton13.CheckedState.Parent = this.guna2CircleButton13;
            this.guna2CircleButton13.CustomImages.Parent = this.guna2CircleButton13;
            this.guna2CircleButton13.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton13.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton13.HoverState.Parent = this.guna2CircleButton13;
            this.guna2CircleButton13.Location = new System.Drawing.Point(41, 88);
            this.guna2CircleButton13.Name = "guna2CircleButton13";
            this.guna2CircleButton13.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton13.ShadowDecoration.Parent = this.guna2CircleButton13;
            this.guna2CircleButton13.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton13.TabIndex = 16;
            this.guna2CircleButton13.Text = "R";
            this.guna2CircleButton13.Click += new System.EventHandler(this.guna2CircleButton13_Click);
            // 
            // guna2CircleButton4
            // 
            this.guna2CircleButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton4.CheckedState.Parent = this.guna2CircleButton4;
            this.guna2CircleButton4.CustomImages.Parent = this.guna2CircleButton4;
            this.guna2CircleButton4.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton4.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton4.HoverState.Parent = this.guna2CircleButton4;
            this.guna2CircleButton4.Location = new System.Drawing.Point(41, 144);
            this.guna2CircleButton4.Name = "guna2CircleButton4";
            this.guna2CircleButton4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton4.ShadowDecoration.Parent = this.guna2CircleButton4;
            this.guna2CircleButton4.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton4.TabIndex = 16;
            this.guna2CircleButton4.Text = "C";
            this.guna2CircleButton4.Click += new System.EventHandler(this.guna2CircleButton4_Click);
            // 
            // Reprintbtn
            // 
            this.Reprintbtn.BackColor = System.Drawing.Color.Transparent;
            this.Reprintbtn.CheckedState.Parent = this.Reprintbtn;
            this.Reprintbtn.CustomImages.Parent = this.Reprintbtn;
            this.Reprintbtn.FillColor = System.Drawing.Color.White;
            this.Reprintbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Reprintbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Reprintbtn.HoverState.Parent = this.Reprintbtn;
            this.Reprintbtn.Location = new System.Drawing.Point(41, 368);
            this.Reprintbtn.Name = "Reprintbtn";
            this.Reprintbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Reprintbtn.ShadowDecoration.Parent = this.Reprintbtn;
            this.Reprintbtn.Size = new System.Drawing.Size(50, 50);
            this.Reprintbtn.TabIndex = 16;
            this.Reprintbtn.Text = "RP";
            this.Reprintbtn.Click += new System.EventHandler(this.Reprintbtn_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(41, 312);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton1.TabIndex = 16;
            this.guna2CircleButton1.Text = "RE";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // guna2CircleButton9
            // 
            this.guna2CircleButton9.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton9.CheckedState.Parent = this.guna2CircleButton9;
            this.guna2CircleButton9.CustomImages.Parent = this.guna2CircleButton9;
            this.guna2CircleButton9.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton9.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton9.HoverState.Parent = this.guna2CircleButton9;
            this.guna2CircleButton9.Location = new System.Drawing.Point(41, 424);
            this.guna2CircleButton9.Name = "guna2CircleButton9";
            this.guna2CircleButton9.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton9.ShadowDecoration.Parent = this.guna2CircleButton9;
            this.guna2CircleButton9.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton9.TabIndex = 16;
            this.guna2CircleButton9.Text = "AB";
            // 
            // Duesbtn
            // 
            this.Duesbtn.BackColor = System.Drawing.Color.Transparent;
            this.Duesbtn.CheckedState.Parent = this.Duesbtn;
            this.Duesbtn.CustomImages.Parent = this.Duesbtn;
            this.Duesbtn.FillColor = System.Drawing.Color.White;
            this.Duesbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Duesbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Duesbtn.HoverState.Parent = this.Duesbtn;
            this.Duesbtn.Location = new System.Drawing.Point(41, 200);
            this.Duesbtn.Name = "Duesbtn";
            this.Duesbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Duesbtn.ShadowDecoration.Parent = this.Duesbtn;
            this.Duesbtn.Size = new System.Drawing.Size(50, 50);
            this.Duesbtn.TabIndex = 16;
            this.Duesbtn.Text = "D";
            this.Duesbtn.Click += new System.EventHandler(this.Duesbtn_Click);
            // 
            // Expensebtn
            // 
            this.Expensebtn.BackColor = System.Drawing.Color.Transparent;
            this.Expensebtn.CheckedState.Parent = this.Expensebtn;
            this.Expensebtn.CustomImages.Parent = this.Expensebtn;
            this.Expensebtn.FillColor = System.Drawing.Color.White;
            this.Expensebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Expensebtn.ForeColor = System.Drawing.Color.Indigo;
            this.Expensebtn.HoverState.Parent = this.Expensebtn;
            this.Expensebtn.Location = new System.Drawing.Point(41, 256);
            this.Expensebtn.Name = "Expensebtn";
            this.Expensebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Expensebtn.ShadowDecoration.Parent = this.Expensebtn;
            this.Expensebtn.Size = new System.Drawing.Size(50, 50);
            this.Expensebtn.TabIndex = 16;
            this.Expensebtn.Text = "E";
            this.Expensebtn.Click += new System.EventHandler(this.Expensebtn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(105, 386);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 22);
            this.label11.TabIndex = 17;
            this.label11.Text = "Reprint";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(105, 516);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 22);
            this.label10.TabIndex = 17;
            this.label10.Text = "Setting";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(105, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 22);
            this.label7.TabIndex = 17;
            this.label7.Text = "Report";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(105, 571);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 22);
            this.label9.TabIndex = 17;
            this.label9.Text = "Logout";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(105, 443);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 22);
            this.label8.TabIndex = 17;
            this.label8.Text = "About";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(105, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 22);
            this.label6.TabIndex = 17;
            this.label6.Text = "Expense";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(105, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 22);
            this.label5.TabIndex = 17;
            this.label5.Text = "Dues";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(105, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 22);
            this.label4.TabIndex = 17;
            this.label4.Text = "Claim";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(105, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 22);
            this.label3.TabIndex = 17;
            this.label3.Text = "Return";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(105, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 22);
            this.label2.TabIndex = 17;
            this.label2.Text = "Sell";
            // 
            // guna2CircleButton8
            // 
            this.guna2CircleButton8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton8.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton8.CheckedState.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.CustomImages.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton8.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton8.HoverState.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.Location = new System.Drawing.Point(1021, 12);
            this.guna2CircleButton8.Name = "guna2CircleButton8";
            this.guna2CircleButton8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton8.ShadowDecoration.Parent = this.guna2CircleButton8;
            this.guna2CircleButton8.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton8.TabIndex = 16;
            this.guna2CircleButton8.Text = "N";
            // 
            // contentPanel
            // 
            this.contentPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.contentPanel.BorderRadius = 10;
            this.contentPanel.FillColor = System.Drawing.Color.White;
            this.contentPanel.Location = new System.Drawing.Point(201, 99);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Padding = new System.Windows.Forms.Padding(5);
            this.contentPanel.ShadowDecoration.Parent = this.contentPanel;
            this.contentPanel.Size = new System.Drawing.Size(1060, 554);
            this.contentPanel.TabIndex = 19;
            // 
            // crossbtn
            // 
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.White;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.Indigo;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(121, 46);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(50, 50);
            this.crossbtn.TabIndex = 18;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // shoplogo
            // 
            this.shoplogo.BorderRadius = 10;
            this.shoplogo.FillColor = System.Drawing.Color.White;
            this.shoplogo.Location = new System.Drawing.Point(17, 12);
            this.shoplogo.Name = "shoplogo";
            this.shoplogo.ShadowDecoration.Parent = this.shoplogo;
            this.shoplogo.Size = new System.Drawing.Size(70, 70);
            this.shoplogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.shoplogo.TabIndex = 16;
            this.shoplogo.TabStop = false;
            // 
            // time
            // 
            this.time.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.time.AutoSize = true;
            this.time.BackColor = System.Drawing.Color.Transparent;
            this.time.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.time.ForeColor = System.Drawing.Color.Indigo;
            this.time.Location = new System.Drawing.Point(634, 26);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(80, 22);
            this.time.TabIndex = 17;
            this.time.Text = "00:00:00";
            // 
            // shoptitle
            // 
            this.shoptitle.AutoSize = true;
            this.shoptitle.BackColor = System.Drawing.Color.Transparent;
            this.shoptitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.shoptitle.ForeColor = System.Drawing.Color.Indigo;
            this.shoptitle.Location = new System.Drawing.Point(109, 44);
            this.shoptitle.Name = "shoptitle";
            this.shoptitle.Size = new System.Drawing.Size(38, 22);
            this.shoptitle.TabIndex = 17;
            this.shoptitle.Text = "title";
            // 
            // shopname
            // 
            this.shopname.AutoSize = true;
            this.shopname.BackColor = System.Drawing.Color.Transparent;
            this.shopname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.shopname.ForeColor = System.Drawing.Color.Indigo;
            this.shopname.Location = new System.Drawing.Point(109, 26);
            this.shopname.Name = "shopname";
            this.shopname.Size = new System.Drawing.Size(109, 22);
            this.shopname.TabIndex = 17;
            this.shopname.Text = "Mobile Shop";
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.BorderRadius = 20;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // guna2GroupBox6
            // 
            this.guna2GroupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox6.BorderRadius = 30;
            this.guna2GroupBox6.Controls.Add(this.minimizebtn);
            this.guna2GroupBox6.Controls.Add(this.maximizebtn);
            this.guna2GroupBox6.Controls.Add(this.crossbtn);
            this.guna2GroupBox6.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox6.FillColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox6.Location = new System.Drawing.Point(1077, -34);
            this.guna2GroupBox6.Name = "guna2GroupBox6";
            this.guna2GroupBox6.ShadowDecoration.Parent = this.guna2GroupBox6;
            this.guna2GroupBox6.Size = new System.Drawing.Size(179, 106);
            this.guna2GroupBox6.TabIndex = 21;
            // 
            // minimizebtn
            // 
            this.minimizebtn.CheckedState.Parent = this.minimizebtn;
            this.minimizebtn.CustomImages.Parent = this.minimizebtn;
            this.minimizebtn.FillColor = System.Drawing.Color.White;
            this.minimizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.minimizebtn.ForeColor = System.Drawing.Color.Indigo;
            this.minimizebtn.HoverState.Parent = this.minimizebtn;
            this.minimizebtn.Location = new System.Drawing.Point(9, 46);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.minimizebtn.ShadowDecoration.Parent = this.minimizebtn;
            this.minimizebtn.Size = new System.Drawing.Size(50, 50);
            this.minimizebtn.TabIndex = 18;
            this.minimizebtn.Text = "__";
            this.minimizebtn.Click += new System.EventHandler(this.minimizebtn_Click);
            // 
            // maximizebtn
            // 
            this.maximizebtn.CheckedState.Parent = this.maximizebtn;
            this.maximizebtn.CustomImages.Parent = this.maximizebtn;
            this.maximizebtn.FillColor = System.Drawing.Color.White;
            this.maximizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.maximizebtn.ForeColor = System.Drawing.Color.Indigo;
            this.maximizebtn.HoverState.Parent = this.maximizebtn;
            this.maximizebtn.Location = new System.Drawing.Point(65, 46);
            this.maximizebtn.Name = "maximizebtn";
            this.maximizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.maximizebtn.ShadowDecoration.Parent = this.maximizebtn;
            this.maximizebtn.Size = new System.Drawing.Size(50, 50);
            this.maximizebtn.TabIndex = 18;
            this.maximizebtn.Text = "|=|";
            this.maximizebtn.Click += new System.EventHandler(this.maximizebtn_Click);
            // 
            // guna2GroupBox5
            // 
            this.guna2GroupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox5.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox5.BorderRadius = 20;
            this.guna2GroupBox5.Controls.Add(this.label1);
            this.guna2GroupBox5.Controls.Add(this.label14);
            this.guna2GroupBox5.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox5.Location = new System.Drawing.Point(201, 659);
            this.guna2GroupBox5.Name = "guna2GroupBox5";
            this.guna2GroupBox5.ShadowDecoration.Parent = this.guna2GroupBox5;
            this.guna2GroupBox5.Size = new System.Drawing.Size(1054, 43);
            this.guna2GroupBox5.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(835, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 22);
            this.label1.TabIndex = 18;
            this.label1.Text = "contact # 0300-0000000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(20, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(554, 22);
            this.label14.TabIndex = 18;
            this.label14.Text = "All copyright has been reserved to Fidx Software House Nawabshah";
            // 
            // itemstimeout
            // 
            this.itemstimeout.Enabled = true;
            this.itemstimeout.Interval = 120000;
            this.itemstimeout.Tick += new System.EventHandler(this.itemstimeout_Tick);
            // 
            // SellScreenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1273, 715);
            this.Controls.Add(this.guna2GroupBox5);
            this.Controls.Add(this.guna2CircleButton8);
            this.Controls.Add(this.guna2GroupBox6);
            this.Controls.Add(this.guna2GroupBox2);
            this.Controls.Add(this.shoplogo);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.shopname);
            this.Controls.Add(this.shoptitle);
            this.Controls.Add(this.time);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SellScreenForm";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellScreenForm";
            this.Load += new System.EventHandler(this.SellScreenForm_Load);
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shoplogo)).EndInit();
            this.guna2GroupBox6.ResumeLayout(false);
            this.guna2GroupBox5.ResumeLayout(false);
            this.guna2GroupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private Guna.UI2.WinForms.Guna2PictureBox shoplogo;
        private System.Windows.Forms.Label shopname;
        private Guna.UI2.WinForms.Guna2Panel contentPanel;
        private System.Windows.Forms.Label time;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2CircleButton Logoutbtn;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton8;
        private Guna.UI2.WinForms.Guna2CircleButton Expensebtn;
        private Guna.UI2.WinForms.Guna2CircleButton Duesbtn;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton4;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton13;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton12;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label shoptitle;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox6;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2CircleButton SellScreenbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2CircleButton minimizebtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        public Guna.UI2.WinForms.Guna2CircleButton maximizebtn;
        private System.Windows.Forms.Timer itemstimeout;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton9;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2CircleButton Reprintbtn;
        private System.Windows.Forms.Label label11;
    }
}