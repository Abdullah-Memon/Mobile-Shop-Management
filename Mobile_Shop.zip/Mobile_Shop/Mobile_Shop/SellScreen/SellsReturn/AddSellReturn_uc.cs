﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen.SellsReturn
{
    public partial class AddSellReturn_uc : UserControl
    {
        public AddSellReturn_uc()
        {
            InitializeComponent();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(invoicebox.Text) || !string.IsNullOrWhiteSpace(invoicebox.Text))
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    SqlCommand cmd = new SqlCommand("findSellBills", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));

                    dt.Load(cmd.ExecuteReader());
                    DB.con.Close();

                    gridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                invoicebox.Focus();
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            ViewSellsReturn_uc vsr = new ViewSellsReturn_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(vsr);
            vsr.Dock = DockStyle.Fill;
        }

        private void gridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                if(gridView.Rows[e.RowIndex].Cells["Warranty"].Value.ToString() != "None")
                {
                    DetailSellReturn_Form dsr = new DetailSellReturn_Form((int)gridView.Rows[e.RowIndex].Cells["Qty"].Value, gridView.Rows[e.RowIndex].Cells["Warranty"].Value.ToString(), gridView.Rows[e.RowIndex].Cells["CatagoryName"].Value.ToString(), Convert.ToDecimal(gridView.Rows[e.RowIndex].Cells["Rate"].Value));
                    dsr.ShowDialog();

                    if(DetailSellReturn_Form.selectedqty > 0)
                    {
                        try
                        {
                            if (DB.con.State == ConnectionState.Closed)
                                DB.con.Open();

                            SqlCommand cmd = new SqlCommand("AddSellReturn", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@qty", DetailSellReturn_Form.selectedqty));
                            cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                            cmd.Parameters.Add(new SqlParameter("@reason", DetailSellReturn_Form.status));
                            cmd.Parameters.Add(new SqlParameter("@recivedate", dsr.recivedate.Value));
                            cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));
                            cmd.Parameters.Add(new SqlParameter("@catagory", gridView.Rows[e.RowIndex].Cells["CatagoryName"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@imei", gridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@color", gridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@itemid", gridView.Rows[e.RowIndex].Cells["IID"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@newwarranty", DetailSellReturn_Form.RemainingWarranty));


                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        object a = new object();
                        EventArgs b = new EventArgs();

                        searchbtn_Click(a, b);
                    }
                }
                else
                {
                    MessageBox.Show("Item cant be Returned");
                }
            }
        }

        private void AddSellReturn_uc_Load(object sender, EventArgs e)
        {
            invoicebox.Focus();
        }
    }
}
