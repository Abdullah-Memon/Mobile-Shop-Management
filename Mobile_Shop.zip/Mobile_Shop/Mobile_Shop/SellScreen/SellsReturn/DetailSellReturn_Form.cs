﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.SellScreen.SellsReturn
{
    public partial class DetailSellReturn_Form : Form
    {
        int totalqty;
        string catagory;
        public DetailSellReturn_Form(int qty, string w, string c, decimal p)
        {
            InitializeComponent();
            totalqty = qty;
            warranty.Text = w;
            catagory = c;
            ProductPricebox.Text = (qty * p).ToString();
        }

        // Global variable to send Values;
        public static int selectedqty;
        public static string status, RemainingWarranty;

        // Cross button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DetailSellReturn_Form_Load(object sender, EventArgs e)
        {
            recivedate.Text = DateTime.Now.ToShortDateString();
            qtybox.Focus();
            selectedqty = 0;
            status = string.Empty;

            if (catagory == "Mobile")
                warranty.ReadOnly = false;
            else
                warranty.ReadOnly = true;
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(qtybox.Text) <= totalqty && Convert.ToInt32(qtybox.Text) > 0)
            {
                try
                {
                    selectedqty = Convert.ToInt32(qtybox.Text);
                    status = Reasonbox.Text;
                    RemainingWarranty = warranty.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                this.Close();
            }
            else
                qtybox.Focus();
        }
    }
}
