﻿namespace Mobile_Shop.SellScreen.SellsReturn
{
    partial class DetailSellReturn_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Contentpanel = new System.Windows.Forms.Panel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Reasonbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.warranty = new Guna.UI2.WinForms.Guna2TextBox();
            this.qtybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.recivedate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.ProductPricebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Contentpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Contentpanel
            // 
            this.Contentpanel.BackColor = System.Drawing.Color.White;
            this.Contentpanel.Controls.Add(this.guna2GradientButton1);
            this.Contentpanel.Controls.Add(this.crossbtn);
            this.Contentpanel.Controls.Add(this.Reasonbox);
            this.Contentpanel.Controls.Add(this.label3);
            this.Contentpanel.Controls.Add(this.label5);
            this.Contentpanel.Controls.Add(this.label6);
            this.Contentpanel.Controls.Add(this.label2);
            this.Contentpanel.Controls.Add(this.label4);
            this.Contentpanel.Controls.Add(this.label1);
            this.Contentpanel.Controls.Add(this.ProductPricebox);
            this.Contentpanel.Controls.Add(this.warranty);
            this.Contentpanel.Controls.Add(this.qtybox);
            this.Contentpanel.Controls.Add(this.recivedate);
            this.Contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Contentpanel.Location = new System.Drawing.Point(10, 10);
            this.Contentpanel.Name = "Contentpanel";
            this.Contentpanel.Size = new System.Drawing.Size(304, 430);
            this.Contentpanel.TabIndex = 1;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(94, 372);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(99, 40);
            this.guna2GradientButton1.TabIndex = 36;
            this.guna2GradientButton1.Text = "Add";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // crossbtn
            // 
            this.crossbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.crossbtn.BackColor = System.Drawing.Color.Transparent;
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.Indigo;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.White;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(266, 3);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 32;
            this.crossbtn.Text = "X";
            this.crossbtn.UseTransparentBackground = true;
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // Reasonbox
            // 
            this.Reasonbox.Location = new System.Drawing.Point(26, 281);
            this.Reasonbox.Multiline = true;
            this.Reasonbox.Name = "Reasonbox";
            this.Reasonbox.Size = new System.Drawing.Size(256, 85);
            this.Reasonbox.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 263);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Remaining Warranty";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Date";
            // 
            // warranty
            // 
            this.warranty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.warranty.DefaultText = "";
            this.warranty.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.warranty.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.warranty.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.warranty.DisabledState.Parent = this.warranty;
            this.warranty.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.warranty.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.warranty.FocusedState.Parent = this.warranty;
            this.warranty.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.warranty.HoverState.Parent = this.warranty;
            this.warranty.Location = new System.Drawing.Point(26, 224);
            this.warranty.Name = "warranty";
            this.warranty.PasswordChar = '\0';
            this.warranty.PlaceholderText = "";
            this.warranty.SelectedText = "";
            this.warranty.ShadowDecoration.Parent = this.warranty;
            this.warranty.Size = new System.Drawing.Size(256, 36);
            this.warranty.TabIndex = 5;
            // 
            // qtybox
            // 
            this.qtybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qtybox.DefaultText = "";
            this.qtybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.qtybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.qtybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qtybox.DisabledState.Parent = this.qtybox;
            this.qtybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qtybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qtybox.FocusedState.Parent = this.qtybox;
            this.qtybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qtybox.HoverState.Parent = this.qtybox;
            this.qtybox.Location = new System.Drawing.Point(109, 157);
            this.qtybox.Name = "qtybox";
            this.qtybox.PasswordChar = '\0';
            this.qtybox.PlaceholderText = "";
            this.qtybox.SelectedText = "";
            this.qtybox.ShadowDecoration.Parent = this.qtybox;
            this.qtybox.Size = new System.Drawing.Size(173, 36);
            this.qtybox.TabIndex = 5;
            // 
            // recivedate
            // 
            this.recivedate.BorderRadius = 10;
            this.recivedate.BorderThickness = 1;
            this.recivedate.CheckedState.Parent = this.recivedate;
            this.recivedate.FillColor = System.Drawing.Color.Indigo;
            this.recivedate.ForeColor = System.Drawing.Color.White;
            this.recivedate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.recivedate.HoverState.Parent = this.recivedate;
            this.recivedate.Location = new System.Drawing.Point(26, 65);
            this.recivedate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.recivedate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.recivedate.Name = "recivedate";
            this.recivedate.ShadowDecoration.Parent = this.recivedate;
            this.recivedate.Size = new System.Drawing.Size(256, 36);
            this.recivedate.TabIndex = 4;
            this.recivedate.Value = new System.DateTime(2022, 9, 16, 23, 13, 36, 306);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.Contentpanel;
            // 
            // ProductPricebox
            // 
            this.ProductPricebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ProductPricebox.DefaultText = "";
            this.ProductPricebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ProductPricebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ProductPricebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProductPricebox.DisabledState.Parent = this.ProductPricebox;
            this.ProductPricebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProductPricebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ProductPricebox.FocusedState.Parent = this.ProductPricebox;
            this.ProductPricebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ProductPricebox.HoverState.Parent = this.ProductPricebox;
            this.ProductPricebox.Location = new System.Drawing.Point(109, 115);
            this.ProductPricebox.Name = "ProductPricebox";
            this.ProductPricebox.PasswordChar = '\0';
            this.ProductPricebox.PlaceholderText = "";
            this.ProductPricebox.SelectedText = "";
            this.ProductPricebox.ShadowDecoration.Parent = this.ProductPricebox;
            this.ProductPricebox.Size = new System.Drawing.Size(174, 36);
            this.ProductPricebox.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "Product Price";
            // 
            // DetailSellReturn_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(324, 450);
            this.Controls.Add(this.Contentpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DetailSellReturn_Form";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DetailSellReturn_Form";
            this.Load += new System.EventHandler(this.DetailSellReturn_Form_Load);
            this.Contentpanel.ResumeLayout(false);
            this.Contentpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Contentpanel;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private System.Windows.Forms.TextBox Reasonbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox qtybox;
        public Guna.UI2.WinForms.Guna2DateTimePicker recivedate;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox warranty;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox ProductPricebox;
    }
}