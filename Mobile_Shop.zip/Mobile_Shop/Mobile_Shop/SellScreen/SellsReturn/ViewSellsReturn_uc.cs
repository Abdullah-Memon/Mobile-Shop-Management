﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen.SellsReturn
{
    public partial class ViewSellsReturn_uc : UserControl
    {
        public ViewSellsReturn_uc()
        {
            InitializeComponent();
        }
        // Function to get Return items detaisl
        private void getReutrnDetails()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("SellReturnDetails",DB.con) {CommandType = CommandType.StoredProcedure};

                dt.Load(cmd.ExecuteReader());

                gridView.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Searching items Coding
        private void guna2DataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void ViewSellsReturn_uc_Load(object sender, EventArgs e)
        {
            getReutrnDetails();
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            AddSellReturn_uc asr = new AddSellReturn_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(asr);
            asr.Dock = DockStyle.Fill;
        }

        private void gridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.ColumnIndex == 0)
            {
                MessageBox.Show("it works");

                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    SqlCommand cmd = new SqlCommand("AddDestroyedItems", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                    cmd.Parameters.Add(new SqlParameter("@sid", gridView.Rows[e.RowIndex].Cells["SID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@imei", gridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@qty", gridView.Rows[e.RowIndex].Cells["Qty"].Value));
                    cmd.Parameters.Add(new SqlParameter("@catagory", gridView.Rows[e.RowIndex].Cells["CatagoryName"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@color", gridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@date", Convert.ToDateTime(DateTime.Now.ToShortDateString())));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                // refreshing data
                getReutrnDetails();
            }
        }
    }
}
