﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Mobile_Shop.SellScreen.SellsReturn;

namespace Mobile_Shop.SellScreen.SellsClaim
{
    public partial class AddSellClaim_uc : UserControl
    {
        public AddSellClaim_uc()
        {
            InitializeComponent();
        }

        // Function to Search Bills
        private void GetBillDetails()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("findSellBills", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                gridView.DataSource = dt;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Search Button Coding
        private void searchbtn_Click(object sender, EventArgs e)
        {
            GetBillDetails();
        }

        // Back Button Coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            ViewSellClaim_uc vsc = new ViewSellClaim_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(vsc);
            vsc.Dock = DockStyle.Fill;
        }

        private void gridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                if (gridView.Rows[e.RowIndex].Cells["Warranty"].Value.ToString().ToLower() != "none")
                {
                    try
                    {
                        // Getting more product Details
                        DetailSellClaim_Form dsc = new DetailSellClaim_Form((int)gridView.Rows[e.RowIndex].Cells["Qty"].Value, Convert.ToDecimal(gridView.Rows[e.RowIndex].Cells["Rate"].Value.ToString()));
                        dsc.ShowDialog();

                        if(DetailSellClaim_Form.chk > 0)
                        {
                            if (DB.con.State == ConnectionState.Closed) ;
                            DB.con.Open();

                            SqlCommand cmd = new SqlCommand("AddSellClaim",DB.con) { CommandType = CommandType.StoredProcedure };

                            cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                            cmd.Parameters.Add(new SqlParameter("@qty", DetailSellClaim_Form.qty));
                            cmd.Parameters.Add(new SqlParameter("@reason", DetailSellClaim_Form.status));
                            cmd.Parameters.Add(new SqlParameter("@date", dsc.claimdate.Value));
                            cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));
                            cmd.Parameters.Add(new SqlParameter("@itemid", gridView.Rows[e.RowIndex].Cells["IID"].Value));
                            cmd.Parameters.Add(new SqlParameter("@imei", gridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@color", gridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));

                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("This Product Cant be Claimed");
                }
                
                // Refreshing list
                GetBillDetails();
            }
        }

        private void AddSellClaim_uc_Load(object sender, EventArgs e)
        {
            invoicebox.Focus();
        }
    }
}

