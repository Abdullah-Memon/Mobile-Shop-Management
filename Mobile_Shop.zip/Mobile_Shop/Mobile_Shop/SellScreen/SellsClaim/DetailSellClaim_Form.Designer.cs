﻿namespace Mobile_Shop.SellScreen.SellsClaim
{
    partial class DetailSellClaim_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Contentpanel = new System.Windows.Forms.Panel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Reasonbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ProductPricebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.qtybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.claimdate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.Contentpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Contentpanel
            // 
            this.Contentpanel.BackColor = System.Drawing.Color.White;
            this.Contentpanel.Controls.Add(this.guna2GradientButton1);
            this.Contentpanel.Controls.Add(this.crossbtn);
            this.Contentpanel.Controls.Add(this.Reasonbox);
            this.Contentpanel.Controls.Add(this.label3);
            this.Contentpanel.Controls.Add(this.label6);
            this.Contentpanel.Controls.Add(this.label2);
            this.Contentpanel.Controls.Add(this.label4);
            this.Contentpanel.Controls.Add(this.label1);
            this.Contentpanel.Controls.Add(this.ProductPricebox);
            this.Contentpanel.Controls.Add(this.qtybox);
            this.Contentpanel.Controls.Add(this.claimdate);
            this.Contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Contentpanel.Location = new System.Drawing.Point(10, 10);
            this.Contentpanel.Name = "Contentpanel";
            this.Contentpanel.Size = new System.Drawing.Size(307, 420);
            this.Contentpanel.TabIndex = 2;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(95, 350);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(99, 40);
            this.guna2GradientButton1.TabIndex = 36;
            this.guna2GradientButton1.Text = "Add";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // crossbtn
            // 
            this.crossbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.crossbtn.BackColor = System.Drawing.Color.Transparent;
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.Indigo;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.White;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(269, 3);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 32;
            this.crossbtn.Text = "X";
            this.crossbtn.UseTransparentBackground = true;
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // Reasonbox
            // 
            this.Reasonbox.Location = new System.Drawing.Point(22, 238);
            this.Reasonbox.Multiline = true;
            this.Reasonbox.Name = "Reasonbox";
            this.Reasonbox.Size = new System.Drawing.Size(256, 106);
            this.Reasonbox.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Status";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "Product Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Date";
            // 
            // ProductPricebox
            // 
            this.ProductPricebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ProductPricebox.DefaultText = "";
            this.ProductPricebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ProductPricebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ProductPricebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProductPricebox.DisabledState.Parent = this.ProductPricebox;
            this.ProductPricebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ProductPricebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ProductPricebox.FocusedState.Parent = this.ProductPricebox;
            this.ProductPricebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ProductPricebox.HoverState.Parent = this.ProductPricebox;
            this.ProductPricebox.Location = new System.Drawing.Point(105, 131);
            this.ProductPricebox.Name = "ProductPricebox";
            this.ProductPricebox.PasswordChar = '\0';
            this.ProductPricebox.PlaceholderText = "";
            this.ProductPricebox.ReadOnly = true;
            this.ProductPricebox.SelectedText = "";
            this.ProductPricebox.ShadowDecoration.Parent = this.ProductPricebox;
            this.ProductPricebox.Size = new System.Drawing.Size(174, 36);
            this.ProductPricebox.TabIndex = 5;
            // 
            // qtybox
            // 
            this.qtybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qtybox.DefaultText = "1";
            this.qtybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.qtybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.qtybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qtybox.DisabledState.Parent = this.qtybox;
            this.qtybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qtybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qtybox.FocusedState.Parent = this.qtybox;
            this.qtybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qtybox.HoverState.Parent = this.qtybox;
            this.qtybox.Location = new System.Drawing.Point(105, 173);
            this.qtybox.Name = "qtybox";
            this.qtybox.PasswordChar = '\0';
            this.qtybox.PlaceholderText = "";
            this.qtybox.SelectedText = "";
            this.qtybox.SelectionStart = 1;
            this.qtybox.ShadowDecoration.Parent = this.qtybox;
            this.qtybox.Size = new System.Drawing.Size(173, 36);
            this.qtybox.TabIndex = 5;
            // 
            // claimdate
            // 
            this.claimdate.BorderRadius = 10;
            this.claimdate.BorderThickness = 1;
            this.claimdate.CheckedState.Parent = this.claimdate;
            this.claimdate.FillColor = System.Drawing.Color.Indigo;
            this.claimdate.ForeColor = System.Drawing.Color.White;
            this.claimdate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.claimdate.HoverState.Parent = this.claimdate;
            this.claimdate.Location = new System.Drawing.Point(22, 81);
            this.claimdate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.claimdate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.claimdate.Name = "claimdate";
            this.claimdate.ShadowDecoration.Parent = this.claimdate;
            this.claimdate.Size = new System.Drawing.Size(256, 36);
            this.claimdate.TabIndex = 4;
            this.claimdate.Value = new System.DateTime(2022, 9, 16, 23, 13, 36, 306);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.Contentpanel;
            // 
            // DetailSellClaim_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(327, 440);
            this.Controls.Add(this.Contentpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DetailSellClaim_Form";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DetailSellClaim_Form";
            this.Load += new System.EventHandler(this.DetailSellClaim_Form_Load);
            this.Contentpanel.ResumeLayout(false);
            this.Contentpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Contentpanel;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private System.Windows.Forms.TextBox Reasonbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox ProductPricebox;
        private Guna.UI2.WinForms.Guna2TextBox qtybox;
        public Guna.UI2.WinForms.Guna2DateTimePicker claimdate;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
    }
}