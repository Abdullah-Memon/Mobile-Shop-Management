﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.SellScreen.SellsReturn
{
    public partial class ViewSellClaim_uc : UserControl
    {
        public ViewSellClaim_uc()
        {
            InitializeComponent();
        }

        // Function to Get Claimed Items Details
        private void GetClaimedItems()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();
                SqlCommand cmd = new SqlCommand("SellClaimDetails",DB.con) { CommandType = CommandType.StoredProcedure };
                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                gridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Loading AddClaim Screen
        private void Addbtn_Click(object sender, EventArgs e)
        {
            SellsClaim.AddSellClaim_uc asc = new SellsClaim.AddSellClaim_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(asc);
            asc.Dock = DockStyle.Fill;
        }

        private void ViewSellClaim_uc_Load(object sender, EventArgs e)
        {
            GetClaimedItems();
        }

        private void gridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                try
                {
                    // Getting more product Details
                    SellsClaim.DetailSellClaim_Form dsc = new SellsClaim.DetailSellClaim_Form((int)gridView.Rows[e.RowIndex].Cells["Qty"].Value);
                    dsc.ShowDialog();
                
                    if (SellsClaim.DetailSellClaim_Form.chk > 0)
                    {
                        if (DB.con.State == ConnectionState.Closed) ;
                        DB.con.Open();
                
                        SqlCommand cmd = new SqlCommand("AddSellClaim",DB.con) { CommandType = CommandType.StoredProcedure };
                
                        cmd.Parameters.Add(new SqlParameter("@data",1));
                        cmd.Parameters.Add(new SqlParameter("@qty", SellsClaim.DetailSellClaim_Form.qty));
                        cmd.Parameters.Add(new SqlParameter("@reason", SellsClaim.DetailSellClaim_Form.status));
                        cmd.Parameters.Add(new SqlParameter("@date", dsc.claimdate.Value));
                        cmd.Parameters.Add(new SqlParameter("@invoice", gridView.Rows[e.RowIndex].Cells["InvoiceNumber"].Value));
                        cmd.Parameters.Add(new SqlParameter("@itemid", gridView.Rows[e.RowIndex].Cells["IID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@imei", gridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString()));
                        cmd.Parameters.Add(new SqlParameter("@color", gridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));
                
                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                //refreshing list
                 GetClaimedItems();
            }

            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are You sure you want to destroy the Product?", "Confimation",MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        SellsClaim.DetailSellClaim_Form dsc = new SellsClaim.DetailSellClaim_Form((int)gridView.Rows[e.RowIndex].Cells["Qty"].Value);
                        dsc.ShowDialog();

                        if (SellsClaim.DetailSellClaim_Form.chk > 0)
                        {
                            if (DB.con.State == ConnectionState.Closed)
                                DB.con.Open();

                            SqlCommand cmd = new SqlCommand("AddDestroyedItems", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                            cmd.Parameters.Add(new SqlParameter("@sid", gridView.Rows[e.RowIndex].Cells["SID"].Value));
                            cmd.Parameters.Add(new SqlParameter("@imei", gridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@qty", SellsClaim.DetailSellClaim_Form.qty));
                            cmd.Parameters.Add(new SqlParameter("@catagory", gridView.Rows[e.RowIndex].Cells["CatagoryName"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@color", gridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@date", Convert.ToDateTime(DateTime.Now.ToShortDateString())));

                            cmd.ExecuteNonQuery();
                            DB.con.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

    }
}
