﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.SellScreen.SellsClaim
{
    public partial class DetailSellClaim_Form : Form
    {
        int totalqty;
        public DetailSellClaim_Form(int q = 0, decimal p = 0)
        {
            InitializeComponent();
            totalqty = q;
            ProductPricebox.Text = (q * p).ToString();
        }

        public static int qty, chk;
        public static string status;

        private void DetailSellClaim_Form_Load(object sender, EventArgs e)
        {
            chk = 0;
            claimdate.Text = DateTime.Now.ToShortDateString();
            qtybox.Focus();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(qtybox.Text) <= totalqty && Convert.ToInt32(qtybox.Text) > 0)
            {
                try
                {
                    chk = 1;
                    qty = Convert.ToInt32(qtybox.Text);
                    status = Reasonbox.Text;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                qtybox.Focus();
            }
        }

        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
