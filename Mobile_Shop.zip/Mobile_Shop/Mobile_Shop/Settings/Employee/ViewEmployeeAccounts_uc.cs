﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Settings.Employee
{
    public partial class ViewEmployeeAccounts_uc : UserControl
    {
        public ViewEmployeeAccounts_uc()
        {
            InitializeComponent();
            DB.connect();
        }
        //Global Variables
        SqlCommand cmd;

        // getting avaiable accounts info
        private void getEMPAccounts()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                DataTable accountsinfo = new DataTable();
                cmd = new SqlCommand("EmployeeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                accountsinfo.Load(cmd.ExecuteReader());

                DB.con.Close();

                EmpoyeeGridView.DataSource = accountsinfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error while getting accounts data " + ex.ToString(), "ERROR");
            }
        }

        // Loading Recycle bin Screen
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            EmployeeAccountsRecycleBin_uc rarb = new EmployeeAccountsRecycleBin_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(rarb);
        }

        // back btn coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            EmployeeDashboard_uc ed = new EmployeeDashboard_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(ed);
        }

        // Main load function
        private void ViewEmployeeAccounts_uc_Load(object sender, EventArgs e)
        {
            getEMPAccounts();
        }

        private void EmpoyeeGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 0 == Update 1== printing Report 2 == delete 4== picture

            // update button coding
            if (e.ColumnIndex == 0)
            {

                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", EmpoyeeGridView.Rows[e.RowIndex].Cells["EmployeeID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@name", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Name"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@role", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Role"].Value.ToString().ToLower()));
                    cmd.Parameters.Add(new SqlParameter("@CNIC", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_CNIC"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@Mobile", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Mobile"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@email", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Email"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@address", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Address"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@username", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Username"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@password", EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Password"].Value.ToString()));

                    byte[] pic = (byte[])EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Picture"].Value;
                    cmd.Parameters.Add(new SqlParameter("@picture", pic));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // refreshing the new information
                    getEMPAccounts();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating Employee's Accounts please try again " + ex.ToString(), "ERROR");
                }

            }

            //particular Reporting
            if (e.ColumnIndex == 1)
            {

            }

            //delete button coding
            if (e.ColumnIndex == 2)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("RemoveEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", EmpoyeeGridView.Rows[e.RowIndex].Cells["EmployeeID"].Value));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // refreshing the new information
                    getEMPAccounts();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting Employee's Accounts please try again " + ex.ToString(), "ERROR");
                }
            }
            // picture button coding
            if (e.ColumnIndex == 4)
            {
                using (OpenFileDialog opf = new OpenFileDialog())
                {
                    opf.Filter = "Image file (*.jpg; *.jpeg; *.png; *.bmp; *.gif;) | *.jpg; *.jpeg; *.png; *.bmp; *.gif;";
                    opf.Multiselect = false;

                    if (opf.ShowDialog() == DialogResult.OK)
                    {
                        EmpoyeeGridView.Rows[e.RowIndex].Cells["E_Picture"].Value = Image.FromFile(opf.FileName);
                    }
                }
            }
        }

        private void SelectedAccountType_TextChanged(object sender, EventArgs e)
        {
            if (SelectedAccountType.SelectedIndex > 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    DataTable foundEMPAccountsdata = new DataTable();

                    cmd = new SqlCommand("findEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@role", SelectedAccountType.SelectedIndex));

                    foundEMPAccountsdata.Load(cmd.ExecuteReader());

                    DB.con.Close();

                    //setting up new data
                    EmpoyeeGridView.DataSource = foundEMPAccountsdata;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while founding accounts please try again " + ex.ToString(), "ERROR");
                }
            }
            else
            { getEMPAccounts(); }
        }
    }
}
