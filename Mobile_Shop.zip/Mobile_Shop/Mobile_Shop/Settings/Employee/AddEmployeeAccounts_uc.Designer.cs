﻿namespace Mobile_Shop.Settings.Employee
{
    partial class AddEmployeeAccounts_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.AddItemsDetailsBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.sAnswer = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.sQuestions = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.accounttypebox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.cpasswordbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.mobilebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.uploadpic = new Guna.UI2.WinForms.Guna2GradientButton();
            this.addressbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.emailbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Additem = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.profile = new Guna.UI2.WinForms.Guna2PictureBox();
            this.warning9 = new System.Windows.Forms.Label();
            this.warning8 = new System.Windows.Forms.Label();
            this.warning7 = new System.Windows.Forms.Label();
            this.warning4 = new System.Windows.Forms.Label();
            this.warning3 = new System.Windows.Forms.Label();
            this.warning6 = new System.Windows.Forms.Label();
            this.warning5 = new System.Windows.Forms.Label();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.usernamebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.namebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.cnicbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Salary = new Guna.UI2.WinForms.Guna2TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.contentpanel.SuspendLayout();
            this.AddItemsDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).BeginInit();
            this.SuspendLayout();
            // 
            // contentpanel
            // 
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.AddItemsDetailsBox);
            this.contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 1;
            // 
            // AddItemsDetailsBox
            // 
            this.AddItemsDetailsBox.BorderRadius = 10;
            this.AddItemsDetailsBox.Controls.Add(this.sAnswer);
            this.AddItemsDetailsBox.Controls.Add(this.label10);
            this.AddItemsDetailsBox.Controls.Add(this.sQuestions);
            this.AddItemsDetailsBox.Controls.Add(this.label11);
            this.AddItemsDetailsBox.Controls.Add(this.label7);
            this.AddItemsDetailsBox.Controls.Add(this.accounttypebox);
            this.AddItemsDetailsBox.Controls.Add(this.Backbtn);
            this.AddItemsDetailsBox.Controls.Add(this.cpasswordbox);
            this.AddItemsDetailsBox.Controls.Add(this.mobilebox);
            this.AddItemsDetailsBox.Controls.Add(this.guna2GradientButton2);
            this.AddItemsDetailsBox.Controls.Add(this.uploadpic);
            this.AddItemsDetailsBox.Controls.Add(this.addressbox);
            this.AddItemsDetailsBox.Controls.Add(this.emailbox);
            this.AddItemsDetailsBox.Controls.Add(this.Additem);
            this.AddItemsDetailsBox.Controls.Add(this.label13);
            this.AddItemsDetailsBox.Controls.Add(this.label5);
            this.AddItemsDetailsBox.Controls.Add(this.profile);
            this.AddItemsDetailsBox.Controls.Add(this.warning9);
            this.AddItemsDetailsBox.Controls.Add(this.warning8);
            this.AddItemsDetailsBox.Controls.Add(this.warning7);
            this.AddItemsDetailsBox.Controls.Add(this.warning4);
            this.AddItemsDetailsBox.Controls.Add(this.warning3);
            this.AddItemsDetailsBox.Controls.Add(this.warning6);
            this.AddItemsDetailsBox.Controls.Add(this.warning5);
            this.AddItemsDetailsBox.Controls.Add(this.warning2);
            this.AddItemsDetailsBox.Controls.Add(this.warning1);
            this.AddItemsDetailsBox.Controls.Add(this.label9);
            this.AddItemsDetailsBox.Controls.Add(this.label2);
            this.AddItemsDetailsBox.Controls.Add(this.label1);
            this.AddItemsDetailsBox.Controls.Add(this.label8);
            this.AddItemsDetailsBox.Controls.Add(this.label12);
            this.AddItemsDetailsBox.Controls.Add(this.label3);
            this.AddItemsDetailsBox.Controls.Add(this.label6);
            this.AddItemsDetailsBox.Controls.Add(this.usernamebox);
            this.AddItemsDetailsBox.Controls.Add(this.label4);
            this.AddItemsDetailsBox.Controls.Add(this.passwordbox);
            this.AddItemsDetailsBox.Controls.Add(this.namebox);
            this.AddItemsDetailsBox.Controls.Add(this.Salary);
            this.AddItemsDetailsBox.Controls.Add(this.cnicbox);
            this.AddItemsDetailsBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AddItemsDetailsBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.AddItemsDetailsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddItemsDetailsBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AddItemsDetailsBox.Location = new System.Drawing.Point(0, 0);
            this.AddItemsDetailsBox.Name = "AddItemsDetailsBox";
            this.AddItemsDetailsBox.ShadowDecoration.Parent = this.AddItemsDetailsBox;
            this.AddItemsDetailsBox.Size = new System.Drawing.Size(1057, 554);
            this.AddItemsDetailsBox.TabIndex = 0;
            // 
            // sAnswer
            // 
            this.sAnswer.BorderRadius = 10;
            this.sAnswer.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sAnswer.DefaultText = "";
            this.sAnswer.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.sAnswer.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.sAnswer.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.sAnswer.DisabledState.Parent = this.sAnswer;
            this.sAnswer.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.sAnswer.FillColor = System.Drawing.Color.WhiteSmoke;
            this.sAnswer.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.sAnswer.FocusedState.Parent = this.sAnswer;
            this.sAnswer.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.sAnswer.HoverState.Parent = this.sAnswer;
            this.sAnswer.Location = new System.Drawing.Point(15, 431);
            this.sAnswer.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.sAnswer.Name = "sAnswer";
            this.sAnswer.PasswordChar = '\0';
            this.sAnswer.PlaceholderText = "";
            this.sAnswer.SelectedText = "";
            this.sAnswer.ShadowDecoration.Parent = this.sAnswer;
            this.sAnswer.Size = new System.Drawing.Size(1028, 48);
            this.sAnswer.TabIndex = 10;
            this.sAnswer.Tag = "info";
            this.sAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Indigo;
            this.label10.Location = new System.Drawing.Point(11, 405);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 19);
            this.label10.TabIndex = 22;
            this.label10.Text = "Answer";
            // 
            // sQuestions
            // 
            this.sQuestions.BackColor = System.Drawing.Color.Transparent;
            this.sQuestions.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.sQuestions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sQuestions.FillColor = System.Drawing.Color.WhiteSmoke;
            this.sQuestions.FocusedColor = System.Drawing.Color.Empty;
            this.sQuestions.FocusedState.Parent = this.sQuestions;
            this.sQuestions.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.sQuestions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.sQuestions.FormattingEnabled = true;
            this.sQuestions.HoverState.Parent = this.sQuestions;
            this.sQuestions.ItemHeight = 30;
            this.sQuestions.Items.AddRange(new object[] {
            "Admin",
            "ShopUser"});
            this.sQuestions.ItemsAppearance.Parent = this.sQuestions;
            this.sQuestions.Location = new System.Drawing.Point(15, 360);
            this.sQuestions.Name = "sQuestions";
            this.sQuestions.ShadowDecoration.Parent = this.sQuestions;
            this.sQuestions.Size = new System.Drawing.Size(1028, 36);
            this.sQuestions.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Indigo;
            this.label11.Location = new System.Drawing.Point(11, 338);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(130, 19);
            this.label11.TabIndex = 21;
            this.label11.Text = "Select Account Type";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(11, 338);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 19);
            this.label7.TabIndex = 21;
            this.label7.Text = "Select Account Type";
            // 
            // accounttypebox
            // 
            this.accounttypebox.BackColor = System.Drawing.Color.Transparent;
            this.accounttypebox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.accounttypebox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.accounttypebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.accounttypebox.FocusedColor = System.Drawing.Color.Empty;
            this.accounttypebox.FocusedState.Parent = this.accounttypebox;
            this.accounttypebox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.accounttypebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.accounttypebox.FormattingEnabled = true;
            this.accounttypebox.HoverState.Parent = this.accounttypebox;
            this.accounttypebox.ItemHeight = 30;
            this.accounttypebox.Items.AddRange(new object[] {
            "Admin",
            "ShopUser"});
            this.accounttypebox.ItemsAppearance.Parent = this.accounttypebox;
            this.accounttypebox.Location = new System.Drawing.Point(15, 86);
            this.accounttypebox.Name = "accounttypebox";
            this.accounttypebox.ShadowDecoration.Parent = this.accounttypebox;
            this.accounttypebox.Size = new System.Drawing.Size(221, 36);
            this.accounttypebox.TabIndex = 0;
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(1004, 3);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // cpasswordbox
            // 
            this.cpasswordbox.BorderRadius = 10;
            this.cpasswordbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cpasswordbox.DefaultText = "";
            this.cpasswordbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cpasswordbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cpasswordbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cpasswordbox.DisabledState.Parent = this.cpasswordbox;
            this.cpasswordbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cpasswordbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.cpasswordbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cpasswordbox.FocusedState.Parent = this.cpasswordbox;
            this.cpasswordbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cpasswordbox.HoverState.Parent = this.cpasswordbox;
            this.cpasswordbox.Location = new System.Drawing.Point(593, 274);
            this.cpasswordbox.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.cpasswordbox.Name = "cpasswordbox";
            this.cpasswordbox.PasswordChar = '\0';
            this.cpasswordbox.PlaceholderText = "";
            this.cpasswordbox.SelectedText = "";
            this.cpasswordbox.ShadowDecoration.Parent = this.cpasswordbox;
            this.cpasswordbox.Size = new System.Drawing.Size(270, 36);
            this.cpasswordbox.TabIndex = 8;
            this.cpasswordbox.Tag = "info";
            this.cpasswordbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // mobilebox
            // 
            this.mobilebox.BorderRadius = 10;
            this.mobilebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mobilebox.DefaultText = "";
            this.mobilebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mobilebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mobilebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mobilebox.DisabledState.Parent = this.mobilebox;
            this.mobilebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mobilebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.mobilebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mobilebox.FocusedState.Parent = this.mobilebox;
            this.mobilebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mobilebox.HoverState.Parent = this.mobilebox;
            this.mobilebox.Location = new System.Drawing.Point(15, 183);
            this.mobilebox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.mobilebox.Name = "mobilebox";
            this.mobilebox.PasswordChar = '\0';
            this.mobilebox.PlaceholderText = "";
            this.mobilebox.SelectedText = "";
            this.mobilebox.ShadowDecoration.Parent = this.mobilebox;
            this.mobilebox.Size = new System.Drawing.Size(270, 36);
            this.mobilebox.TabIndex = 3;
            this.mobilebox.Tag = "info";
            this.mobilebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mobilebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cnicbox_KeyPress);
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton2.BorderRadius = 10;
            this.guna2GradientButton2.BorderThickness = 2;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(763, 489);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(137, 50);
            this.guna2GradientButton2.TabIndex = 6;
            this.guna2GradientButton2.Text = "Clear";
            // 
            // uploadpic
            // 
            this.uploadpic.BackColor = System.Drawing.Color.Transparent;
            this.uploadpic.BorderColor = System.Drawing.Color.White;
            this.uploadpic.BorderRadius = 10;
            this.uploadpic.BorderThickness = 2;
            this.uploadpic.CheckedState.Parent = this.uploadpic;
            this.uploadpic.CustomImages.Parent = this.uploadpic;
            this.uploadpic.FillColor = System.Drawing.Color.Indigo;
            this.uploadpic.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.uploadpic.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.uploadpic.ForeColor = System.Drawing.Color.White;
            this.uploadpic.HoverState.Parent = this.uploadpic;
            this.uploadpic.Location = new System.Drawing.Point(906, 274);
            this.uploadpic.Name = "uploadpic";
            this.uploadpic.ShadowDecoration.Parent = this.uploadpic;
            this.uploadpic.Size = new System.Drawing.Size(116, 36);
            this.uploadpic.TabIndex = 11;
            this.uploadpic.Text = "Upload";
            this.uploadpic.Click += new System.EventHandler(this.uploadpic_Click);
            // 
            // addressbox
            // 
            this.addressbox.BorderRadius = 10;
            this.addressbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.addressbox.DefaultText = "";
            this.addressbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.addressbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.addressbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.addressbox.DisabledState.Parent = this.addressbox;
            this.addressbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.addressbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.addressbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.addressbox.FocusedState.Parent = this.addressbox;
            this.addressbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.addressbox.HoverState.Parent = this.addressbox;
            this.addressbox.Location = new System.Drawing.Point(593, 183);
            this.addressbox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.addressbox.Name = "addressbox";
            this.addressbox.PasswordChar = '\0';
            this.addressbox.PlaceholderText = "";
            this.addressbox.SelectedText = "";
            this.addressbox.ShadowDecoration.Parent = this.addressbox;
            this.addressbox.Size = new System.Drawing.Size(270, 36);
            this.addressbox.TabIndex = 5;
            this.addressbox.Tag = "info";
            this.addressbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // emailbox
            // 
            this.emailbox.BorderRadius = 10;
            this.emailbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailbox.DefaultText = "";
            this.emailbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.emailbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.emailbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailbox.DisabledState.Parent = this.emailbox;
            this.emailbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.emailbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailbox.FocusedState.Parent = this.emailbox;
            this.emailbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailbox.HoverState.Parent = this.emailbox;
            this.emailbox.Location = new System.Drawing.Point(304, 183);
            this.emailbox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.emailbox.Name = "emailbox";
            this.emailbox.PasswordChar = '\0';
            this.emailbox.PlaceholderText = "";
            this.emailbox.SelectedText = "";
            this.emailbox.ShadowDecoration.Parent = this.emailbox;
            this.emailbox.Size = new System.Drawing.Size(270, 36);
            this.emailbox.TabIndex = 4;
            this.emailbox.Tag = "info";
            this.emailbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Additem
            // 
            this.Additem.BackColor = System.Drawing.Color.Transparent;
            this.Additem.BorderColor = System.Drawing.Color.White;
            this.Additem.BorderRadius = 10;
            this.Additem.BorderThickness = 2;
            this.Additem.CheckedState.Parent = this.Additem;
            this.Additem.CustomImages.Parent = this.Additem;
            this.Additem.FillColor = System.Drawing.Color.Indigo;
            this.Additem.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Additem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Additem.ForeColor = System.Drawing.Color.White;
            this.Additem.HoverState.Parent = this.Additem;
            this.Additem.Location = new System.Drawing.Point(906, 489);
            this.Additem.Name = "Additem";
            this.Additem.ShadowDecoration.Parent = this.Additem;
            this.Additem.Size = new System.Drawing.Size(137, 50);
            this.Additem.TabIndex = 12;
            this.Additem.Text = "ADD";
            this.Additem.Click += new System.EventHandler(this.Additem_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Indigo;
            this.label13.Location = new System.Drawing.Point(589, 250);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 19);
            this.label13.TabIndex = 1;
            this.label13.Text = "Confirm Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(11, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 19);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mobile";
            // 
            // profile
            // 
            this.profile.BorderRadius = 10;
            this.profile.FillColor = System.Drawing.Color.WhiteSmoke;
            this.profile.Location = new System.Drawing.Point(881, 73);
            this.profile.Name = "profile";
            this.profile.ShadowDecoration.Parent = this.profile;
            this.profile.Size = new System.Drawing.Size(162, 195);
            this.profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profile.TabIndex = 4;
            this.profile.TabStop = false;
            // 
            // warning9
            // 
            this.warning9.AutoSize = true;
            this.warning9.ForeColor = System.Drawing.Color.Red;
            this.warning9.Location = new System.Drawing.Point(703, 250);
            this.warning9.Name = "warning9";
            this.warning9.Size = new System.Drawing.Size(160, 19);
            this.warning9.TabIndex = 1;
            this.warning9.Text = "* Password not Matched";
            // 
            // warning8
            // 
            this.warning8.AutoSize = true;
            this.warning8.ForeColor = System.Drawing.Color.Red;
            this.warning8.Location = new System.Drawing.Point(22, 520);
            this.warning8.Name = "warning8";
            this.warning8.Size = new System.Drawing.Size(156, 19);
            this.warning8.TabIndex = 1;
            this.warning8.Text = "* Account Already Exists";
            // 
            // warning7
            // 
            this.warning7.AutoSize = true;
            this.warning7.ForeColor = System.Drawing.Color.Red;
            this.warning7.Location = new System.Drawing.Point(717, 159);
            this.warning7.Name = "warning7";
            this.warning7.Size = new System.Drawing.Size(146, 19);
            this.warning7.TabIndex = 1;
            this.warning7.Text = "* Please Enter Address";
            // 
            // warning4
            // 
            this.warning4.AutoSize = true;
            this.warning4.ForeColor = System.Drawing.Color.Red;
            this.warning4.Location = new System.Drawing.Point(131, 159);
            this.warning4.Name = "warning4";
            this.warning4.Size = new System.Drawing.Size(139, 19);
            this.warning4.TabIndex = 1;
            this.warning4.Text = "* Please Enter Mobile";
            // 
            // warning3
            // 
            this.warning3.AutoSize = true;
            this.warning3.ForeColor = System.Drawing.Color.Red;
            this.warning3.Location = new System.Drawing.Point(518, 61);
            this.warning3.Name = "warning3";
            this.warning3.Size = new System.Drawing.Size(129, 19);
            this.warning3.TabIndex = 1;
            this.warning3.Text = "* Please Enter CNIC";
            // 
            // warning6
            // 
            this.warning6.AutoSize = true;
            this.warning6.ForeColor = System.Drawing.Color.Red;
            this.warning6.Location = new System.Drawing.Point(461, 249);
            this.warning6.Name = "warning6";
            this.warning6.Size = new System.Drawing.Size(113, 19);
            this.warning6.TabIndex = 1;
            this.warning6.Text = "* Enter Password";
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.ForeColor = System.Drawing.Color.Red;
            this.warning5.Location = new System.Drawing.Point(151, 249);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(119, 19);
            this.warning5.TabIndex = 1;
            this.warning5.Text = "* Enter UserName";
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(308, 61);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(133, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Please Enter Name";
            // 
            // warning1
            // 
            this.warning1.AutoSize = true;
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(56, 125);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(180, 19);
            this.warning1.TabIndex = 1;
            this.warning1.Text = "* Please select Account type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Indigo;
            this.label9.Location = new System.Drawing.Point(11, 250);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 19);
            this.label9.TabIndex = 1;
            this.label9.Text = "UserName";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(11, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Account Type";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(300, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(245, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(458, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "CNIC";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(601, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 19);
            this.label6.TabIndex = 1;
            this.label6.Text = "Address";
            // 
            // usernamebox
            // 
            this.usernamebox.BorderRadius = 10;
            this.usernamebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.usernamebox.DefaultText = "";
            this.usernamebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.usernamebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.usernamebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.usernamebox.DisabledState.Parent = this.usernamebox;
            this.usernamebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.usernamebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.usernamebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.usernamebox.FocusedState.Parent = this.usernamebox;
            this.usernamebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.usernamebox.HoverState.Parent = this.usernamebox;
            this.usernamebox.Location = new System.Drawing.Point(15, 274);
            this.usernamebox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.usernamebox.Name = "usernamebox";
            this.usernamebox.PasswordChar = '\0';
            this.usernamebox.PlaceholderText = "";
            this.usernamebox.SelectedText = "";
            this.usernamebox.ShadowDecoration.Parent = this.usernamebox;
            this.usernamebox.Size = new System.Drawing.Size(270, 36);
            this.usernamebox.TabIndex = 6;
            this.usernamebox.Tag = "info";
            this.usernamebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(300, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Email Address";
            // 
            // passwordbox
            // 
            this.passwordbox.BorderRadius = 10;
            this.passwordbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.passwordbox.DefaultText = "";
            this.passwordbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.passwordbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.passwordbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.passwordbox.DisabledState.Parent = this.passwordbox;
            this.passwordbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.passwordbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.passwordbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.passwordbox.FocusedState.Parent = this.passwordbox;
            this.passwordbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.passwordbox.HoverState.Parent = this.passwordbox;
            this.passwordbox.Location = new System.Drawing.Point(304, 274);
            this.passwordbox.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.passwordbox.Name = "passwordbox";
            this.passwordbox.PasswordChar = '\0';
            this.passwordbox.PlaceholderText = "";
            this.passwordbox.SelectedText = "";
            this.passwordbox.ShadowDecoration.Parent = this.passwordbox;
            this.passwordbox.Size = new System.Drawing.Size(270, 36);
            this.passwordbox.TabIndex = 7;
            this.passwordbox.Tag = "info";
            this.passwordbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // namebox
            // 
            this.namebox.BorderRadius = 10;
            this.namebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namebox.DefaultText = "";
            this.namebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.namebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.namebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.DisabledState.Parent = this.namebox;
            this.namebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.namebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.FocusedState.Parent = this.namebox;
            this.namebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.HoverState.Parent = this.namebox;
            this.namebox.Location = new System.Drawing.Point(249, 86);
            this.namebox.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.namebox.Name = "namebox";
            this.namebox.PasswordChar = '\0';
            this.namebox.PlaceholderText = "";
            this.namebox.SelectedText = "";
            this.namebox.ShadowDecoration.Parent = this.namebox;
            this.namebox.Size = new System.Drawing.Size(192, 36);
            this.namebox.TabIndex = 1;
            this.namebox.Tag = "info";
            this.namebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cnicbox
            // 
            this.cnicbox.BorderRadius = 10;
            this.cnicbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cnicbox.DefaultText = "";
            this.cnicbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cnicbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cnicbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cnicbox.DisabledState.Parent = this.cnicbox;
            this.cnicbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cnicbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.cnicbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cnicbox.FocusedState.Parent = this.cnicbox;
            this.cnicbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cnicbox.HoverState.Parent = this.cnicbox;
            this.cnicbox.Location = new System.Drawing.Point(454, 86);
            this.cnicbox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cnicbox.Name = "cnicbox";
            this.cnicbox.PasswordChar = '\0';
            this.cnicbox.PlaceholderText = "";
            this.cnicbox.SelectedText = "";
            this.cnicbox.ShadowDecoration.Parent = this.cnicbox;
            this.cnicbox.Size = new System.Drawing.Size(197, 36);
            this.cnicbox.TabIndex = 2;
            this.cnicbox.Tag = "info";
            this.cnicbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cnicbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cnicbox_KeyPress);
            // 
            // Salary
            // 
            this.Salary.BorderRadius = 10;
            this.Salary.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Salary.DefaultText = "";
            this.Salary.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Salary.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Salary.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Salary.DisabledState.Parent = this.Salary;
            this.Salary.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Salary.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Salary.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Salary.FocusedState.Parent = this.Salary;
            this.Salary.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Salary.HoverState.Parent = this.Salary;
            this.Salary.Location = new System.Drawing.Point(664, 86);
            this.Salary.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.Salary.Name = "Salary";
            this.Salary.PasswordChar = '\0';
            this.Salary.PlaceholderText = "0.00";
            this.Salary.SelectedText = "";
            this.Salary.ShadowDecoration.Parent = this.Salary;
            this.Salary.Size = new System.Drawing.Size(197, 36);
            this.Salary.TabIndex = 2;
            this.Salary.Tag = "info";
            this.Salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Salary.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cnicbox_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Indigo;
            this.label12.Location = new System.Drawing.Point(664, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 19);
            this.label12.TabIndex = 1;
            this.label12.Text = "Salary";
            // 
            // AddEmployeeAccounts_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "AddEmployeeAccounts_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.AddEmployeeAccounts_uc_Load);
            this.contentpanel.ResumeLayout(false);
            this.AddItemsDetailsBox.ResumeLayout(false);
            this.AddItemsDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2GroupBox AddItemsDetailsBox;
        private Guna.UI2.WinForms.Guna2ComboBox accounttypebox;
        private Guna.UI2.WinForms.Guna2TextBox mobilebox;
        private Guna.UI2.WinForms.Guna2TextBox addressbox;
        private Guna.UI2.WinForms.Guna2TextBox emailbox;
        private Guna.UI2.WinForms.Guna2GradientButton Additem;
        private Guna.UI2.WinForms.Guna2GradientButton uploadpic;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2PictureBox profile;
        private System.Windows.Forms.Label warning8;
        private System.Windows.Forms.Label warning7;
        private System.Windows.Forms.Label warning4;
        private System.Windows.Forms.Label warning3;
        private System.Windows.Forms.Label warning2;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox namebox;
        private Guna.UI2.WinForms.Guna2TextBox cnicbox;
        private Guna.UI2.WinForms.Guna2TextBox cpasswordbox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox usernamebox;
        private Guna.UI2.WinForms.Guna2TextBox passwordbox;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private System.Windows.Forms.Label warning6;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label warning9;
        private Guna.UI2.WinForms.Guna2ComboBox sQuestions;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox sAnswer;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2TextBox Salary;
    }
}
