﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.Settings.Employee.Reporting
{
    class EmployeeAccountsDataClass
    {
        public string EMP_Name { set; get; }
        public string EMP_CNIC { set; get; }
        public string EMP_Mobile { set; get; }
        public string EMP_EmailAddress { set; get; }
        public string EMP_Address { set; get; }
        public byte[] EMP_Picture { set; get; }
        public string EMP_Role { set; get; }
        public string EMP_Username { set; get; }
        public string EMP_Password { set; get; }

    }
}
