﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.Settings.Employee.Reporting
{
    public partial class GenerateEmployeeAccountsReportForm : Form
    {
        int AccountType;
        public GenerateEmployeeAccountsReportForm(int account)
        {
            InitializeComponent();
            AccountType = account;
        }

        //cross button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                WindowState = FormWindowState.Normal;
            else
                WindowState = FormWindowState.Maximized;
        }

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;

        }

        private void GenerateEmployeeAccountsReportForm_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();

            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                SqlCommand cmd = new SqlCommand("GenerateEmployeeReport", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@type", AccountType ));
                dt.Load(cmd.ExecuteReader());

                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error whlie generating Employees Report " + ex.ToString(), "Error");
                throw;
            }

            EmployeeAccountsReportPage earp = new EmployeeAccountsReportPage();
            earp.DataSource = dt;

            InstanceReportSource irs = new InstanceReportSource() { ReportDocument = earp };

            reportViewer1.ReportSource = irs;
            reportViewer1.RefreshReport();

        }
    }
}
