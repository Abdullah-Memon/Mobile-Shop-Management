﻿namespace Mobile_Shop.Settings.Employee
{
    partial class EmployeeAccountsRecycleBin_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.RestoreAllbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.DeleteAllbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label14 = new System.Windows.Forms.Label();
            this.SelectedAccountType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.EmpoyeeGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.E_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Restore = new System.Windows.Forms.DataGridViewButtonColumn();
            this.E_Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.contentpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmpoyeeGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // contentpanel
            // 
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.EmpoyeeGridView);
            this.contentpanel.Controls.Add(this.RestoreAllbtn);
            this.contentpanel.Controls.Add(this.DeleteAllbtn);
            this.contentpanel.Controls.Add(this.Backbtn);
            this.contentpanel.Controls.Add(this.label14);
            this.contentpanel.Controls.Add(this.SelectedAccountType);
            this.contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 2;
            // 
            // RestoreAllbtn
            // 
            this.RestoreAllbtn.BackColor = System.Drawing.Color.Transparent;
            this.RestoreAllbtn.BorderColor = System.Drawing.Color.White;
            this.RestoreAllbtn.BorderRadius = 10;
            this.RestoreAllbtn.BorderThickness = 2;
            this.RestoreAllbtn.CheckedState.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.CustomImages.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.FillColor = System.Drawing.Color.Indigo;
            this.RestoreAllbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.RestoreAllbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RestoreAllbtn.ForeColor = System.Drawing.Color.White;
            this.RestoreAllbtn.HoverState.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.Location = new System.Drawing.Point(801, 12);
            this.RestoreAllbtn.Name = "RestoreAllbtn";
            this.RestoreAllbtn.ShadowDecoration.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.Size = new System.Drawing.Size(89, 36);
            this.RestoreAllbtn.TabIndex = 15;
            this.RestoreAllbtn.Text = "Restore All";
            this.RestoreAllbtn.Click += new System.EventHandler(this.RestoreAllbtn_Click);
            // 
            // DeleteAllbtn
            // 
            this.DeleteAllbtn.BackColor = System.Drawing.Color.Transparent;
            this.DeleteAllbtn.BorderColor = System.Drawing.Color.White;
            this.DeleteAllbtn.BorderRadius = 10;
            this.DeleteAllbtn.BorderThickness = 2;
            this.DeleteAllbtn.CheckedState.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.CustomImages.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.FillColor = System.Drawing.Color.Indigo;
            this.DeleteAllbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.DeleteAllbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DeleteAllbtn.ForeColor = System.Drawing.Color.White;
            this.DeleteAllbtn.HoverState.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.Location = new System.Drawing.Point(896, 12);
            this.DeleteAllbtn.Name = "DeleteAllbtn";
            this.DeleteAllbtn.ShadowDecoration.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.Size = new System.Drawing.Size(89, 36);
            this.DeleteAllbtn.TabIndex = 16;
            this.DeleteAllbtn.Text = "Delete All";
            this.DeleteAllbtn.Click += new System.EventHandler(this.DeleteAllbtn_Click);
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(991, 5);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 22;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(18, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 20);
            this.label14.TabIndex = 17;
            this.label14.Text = "Account type";
            // 
            // SelectedAccountType
            // 
            this.SelectedAccountType.BackColor = System.Drawing.Color.Transparent;
            this.SelectedAccountType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedAccountType.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedAccountType.FocusedState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedAccountType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedAccountType.FormattingEnabled = true;
            this.SelectedAccountType.HoverState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.ItemHeight = 30;
            this.SelectedAccountType.Items.AddRange(new object[] {
            "All Accounts",
            "Admin",
            "Shopuser"});
            this.SelectedAccountType.ItemsAppearance.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Location = new System.Drawing.Point(142, 12);
            this.SelectedAccountType.Name = "SelectedAccountType";
            this.SelectedAccountType.ShadowDecoration.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Size = new System.Drawing.Size(223, 36);
            this.SelectedAccountType.TabIndex = 15;
            this.SelectedAccountType.TextChanged += new System.EventHandler(this.SelectedAccountType_TextChanged);
            // 
            // EmpoyeeGridView
            // 
            this.EmpoyeeGridView.AllowUserToAddRows = false;
            this.EmpoyeeGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.EmpoyeeGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.EmpoyeeGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.EmpoyeeGridView.BackgroundColor = System.Drawing.Color.White;
            this.EmpoyeeGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EmpoyeeGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmpoyeeGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmpoyeeGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.EmpoyeeGridView.ColumnHeadersHeight = 21;
            this.EmpoyeeGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.E_Picture,
            this.E_Name,
            this.E_CNIC,
            this.E_Role,
            this.E_Mobile,
            this.E_Email,
            this.E_Address,
            this.E_Username,
            this.E_Password,
            this.E_Restore,
            this.E_Delete});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmpoyeeGridView.DefaultCellStyle = dataGridViewCellStyle8;
            this.EmpoyeeGridView.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.EmpoyeeGridView.EnableHeadersVisualStyles = false;
            this.EmpoyeeGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.EmpoyeeGridView.Location = new System.Drawing.Point(0, 61);
            this.EmpoyeeGridView.Name = "EmpoyeeGridView";
            this.EmpoyeeGridView.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmpoyeeGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.EmpoyeeGridView.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.EmpoyeeGridView.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.EmpoyeeGridView.RowTemplate.Height = 70;
            this.EmpoyeeGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EmpoyeeGridView.Size = new System.Drawing.Size(1060, 493);
            this.EmpoyeeGridView.TabIndex = 30;
            this.EmpoyeeGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.EmpoyeeGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.EmpoyeeGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.EmpoyeeGridView.ThemeStyle.ReadOnly = true;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.Height = 70;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.EmpoyeeGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EmpoyeeGridView_CellContentClick);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EMPID";
            this.EmployeeID.HeaderText = "ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.ReadOnly = true;
            this.EmployeeID.Visible = false;
            // 
            // E_Picture
            // 
            this.E_Picture.DataPropertyName = "EMP_Picture";
            this.E_Picture.HeaderText = "Picture";
            this.E_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.E_Picture.Name = "E_Picture";
            this.E_Picture.ReadOnly = true;
            // 
            // E_Name
            // 
            this.E_Name.DataPropertyName = "EMP_Name";
            this.E_Name.HeaderText = "Name";
            this.E_Name.Name = "E_Name";
            this.E_Name.ReadOnly = true;
            // 
            // E_CNIC
            // 
            this.E_CNIC.DataPropertyName = "EMP_CNIC";
            this.E_CNIC.HeaderText = "CNIC";
            this.E_CNIC.Name = "E_CNIC";
            this.E_CNIC.ReadOnly = true;
            // 
            // E_Role
            // 
            this.E_Role.DataPropertyName = "EMP_Role";
            this.E_Role.HeaderText = "Role";
            this.E_Role.Name = "E_Role";
            this.E_Role.ReadOnly = true;
            // 
            // E_Mobile
            // 
            this.E_Mobile.DataPropertyName = "EMP_Mobile";
            this.E_Mobile.HeaderText = "Mobile";
            this.E_Mobile.Name = "E_Mobile";
            this.E_Mobile.ReadOnly = true;
            // 
            // E_Email
            // 
            this.E_Email.DataPropertyName = "EMP_EmailAddress";
            this.E_Email.HeaderText = "Email";
            this.E_Email.Name = "E_Email";
            this.E_Email.ReadOnly = true;
            // 
            // E_Address
            // 
            this.E_Address.DataPropertyName = "EMP_Address";
            this.E_Address.HeaderText = "Address";
            this.E_Address.Name = "E_Address";
            this.E_Address.ReadOnly = true;
            // 
            // E_Username
            // 
            this.E_Username.DataPropertyName = "EMP_Username";
            this.E_Username.HeaderText = "Username";
            this.E_Username.Name = "E_Username";
            this.E_Username.ReadOnly = true;
            // 
            // E_Password
            // 
            this.E_Password.DataPropertyName = "EMP_Password";
            this.E_Password.HeaderText = "Password";
            this.E_Password.Name = "E_Password";
            this.E_Password.ReadOnly = true;
            // 
            // E_Restore
            // 
            this.E_Restore.FillWeight = 50F;
            this.E_Restore.HeaderText = "Restore";
            this.E_Restore.Name = "E_Restore";
            this.E_Restore.ReadOnly = true;
            this.E_Restore.Text = "Restore";
            this.E_Restore.UseColumnTextForButtonValue = true;
            // 
            // E_Delete
            // 
            this.E_Delete.FillWeight = 50F;
            this.E_Delete.HeaderText = "Delete";
            this.E_Delete.Name = "E_Delete";
            this.E_Delete.ReadOnly = true;
            this.E_Delete.Text = "Delete";
            this.E_Delete.UseColumnTextForButtonValue = true;
            // 
            // EmployeeAccountsRecycleBin_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "EmployeeAccountsRecycleBin_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.EmployeeAccountsRecycleBin_uc_Load);
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmpoyeeGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2GradientButton RestoreAllbtn;
        private Guna.UI2.WinForms.Guna2GradientButton DeleteAllbtn;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedAccountType;
        private Guna.UI2.WinForms.Guna2DataGridView EmpoyeeGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewImageColumn E_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Password;
        private System.Windows.Forms.DataGridViewButtonColumn E_Restore;
        private System.Windows.Forms.DataGridViewButtonColumn E_Delete;
    }
}
