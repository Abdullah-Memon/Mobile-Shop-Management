﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.Settings.Employee
{
    public partial class EmployeeDashboard_uc : UserControl
    {
        public EmployeeDashboard_uc()
        {
            InitializeComponent();
        }
        // add usercontrol function
        private void addUserControl(UserControl uc)
        {
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(uc);
        }

        // Loading View Accounts Screen
        private void showAccountsbtn_Click(object sender, EventArgs e)
        {
            ViewEmployeeAccounts_uc vea = new ViewEmployeeAccounts_uc();
            addUserControl(vea);
        }

        // Loading Add Accounts Screen
        private void AddAccountbtn_Click(object sender, EventArgs e)
        {
            AddEmployeeAccounts_uc aea = new AddEmployeeAccounts_uc();
            addUserControl(aea);
        }

        // loading Reporting Screen
        private void AccountsReportBtn_Click(object sender, EventArgs e)
        {
            Reporting.GenerateEmployeeAccountsReportForm gearf = new Reporting.GenerateEmployeeAccountsReportForm(SelectedAccounts.SelectedIndex);
            gearf.ShowDialog();
        }

        // back btn coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            Settings_uc s = new Settings_uc();
            addUserControl(s);
        }
    }
}
