﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Settings.Employee
{
    public partial class EmployeeAccountsRecycleBin_uc : UserControl
    {
        public EmployeeAccountsRecycleBin_uc()
        {
            InitializeComponent();
        }
        //global variables
        SqlCommand cmd;

        // back btn coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            ViewEmployeeAccounts_uc vea = new ViewEmployeeAccounts_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(vea);
        }

        // getting delete accounts data
        private void getdeletedAccounts()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                DataTable getdeleteddata = new DataTable();
                cmd = new SqlCommand("EmployeeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));

                getdeleteddata.Load(cmd.ExecuteReader());
                DB.con.Close();

                EmpoyeeGridView.DataSource = getdeleteddata;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting deleted data " + ex.ToString(), "Error");
            }
        }

        // main load function
        private void EmployeeAccountsRecycleBin_uc_Load(object sender, EventArgs e)
        {
            // getting data
            getdeletedAccounts();
        }

        //grid view buttons coding
        private void EmpoyeeGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //restore button coding
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@executeFrom", 1));
                    cmd.Parameters.Add(new SqlParameter("@id", EmpoyeeGridView.Rows[e.RowIndex].Cells["EmployeeID"].Value));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // refreshing gridview
                    getdeletedAccounts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while Restoring data " + ex.ToString(), "Error");
                }
            }
            
            //Delete button coding
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure? you want to delete account permanantly.","Confirmation",MessageBoxButtons.YesNo)==DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("RemoveEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", EmpoyeeGridView.Rows[e.RowIndex].Cells["EmployeeID"].Value));

                        cmd.ExecuteNonQuery();
                        DB.con.Close();

                        // refreshing gridview
                        getdeletedAccounts();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while deleting data " + ex.ToString(), "Error");
                    }
                }
            }
        }

        // select account type coding
        private void SelectedAccountType_TextChanged(object sender, EventArgs e)
        {
            if (SelectedAccountType.SelectedIndex > 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    DataTable foundEMPAccountsdata = new DataTable();

                    cmd = new SqlCommand("findEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@role", SelectedAccountType.SelectedIndex));
                    cmd.Parameters.Add(new SqlParameter("@status", 1));

                    foundEMPAccountsdata.Load(cmd.ExecuteReader());

                    DB.con.Close();

                    //setting up new data
                    EmpoyeeGridView.DataSource = foundEMPAccountsdata;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while founding accounts please try again " + ex.ToString(), "ERROR");
                }
            }
            else
            { getdeletedAccounts(); }
        }

        //restore all button coding
        private void RestoreAllbtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to restore all the employee Accounts","Confirmation",MessageBoxButtons.YesNo)== DialogResult.Yes)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                for (int i = 0; i < EmpoyeeGridView.Rows.Count; i++)
                {
                    cmd = new SqlCommand("UpdateEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@executeFrom", 1));
                    cmd.Parameters.Add(new SqlParameter("@id", EmpoyeeGridView.Rows[i].Cells["EmployeeID"].Value));
                    cmd.ExecuteNonQuery();
                    
                }
                DB.con.Close();

                // refreshing gridview
                getdeletedAccounts();
            }
        }

        //delete all button coding
        private void DeleteAllbtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete all the employee Accounts", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                for (int i = 0; i < EmpoyeeGridView.Rows.Count; i++)
                {
                    cmd = new SqlCommand("RemoveEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", EmpoyeeGridView.Rows[i].Cells["EmployeeID"].Value));

                    cmd.ExecuteNonQuery();

                }
                DB.con.Close();

                // refreshing gridview
                getdeletedAccounts();
            }
        }
    }
}
