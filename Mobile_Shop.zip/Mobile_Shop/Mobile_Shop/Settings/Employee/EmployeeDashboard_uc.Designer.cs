﻿namespace Mobile_Shop.Settings.Employee
{
    partial class EmployeeDashboard_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SelectedAccounts = new Guna.UI2.WinForms.Guna2ComboBox();
            this.AccountsReportBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.AddAccountbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.showAccountsbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.ContentPanel.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Controls.Add(this.guna2GroupBox3);
            this.ContentPanel.Controls.Add(this.guna2GroupBox2);
            this.ContentPanel.Controls.Add(this.guna2GroupBox1);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 1;
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.BorderRadius = 20;
            this.guna2GroupBox3.Controls.Add(this.label4);
            this.guna2GroupBox3.Controls.Add(this.SelectedAccounts);
            this.guna2GroupBox3.Controls.Add(this.AccountsReportBtn);
            this.guna2GroupBox3.Controls.Add(this.guna2PictureBox3);
            this.guna2GroupBox3.Controls.Add(this.label3);
            this.guna2GroupBox3.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(708, 59);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(347, 490);
            this.guna2GroupBox3.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 339);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 19);
            this.label4.TabIndex = 16;
            this.label4.Text = "Select Empoyee Account Type";
            // 
            // SelectedAccounts
            // 
            this.SelectedAccounts.BackColor = System.Drawing.Color.Transparent;
            this.SelectedAccounts.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedAccounts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedAccounts.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedAccounts.FocusedState.Parent = this.SelectedAccounts;
            this.SelectedAccounts.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedAccounts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedAccounts.FormattingEnabled = true;
            this.SelectedAccounts.HoverState.Parent = this.SelectedAccounts;
            this.SelectedAccounts.ItemHeight = 30;
            this.SelectedAccounts.Items.AddRange(new object[] {
            "All",
            "Admin",
            "Shopuser"});
            this.SelectedAccounts.ItemsAppearance.Parent = this.SelectedAccounts;
            this.SelectedAccounts.Location = new System.Drawing.Point(59, 361);
            this.SelectedAccounts.Name = "SelectedAccounts";
            this.SelectedAccounts.ShadowDecoration.Parent = this.SelectedAccounts;
            this.SelectedAccounts.Size = new System.Drawing.Size(232, 36);
            this.SelectedAccounts.TabIndex = 15;
            // 
            // AccountsReportBtn
            // 
            this.AccountsReportBtn.BackColor = System.Drawing.Color.Transparent;
            this.AccountsReportBtn.BorderColor = System.Drawing.Color.White;
            this.AccountsReportBtn.BorderRadius = 10;
            this.AccountsReportBtn.BorderThickness = 2;
            this.AccountsReportBtn.CheckedState.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.CustomImages.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.FillColor = System.Drawing.Color.Indigo;
            this.AccountsReportBtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AccountsReportBtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AccountsReportBtn.ForeColor = System.Drawing.Color.White;
            this.AccountsReportBtn.HoverState.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.Location = new System.Drawing.Point(99, 403);
            this.AccountsReportBtn.Name = "AccountsReportBtn";
            this.AccountsReportBtn.ShadowDecoration.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.Size = new System.Drawing.Size(150, 45);
            this.AccountsReportBtn.TabIndex = 14;
            this.AccountsReportBtn.Text = "Accounts Report";
            this.AccountsReportBtn.Click += new System.EventHandler(this.AccountsReportBtn_Click);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox3.Location = new System.Drawing.Point(24, 108);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(300, 200);
            this.guna2PictureBox3.TabIndex = 1;
            this.guna2PictureBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(61, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(226, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Employee Accounts Report";
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.BorderRadius = 20;
            this.guna2GroupBox2.Controls.Add(this.AddAccountbtn);
            this.guna2GroupBox2.Controls.Add(this.guna2PictureBox2);
            this.guna2GroupBox2.Controls.Add(this.label2);
            this.guna2GroupBox2.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(357, 59);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(347, 490);
            this.guna2GroupBox2.TabIndex = 28;
            // 
            // AddAccountbtn
            // 
            this.AddAccountbtn.BackColor = System.Drawing.Color.Transparent;
            this.AddAccountbtn.BorderColor = System.Drawing.Color.White;
            this.AddAccountbtn.BorderRadius = 10;
            this.AddAccountbtn.BorderThickness = 2;
            this.AddAccountbtn.CheckedState.Parent = this.AddAccountbtn;
            this.AddAccountbtn.CustomImages.Parent = this.AddAccountbtn;
            this.AddAccountbtn.FillColor = System.Drawing.Color.Indigo;
            this.AddAccountbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AddAccountbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddAccountbtn.ForeColor = System.Drawing.Color.White;
            this.AddAccountbtn.HoverState.Parent = this.AddAccountbtn;
            this.AddAccountbtn.Location = new System.Drawing.Point(97, 403);
            this.AddAccountbtn.Name = "AddAccountbtn";
            this.AddAccountbtn.ShadowDecoration.Parent = this.AddAccountbtn;
            this.AddAccountbtn.Size = new System.Drawing.Size(150, 45);
            this.AddAccountbtn.TabIndex = 14;
            this.AddAccountbtn.Text = "Add Accounts";
            this.AddAccountbtn.Click += new System.EventHandler(this.AddAccountbtn_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox2.Location = new System.Drawing.Point(22, 108);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(300, 200);
            this.guna2PictureBox2.TabIndex = 1;
            this.guna2PictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(69, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Add Employee Accounts";
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.BorderRadius = 20;
            this.guna2GroupBox1.Controls.Add(this.showAccountsbtn);
            this.guna2GroupBox1.Controls.Add(this.guna2PictureBox1);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(6, 59);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(347, 490);
            this.guna2GroupBox1.TabIndex = 27;
            // 
            // showAccountsbtn
            // 
            this.showAccountsbtn.BackColor = System.Drawing.Color.Transparent;
            this.showAccountsbtn.BorderColor = System.Drawing.Color.White;
            this.showAccountsbtn.BorderRadius = 10;
            this.showAccountsbtn.BorderThickness = 2;
            this.showAccountsbtn.CheckedState.Parent = this.showAccountsbtn;
            this.showAccountsbtn.CustomImages.Parent = this.showAccountsbtn;
            this.showAccountsbtn.FillColor = System.Drawing.Color.Indigo;
            this.showAccountsbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.showAccountsbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showAccountsbtn.ForeColor = System.Drawing.Color.White;
            this.showAccountsbtn.HoverState.Parent = this.showAccountsbtn;
            this.showAccountsbtn.Location = new System.Drawing.Point(99, 403);
            this.showAccountsbtn.Name = "showAccountsbtn";
            this.showAccountsbtn.ShadowDecoration.Parent = this.showAccountsbtn;
            this.showAccountsbtn.Size = new System.Drawing.Size(150, 45);
            this.showAccountsbtn.TabIndex = 14;
            this.showAccountsbtn.Text = "Show Accounts";
            this.showAccountsbtn.Click += new System.EventHandler(this.showAccountsbtn_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox1.Location = new System.Drawing.Point(24, 108);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(300, 200);
            this.guna2PictureBox1.TabIndex = 1;
            this.guna2PictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(66, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Show Employee Accounts";
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1007, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(50, 50);
            this.backbtn.TabIndex = 26;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // EmployeeDashboard_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ContentPanel);
            this.Name = "EmployeeDashboard_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.ResumeLayout(false);
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedAccounts;
        private Guna.UI2.WinForms.Guna2GradientButton AccountsReportBtn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2GradientButton AddAccountbtn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2GradientButton showAccountsbtn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label1;
    }
}
