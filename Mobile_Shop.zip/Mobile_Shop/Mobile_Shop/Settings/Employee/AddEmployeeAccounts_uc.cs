﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Settings.Employee
{
    public partial class AddEmployeeAccounts_uc : UserControl
    {
        public AddEmployeeAccounts_uc()
        {
            InitializeComponent();
        }
        // global variables
        SqlCommand cmd;
        

        // back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            EmployeeDashboard_uc ed = new EmployeeDashboard_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(ed);
        }

        // getting security question
        private void getQuestions()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                DataTable getquestionsdata = new DataTable();
                cmd = new SqlCommand("SecurityQuestionsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                getquestionsdata.Load(cmd.ExecuteReader());

                sQuestions.DataSource = getquestionsdata;
                sQuestions.DisplayMember = "SQ";
                sQuestions.ValueMember = "SQID";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting questions " + ex.ToString(), "Error");
            }
        }

        private void AddEmployeeAccounts_uc_Load(object sender, EventArgs e)
        {
            // retriving all security questions
            getQuestions();

            // hiding all warinings
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
            warning6.Hide();
            warning7.Hide();
            warning8.Hide();
            warning9.Hide();
        }

        // Upload picture button coding
        private void uploadpic_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.Filter = "Image file (*.jpg; *.jpeg; *.png; *.bmp; *.gif;) | *.jpg; *.jpeg; *.png; *.bmp; *.gif;";
                opf.Multiselect = false;

                if (opf.ShowDialog() == DialogResult.OK)
                {
                    profile.Image = Image.FromFile(opf.FileName);
                }

            }
        }

        // Add account button coding
        private void Additem_Click(object sender, EventArgs e)
        {
            //resting warinings 
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
            warning6.Hide();
            warning7.Hide();
            warning8.Hide();
            warning9.Hide();


            // checing provided information
            if (string.IsNullOrEmpty(accounttypebox.Text) || string.IsNullOrWhiteSpace(accounttypebox.Text) || string.IsNullOrEmpty(namebox.Text) || string.IsNullOrEmpty(cnicbox.Text) || string.IsNullOrEmpty(mobilebox.Text) || string.IsNullOrEmpty(addressbox.Text) || string.IsNullOrEmpty(usernamebox.Text) || string.IsNullOrEmpty(passwordbox.Text) || string.IsNullOrEmpty(cpasswordbox.Text) || profile.Image == null)
            {
                if (accounttypebox.Text == string.Empty)
                {
                    accounttypebox.Focus();
                    warning1.Show();
                }
                else if (namebox.Text == string.Empty)
                {
                    namebox.Focus();
                    warning2.Show();
                }
                else if (cnicbox.Text == string.Empty)
                {
                    cnicbox.Focus();
                    warning3.Show();
                }
                else if (mobilebox.Text == string.Empty)
                {
                    mobilebox.Focus();
                    warning4.Show();
                }

                else if (addressbox.Text == string.Empty)
                {
                    addressbox.Focus();
                    warning7.Show();
                }
                else if (usernamebox.Text == string.Empty)
                {
                    usernamebox.Focus();
                    warning5.Show();

                }
                else if (passwordbox.Text == string.Empty)
                {
                    passwordbox.Focus();
                    warning6.Show();
                }
                else if (cpasswordbox.Text == string.Empty)
                {
                    cpasswordbox.Focus();
                    warning9.Show();
                }
                else
                {
                    MessageBox.Show("Please enter Profile picture or restart the application", "Error");
                }
                
            }
            // Adding information to database
            else
            {
                if (passwordbox.Text == cpasswordbox.Text)
                {
                    // adding new data
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        ImageConverter img = new ImageConverter();
                        byte[] pic = (byte[])img.ConvertTo(profile.Image, Type.GetType("System.Byte[]"));

                        cmd = new SqlCommand("AddEmployee", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@picture", pic));
                        cmd.Parameters.Add(new SqlParameter("@name", namebox.Text));
                        cmd.Parameters.Add(new SqlParameter("@role", accounttypebox.SelectedIndex));
                        cmd.Parameters.Add(new SqlParameter("@CNIC", cnicbox.Text));
                        cmd.Parameters.Add(new SqlParameter("@Mobile", mobilebox.Text));
                        cmd.Parameters.Add(new SqlParameter("@email", emailbox.Text));
                        cmd.Parameters.Add(new SqlParameter("@address", addressbox.Text));
                        cmd.Parameters.Add(new SqlParameter("@username", usernamebox.Text));
                        cmd.Parameters.Add(new SqlParameter("@password", cpasswordbox.Text));
                        cmd.Parameters.Add(new SqlParameter("@sqid", sQuestions.SelectedValue));
                        cmd.Parameters.Add(new SqlParameter("@sqans", sAnswer.Text));

                        if (string.IsNullOrEmpty(Salary.Text) || string.IsNullOrWhiteSpace(Salary.Text))
                            Salary.Text = "0.00";
                        cmd.Parameters.Add(new SqlParameter("@salary", Convert.ToDecimal(Salary.Text)));

                        int chk = cmd.ExecuteNonQuery();
                        DB.con.Close();

                        if (chk == 0)
                        {
                            warning8.Show();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while Adding new Employee account Please try again " + ex.ToString(), "Error");
                    }

                    //clearing all information
                    namebox.Text = string.Empty;
                    cnicbox.Text = string.Empty;
                    mobilebox.Text = string.Empty;
                    usernamebox.Text = string.Empty;
                    passwordbox.Text = string.Empty;
                    cpasswordbox.Text = string.Empty;
                    emailbox.Text = string.Empty;
                    addressbox.Text = string.Empty;
                    profile.Image = null;
                    
                }
                else
                {
                    cpasswordbox.Focus();
                    warning9.Show();
                }
                

            }
        }

        private void cnicbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '-'))
                e.Handled = true;
        }
    }
}
