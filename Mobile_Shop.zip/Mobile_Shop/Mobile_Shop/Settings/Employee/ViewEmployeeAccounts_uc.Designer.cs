﻿namespace Mobile_Shop.Settings.Employee
{
    partial class ViewEmployeeAccounts_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.EmpoyeeGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.SelectedAccountType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.E_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.E_Update = new System.Windows.Forms.DataGridViewButtonColumn();
            this.E_Print = new System.Windows.Forms.DataGridViewButtonColumn();
            this.E_Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmpoyeeGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Controls.Add(this.EmpoyeeGridView);
            this.ContentPanel.Controls.Add(this.label14);
            this.ContentPanel.Controls.Add(this.SelectedAccountType);
            this.ContentPanel.Controls.Add(this.guna2CircleButton1);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 2;
            // 
            // EmpoyeeGridView
            // 
            this.EmpoyeeGridView.AllowUserToAddRows = false;
            this.EmpoyeeGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.EmpoyeeGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.EmpoyeeGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.EmpoyeeGridView.BackgroundColor = System.Drawing.Color.White;
            this.EmpoyeeGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EmpoyeeGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmpoyeeGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmpoyeeGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.EmpoyeeGridView.ColumnHeadersHeight = 21;
            this.EmpoyeeGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.E_Picture,
            this.E_Name,
            this.E_CNIC,
            this.E_Role,
            this.E_Mobile,
            this.E_Email,
            this.E_Address,
            this.E_Username,
            this.E_Password,
            this.E_Update,
            this.E_Print,
            this.E_Delete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmpoyeeGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.EmpoyeeGridView.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.EmpoyeeGridView.EnableHeadersVisualStyles = false;
            this.EmpoyeeGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.EmpoyeeGridView.Location = new System.Drawing.Point(0, 61);
            this.EmpoyeeGridView.Name = "EmpoyeeGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.EmpoyeeGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.EmpoyeeGridView.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.EmpoyeeGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.EmpoyeeGridView.RowTemplate.Height = 70;
            this.EmpoyeeGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EmpoyeeGridView.Size = new System.Drawing.Size(1060, 493);
            this.EmpoyeeGridView.TabIndex = 29;
            this.EmpoyeeGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.EmpoyeeGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.EmpoyeeGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.EmpoyeeGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.EmpoyeeGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.EmpoyeeGridView.ThemeStyle.ReadOnly = false;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.Height = 70;
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.EmpoyeeGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.EmpoyeeGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EmpoyeeGridView_CellContentClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(18, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 20);
            this.label14.TabIndex = 28;
            this.label14.Text = "Account type";
            // 
            // SelectedAccountType
            // 
            this.SelectedAccountType.BackColor = System.Drawing.Color.Transparent;
            this.SelectedAccountType.BorderRadius = 10;
            this.SelectedAccountType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedAccountType.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedAccountType.FocusedState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedAccountType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedAccountType.FormattingEnabled = true;
            this.SelectedAccountType.HoverState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.ItemHeight = 30;
            this.SelectedAccountType.Items.AddRange(new object[] {
            "All Accounts",
            "Admin",
            "ShopUser"});
            this.SelectedAccountType.ItemsAppearance.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Location = new System.Drawing.Point(142, 10);
            this.SelectedAccountType.Name = "SelectedAccountType";
            this.SelectedAccountType.ShadowDecoration.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Size = new System.Drawing.Size(256, 36);
            this.SelectedAccountType.TabIndex = 27;
            this.SelectedAccountType.TextChanged += new System.EventHandler(this.SelectedAccountType_TextChanged);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(951, 3);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton1.TabIndex = 26;
            this.guna2CircleButton1.Text = "♻️";
            this.guna2CircleButton1.UseTransparentBackground = true;
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1007, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(50, 50);
            this.backbtn.TabIndex = 26;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EMPID";
            this.EmployeeID.HeaderText = "ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.Visible = false;
            // 
            // E_Picture
            // 
            this.E_Picture.DataPropertyName = "EMP_Picture";
            this.E_Picture.HeaderText = "Picture";
            this.E_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.E_Picture.Name = "E_Picture";
            // 
            // E_Name
            // 
            this.E_Name.DataPropertyName = "EMP_Name";
            this.E_Name.HeaderText = "Name";
            this.E_Name.Name = "E_Name";
            // 
            // E_CNIC
            // 
            this.E_CNIC.DataPropertyName = "EMP_CNIC";
            this.E_CNIC.HeaderText = "CNIC";
            this.E_CNIC.Name = "E_CNIC";
            // 
            // E_Role
            // 
            this.E_Role.DataPropertyName = "EMP_Role";
            this.E_Role.HeaderText = "Role";
            this.E_Role.Name = "E_Role";
            // 
            // E_Mobile
            // 
            this.E_Mobile.DataPropertyName = "EMP_Mobile";
            this.E_Mobile.HeaderText = "Mobile";
            this.E_Mobile.Name = "E_Mobile";
            // 
            // E_Email
            // 
            this.E_Email.DataPropertyName = "EMP_EmailAddress";
            this.E_Email.HeaderText = "Email";
            this.E_Email.Name = "E_Email";
            // 
            // E_Address
            // 
            this.E_Address.DataPropertyName = "EMP_Address";
            this.E_Address.HeaderText = "Address";
            this.E_Address.Name = "E_Address";
            // 
            // E_Username
            // 
            this.E_Username.DataPropertyName = "EMP_Username";
            this.E_Username.HeaderText = "Username";
            this.E_Username.Name = "E_Username";
            // 
            // E_Password
            // 
            this.E_Password.DataPropertyName = "EMP_Password";
            this.E_Password.HeaderText = "Password";
            this.E_Password.Name = "E_Password";
            // 
            // E_Update
            // 
            this.E_Update.FillWeight = 50F;
            this.E_Update.HeaderText = "Update";
            this.E_Update.Name = "E_Update";
            this.E_Update.Text = "Update";
            this.E_Update.UseColumnTextForButtonValue = true;
            // 
            // E_Print
            // 
            this.E_Print.FillWeight = 50F;
            this.E_Print.HeaderText = "Print";
            this.E_Print.Name = "E_Print";
            this.E_Print.Text = "Print";
            this.E_Print.UseColumnTextForButtonValue = true;
            // 
            // E_Delete
            // 
            this.E_Delete.FillWeight = 50F;
            this.E_Delete.HeaderText = "Delete";
            this.E_Delete.Name = "E_Delete";
            this.E_Delete.Text = "Delete";
            this.E_Delete.UseColumnTextForButtonValue = true;
            // 
            // ViewEmployeeAccounts_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ContentPanel);
            this.Name = "ViewEmployeeAccounts_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ViewEmployeeAccounts_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmpoyeeGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2DataGridView EmpoyeeGridView;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedAccountType;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewImageColumn E_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn E_Password;
        private System.Windows.Forms.DataGridViewButtonColumn E_Update;
        private System.Windows.Forms.DataGridViewButtonColumn E_Print;
        private System.Windows.Forms.DataGridViewButtonColumn E_Delete;
    }
}
