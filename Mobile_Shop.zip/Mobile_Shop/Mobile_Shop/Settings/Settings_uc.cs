﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.Settings
{
    public partial class Settings_uc : UserControl
    {
        public Settings_uc()
        {
            InitializeComponent();
            DB.connect();
        }
        // load usercontrol function
        private void addUserControl(UserControl uc)
        {
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }

        //Loading Employee Screen
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            Employee.EmployeeDashboard_uc ed = new Employee.EmployeeDashboard_uc();
            addUserControl(ed);

        }

        //loading Payment Screen
        private void Paymentbtn_Click(object sender, EventArgs e)
        {
            Payment.PaymentDashboard_uc pd = new Payment.PaymentDashboard_uc();
            addUserControl(pd);
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            MainScreen.DashBoardScreenForm dsf = new MainScreen.DashBoardScreenForm();
            addUserControl(dsf);
        }

        private void securityQuestionbtn_Click(object sender, EventArgs e)
        {
            SecurityQuestions.ViewSecurityQuestion_uc vsq = new SecurityQuestions.ViewSecurityQuestion_uc();
            addUserControl(vsq);
        }

        private void notifybtn_Click(object sender, EventArgs e)
        {
            Notification.NotificationSetting_uc ns = new Notification.NotificationSetting_uc();
            addUserControl(ns);
        }
    }
}
