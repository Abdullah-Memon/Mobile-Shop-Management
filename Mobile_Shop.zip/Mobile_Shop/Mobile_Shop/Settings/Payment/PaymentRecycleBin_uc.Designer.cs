﻿namespace Mobile_Shop.Settings.Payment
{
    partial class PaymentRecycleBin_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.groupbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.showDeletedPaymentType = new Guna.UI2.WinForms.Guna2DataGridView();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.PaymentID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentDetails = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RestorePaymentType = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpense = new System.Windows.Forms.DataGridViewButtonColumn();
            this.RestoreAllbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.DeleteAllbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ContentPanel.SuspendLayout();
            this.groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showDeletedPaymentType)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Controls.Add(this.RestoreAllbtn);
            this.ContentPanel.Controls.Add(this.DeleteAllbtn);
            this.ContentPanel.Controls.Add(this.groupbox);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 2;
            // 
            // groupbox
            // 
            this.groupbox.BorderRadius = 10;
            this.groupbox.Controls.Add(this.showDeletedPaymentType);
            this.groupbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.groupbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.groupbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.groupbox.Location = new System.Drawing.Point(3, 62);
            this.groupbox.Name = "groupbox";
            this.groupbox.ShadowDecoration.Parent = this.groupbox;
            this.groupbox.Size = new System.Drawing.Size(1054, 486);
            this.groupbox.TabIndex = 27;
            // 
            // showDeletedPaymentType
            // 
            this.showDeletedPaymentType.AllowUserToAddRows = false;
            this.showDeletedPaymentType.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showDeletedPaymentType.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.showDeletedPaymentType.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.showDeletedPaymentType.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.showDeletedPaymentType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showDeletedPaymentType.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showDeletedPaymentType.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showDeletedPaymentType.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.showDeletedPaymentType.ColumnHeadersHeight = 21;
            this.showDeletedPaymentType.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PaymentID,
            this.PaymentType,
            this.PaymentDetails,
            this.RestorePaymentType,
            this.DeleteExpense});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.showDeletedPaymentType.DefaultCellStyle = dataGridViewCellStyle3;
            this.showDeletedPaymentType.EnableHeadersVisualStyles = false;
            this.showDeletedPaymentType.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showDeletedPaymentType.Location = new System.Drawing.Point(18, 24);
            this.showDeletedPaymentType.Name = "showDeletedPaymentType";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showDeletedPaymentType.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.showDeletedPaymentType.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.showDeletedPaymentType.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.showDeletedPaymentType.RowTemplate.Height = 50;
            this.showDeletedPaymentType.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.showDeletedPaymentType.Size = new System.Drawing.Size(1021, 448);
            this.showDeletedPaymentType.TabIndex = 20;
            this.showDeletedPaymentType.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.showDeletedPaymentType.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showDeletedPaymentType.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.showDeletedPaymentType.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.showDeletedPaymentType.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.showDeletedPaymentType.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.showDeletedPaymentType.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.showDeletedPaymentType.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showDeletedPaymentType.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.showDeletedPaymentType.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.showDeletedPaymentType.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showDeletedPaymentType.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.showDeletedPaymentType.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.showDeletedPaymentType.ThemeStyle.HeaderStyle.Height = 21;
            this.showDeletedPaymentType.ThemeStyle.ReadOnly = false;
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.Height = 50;
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.showDeletedPaymentType.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.showDeletedPaymentType.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showDeletedPaymentType_CellContentClick);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1007, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(50, 50);
            this.backbtn.TabIndex = 26;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // PaymentID
            // 
            this.PaymentID.DataPropertyName = "PID";
            this.PaymentID.HeaderText = "PaymentID";
            this.PaymentID.Name = "PaymentID";
            this.PaymentID.Visible = false;
            // 
            // PaymentType
            // 
            this.PaymentType.DataPropertyName = "P_Type";
            this.PaymentType.FillWeight = 99.11879F;
            this.PaymentType.HeaderText = "Payment";
            this.PaymentType.Name = "PaymentType";
            // 
            // PaymentDetails
            // 
            this.PaymentDetails.DataPropertyName = "P_Details";
            this.PaymentDetails.HeaderText = "Details";
            this.PaymentDetails.Name = "PaymentDetails";
            // 
            // RestorePaymentType
            // 
            this.RestorePaymentType.FillWeight = 30F;
            this.RestorePaymentType.HeaderText = "Restore";
            this.RestorePaymentType.Name = "RestorePaymentType";
            this.RestorePaymentType.Text = "Restore";
            this.RestorePaymentType.UseColumnTextForButtonValue = true;
            // 
            // DeleteExpense
            // 
            this.DeleteExpense.FillWeight = 30F;
            this.DeleteExpense.HeaderText = "Delete";
            this.DeleteExpense.Name = "DeleteExpense";
            this.DeleteExpense.Text = "Delete";
            this.DeleteExpense.UseColumnTextForButtonValue = true;
            // 
            // RestoreAllbtn
            // 
            this.RestoreAllbtn.BackColor = System.Drawing.Color.Transparent;
            this.RestoreAllbtn.BorderColor = System.Drawing.Color.White;
            this.RestoreAllbtn.BorderRadius = 10;
            this.RestoreAllbtn.BorderThickness = 2;
            this.RestoreAllbtn.CheckedState.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.CustomImages.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.FillColor = System.Drawing.Color.Indigo;
            this.RestoreAllbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.RestoreAllbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RestoreAllbtn.ForeColor = System.Drawing.Color.White;
            this.RestoreAllbtn.HoverState.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.Location = new System.Drawing.Point(802, 10);
            this.RestoreAllbtn.Name = "RestoreAllbtn";
            this.RestoreAllbtn.ShadowDecoration.Parent = this.RestoreAllbtn;
            this.RestoreAllbtn.Size = new System.Drawing.Size(89, 36);
            this.RestoreAllbtn.TabIndex = 28;
            this.RestoreAllbtn.Text = "Restore All";
            this.RestoreAllbtn.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // DeleteAllbtn
            // 
            this.DeleteAllbtn.BackColor = System.Drawing.Color.Transparent;
            this.DeleteAllbtn.BorderColor = System.Drawing.Color.White;
            this.DeleteAllbtn.BorderRadius = 10;
            this.DeleteAllbtn.BorderThickness = 2;
            this.DeleteAllbtn.CheckedState.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.CustomImages.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.FillColor = System.Drawing.Color.Indigo;
            this.DeleteAllbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.DeleteAllbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DeleteAllbtn.ForeColor = System.Drawing.Color.White;
            this.DeleteAllbtn.HoverState.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.Location = new System.Drawing.Point(897, 10);
            this.DeleteAllbtn.Name = "DeleteAllbtn";
            this.DeleteAllbtn.ShadowDecoration.Parent = this.DeleteAllbtn;
            this.DeleteAllbtn.Size = new System.Drawing.Size(89, 36);
            this.DeleteAllbtn.TabIndex = 29;
            this.DeleteAllbtn.Text = "Delete All";
            this.DeleteAllbtn.Click += new System.EventHandler(this.guna2GradientButton2_Click);
            // 
            // PaymentRecycleBin_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ContentPanel);
            this.Name = "PaymentRecycleBin_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.PaymentRecycleBin_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            this.groupbox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.showDeletedPaymentType)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2GroupBox groupbox;
        private Guna.UI2.WinForms.Guna2DataGridView showDeletedPaymentType;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentDetails;
        private System.Windows.Forms.DataGridViewButtonColumn RestorePaymentType;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpense;
        private Guna.UI2.WinForms.Guna2GradientButton RestoreAllbtn;
        private Guna.UI2.WinForms.Guna2GradientButton DeleteAllbtn;
    }
}
