﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Settings.Payment
{
    public partial class PaymentRecycleBin_uc : UserControl
    {
        public PaymentRecycleBin_uc()
        {
            InitializeComponent();
        }
        //global Variables
        SqlCommand cmd;

        //Retriving Deleted Data
        private void getDeletedPaymentTypeData()
        {
            DataTable getDeletedData = new DataTable();
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                getDeletedData.Load(cmd.ExecuteReader());

                showDeletedPaymentType.DataSource = getDeletedData;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while retriving PaymentType data " + ex.ToString(), "Error");
            }
        }

        // back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            PaymentDashboard_uc pd = new PaymentDashboard_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(pd);
        }

        // Main load function
        private void PaymentRecycleBin_uc_Load(object sender, EventArgs e)
        {
            getDeletedPaymentTypeData();
        }

        //grid view button coding
        private void showDeletedPaymentType_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //restore button coding
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdatePaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@executeFrom", 1));
                    cmd.Parameters.Add(new SqlParameter("@id", showDeletedPaymentType.Rows[e.RowIndex].Cells["PaymentID"].Value));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    //Refreshing data
                    getDeletedPaymentTypeData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while restoring the data "+ex.ToString(), "Error");
                }
            }

            // permanatly delete button coding
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure? You want to delete selected Payment Type. ","Confirmation",MessageBoxButtons.YesNo)== DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("RemovePaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", showDeletedPaymentType.Rows[e.RowIndex].Cells["PaymentID"].Value));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    //Refreshing data
                    getDeletedPaymentTypeData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting the data "+ex.ToString(), "Error");
                }
                }
            }
        }

        // Delete all button coding
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure? You want to delete all Payment Type. ", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                for (int i = 0; i < showDeletedPaymentType.Rows.Count; i++)
                {
                        cmd = new SqlCommand("RemovePaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", showDeletedPaymentType.Rows[i].Cells["PaymentID"].Value));

                        cmd.ExecuteNonQuery();
                     
                }
                DB.con.Close();

                //Refreshing data
                getDeletedPaymentTypeData();
            }
        }

        //restore all button coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }

            for (int i = 0; i < showDeletedPaymentType.Rows.Count; i++)
            {
                    cmd = new SqlCommand("UpdatePaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@executeFrom", 1));
                    cmd.Parameters.Add(new SqlParameter("@id", showDeletedPaymentType.Rows[i].Cells["PaymentID"].Value));

                    cmd.ExecuteNonQuery();
                    
            }
            DB.con.Close();
            //Refreshing data
            getDeletedPaymentTypeData();

        }
    }
}
