﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Settings.Payment
{
    public partial class PaymentDashboard_uc : UserControl
    {
        public PaymentDashboard_uc()
        {
            InitializeComponent();
            DB.connect();
        }

        // global variables
        SqlCommand cmd;
        int chk;

        // function to retrive all available data
        private void getPaymentTypeData()
        {
            DataTable getdata = new DataTable();
            if (DB.con.State== ConnectionState.Closed)
	        {
                DB.con.Open();
	        }
            try
            {
                cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                getdata.Load(cmd.ExecuteReader());

                showPaymentType.DataSource = getdata;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while retriving PaymentType data " + ex.ToString(), "Error");
            }
        }

        // back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            Settings_uc s = new Settings_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(s);
        }

        // Loading Recycle bin screen
        private void Recyclebinbtn_Click(object sender, EventArgs e)
        {
            PaymentRecycleBin_uc prb = new PaymentRecycleBin_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(prb);
        }

        // Main Load function
        private void PaymentDashboard_uc_Load(object sender, EventArgs e)
        {
            // getting all avaiable data
            getPaymentTypeData();

            // hiding all warinings
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
        }

        private void AddPayment_Click(object sender, EventArgs e)
        {
            chk = 0;
            // Resting waringnigs
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
           
            // checking provided information and adding new information
            if (string.IsNullOrWhiteSpace (newPayment.Text) || string.IsNullOrEmpty(newPayment.Text))
	        {
	    	    newPayment.Focus();
                warning1.Show();
	        }
            else if (string.IsNullOrWhiteSpace (PayDetail.Text) || string.IsNullOrEmpty (PayDetail.Text))
            {
                PayDetail.Focus();
                warning2.Show();
            }
            else
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("AddPaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@PaymentType", newPayment.Text));
                    cmd.Parameters.Add(new SqlParameter("@PaymentDetails", PayDetail.Text));

                    chk = cmd.ExecuteNonQuery();
                    
                    DB.con.Close();

                    // refreshing Data
                    getPaymentTypeData();
                    
                    if (chk < 0)
                    {
                        warning3.Show();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding new payment type " + ex.ToString(), "Error");
                }

                
            }
        }

        // Grid view button coding
        private void showPaymentType_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            chk = 0;
            // Resting warnings
            warning5.Hide();
            warning4.Hide();
            //update button coding
            if (e.ColumnIndex == 0)
	        {
                if ((int)showPaymentType.Rows[e.RowIndex].Cells["PaymentID"].Value > 2)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("UpdatePaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", showPaymentType.Rows[e.RowIndex].Cells["PaymentID"].Value));
                        cmd.Parameters.Add(new SqlParameter("@PaymentType", showPaymentType.Rows[e.RowIndex].Cells["PaymentType"].Value.ToString()));
                        cmd.Parameters.Add(new SqlParameter("@PaymentDetails", showPaymentType.Rows[e.RowIndex].Cells["PaymentDetails"].Value.ToString()));
                        chk = cmd.ExecuteNonQuery();

                        DB.con.Close();

                        // refreshing gridview
                        getPaymentTypeData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while updating Payment Data " + ex.ToString(), "Error");
                    }
                    if (chk > 0)
                    {
                        warning4.Show();
                    }
                }
	        }

            // delete button coding
            if (e.ColumnIndex == 1)
	        {
                if ((int)showPaymentType.Rows[e.RowIndex].Cells["PaymentID"].Value > 2)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("RemovePaymentType", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", showPaymentType.Rows[e.RowIndex].Cells["PaymentID"].Value));
                        chk = cmd.ExecuteNonQuery();

                        DB.con.Close();

                        //refreshing data
                        getPaymentTypeData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while deleting Payment type " + ex.ToString(), "Error");
                    }
                    if (chk > 0)
                    {
                        warning5.Show();
                    }
                }
	        }
        }
    }
}
