﻿namespace Mobile_Shop.Settings.Payment
{
    partial class PaymentDashboard_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.AddPayment = new Guna.UI2.WinForms.Guna2GradientButton();
            this.showPaymentType = new Guna.UI2.WinForms.Guna2DataGridView();
            this.PaymentID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentDetails = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updateItems = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpense = new System.Windows.Forms.DataGridViewButtonColumn();
            this.warning4 = new System.Windows.Forms.Label();
            this.warning3 = new System.Windows.Forms.Label();
            this.warning5 = new System.Windows.Forms.Label();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PayDetail = new Guna.UI2.WinForms.Guna2TextBox();
            this.newPayment = new Guna.UI2.WinForms.Guna2TextBox();
            this.Recyclebinbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.ContentPanel.SuspendLayout();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showPaymentType)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Controls.Add(this.ShowAddedItemsDetailBox);
            this.ContentPanel.Controls.Add(this.Recyclebinbtn);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 1;
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.AddPayment);
            this.ShowAddedItemsDetailBox.Controls.Add(this.showPaymentType);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning4);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning3);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning5);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning2);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning1);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label1);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label8);
            this.ShowAddedItemsDetailBox.Controls.Add(this.PayDetail);
            this.ShowAddedItemsDetailBox.Controls.Add(this.newPayment);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(3, 62);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(1054, 486);
            this.ShowAddedItemsDetailBox.TabIndex = 27;
            // 
            // AddPayment
            // 
            this.AddPayment.BackColor = System.Drawing.Color.Transparent;
            this.AddPayment.BorderColor = System.Drawing.Color.White;
            this.AddPayment.BorderRadius = 10;
            this.AddPayment.BorderThickness = 2;
            this.AddPayment.CheckedState.Parent = this.AddPayment;
            this.AddPayment.CustomImages.Parent = this.AddPayment;
            this.AddPayment.FillColor = System.Drawing.Color.Indigo;
            this.AddPayment.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AddPayment.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddPayment.ForeColor = System.Drawing.Color.White;
            this.AddPayment.HoverState.Parent = this.AddPayment;
            this.AddPayment.Location = new System.Drawing.Point(219, 211);
            this.AddPayment.Name = "AddPayment";
            this.AddPayment.ShadowDecoration.Parent = this.AddPayment;
            this.AddPayment.Size = new System.Drawing.Size(106, 36);
            this.AddPayment.TabIndex = 15;
            this.AddPayment.Text = "ADD";
            this.AddPayment.Click += new System.EventHandler(this.AddPayment_Click);
            // 
            // showPaymentType
            // 
            this.showPaymentType.AllowUserToAddRows = false;
            this.showPaymentType.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showPaymentType.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.showPaymentType.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.showPaymentType.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.showPaymentType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showPaymentType.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showPaymentType.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showPaymentType.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.showPaymentType.ColumnHeadersHeight = 21;
            this.showPaymentType.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PaymentID,
            this.PaymentType,
            this.PaymentDetails,
            this.updateItems,
            this.DeleteExpense});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.showPaymentType.DefaultCellStyle = dataGridViewCellStyle8;
            this.showPaymentType.EnableHeadersVisualStyles = false;
            this.showPaymentType.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showPaymentType.Location = new System.Drawing.Point(351, 24);
            this.showPaymentType.Name = "showPaymentType";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showPaymentType.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.showPaymentType.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.showPaymentType.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.showPaymentType.RowTemplate.Height = 50;
            this.showPaymentType.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.showPaymentType.Size = new System.Drawing.Size(688, 448);
            this.showPaymentType.TabIndex = 20;
            this.showPaymentType.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.showPaymentType.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showPaymentType.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.showPaymentType.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.showPaymentType.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.showPaymentType.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.showPaymentType.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.showPaymentType.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showPaymentType.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.showPaymentType.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.showPaymentType.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showPaymentType.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.showPaymentType.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.showPaymentType.ThemeStyle.HeaderStyle.Height = 21;
            this.showPaymentType.ThemeStyle.ReadOnly = false;
            this.showPaymentType.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.showPaymentType.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showPaymentType.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showPaymentType.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.showPaymentType.ThemeStyle.RowsStyle.Height = 50;
            this.showPaymentType.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.showPaymentType.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.showPaymentType.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showPaymentType_CellContentClick);
            // 
            // PaymentID
            // 
            this.PaymentID.DataPropertyName = "PID";
            this.PaymentID.HeaderText = "PaymentID";
            this.PaymentID.Name = "PaymentID";
            this.PaymentID.Visible = false;
            // 
            // PaymentType
            // 
            this.PaymentType.DataPropertyName = "P_Type";
            this.PaymentType.FillWeight = 99.11879F;
            this.PaymentType.HeaderText = "Payment";
            this.PaymentType.Name = "PaymentType";
            // 
            // PaymentDetails
            // 
            this.PaymentDetails.DataPropertyName = "P_Details";
            this.PaymentDetails.HeaderText = "Details";
            this.PaymentDetails.Name = "PaymentDetails";
            // 
            // updateItems
            // 
            this.updateItems.FillWeight = 30F;
            this.updateItems.HeaderText = "Update";
            this.updateItems.Name = "updateItems";
            this.updateItems.Text = "Update";
            this.updateItems.UseColumnTextForButtonValue = true;
            // 
            // DeleteExpense
            // 
            this.DeleteExpense.FillWeight = 30F;
            this.DeleteExpense.HeaderText = "Delete";
            this.DeleteExpense.Name = "DeleteExpense";
            this.DeleteExpense.Text = "Delete";
            this.DeleteExpense.UseColumnTextForButtonValue = true;
            // 
            // warning4
            // 
            this.warning4.AutoSize = true;
            this.warning4.ForeColor = System.Drawing.Color.Green;
            this.warning4.Location = new System.Drawing.Point(29, 319);
            this.warning4.Name = "warning4";
            this.warning4.Size = new System.Drawing.Size(182, 19);
            this.warning4.TabIndex = 1;
            this.warning4.Text = "* Expense has been updated";
            // 
            // warning3
            // 
            this.warning3.AutoSize = true;
            this.warning3.ForeColor = System.Drawing.Color.Red;
            this.warning3.Location = new System.Drawing.Point(29, 189);
            this.warning3.Name = "warning3";
            this.warning3.Size = new System.Drawing.Size(210, 19);
            this.warning3.TabIndex = 1;
            this.warning3.Text = "* Payment method already Exists";
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.ForeColor = System.Drawing.Color.Green;
            this.warning5.Location = new System.Drawing.Point(29, 338);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(250, 19);
            this.warning5.TabIndex = 1;
            this.warning5.Text = "* Expense has been deleted successfully";
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(178, 122);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(147, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Please Enter Account";
            // 
            // warning1
            // 
            this.warning1.AutoSize = true;
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(142, 49);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(196, 19);
            this.warning1.TabIndex = 1;
            this.warning1.Text = "* Please Enter Payment Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(29, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Account number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(29, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Payment Detail";
            // 
            // PayDetail
            // 
            this.PayDetail.BorderRadius = 10;
            this.PayDetail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PayDetail.DefaultText = "";
            this.PayDetail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PayDetail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PayDetail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PayDetail.DisabledState.Parent = this.PayDetail;
            this.PayDetail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PayDetail.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PayDetail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PayDetail.FocusedState.Parent = this.PayDetail;
            this.PayDetail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PayDetail.HoverState.Parent = this.PayDetail;
            this.PayDetail.Location = new System.Drawing.Point(33, 150);
            this.PayDetail.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.PayDetail.Name = "PayDetail";
            this.PayDetail.PasswordChar = '\0';
            this.PayDetail.PlaceholderText = "";
            this.PayDetail.SelectedText = "";
            this.PayDetail.ShadowDecoration.Parent = this.PayDetail;
            this.PayDetail.Size = new System.Drawing.Size(292, 36);
            this.PayDetail.TabIndex = 3;
            this.PayDetail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // newPayment
            // 
            this.newPayment.BorderRadius = 10;
            this.newPayment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newPayment.DefaultText = "";
            this.newPayment.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newPayment.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newPayment.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newPayment.DisabledState.Parent = this.newPayment;
            this.newPayment.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newPayment.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newPayment.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newPayment.FocusedState.Parent = this.newPayment;
            this.newPayment.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newPayment.HoverState.Parent = this.newPayment;
            this.newPayment.Location = new System.Drawing.Point(33, 77);
            this.newPayment.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.newPayment.Name = "newPayment";
            this.newPayment.PasswordChar = '\0';
            this.newPayment.PlaceholderText = "";
            this.newPayment.SelectedText = "";
            this.newPayment.ShadowDecoration.Parent = this.newPayment;
            this.newPayment.Size = new System.Drawing.Size(292, 36);
            this.newPayment.TabIndex = 3;
            this.newPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Recyclebinbtn
            // 
            this.Recyclebinbtn.BackColor = System.Drawing.Color.Transparent;
            this.Recyclebinbtn.CheckedState.Parent = this.Recyclebinbtn;
            this.Recyclebinbtn.CustomImages.Parent = this.Recyclebinbtn;
            this.Recyclebinbtn.FillColor = System.Drawing.Color.Indigo;
            this.Recyclebinbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Recyclebinbtn.ForeColor = System.Drawing.Color.White;
            this.Recyclebinbtn.HoverState.Parent = this.Recyclebinbtn;
            this.Recyclebinbtn.Location = new System.Drawing.Point(951, 6);
            this.Recyclebinbtn.Name = "Recyclebinbtn";
            this.Recyclebinbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Recyclebinbtn.ShadowDecoration.Parent = this.Recyclebinbtn;
            this.Recyclebinbtn.Size = new System.Drawing.Size(50, 50);
            this.Recyclebinbtn.TabIndex = 28;
            this.Recyclebinbtn.Text = "♻️";
            this.Recyclebinbtn.Click += new System.EventHandler(this.Recyclebinbtn_Click);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1007, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(50, 50);
            this.backbtn.TabIndex = 26;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // PaymentDashboard_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ContentPanel);
            this.Name = "PaymentDashboard_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.PaymentDashboard_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showPaymentType)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2GradientButton AddPayment;
        private Guna.UI2.WinForms.Guna2DataGridView showPaymentType;
        private System.Windows.Forms.Label warning4;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox newPayment;
        private Guna.UI2.WinForms.Guna2CircleButton Recyclebinbtn;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox PayDetail;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentDetails;
        private System.Windows.Forms.DataGridViewButtonColumn updateItems;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpense;
        private System.Windows.Forms.Label warning2;
        private System.Windows.Forms.Label warning3;
    }
}
