﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Settings.SecurityQuestions
{
    public partial class ViewSecurityQuestion_uc : UserControl
    {
        public ViewSecurityQuestion_uc()
        {
            InitializeComponent();
        }
        // global variables
        SqlCommand cmd;
        int chk;

        //back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            Settings_uc s = new Settings_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(s);
        }

        // Adding new questions
        private void getSecurityQuestions()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                DataTable data = new DataTable();
                cmd = new SqlCommand("SecurityQuestionsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                data.Load(cmd.ExecuteReader());

                DB.con.Close();

                showQuestions.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading questions " + ex.ToString(), "Error");
                throw;
            }
        }

        private void AddQuestions_Click(object sender, EventArgs e)
        {
            //resting warnings
            warning2.Hide();
            warning3.Hide();

            // checking provided information
            if (string.IsNullOrWhiteSpace(newQuestion.Text) || string.IsNullOrEmpty(newQuestion.Text))
            {
                newQuestion.Focus();
                warning2.Show();
            }
                // adding new information
            else
            {
                chk = 0;
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("AddSecurityQuestions", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@question", newQuestion.Text));
                    chk = cmd.ExecuteNonQuery();
                    DB.con.Close();

                    if (chk < 0)
                    {
                        warning3.Show();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding new questions " + ex.ToString(), "Error");
                    throw;
                }

                newQuestion.Text = string.Empty;
                
                //refresing grid view
                getSecurityQuestions();
            }
        }

        private void ViewSecurityQuestion_uc_Load(object sender, EventArgs e)
        {
            getSecurityQuestions();

            // hiding all warning messages
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
        }

        private void showQuestions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 0 == update and 1 == delete
        }
    }
}
