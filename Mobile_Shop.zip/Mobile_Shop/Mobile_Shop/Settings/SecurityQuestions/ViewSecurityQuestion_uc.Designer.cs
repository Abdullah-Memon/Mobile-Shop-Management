﻿namespace Mobile_Shop.Settings.SecurityQuestions
{
    partial class ViewSecurityQuestion_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.AddQuestions = new Guna.UI2.WinForms.Guna2GradientButton();
            this.showQuestions = new Guna.UI2.WinForms.Guna2DataGridView();
            this.warning4 = new System.Windows.Forms.Label();
            this.warning3 = new System.Windows.Forms.Label();
            this.warning5 = new System.Windows.Forms.Label();
            this.warning2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.newQuestion = new Guna.UI2.WinForms.Guna2TextBox();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.SQuestionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Questions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updateItems = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpense = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ContentPanel.SuspendLayout();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showQuestions)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Controls.Add(this.AddQuestions);
            this.ContentPanel.Controls.Add(this.ShowAddedItemsDetailBox);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Controls.Add(this.newQuestion);
            this.ContentPanel.Controls.Add(this.label1);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 2;
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.showQuestions);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning4);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning3);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning5);
            this.ShowAddedItemsDetailBox.Controls.Add(this.warning2);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(3, 62);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(1054, 486);
            this.ShowAddedItemsDetailBox.TabIndex = 27;
            // 
            // AddQuestions
            // 
            this.AddQuestions.BackColor = System.Drawing.Color.Transparent;
            this.AddQuestions.BorderColor = System.Drawing.Color.White;
            this.AddQuestions.BorderRadius = 10;
            this.AddQuestions.BorderThickness = 2;
            this.AddQuestions.CheckedState.Parent = this.AddQuestions;
            this.AddQuestions.CustomImages.Parent = this.AddQuestions;
            this.AddQuestions.FillColor = System.Drawing.Color.Indigo;
            this.AddQuestions.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AddQuestions.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddQuestions.ForeColor = System.Drawing.Color.White;
            this.AddQuestions.HoverState.Parent = this.AddQuestions;
            this.AddQuestions.Location = new System.Drawing.Point(788, 13);
            this.AddQuestions.Name = "AddQuestions";
            this.AddQuestions.ShadowDecoration.Parent = this.AddQuestions;
            this.AddQuestions.Size = new System.Drawing.Size(106, 36);
            this.AddQuestions.TabIndex = 15;
            this.AddQuestions.Text = "ADD";
            this.AddQuestions.Click += new System.EventHandler(this.AddQuestions_Click);
            // 
            // showQuestions
            // 
            this.showQuestions.AllowUserToAddRows = false;
            this.showQuestions.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showQuestions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.showQuestions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.showQuestions.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.showQuestions.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showQuestions.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showQuestions.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showQuestions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.showQuestions.ColumnHeadersHeight = 21;
            this.showQuestions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SQuestionID,
            this.Questions,
            this.updateItems,
            this.DeleteExpense});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.showQuestions.DefaultCellStyle = dataGridViewCellStyle3;
            this.showQuestions.EnableHeadersVisualStyles = false;
            this.showQuestions.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showQuestions.Location = new System.Drawing.Point(17, 33);
            this.showQuestions.Name = "showQuestions";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showQuestions.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.showQuestions.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.showQuestions.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.showQuestions.RowTemplate.Height = 50;
            this.showQuestions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.showQuestions.Size = new System.Drawing.Size(1022, 439);
            this.showQuestions.TabIndex = 20;
            this.showQuestions.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.showQuestions.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showQuestions.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.showQuestions.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.showQuestions.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.showQuestions.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.showQuestions.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.showQuestions.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showQuestions.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.showQuestions.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.showQuestions.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showQuestions.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.showQuestions.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.showQuestions.ThemeStyle.HeaderStyle.Height = 21;
            this.showQuestions.ThemeStyle.ReadOnly = false;
            this.showQuestions.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.showQuestions.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showQuestions.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showQuestions.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.showQuestions.ThemeStyle.RowsStyle.Height = 50;
            this.showQuestions.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.showQuestions.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.showQuestions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showQuestions_CellContentClick);
            // 
            // warning4
            // 
            this.warning4.AutoSize = true;
            this.warning4.ForeColor = System.Drawing.Color.Green;
            this.warning4.Location = new System.Drawing.Point(590, 11);
            this.warning4.Name = "warning4";
            this.warning4.Size = new System.Drawing.Size(189, 19);
            this.warning4.TabIndex = 1;
            this.warning4.Text = "* Question has been updated";
            // 
            // warning3
            // 
            this.warning3.AutoSize = true;
            this.warning3.ForeColor = System.Drawing.Color.Red;
            this.warning3.Location = new System.Drawing.Point(13, 11);
            this.warning3.Name = "warning3";
            this.warning3.Size = new System.Drawing.Size(209, 19);
            this.warning3.TabIndex = 1;
            this.warning3.Text = "* Security question already Exists";
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.ForeColor = System.Drawing.Color.Green;
            this.warning5.Location = new System.Drawing.Point(789, 11);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(257, 19);
            this.warning5.TabIndex = 1;
            this.warning5.Text = "* Question has been deleted successfully";
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(294, 11);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(205, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Please Enter Secutity Question";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(64, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Security Question";
            // 
            // newQuestion
            // 
            this.newQuestion.BorderRadius = 10;
            this.newQuestion.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newQuestion.DefaultText = "";
            this.newQuestion.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newQuestion.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newQuestion.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newQuestion.DisabledState.Parent = this.newQuestion;
            this.newQuestion.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newQuestion.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newQuestion.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newQuestion.FocusedState.Parent = this.newQuestion;
            this.newQuestion.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newQuestion.HoverState.Parent = this.newQuestion;
            this.newQuestion.Location = new System.Drawing.Point(207, 13);
            this.newQuestion.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.newQuestion.Name = "newQuestion";
            this.newQuestion.PasswordChar = '\0';
            this.newQuestion.PlaceholderText = "";
            this.newQuestion.SelectedText = "";
            this.newQuestion.ShadowDecoration.Parent = this.newQuestion;
            this.newQuestion.Size = new System.Drawing.Size(575, 36);
            this.newQuestion.TabIndex = 3;
            this.newQuestion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1007, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(50, 50);
            this.backbtn.TabIndex = 26;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // SQuestionID
            // 
            this.SQuestionID.DataPropertyName = "SQID";
            this.SQuestionID.HeaderText = "SQuestionID";
            this.SQuestionID.Name = "SQuestionID";
            this.SQuestionID.Visible = false;
            // 
            // Questions
            // 
            this.Questions.DataPropertyName = "SQ";
            this.Questions.FillWeight = 99.11879F;
            this.Questions.HeaderText = "Security Question";
            this.Questions.Name = "Questions";
            // 
            // updateItems
            // 
            this.updateItems.FillWeight = 30F;
            this.updateItems.HeaderText = "Update";
            this.updateItems.Name = "updateItems";
            this.updateItems.Text = "Update";
            this.updateItems.UseColumnTextForButtonValue = true;
            this.updateItems.Visible = false;
            // 
            // DeleteExpense
            // 
            this.DeleteExpense.FillWeight = 30F;
            this.DeleteExpense.HeaderText = "Delete";
            this.DeleteExpense.Name = "DeleteExpense";
            this.DeleteExpense.Text = "Delete";
            this.DeleteExpense.UseColumnTextForButtonValue = true;
            this.DeleteExpense.Visible = false;
            // 
            // ViewSecurityQuestion_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ContentPanel);
            this.Name = "ViewSecurityQuestion_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ViewSecurityQuestion_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showQuestions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2GradientButton AddQuestions;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2DataGridView showQuestions;
        private System.Windows.Forms.Label warning4;
        private System.Windows.Forms.Label warning3;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label warning2;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private Guna.UI2.WinForms.Guna2TextBox newQuestion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SQuestionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Questions;
        private System.Windows.Forms.DataGridViewButtonColumn updateItems;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpense;
    }
}
