﻿namespace Mobile_Shop.StockScreen
{
    partial class StockScreenForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton5 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ViewStockbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // ContentPanel
            // 
            this.ContentPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentPanel.Location = new System.Drawing.Point(3, 3);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(900, 548);
            this.ContentPanel.TabIndex = 0;
            // 
            // guna2GradientButton6
            // 
            this.guna2GradientButton6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton6.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton6.BorderRadius = 10;
            this.guna2GradientButton6.BorderThickness = 2;
            this.guna2GradientButton6.CheckedState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.CustomImages.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton6.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton6.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton6.HoverState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Location = new System.Drawing.Point(914, 332);
            this.guna2GradientButton6.Name = "guna2GradientButton6";
            this.guna2GradientButton6.ShadowDecoration.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Size = new System.Drawing.Size(129, 50);
            this.guna2GradientButton6.TabIndex = 16;
            this.guna2GradientButton6.Text = "Check Payment";
            // 
            // guna2GradientButton5
            // 
            this.guna2GradientButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton5.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton5.BorderRadius = 10;
            this.guna2GradientButton5.BorderThickness = 2;
            this.guna2GradientButton5.CheckedState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.CustomImages.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton5.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton5.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton5.HoverState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Location = new System.Drawing.Point(914, 268);
            this.guna2GradientButton5.Name = "guna2GradientButton5";
            this.guna2GradientButton5.ShadowDecoration.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Size = new System.Drawing.Size(129, 50);
            this.guna2GradientButton5.TabIndex = 17;
            this.guna2GradientButton5.Text = "Pay Purchase Stock";
            // 
            // guna2GradientButton4
            // 
            this.guna2GradientButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton4.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton4.BorderRadius = 10;
            this.guna2GradientButton4.BorderThickness = 2;
            this.guna2GradientButton4.CheckedState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.CustomImages.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton4.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton4.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton4.HoverState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Location = new System.Drawing.Point(914, 204);
            this.guna2GradientButton4.Name = "guna2GradientButton4";
            this.guna2GradientButton4.ShadowDecoration.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Size = new System.Drawing.Size(129, 50);
            this.guna2GradientButton4.TabIndex = 18;
            this.guna2GradientButton4.Text = "Purchase Stock";
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton3.BorderRadius = 10;
            this.guna2GradientButton3.BorderThickness = 2;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(914, 140);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(129, 50);
            this.guna2GradientButton3.TabIndex = 19;
            this.guna2GradientButton3.Text = "Print Invoice Detail";
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton2.BorderRadius = 10;
            this.guna2GradientButton2.BorderThickness = 2;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(917, 76);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(129, 50);
            this.guna2GradientButton2.TabIndex = 20;
            this.guna2GradientButton2.Text = "Purchase Item Detail";
            // 
            // ViewStockbtn
            // 
            this.ViewStockbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ViewStockbtn.BackColor = System.Drawing.Color.Transparent;
            this.ViewStockbtn.BorderColor = System.Drawing.Color.White;
            this.ViewStockbtn.BorderRadius = 10;
            this.ViewStockbtn.BorderThickness = 2;
            this.ViewStockbtn.CheckedState.Parent = this.ViewStockbtn;
            this.ViewStockbtn.CustomImages.Parent = this.ViewStockbtn;
            this.ViewStockbtn.FillColor = System.Drawing.Color.Indigo;
            this.ViewStockbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ViewStockbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ViewStockbtn.ForeColor = System.Drawing.Color.White;
            this.ViewStockbtn.HoverState.Parent = this.ViewStockbtn;
            this.ViewStockbtn.Location = new System.Drawing.Point(917, 12);
            this.ViewStockbtn.Name = "ViewStockbtn";
            this.ViewStockbtn.ShadowDecoration.Parent = this.ViewStockbtn;
            this.ViewStockbtn.Size = new System.Drawing.Size(129, 50);
            this.ViewStockbtn.TabIndex = 21;
            this.ViewStockbtn.Text = "View Stock";
            this.ViewStockbtn.Click += new System.EventHandler(this.ViewStockbtn_Click);
            // 
            // StockScreenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.guna2GradientButton6);
            this.Controls.Add(this.guna2GradientButton5);
            this.Controls.Add(this.guna2GradientButton4);
            this.Controls.Add(this.guna2GradientButton3);
            this.Controls.Add(this.guna2GradientButton2);
            this.Controls.Add(this.ViewStockbtn);
            this.Controls.Add(this.ContentPanel);
            this.Name = "StockScreenForm";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.StockScreenForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton6;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton5;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2GradientButton ViewStockbtn;
    }
}
