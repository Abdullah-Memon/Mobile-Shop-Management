﻿namespace Mobile_Shop.StockScreen.ItemStock
{
    partial class ViewMoreDetail_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.stockGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.UpdateAllbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Product_SID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_IMEIID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_IMEI1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_IMEI2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Color = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_SP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_PP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Box = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Product_warranty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_State = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Product_Update = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Product_Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.Controls.Add(this.UpdateAllbtn);
            this.ContentPanel.Controls.Add(this.stockGridView);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(900, 548);
            this.ContentPanel.TabIndex = 2;
            // 
            // stockGridView
            // 
            this.stockGridView.AllowUserToAddRows = false;
            this.stockGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.stockGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.stockGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stockGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.stockGridView.BackgroundColor = System.Drawing.Color.White;
            this.stockGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.stockGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.stockGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.stockGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.stockGridView.ColumnHeadersHeight = 52;
            this.stockGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Product_SID,
            this.Product_IMEIID,
            this.ItemName,
            this.Product_IMEI1,
            this.Product_IMEI2,
            this.Product_Color,
            this.Product_SP,
            this.Product_PP,
            this.Product_Box,
            this.Product_warranty,
            this.Product_Date,
            this.Product_State,
            this.Product_Update,
            this.Product_Delete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.stockGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.stockGridView.EnableHeadersVisualStyles = false;
            this.stockGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.stockGridView.Location = new System.Drawing.Point(3, 63);
            this.stockGridView.Name = "stockGridView";
            this.stockGridView.RowHeadersVisible = false;
            this.stockGridView.RowTemplate.Height = 50;
            this.stockGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.stockGridView.Size = new System.Drawing.Size(894, 482);
            this.stockGridView.TabIndex = 0;
            this.stockGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.stockGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.stockGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.stockGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.stockGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.stockGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.stockGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.stockGridView.ThemeStyle.HeaderStyle.Height = 52;
            this.stockGridView.ThemeStyle.ReadOnly = false;
            this.stockGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.stockGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.stockGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.stockGridView.ThemeStyle.RowsStyle.Height = 50;
            this.stockGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.stockGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.stockGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockGridView_CellContentClick);
            // 
            // backbtn
            // 
            this.backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(847, 7);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(50, 50);
            this.backbtn.TabIndex = 27;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // UpdateAllbtn
            // 
            this.UpdateAllbtn.BackColor = System.Drawing.Color.Transparent;
            this.UpdateAllbtn.BorderColor = System.Drawing.Color.White;
            this.UpdateAllbtn.BorderRadius = 10;
            this.UpdateAllbtn.BorderThickness = 2;
            this.UpdateAllbtn.CheckedState.Parent = this.UpdateAllbtn;
            this.UpdateAllbtn.CustomImages.Parent = this.UpdateAllbtn;
            this.UpdateAllbtn.FillColor = System.Drawing.Color.Indigo;
            this.UpdateAllbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.UpdateAllbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.UpdateAllbtn.ForeColor = System.Drawing.Color.White;
            this.UpdateAllbtn.HoverState.Parent = this.UpdateAllbtn;
            this.UpdateAllbtn.Location = new System.Drawing.Point(3, 18);
            this.UpdateAllbtn.Name = "UpdateAllbtn";
            this.UpdateAllbtn.ShadowDecoration.Parent = this.UpdateAllbtn;
            this.UpdateAllbtn.Size = new System.Drawing.Size(96, 39);
            this.UpdateAllbtn.TabIndex = 28;
            this.UpdateAllbtn.Text = "Update All";
            this.UpdateAllbtn.Click += new System.EventHandler(this.UpdateAllbtn_Click);
            // 
            // Product_SID
            // 
            this.Product_SID.DataPropertyName = "SID";
            this.Product_SID.HeaderText = "SID";
            this.Product_SID.Name = "Product_SID";
            this.Product_SID.Visible = false;
            // 
            // Product_IMEIID
            // 
            this.Product_IMEIID.DataPropertyName = "IMEIID";
            this.Product_IMEIID.HeaderText = "IMEIID";
            this.Product_IMEIID.Name = "Product_IMEIID";
            this.Product_IMEIID.ReadOnly = true;
            this.Product_IMEIID.Visible = false;
            // 
            // ItemName
            // 
            this.ItemName.DataPropertyName = "Item_Name";
            this.ItemName.HeaderText = "Product Name";
            this.ItemName.Name = "ItemName";
            this.ItemName.ReadOnly = true;
            // 
            // Product_IMEI1
            // 
            this.Product_IMEI1.DataPropertyName = "IMEI_1";
            this.Product_IMEI1.HeaderText = "IMEI 1";
            this.Product_IMEI1.Name = "Product_IMEI1";
            // 
            // Product_IMEI2
            // 
            this.Product_IMEI2.DataPropertyName = "IMEI_2";
            this.Product_IMEI2.HeaderText = "IMEI 2";
            this.Product_IMEI2.Name = "Product_IMEI2";
            // 
            // Product_Color
            // 
            this.Product_Color.DataPropertyName = "Color";
            this.Product_Color.HeaderText = "Color";
            this.Product_Color.Name = "Product_Color";
            // 
            // Product_SP
            // 
            this.Product_SP.DataPropertyName = "SP";
            this.Product_SP.HeaderText = "Sell Price";
            this.Product_SP.Name = "Product_SP";
            // 
            // Product_PP
            // 
            this.Product_PP.DataPropertyName = "PP";
            this.Product_PP.HeaderText = "Purchase Price";
            this.Product_PP.Name = "Product_PP";
            // 
            // Product_Box
            // 
            this.Product_Box.DataPropertyName = "Box";
            this.Product_Box.HeaderText = "Box";
            this.Product_Box.Items.AddRange(new object[] {
            "Available",
            "Not Available"});
            this.Product_Box.Name = "Product_Box";
            this.Product_Box.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Product_Box.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Product_warranty
            // 
            this.Product_warranty.DataPropertyName = "Warranty";
            this.Product_warranty.HeaderText = "Warranty";
            this.Product_warranty.Name = "Product_warranty";
            // 
            // Product_Date
            // 
            this.Product_Date.DataPropertyName = "Date";
            this.Product_Date.HeaderText = "Date";
            this.Product_Date.Name = "Product_Date";
            // 
            // Product_State
            // 
            this.Product_State.DataPropertyName = "Item_State";
            this.Product_State.HeaderText = "Status";
            this.Product_State.Items.AddRange(new object[] {
            "Un Used",
            "Used"});
            this.Product_State.Name = "Product_State";
            this.Product_State.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Product_State.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Product_Update
            // 
            this.Product_Update.FillWeight = 50F;
            this.Product_Update.HeaderText = "Update";
            this.Product_Update.Name = "Product_Update";
            this.Product_Update.Text = "Update";
            this.Product_Update.UseColumnTextForButtonValue = true;
            // 
            // Product_Delete
            // 
            this.Product_Delete.FillWeight = 50F;
            this.Product_Delete.HeaderText = "Delete";
            this.Product_Delete.Name = "Product_Delete";
            this.Product_Delete.Text = "Delete";
            this.Product_Delete.UseColumnTextForButtonValue = true;
            // 
            // ViewMoreDetail_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ContentPanel);
            this.Name = "ViewMoreDetail_uc";
            this.Size = new System.Drawing.Size(900, 548);
            this.Load += new System.EventHandler(this.ViewMoreDetail_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.stockGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2DataGridView stockGridView;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton UpdateAllbtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_SID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_IMEIID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_IMEI1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_IMEI2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Color;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_SP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_PP;
        private System.Windows.Forms.DataGridViewComboBoxColumn Product_Box;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_warranty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Date;
        private System.Windows.Forms.DataGridViewComboBoxColumn Product_State;
        private System.Windows.Forms.DataGridViewButtonColumn Product_Update;
        private System.Windows.Forms.DataGridViewButtonColumn Product_Delete;
    }
}
