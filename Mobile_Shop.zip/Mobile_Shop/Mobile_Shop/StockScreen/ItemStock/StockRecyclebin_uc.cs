﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.StockScreen.ItemStock
{
    public partial class StockRecyclebin_uc : UserControl
    {
        public StockRecyclebin_uc()
        {
            InitializeComponent();
        }

        private void getData()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("StockDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                dt.Load(cmd.ExecuteReader());

                stockGridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void StockRecyclebin_uc_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void stockGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 1 || e.ColumnIndex == 2)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    SqlCommand cmd = new SqlCommand("RemoveStock", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@sid", stockGridView.Rows[e.RowIndex].Cells["Product_SID"].Value));

                    cmd.Parameters.Add(new SqlParameter("@data", e.ColumnIndex));
                    
                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    //Refreshing data
                    getData();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            ViewITemStock_uc vis = new ViewITemStock_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(vis);
            vis.Dock = DockStyle.Fill;
        }
    }
}
