﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.StockScreen.ItemStock
{
    public partial class ViewMoreDetail_uc : UserControl
    {
        int sid = 0;
        public ViewMoreDetail_uc(int a)
        {
            InitializeComponent();
            sid = a;
        }

        //global variable
        SqlCommand cmd;

        // Function to verify IMEI
        //private bool VerifyIMEI()
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        if (DB.con.State == ConnectionState.Closed)
        //            DB.con.Open();

        //        SqlCommand cmd = new SqlCommand("VerifyIMEI", DB.con) { CommandType = CommandType.StoredProcedure };
        //        cmd.Parameters.Add(new SqlParameter("@iid", dgvr.Cells["ItemID"].Value));

        //        if (!string.IsNullOrEmpty(IMEI1.Text) || !string.IsNullOrWhiteSpace(IMEI1.Text))
        //            cmd.Parameters.Add(new SqlParameter("@imei1", IMEI1.Text));

        //        if (!string.IsNullOrEmpty(IMEI2.Text) || !string.IsNullOrWhiteSpace(IMEI2.Text))
        //            cmd.Parameters.Add(new SqlParameter("@imei2", IMEI2.Text));

        //        dt.Load(cmd.ExecuteReader());
        //        DB.con.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //    if (dt.Rows.Count > 0)
        //        return false;
        //    else
        //        return true;
        //}

        // getting imei information
        private void getData()
        {
            if (DB.con.State == ConnectionState.Closed)
                DB.con.Open();
            try
            {
                
                DataTable data = new DataTable();

                cmd = new SqlCommand("StockDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));
                cmd.Parameters.Add(new SqlParameter("@sid", sid));

                data.Load(cmd.ExecuteReader());

                DB.con.Close();
                Product_Box.DataSource = data;
                Product_Box.ValueMember = "Box";

                Product_State.DataSource = data;
                Product_State.ValueMember = "Item_State";

                stockGridView.DataSource = data;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error");
            }
        }
        private void ViewMoreDetail_uc_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            ViewITemStock_uc vis = new ViewITemStock_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(vis);
            vis.Dock = DockStyle.Fill;
        }

        private void stockGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Update
            if (e.ColumnIndex == 0)
            {
                //if (VerifyIMEI())
                //{
                //    try
                //    {
                //        if (DB.con.State == ConnectionState.Closed)
                //            DB.con.Open();
                        
                //        cmd = new SqlCommand("UpdateStock", DB.con) { CommandType = CommandType.StoredProcedure };
                //        cmd.Parameters.Add(new SqlParameter("@imeiid", stockGridView.Rows[e.RowIndex].Cells["Product_IMEIID"].Value));
                //        cmd.Parameters.Add(new SqlParameter("@imei1", stockGridView.Rows[e.RowIndex].Cells["Product_IMEI1"].Value.ToString()));
                //        cmd.Parameters.Add(new SqlParameter("@imei2", stockGridView.Rows[e.RowIndex].Cells["Product_IMEI2"].Value.ToString()));
                //        cmd.Parameters.Add(new SqlParameter("@sp", Convert.ToDecimal(stockGridView.Rows[e.RowIndex].Cells["Product_SP"].Value)));

                //        if (stockGridView.Rows[e.RowIndex].Cells["Product_Box"].Value.ToString() == "Yes")
                //            cmd.Parameters.Add(new SqlParameter("@box", 1));
                //        else
                //            cmd.Parameters.Add(new SqlParameter("@box", 0));

                //        cmd.Parameters.Add(new SqlParameter("@warranty", stockGridView.Rows[e.RowIndex].Cells["Product_warranty"].Value.ToString()));

                //        if (stockGridView.Rows[e.RowIndex].Cells["Product_State"].Value.ToString() == "Used")
                //            cmd.Parameters.Add(new SqlParameter("@state", 1));
                //        else
                //            cmd.Parameters.Add(new SqlParameter("@state", 0));

                //        cmd.ExecuteNonQuery();

                //        //Refresh data
                //        getData();
                //    }
                //    catch (Exception ex)
                //    {
                //        MessageBox.Show(ex.Message);
                //    }
                //}
                //else
                //{
                //    MessageBox.Show("This IMEI is already exist");
                //}
            }
            // Delete
            if (e.ColumnIndex == 1)
            { 
                
            }
        }

        private void UpdateAllbtn_Click(object sender, EventArgs e)
        {
            UpdateProduct_uc up = new UpdateProduct_uc();
            up.ShowDialog();

            if (UpdateProduct_uc.chk > 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("UpdateStock", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 1));
                    cmd.Parameters.Add(new SqlParameter("@sid", stockGridView.Rows[0].Cells["Product_SID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@color", stockGridView.Rows[0].Cells["Product_Color"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@state", UpdateProduct_uc.state));
                    cmd.Parameters.Add(new SqlParameter("@sp", UpdateProduct_uc.sp));

                    if (stockGridView.Rows[0].Cells["Product_IMEI1"].ToString() == " ")
                        cmd.Parameters.Add(new SqlParameter("@default", 1));


                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                    //Refresh data
                    getData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
