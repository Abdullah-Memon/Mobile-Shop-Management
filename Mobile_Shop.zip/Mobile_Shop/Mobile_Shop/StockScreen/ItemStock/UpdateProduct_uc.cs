﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.StockScreen.ItemStock
{
    public partial class UpdateProduct_uc : Form
    {
        public UpdateProduct_uc()
        {
            InitializeComponent();
        }

        public static int chk, state;
        public static decimal sp;

        private void UpdateProduct_uc_Load(object sender, EventArgs e)
        {
            chk = 0;
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sell.Text) || !string.IsNullOrWhiteSpace(sell.Text))
            {
                sp = Convert.ToDecimal(sell.Text);
                state = typebox.SelectedIndex;
                chk = 1;
                this.Close();
            }
            else
                chk = 0;
        }

        private void closebtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
