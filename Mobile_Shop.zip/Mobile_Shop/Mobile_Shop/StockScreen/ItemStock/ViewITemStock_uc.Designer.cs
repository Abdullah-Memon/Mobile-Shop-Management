﻿namespace Mobile_Shop.StockScreen.ItemStock
{
    partial class ViewITemStock_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.Searchtxt = new System.Windows.Forms.Label();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.stockGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Product_SID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_IID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_IMEIID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.Product_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Brand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Color = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_QtyN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Details = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Update = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Product_Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.Controls.Add(this.Searchtxt);
            this.ContentPanel.Controls.Add(this.guna2CircleButton1);
            this.ContentPanel.Controls.Add(this.stockGridView);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(900, 548);
            this.ContentPanel.TabIndex = 1;
            this.ContentPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.ContentPanel_Paint);
            // 
            // Searchtxt
            // 
            this.Searchtxt.AutoSize = true;
            this.Searchtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchtxt.ForeColor = System.Drawing.Color.Indigo;
            this.Searchtxt.Location = new System.Drawing.Point(3, 21);
            this.Searchtxt.Name = "Searchtxt";
            this.Searchtxt.Size = new System.Drawing.Size(67, 22);
            this.Searchtxt.TabIndex = 24;
            this.Searchtxt.Text = "Search";
            this.Searchtxt.Click += new System.EventHandler(this.Searchtxt_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(857, 3);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(40, 40);
            this.guna2CircleButton1.TabIndex = 23;
            this.guna2CircleButton1.Text = "♻️";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // stockGridView
            // 
            this.stockGridView.AllowUserToAddRows = false;
            this.stockGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.stockGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.stockGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stockGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.stockGridView.BackgroundColor = System.Drawing.Color.White;
            this.stockGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.stockGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.stockGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.stockGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.stockGridView.ColumnHeadersHeight = 52;
            this.stockGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Product_SID,
            this.Product_IID,
            this.Product_IMEIID,
            this.Product_Picture,
            this.Product_Name,
            this.Product_Catagory,
            this.Product_Company,
            this.Product_Brand,
            this.Color,
            this.Product_Qty,
            this.Product_QtyN,
            this.Details,
            this.Update,
            this.Product_Delete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.stockGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.stockGridView.EnableHeadersVisualStyles = false;
            this.stockGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.stockGridView.Location = new System.Drawing.Point(3, 49);
            this.stockGridView.Name = "stockGridView";
            this.stockGridView.ReadOnly = true;
            this.stockGridView.RowHeadersVisible = false;
            this.stockGridView.RowTemplate.Height = 50;
            this.stockGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.stockGridView.Size = new System.Drawing.Size(894, 496);
            this.stockGridView.TabIndex = 0;
            this.stockGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.stockGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.stockGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.stockGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.stockGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.stockGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.stockGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.stockGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.stockGridView.ThemeStyle.HeaderStyle.Height = 52;
            this.stockGridView.ThemeStyle.ReadOnly = true;
            this.stockGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.stockGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.stockGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.stockGridView.ThemeStyle.RowsStyle.Height = 50;
            this.stockGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.stockGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.stockGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockGridView_CellContentClick);
            this.stockGridView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.stockGridView_KeyDown);
            // 
            // Product_SID
            // 
            this.Product_SID.DataPropertyName = "SID";
            this.Product_SID.HeaderText = "SID";
            this.Product_SID.Name = "Product_SID";
            this.Product_SID.ReadOnly = true;
            this.Product_SID.Visible = false;
            // 
            // Product_IID
            // 
            this.Product_IID.DataPropertyName = "IID";
            this.Product_IID.HeaderText = "IID";
            this.Product_IID.Name = "Product_IID";
            this.Product_IID.ReadOnly = true;
            this.Product_IID.Visible = false;
            // 
            // Product_IMEIID
            // 
            this.Product_IMEIID.DataPropertyName = "IMEIID";
            this.Product_IMEIID.HeaderText = "IMEIID";
            this.Product_IMEIID.Name = "Product_IMEIID";
            this.Product_IMEIID.ReadOnly = true;
            this.Product_IMEIID.Visible = false;
            // 
            // Product_Picture
            // 
            this.Product_Picture.DataPropertyName = "Item_Picture";
            this.Product_Picture.FillWeight = 50F;
            this.Product_Picture.HeaderText = "Picture";
            this.Product_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Product_Picture.Name = "Product_Picture";
            this.Product_Picture.ReadOnly = true;
            this.Product_Picture.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Product_Picture.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Product_Name
            // 
            this.Product_Name.DataPropertyName = "Item_Name";
            this.Product_Name.HeaderText = "Item Name";
            this.Product_Name.Name = "Product_Name";
            this.Product_Name.ReadOnly = true;
            // 
            // Product_Catagory
            // 
            this.Product_Catagory.DataPropertyName = "C_Name";
            this.Product_Catagory.HeaderText = "Catagory";
            this.Product_Catagory.Name = "Product_Catagory";
            this.Product_Catagory.ReadOnly = true;
            // 
            // Product_Company
            // 
            this.Product_Company.DataPropertyName = "COM_Name";
            this.Product_Company.HeaderText = "Company";
            this.Product_Company.Name = "Product_Company";
            this.Product_Company.ReadOnly = true;
            // 
            // Product_Brand
            // 
            this.Product_Brand.DataPropertyName = "B_Name";
            this.Product_Brand.HeaderText = "Brand";
            this.Product_Brand.Name = "Product_Brand";
            this.Product_Brand.ReadOnly = true;
            // 
            // Color
            // 
            this.Color.DataPropertyName = "Color";
            this.Color.HeaderText = "Color";
            this.Color.Name = "Color";
            this.Color.ReadOnly = true;
            // 
            // Product_Qty
            // 
            this.Product_Qty.DataPropertyName = "QTY";
            this.Product_Qty.HeaderText = "Qty";
            this.Product_Qty.Name = "Product_Qty";
            this.Product_Qty.ReadOnly = true;
            // 
            // Product_QtyN
            // 
            this.Product_QtyN.DataPropertyName = "QTY_N";
            this.Product_QtyN.HeaderText = "Notification at";
            this.Product_QtyN.Name = "Product_QtyN";
            this.Product_QtyN.ReadOnly = true;
            // 
            // Details
            // 
            this.Details.FillWeight = 50F;
            this.Details.HeaderText = "Details";
            this.Details.Name = "Details";
            this.Details.ReadOnly = true;
            this.Details.Text = "Details";
            this.Details.UseColumnTextForButtonValue = true;
            // 
            // Update
            // 
            this.Update.FillWeight = 50F;
            this.Update.HeaderText = "Update";
            this.Update.Name = "Update";
            this.Update.ReadOnly = true;
            this.Update.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Update.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Update.Text = "Update";
            this.Update.UseColumnTextForButtonValue = true;
            // 
            // Product_Delete
            // 
            this.Product_Delete.FillWeight = 50F;
            this.Product_Delete.HeaderText = "Delete";
            this.Product_Delete.Name = "Product_Delete";
            this.Product_Delete.ReadOnly = true;
            this.Product_Delete.Text = "Delete";
            this.Product_Delete.UseColumnTextForButtonValue = true;
            // 
            // ViewITemStock_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ContentPanel);
            this.Name = "ViewITemStock_uc";
            this.Size = new System.Drawing.Size(900, 548);
            this.Load += new System.EventHandler(this.ViewITemStock_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2DataGridView stockGridView;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private System.Windows.Forms.Label Searchtxt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_SID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_IID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_IMEIID;
        private System.Windows.Forms.DataGridViewImageColumn Product_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Company;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Brand;
        private System.Windows.Forms.DataGridViewTextBoxColumn Color;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_QtyN;
        private System.Windows.Forms.DataGridViewButtonColumn Details;
        private System.Windows.Forms.DataGridViewButtonColumn Update;
        private System.Windows.Forms.DataGridViewButtonColumn Product_Delete;
    }
}
