﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.StockScreen.ItemStock
{
    public partial class ViewITemStock_uc : UserControl
    {
        public ViewITemStock_uc()
        {
            InitializeComponent();
        }

        // Global Variables
        SqlCommand cmd;
        string search;

        // Function getting searched items details
        private void GetSearch(string a)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable data = new DataTable();
                cmd = new SqlCommand("StockDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 2));
                cmd.Parameters.Add(new SqlParameter("@search", a));
                data.Load(cmd.ExecuteReader());

                DB.con.Close();
                stockGridView.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching item please try again " + ex.Message, "Error");
            }
        }

        // Function changing data into number
        private string ConvertNumber(string a)
        {
            string number = null;
            if (a == "D1" || a == "NumPad1")
                number = "1";
            else if (a == "D2" || a == "NumPad2")
                number = "2";
            else if (a == "D3" || a == "NumPad3")
                number = "3";
            else if (a == "D4" || a == "NumPad4")
                number = "4";
            else if (a == "D5" || a == "NumPad5")
                number = "5";
            else if (a == "D6" || a == "NumPad6")
                number = "6";
            else if (a == "D7" || a == "NumPad7")
                number = "7";
            else if (a == "D8" || a == "NumPad8")
                number = "8";
            else if (a == "D9" || a == "NumPad9")
                number = "9";
            else if (a == "D0" || a == "NumPad0")
                number = "0";
            else
                number = a;
            return number;
        }

        // get stock data
        private void getData()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                DataTable data = new DataTable();
                cmd = new SqlCommand("StockDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                data.Load(cmd.ExecuteReader());

                stockGridView.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error");
               
            }
        }

        // Main load Function
        private void ViewITemStock_uc_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void stockGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //1 == Show more details
           // MessageBox.Show(e.ColumnIndex.ToString());
            //IMEI button coding
            if (e.ColumnIndex == 1)
            {
                int sendme = (int)stockGridView.Rows[e.RowIndex].Cells["Product_SID"].Value;
                ViewMoreDetail_uc vmd = new ViewMoreDetail_uc(sendme);
                ContentPanel.Controls.Clear();
                ContentPanel.Controls.Add(vmd);
                vmd.Dock = DockStyle.Fill;
            }
            if (e.ColumnIndex == 2)
            {
                if (MessageBox.Show("Are you sure you want to Delete Complete Stock; It might Effect all previous Record!","Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("RemoveStock",DB.con) { CommandType = CommandType.StoredProcedure};
                    cmd.Parameters.Add(new SqlParameter("@sid", stockGridView.Rows[e.RowIndex].Cells["Product_SID"].Value));
                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // Refreshing list
                    getData();
                }
            }
        }

        private void stockGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (Char.IsLetter((char)e.KeyData))
            {
                search += ConvertNumber(e.KeyData.ToString());
                Searchtxt.Text = search.ToString();
                GetSearch(search);
            }

            if (char.IsNumber((char)e.KeyData))
            {
                search += ConvertNumber(e.KeyData.ToString());
                Searchtxt.Text = search;
                GetSearch(search);
            }

            if (e.KeyData == Keys.Back || e.KeyData == Keys.Escape)
            {
                search = string.Empty;
                Searchtxt.Text = search;
                getData();
            }
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            StockRecyclebin_uc sr = new StockRecyclebin_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(sr);
            sr.Dock = DockStyle.Fill;
        }

        private void ContentPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Searchtxt_Click(object sender, EventArgs e)
        {

        }
    }
}
