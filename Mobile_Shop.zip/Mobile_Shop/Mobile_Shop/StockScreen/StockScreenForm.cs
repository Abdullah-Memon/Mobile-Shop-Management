﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.StockScreen
{
    public partial class StockScreenForm : UserControl
    {
        public StockScreenForm()
        {
            InitializeComponent();
        }

        private void addUserControl(UserControl uc)
        {
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }
        private void ViewStockbtn_Click(object sender, EventArgs e)
        {
            ItemStock.ViewITemStock_uc vis = new ItemStock.ViewITemStock_uc();
            addUserControl(vis);
        }

        private void StockScreenForm_Load(object sender, EventArgs e)
        {
            ViewStockbtn_Click(null, null);
        }
    }
}
