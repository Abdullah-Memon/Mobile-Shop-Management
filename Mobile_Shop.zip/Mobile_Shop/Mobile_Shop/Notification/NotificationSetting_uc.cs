﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Notification
{
    public partial class NotificationSetting_uc : UserControl
    {
        public NotificationSetting_uc()
        {
            InitializeComponent();
        }
        //Global vairables
        SqlCommand cmd;

        //Get Items Data
        private void GetItemsData()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();
                DataTable dt = new DataTable();
                
                cmd = new SqlCommand("NotificationDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                dt.Load(cmd.ExecuteReader());

                ItemsGridView.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Main Load Function
        private void NotificationSetting_uc_Load(object sender, EventArgs e)
        {
            GetItemsData();
        }

        //Grid view button coding
        private void ItemsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex.ToString());
            if (e.ColumnIndex == 0)
            {
                // sending values to database
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                    cmd = new SqlCommand("NotificationDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data",1));
                    cmd.Parameters.Add(new SqlParameter("@notify", ItemsGridView.Rows[e.RowIndex].Cells["Notify"].Value));
                    cmd.Parameters.Add(new SqlParameter("@itemid", ItemsGridView.Rows[e.RowIndex].Cells["ID"].Value));

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //refreshing page
                GetItemsData();
            }
        }

        //Default Notification Button Coding
        private void DefaultNotifyBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(DefaultNotifyBox.Text) || !string.IsNullOrWhiteSpace(DefaultNotifyBox.Text))
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                    cmd = new SqlCommand("NotificationDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 2));
                    cmd.Parameters.Add(new SqlParameter("@notify", Convert.ToInt16(DefaultNotifyBox.Text)));

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //refreshing page
                GetItemsData();
            }
        }

        //Back Button Coding
        private void BackBtn_Click(object sender, EventArgs e)
        {
            Settings.Settings_uc s = new Settings.Settings_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(s);
            s.Dock = DockStyle.Fill;
        }

        //Search Button Coding
        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SearchBox.Text) || !string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    cmd = new SqlCommand("NotificationDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 3));
                    cmd.Parameters.Add(new SqlParameter("@searchItem", SearchBox.Text));

                    dt.Load(cmd.ExecuteReader());
                    ItemsGridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
            else
                //refreshing page
                GetItemsData();
        }
    }
}
