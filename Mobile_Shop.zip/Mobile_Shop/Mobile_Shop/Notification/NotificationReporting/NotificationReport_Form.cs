﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.Notification.NotificationReporting
{
    public partial class NotificationReport_Form : Form
    {
        public NotificationReport_Form()
        {
            InitializeComponent();
        }

        // Main load function
        private void NotificationReport_Form_Load(object sender, EventArgs e)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("GenerateNotificationReport", DB.con) { CommandType = CommandType.StoredProcedure };
                dt.Load(cmd.ExecuteReader());

                NotificationReport_Page nrp = new NotificationReport_Page();
                nrp.DataSource = dt;

                InstanceReportSource irs = new InstanceReportSource() { ReportDocument = nrp };

                reportViewer1.ReportSource = irs;
                reportViewer1.RefreshReport();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Cross button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // maximize button coding
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Maximized)
                WindowState = FormWindowState.Maximized;
            else
                WindowState = FormWindowState.Normal;
        }

        //Minimize button coding
        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
