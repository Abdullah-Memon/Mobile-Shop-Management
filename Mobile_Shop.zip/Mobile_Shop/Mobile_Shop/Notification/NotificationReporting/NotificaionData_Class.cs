﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.Notification.NotificationReporting
{
    public class NotificaionData_Class
    {
        public static string COM_Name {set; get;}
        public static string Item_Name {set; get;}
        public static string C_Name {set; get;}
        public static string B_Name {set; get;}
        public static int QTY { set; get; }
    }
}
