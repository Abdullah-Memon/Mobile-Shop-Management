﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.Account.Reporting
{
    class AccountsReportDataClass
    {
        public byte[] A_Picture {set;get;} 
        public string A_Name {set;get;}
        public string A_CNIC {set;get;}
        public string A_Mobile {set;get;}
        public string A_EmailAddress {set;get;}
        public string A_Address { set; get; }
        public string A_Role { set; get; }
    }
}
