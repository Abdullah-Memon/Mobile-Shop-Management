﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.Account.Reporting
{
    public partial class GenerateAccountsReportForm : Form
    {
        int AccountSelected;
        public GenerateAccountsReportForm(int AccountType)
        {
            InitializeComponent();
            DB.connect();
            AccountSelected = AccountType;
        }
       

        // closing button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // main load function
        private void GenerateAccountsReportForm_Load(object sender, EventArgs e)
        {
            DataTable getdata = new DataTable();
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                SqlCommand cmd = new SqlCommand("GenerateAccountsReport", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@type", AccountSelected));
                getdata.Load(cmd.ExecuteReader());
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }


            AccountsReportPage arp = new AccountsReportPage();
            arp.DataSource = getdata;

            InstanceReportSource irs = new InstanceReportSource() { ReportDocument = arp };

            reportViewer1.ReportSource = irs;
            reportViewer1.RefreshReport();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Maximized;

            }
            else
            {
                WindowState = FormWindowState.Normal;
                
            }
        }

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
