﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.Account
{
    public partial class AccountsDashoboard_uc : UserControl
    {
        public AccountsDashoboard_uc()
        {
            InitializeComponent();
        }

        // function to manage user controls
        private void addUserControl(UserControl uc)
        {
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }

        // show accounts button coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            ViewAccounts_uc va = new ViewAccounts_uc();
            addUserControl(va);
        }

        // add accounts button coding
        private void AddAccountbtn_Click(object sender, EventArgs e)
        {
            AddAcounts_uc aa = new AddAcounts_uc();
            addUserControl(aa);
        }

        // generate Report button coding
        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            if (SelectedAccounts.Text != string.Empty)
            {
                Reporting.GenerateAccountsReportForm garf = new Reporting.GenerateAccountsReportForm(SelectedAccounts.SelectedIndex);
                garf.Show();
            }
            else
            {
                SelectedAccounts.Focus();
            }
        }

        // View Dues Button;
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            DUES.Dues_Form dpf = new DUES.Dues_Form();
            dpf.Show();
        }
    }
}
