﻿namespace Mobile_Shop.Account
{
    partial class AccountsRecycleBin_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.DeletedAccountsGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ACC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.ACC_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Restore = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ACC_Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.SelectedAccountType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.contentpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletedAccountsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // contentpanel
            // 
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.guna2GradientButton1);
            this.contentpanel.Controls.Add(this.guna2GradientButton2);
            this.contentpanel.Controls.Add(this.Backbtn);
            this.contentpanel.Controls.Add(this.DeletedAccountsGridView);
            this.contentpanel.Controls.Add(this.label14);
            this.contentpanel.Controls.Add(this.SelectedAccountType);
            this.contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 1;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(801, 12);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(89, 36);
            this.guna2GradientButton1.TabIndex = 15;
            this.guna2GradientButton1.Text = "Restore All";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton2.BorderRadius = 10;
            this.guna2GradientButton2.BorderThickness = 2;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(896, 12);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(89, 36);
            this.guna2GradientButton2.TabIndex = 16;
            this.guna2GradientButton2.Text = "Delete All";
            this.guna2GradientButton2.Click += new System.EventHandler(this.guna2GradientButton2_Click);
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(991, 5);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 22;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // DeletedAccountsGridView
            // 
            this.DeletedAccountsGridView.AllowUserToAddRows = false;
            this.DeletedAccountsGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedAccountsGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DeletedAccountsGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DeletedAccountsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeletedAccountsGridView.BackgroundColor = System.Drawing.Color.White;
            this.DeletedAccountsGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DeletedAccountsGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedAccountsGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DeletedAccountsGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DeletedAccountsGridView.ColumnHeadersHeight = 21;
            this.DeletedAccountsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACC_ID,
            this.ACC_Picture,
            this.ACC_Name,
            this.ACC_Role,
            this.ACC_CNIC,
            this.ACC_Mobile,
            this.ACC_Email,
            this.ACC_Address,
            this.ACC_Restore,
            this.ACC_Delete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DeletedAccountsGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.DeletedAccountsGridView.EnableHeadersVisualStyles = false;
            this.DeletedAccountsGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedAccountsGridView.Location = new System.Drawing.Point(0, 61);
            this.DeletedAccountsGridView.Name = "DeletedAccountsGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DeletedAccountsGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DeletedAccountsGridView.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.DeletedAccountsGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DeletedAccountsGridView.RowTemplate.Height = 70;
            this.DeletedAccountsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DeletedAccountsGridView.Size = new System.Drawing.Size(1060, 493);
            this.DeletedAccountsGridView.TabIndex = 21;
            this.DeletedAccountsGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.DeletedAccountsGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedAccountsGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DeletedAccountsGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DeletedAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DeletedAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DeletedAccountsGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DeletedAccountsGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedAccountsGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.DeletedAccountsGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DeletedAccountsGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DeletedAccountsGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedAccountsGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DeletedAccountsGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.DeletedAccountsGridView.ThemeStyle.ReadOnly = false;
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.Height = 70;
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.DeletedAccountsGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DeletedAccountsGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AccountsGridView_CellContentClick);
            // 
            // ACC_ID
            // 
            this.ACC_ID.DataPropertyName = "AID";
            this.ACC_ID.HeaderText = "ID";
            this.ACC_ID.Name = "ACC_ID";
            this.ACC_ID.Visible = false;
            // 
            // ACC_Picture
            // 
            this.ACC_Picture.DataPropertyName = "A_Picture";
            this.ACC_Picture.HeaderText = "Picture";
            this.ACC_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.ACC_Picture.Name = "ACC_Picture";
            // 
            // ACC_Name
            // 
            this.ACC_Name.DataPropertyName = "A_Name";
            this.ACC_Name.HeaderText = "Name";
            this.ACC_Name.Name = "ACC_Name";
            // 
            // ACC_Role
            // 
            this.ACC_Role.DataPropertyName = "A_Role";
            this.ACC_Role.HeaderText = "Role";
            this.ACC_Role.Name = "ACC_Role";
            // 
            // ACC_CNIC
            // 
            this.ACC_CNIC.DataPropertyName = "A_CNIC";
            this.ACC_CNIC.HeaderText = "CNIC";
            this.ACC_CNIC.Name = "ACC_CNIC";
            // 
            // ACC_Mobile
            // 
            this.ACC_Mobile.DataPropertyName = "A_Mobile";
            this.ACC_Mobile.HeaderText = "Mobile";
            this.ACC_Mobile.Name = "ACC_Mobile";
            // 
            // ACC_Email
            // 
            this.ACC_Email.DataPropertyName = "A_EmailAddress";
            this.ACC_Email.HeaderText = "Email";
            this.ACC_Email.Name = "ACC_Email";
            // 
            // ACC_Address
            // 
            this.ACC_Address.DataPropertyName = "A_Address";
            this.ACC_Address.HeaderText = "Address";
            this.ACC_Address.Name = "ACC_Address";
            // 
            // ACC_Restore
            // 
            this.ACC_Restore.FillWeight = 50F;
            this.ACC_Restore.HeaderText = "Restore";
            this.ACC_Restore.Name = "ACC_Restore";
            this.ACC_Restore.Text = "Restore";
            this.ACC_Restore.UseColumnTextForButtonValue = true;
            // 
            // ACC_Delete
            // 
            this.ACC_Delete.FillWeight = 50F;
            this.ACC_Delete.HeaderText = "Delete";
            this.ACC_Delete.Name = "ACC_Delete";
            this.ACC_Delete.Text = "Delete";
            this.ACC_Delete.UseColumnTextForButtonValue = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(18, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 20);
            this.label14.TabIndex = 17;
            this.label14.Text = "Account type";
            // 
            // SelectedAccountType
            // 
            this.SelectedAccountType.BackColor = System.Drawing.Color.Transparent;
            this.SelectedAccountType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedAccountType.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedAccountType.FocusedState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedAccountType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedAccountType.FormattingEnabled = true;
            this.SelectedAccountType.HoverState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.ItemHeight = 30;
            this.SelectedAccountType.Items.AddRange(new object[] {
            "All Accounts",
            "Supplier",
            "Customer"});
            this.SelectedAccountType.ItemsAppearance.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Location = new System.Drawing.Point(142, 15);
            this.SelectedAccountType.Name = "SelectedAccountType";
            this.SelectedAccountType.ShadowDecoration.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Size = new System.Drawing.Size(223, 36);
            this.SelectedAccountType.TabIndex = 15;
            this.SelectedAccountType.TextChanged += new System.EventHandler(this.guna2ComboBox1_TextChanged);
            // 
            // AccountsRecycleBin_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "AccountsRecycleBin_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.AccountsRecycleBin_uc_Load);
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletedAccountsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2DataGridView DeletedAccountsGridView;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedAccountType;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_ID;
        private System.Windows.Forms.DataGridViewImageColumn ACC_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Address;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Restore;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Delete;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;

    }
}
