﻿namespace Mobile_Shop.Account
{
    partial class AddAcounts_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.AddedAccountsGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ACC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.ACC_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Update = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label7 = new System.Windows.Forms.Label();
            this.AddItemsDetailsBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.accounttypebox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.mobilebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.addressbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.emailbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Additem = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label5 = new System.Windows.Forms.Label();
            this.profile = new Guna.UI2.WinForms.Guna2PictureBox();
            this.warning6 = new System.Windows.Forms.Label();
            this.warning5 = new System.Windows.Forms.Label();
            this.warning4 = new System.Windows.Forms.Label();
            this.warning3 = new System.Windows.Forms.Label();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.namebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.cnicbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.contentpanel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddedAccountsGridView)).BeginInit();
            this.AddItemsDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).BeginInit();
            this.SuspendLayout();
            // 
            // contentpanel
            // 
            this.contentpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.tableLayoutPanel1);
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.ShowAddedItemsDetailBox, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.AddItemsDetailsBox, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1060, 554);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.AddedAccountsGridView);
            this.ShowAddedItemsDetailBox.Controls.Add(this.Backbtn);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label7);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(373, 3);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(684, 548);
            this.ShowAddedItemsDetailBox.TabIndex = 7;
            // 
            // AddedAccountsGridView
            // 
            this.AddedAccountsGridView.AllowUserToAddRows = false;
            this.AddedAccountsGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AddedAccountsGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.AddedAccountsGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddedAccountsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AddedAccountsGridView.BackgroundColor = System.Drawing.Color.White;
            this.AddedAccountsGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AddedAccountsGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AddedAccountsGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AddedAccountsGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.AddedAccountsGridView.ColumnHeadersHeight = 21;
            this.AddedAccountsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACC_ID,
            this.ACC_Picture,
            this.ACC_Name,
            this.ACC_Role,
            this.ACC_CNIC,
            this.ACC_Mobile,
            this.ACC_Email,
            this.ACC_Address,
            this.ACC_Update});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AddedAccountsGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.AddedAccountsGridView.EnableHeadersVisualStyles = false;
            this.AddedAccountsGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AddedAccountsGridView.Location = new System.Drawing.Point(18, 65);
            this.AddedAccountsGridView.Name = "AddedAccountsGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AddedAccountsGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.AddedAccountsGridView.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.AddedAccountsGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.AddedAccountsGridView.RowTemplate.Height = 60;
            this.AddedAccountsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AddedAccountsGridView.Size = new System.Drawing.Size(660, 467);
            this.AddedAccountsGridView.TabIndex = 20;
            this.AddedAccountsGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.AddedAccountsGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AddedAccountsGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.AddedAccountsGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.AddedAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.AddedAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.AddedAccountsGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.AddedAccountsGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AddedAccountsGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.AddedAccountsGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AddedAccountsGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddedAccountsGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.AddedAccountsGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.AddedAccountsGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.AddedAccountsGridView.ThemeStyle.ReadOnly = false;
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.Height = 60;
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.AddedAccountsGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.AddedAccountsGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AddedAccountsGridView_CellContentClick);
            // 
            // ACC_ID
            // 
            this.ACC_ID.DataPropertyName = "AID";
            this.ACC_ID.HeaderText = "ID";
            this.ACC_ID.Name = "ACC_ID";
            this.ACC_ID.Visible = false;
            // 
            // ACC_Picture
            // 
            this.ACC_Picture.DataPropertyName = "A_Picture";
            this.ACC_Picture.FillWeight = 50F;
            this.ACC_Picture.HeaderText = "Picture";
            this.ACC_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.ACC_Picture.Name = "ACC_Picture";
            // 
            // ACC_Name
            // 
            this.ACC_Name.DataPropertyName = "A_Name";
            this.ACC_Name.HeaderText = "Name";
            this.ACC_Name.Name = "ACC_Name";
            // 
            // ACC_Role
            // 
            this.ACC_Role.DataPropertyName = "A_Role";
            this.ACC_Role.HeaderText = "Role";
            this.ACC_Role.Name = "ACC_Role";
            // 
            // ACC_CNIC
            // 
            this.ACC_CNIC.DataPropertyName = "A_CNIC";
            this.ACC_CNIC.HeaderText = "CNIC";
            this.ACC_CNIC.Name = "ACC_CNIC";
            // 
            // ACC_Mobile
            // 
            this.ACC_Mobile.DataPropertyName = "A_Mobile";
            this.ACC_Mobile.HeaderText = "Mobile";
            this.ACC_Mobile.Name = "ACC_Mobile";
            // 
            // ACC_Email
            // 
            this.ACC_Email.DataPropertyName = "A_EmailAddress";
            this.ACC_Email.HeaderText = "Email";
            this.ACC_Email.Name = "ACC_Email";
            // 
            // ACC_Address
            // 
            this.ACC_Address.DataPropertyName = "A_Address";
            this.ACC_Address.HeaderText = "Address";
            this.ACC_Address.Name = "ACC_Address";
            // 
            // ACC_Update
            // 
            this.ACC_Update.FillWeight = 50F;
            this.ACC_Update.HeaderText = "Update";
            this.ACC_Update.Name = "ACC_Update";
            this.ACC_Update.Text = "Update";
            this.ACC_Update.UseColumnTextForButtonValue = true;
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(628, 9);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(14, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 24);
            this.label7.TabIndex = 17;
            this.label7.Text = "Search";
            // 
            // AddItemsDetailsBox
            // 
            this.AddItemsDetailsBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddItemsDetailsBox.BorderRadius = 10;
            this.AddItemsDetailsBox.Controls.Add(this.accounttypebox);
            this.AddItemsDetailsBox.Controls.Add(this.mobilebox);
            this.AddItemsDetailsBox.Controls.Add(this.addressbox);
            this.AddItemsDetailsBox.Controls.Add(this.emailbox);
            this.AddItemsDetailsBox.Controls.Add(this.Additem);
            this.AddItemsDetailsBox.Controls.Add(this.guna2GradientButton1);
            this.AddItemsDetailsBox.Controls.Add(this.label5);
            this.AddItemsDetailsBox.Controls.Add(this.profile);
            this.AddItemsDetailsBox.Controls.Add(this.warning6);
            this.AddItemsDetailsBox.Controls.Add(this.warning5);
            this.AddItemsDetailsBox.Controls.Add(this.warning4);
            this.AddItemsDetailsBox.Controls.Add(this.warning3);
            this.AddItemsDetailsBox.Controls.Add(this.warning2);
            this.AddItemsDetailsBox.Controls.Add(this.warning1);
            this.AddItemsDetailsBox.Controls.Add(this.label2);
            this.AddItemsDetailsBox.Controls.Add(this.label8);
            this.AddItemsDetailsBox.Controls.Add(this.label3);
            this.AddItemsDetailsBox.Controls.Add(this.label6);
            this.AddItemsDetailsBox.Controls.Add(this.label4);
            this.AddItemsDetailsBox.Controls.Add(this.namebox);
            this.AddItemsDetailsBox.Controls.Add(this.cnicbox);
            this.AddItemsDetailsBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AddItemsDetailsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddItemsDetailsBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AddItemsDetailsBox.Location = new System.Drawing.Point(3, 3);
            this.AddItemsDetailsBox.Name = "AddItemsDetailsBox";
            this.AddItemsDetailsBox.ShadowDecoration.Parent = this.AddItemsDetailsBox;
            this.AddItemsDetailsBox.Size = new System.Drawing.Size(364, 548);
            this.AddItemsDetailsBox.TabIndex = 6;
            // 
            // accounttypebox
            // 
            this.accounttypebox.BackColor = System.Drawing.Color.Transparent;
            this.accounttypebox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.accounttypebox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.accounttypebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.accounttypebox.FocusedColor = System.Drawing.Color.Empty;
            this.accounttypebox.FocusedState.Parent = this.accounttypebox;
            this.accounttypebox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.accounttypebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.accounttypebox.FormattingEnabled = true;
            this.accounttypebox.HoverState.Parent = this.accounttypebox;
            this.accounttypebox.ItemHeight = 30;
            this.accounttypebox.Items.AddRange(new object[] {
            "None",
            "Supplier",
            "Customer"});
            this.accounttypebox.ItemsAppearance.Parent = this.accounttypebox;
            this.accounttypebox.Location = new System.Drawing.Point(15, 40);
            this.accounttypebox.Name = "accounttypebox";
            this.accounttypebox.ShadowDecoration.Parent = this.accounttypebox;
            this.accounttypebox.Size = new System.Drawing.Size(336, 36);
            this.accounttypebox.TabIndex = 0;
            // 
            // mobilebox
            // 
            this.mobilebox.BorderRadius = 10;
            this.mobilebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mobilebox.DefaultText = "";
            this.mobilebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.mobilebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.mobilebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mobilebox.DisabledState.Parent = this.mobilebox;
            this.mobilebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.mobilebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.mobilebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mobilebox.FocusedState.Parent = this.mobilebox;
            this.mobilebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.mobilebox.HoverState.Parent = this.mobilebox;
            this.mobilebox.Location = new System.Drawing.Point(15, 274);
            this.mobilebox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.mobilebox.Name = "mobilebox";
            this.mobilebox.PasswordChar = '\0';
            this.mobilebox.PlaceholderText = "";
            this.mobilebox.SelectedText = "";
            this.mobilebox.ShadowDecoration.Parent = this.mobilebox;
            this.mobilebox.Size = new System.Drawing.Size(336, 37);
            this.mobilebox.TabIndex = 3;
            this.mobilebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mobilebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cnicbox_KeyPress);
            // 
            // addressbox
            // 
            this.addressbox.BorderRadius = 10;
            this.addressbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.addressbox.DefaultText = "";
            this.addressbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.addressbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.addressbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.addressbox.DisabledState.Parent = this.addressbox;
            this.addressbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.addressbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.addressbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.addressbox.FocusedState.Parent = this.addressbox;
            this.addressbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.addressbox.HoverState.Parent = this.addressbox;
            this.addressbox.Location = new System.Drawing.Point(15, 412);
            this.addressbox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.addressbox.Name = "addressbox";
            this.addressbox.PasswordChar = '\0';
            this.addressbox.PlaceholderText = "";
            this.addressbox.SelectedText = "";
            this.addressbox.ShadowDecoration.Parent = this.addressbox;
            this.addressbox.Size = new System.Drawing.Size(336, 37);
            this.addressbox.TabIndex = 5;
            this.addressbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // emailbox
            // 
            this.emailbox.BorderRadius = 10;
            this.emailbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailbox.DefaultText = "";
            this.emailbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.emailbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.emailbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailbox.DisabledState.Parent = this.emailbox;
            this.emailbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.emailbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailbox.FocusedState.Parent = this.emailbox;
            this.emailbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailbox.HoverState.Parent = this.emailbox;
            this.emailbox.Location = new System.Drawing.Point(15, 340);
            this.emailbox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.emailbox.Name = "emailbox";
            this.emailbox.PasswordChar = '\0';
            this.emailbox.PlaceholderText = "";
            this.emailbox.SelectedText = "";
            this.emailbox.ShadowDecoration.Parent = this.emailbox;
            this.emailbox.Size = new System.Drawing.Size(336, 37);
            this.emailbox.TabIndex = 4;
            this.emailbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Additem
            // 
            this.Additem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Additem.BackColor = System.Drawing.Color.Transparent;
            this.Additem.BorderColor = System.Drawing.Color.White;
            this.Additem.BorderRadius = 10;
            this.Additem.BorderThickness = 2;
            this.Additem.CheckedState.Parent = this.Additem;
            this.Additem.CustomImages.Parent = this.Additem;
            this.Additem.FillColor = System.Drawing.Color.Indigo;
            this.Additem.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Additem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Additem.ForeColor = System.Drawing.Color.White;
            this.Additem.HoverState.Parent = this.Additem;
            this.Additem.Location = new System.Drawing.Point(109, 492);
            this.Additem.Name = "Additem";
            this.Additem.ShadowDecoration.Parent = this.Additem;
            this.Additem.Size = new System.Drawing.Size(153, 50);
            this.Additem.TabIndex = 7;
            this.Additem.Text = "ADD";
            this.Additem.Click += new System.EventHandler(this.Additem_Click);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(239, 233);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(106, 36);
            this.guna2GradientButton1.TabIndex = 6;
            this.guna2GradientButton1.Text = "Upload";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(23, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 19);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mobile";
            // 
            // profile
            // 
            this.profile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.profile.BorderRadius = 10;
            this.profile.FillColor = System.Drawing.Color.WhiteSmoke;
            this.profile.Location = new System.Drawing.Point(235, 112);
            this.profile.Name = "profile";
            this.profile.ShadowDecoration.Parent = this.profile;
            this.profile.Size = new System.Drawing.Size(115, 115);
            this.profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profile.TabIndex = 4;
            this.profile.TabStop = false;
            // 
            // warning6
            // 
            this.warning6.AutoSize = true;
            this.warning6.ForeColor = System.Drawing.Color.Red;
            this.warning6.Location = new System.Drawing.Point(94, 470);
            this.warning6.Name = "warning6";
            this.warning6.Size = new System.Drawing.Size(156, 19);
            this.warning6.TabIndex = 1;
            this.warning6.Text = "* Account Already Exists";
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.ForeColor = System.Drawing.Color.Red;
            this.warning5.Location = new System.Drawing.Point(185, 388);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(146, 19);
            this.warning5.TabIndex = 1;
            this.warning5.Text = "* Please Enter Address";
            // 
            // warning4
            // 
            this.warning4.AutoSize = true;
            this.warning4.ForeColor = System.Drawing.Color.Red;
            this.warning4.Location = new System.Drawing.Point(80, 250);
            this.warning4.Name = "warning4";
            this.warning4.Size = new System.Drawing.Size(139, 19);
            this.warning4.TabIndex = 1;
            this.warning4.Text = "* Please Enter Mobile";
            // 
            // warning3
            // 
            this.warning3.AutoSize = true;
            this.warning3.ForeColor = System.Drawing.Color.Red;
            this.warning3.Location = new System.Drawing.Point(70, 176);
            this.warning3.Name = "warning3";
            this.warning3.Size = new System.Drawing.Size(129, 19);
            this.warning3.TabIndex = 1;
            this.warning3.Text = "* Please Enter CNIC";
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(70, 103);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(133, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Please Enter Name";
            // 
            // warning1
            // 
            this.warning1.AutoSize = true;
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(171, 18);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(180, 19);
            this.warning1.TabIndex = 1;
            this.warning1.Text = "* Please select Account type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(19, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Account Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(19, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(23, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "CNIC";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(23, 388);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 19);
            this.label6.TabIndex = 1;
            this.label6.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(23, 316);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Email Address";
            // 
            // namebox
            // 
            this.namebox.BorderRadius = 10;
            this.namebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namebox.DefaultText = "";
            this.namebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.namebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.namebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.DisabledState.Parent = this.namebox;
            this.namebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.namebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.FocusedState.Parent = this.namebox;
            this.namebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namebox.HoverState.Parent = this.namebox;
            this.namebox.Location = new System.Drawing.Point(15, 131);
            this.namebox.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.namebox.Name = "namebox";
            this.namebox.PasswordChar = '\0';
            this.namebox.PlaceholderText = "";
            this.namebox.SelectedText = "";
            this.namebox.ShadowDecoration.Parent = this.namebox;
            this.namebox.Size = new System.Drawing.Size(200, 36);
            this.namebox.TabIndex = 1;
            this.namebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cnicbox
            // 
            this.cnicbox.BorderRadius = 10;
            this.cnicbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cnicbox.DefaultText = "";
            this.cnicbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cnicbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cnicbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cnicbox.DisabledState.Parent = this.cnicbox;
            this.cnicbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cnicbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.cnicbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cnicbox.FocusedState.Parent = this.cnicbox;
            this.cnicbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cnicbox.HoverState.Parent = this.cnicbox;
            this.cnicbox.Location = new System.Drawing.Point(15, 200);
            this.cnicbox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cnicbox.Name = "cnicbox";
            this.cnicbox.PasswordChar = '\0';
            this.cnicbox.PlaceholderText = "";
            this.cnicbox.SelectedText = "";
            this.cnicbox.ShadowDecoration.Parent = this.cnicbox;
            this.cnicbox.Size = new System.Drawing.Size(200, 36);
            this.cnicbox.TabIndex = 2;
            this.cnicbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cnicbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cnicbox_KeyPress);
            // 
            // AddAcounts_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "AddAcounts_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.AddAcounts_uc_Load);
            this.contentpanel.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddedAccountsGridView)).EndInit();
            this.AddItemsDetailsBox.ResumeLayout(false);
            this.AddItemsDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2DataGridView AddedAccountsGridView;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2GroupBox AddItemsDetailsBox;
        private Guna.UI2.WinForms.Guna2GradientButton Additem;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2PictureBox profile;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox namebox;
        private Guna.UI2.WinForms.Guna2TextBox cnicbox;
        private Guna.UI2.WinForms.Guna2TextBox mobilebox;
        private Guna.UI2.WinForms.Guna2TextBox addressbox;
        private Guna.UI2.WinForms.Guna2TextBox emailbox;
        private Guna.UI2.WinForms.Guna2ComboBox accounttypebox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label warning4;
        private System.Windows.Forms.Label warning3;
        private System.Windows.Forms.Label warning2;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Label warning6;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_ID;
        private System.Windows.Forms.DataGridViewImageColumn ACC_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Address;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Update;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;

    }
}
