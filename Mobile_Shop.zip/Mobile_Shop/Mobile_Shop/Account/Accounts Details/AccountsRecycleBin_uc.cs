﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Account
{
    public partial class AccountsRecycleBin_uc : UserControl
    {
        public AccountsRecycleBin_uc()
        {
            InitializeComponent();
        }

        // global variables
        SqlCommand cmd;

        // getting deleted accounts information
        private void getdeletedaccountdata()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }

            try
            {
                DataTable accountsinfo = new DataTable();
                cmd = new SqlCommand("AccountsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status",1));
                accountsinfo.Load(cmd.ExecuteReader());

                DB.con.Close();

                DeletedAccountsGridView.DataSource = accountsinfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error while getting accounts data " + ex.ToString(), "ERROR");
            }
        }

        //Main load function
        private void AccountsRecycleBin_uc_Load(object sender, EventArgs e)
        {
            getdeletedaccountdata();
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            ViewAccounts_uc va = new ViewAccounts_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(va);
            va.Dock = DockStyle.Fill;
        }

        // finding account by account type
        private void guna2ComboBox1_TextChanged(object sender, EventArgs e)
        {
            if (SelectedAccountType.Text.ToLower() != "all accounts")
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    DataTable foundAccountsdata = new DataTable();

                    cmd = new SqlCommand("findAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@role", SelectedAccountType.Text.ToLower()));
                    cmd.Parameters.Add(new SqlParameter("@status", 1));

                    foundAccountsdata.Load(cmd.ExecuteReader());

                    DB.con.Close();

                    //setting up new data
                    DeletedAccountsGridView.DataSource = foundAccountsdata;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while founding accounts please try again " + ex.ToString(), "ERROR");
                }
            }
            else
            { getdeletedaccountdata(); }
        }

        // grid view button coding
        private void AccountsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //0 == restore and 1 == parmanentdelete

            //restore button coding
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@executefrom", 1));
                    cmd.Parameters.Add(new SqlParameter("@id", DeletedAccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value));
                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    //refresing deleted data
                    getdeletedaccountdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while restoring data Please try again " + ex.ToString(), "Error");
                }
            }

            // paramanently delete button coding
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure you want to parmantly delete selected Account? ","Confirmation",MessageBoxButtons.YesNo)== DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("RemoveAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@id", DeletedAccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value));
                        cmd.ExecuteNonQuery();
                        DB.con.Close();

                        // refreshing recyclebin data
                        getdeletedaccountdata();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while parmanently delete accounts please try again " + ex.ToString(), "ERROR");
                    }
                }
            }
        }

        // all data restore button coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            for (int i = 0; i < DeletedAccountsGridView.Rows.Count; i++)
            {
                cmd = new SqlCommand("UpdateAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@executefrom", 1));
                cmd.Parameters.Add(new SqlParameter("@id", DeletedAccountsGridView.Rows[i].Cells["ACC_ID"].Value));
                cmd.ExecuteNonQuery();
            }
            DB.con.Close();

            //refreshing gridview
            getdeletedaccountdata();
        }

        // all data delete button coding
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete all data parmanently? ","Confirmation",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                for (int i = 0; i < DeletedAccountsGridView.Rows.Count; i++)
                {
                    cmd = new SqlCommand("RemoveAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", DeletedAccountsGridView.Rows[i].Cells["ACC_ID"].Value));
                    cmd.ExecuteNonQuery();
                }
                DB.con.Close();

                //refreshing gridview
                getdeletedaccountdata();
            }
        }
    }
}
