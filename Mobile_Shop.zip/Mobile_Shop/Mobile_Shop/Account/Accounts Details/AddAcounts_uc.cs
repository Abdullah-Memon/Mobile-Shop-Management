﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Account
{
    public partial class AddAcounts_uc : UserControl
    {
        public AddAcounts_uc()
        {
            InitializeComponent();
        }
        // global variables
        SqlCommand cmd;

        // add account button coding
        private void Additem_Click(object sender, EventArgs e)
        {
            //resting warinings 
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
            warning6.Hide();

            // checing provided information
            if ((accounttypebox.Text != "None" || accounttypebox.Text != string.Empty) && namebox.Text != string.Empty && cnicbox.Text != string.Empty && mobilebox.Text != string.Empty && addressbox.Text != string.Empty && profile.Image != null)
            {
                if (accounttypebox.Text.ToLower() == "supplier" || accounttypebox.Text.ToLower() == "customer")
                {
                    // adding new data
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        ImageConverter img = new ImageConverter();
                        byte[] pic = (byte[])img.ConvertTo(profile.Image, Type.GetType("System.Byte[]"));
                        
                        cmd = new SqlCommand("AddAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@picture", pic));
                        cmd.Parameters.Add(new SqlParameter("@name", namebox.Text));
                        cmd.Parameters.Add(new SqlParameter("@rolestatus", accounttypebox.Text.ToLower()));
                        cmd.Parameters.Add(new SqlParameter("@CNIC", cnicbox.Text));
                        cmd.Parameters.Add(new SqlParameter("@Mobile", mobilebox.Text));
                        cmd.Parameters.Add(new SqlParameter("@email", emailbox.Text));
                        cmd.Parameters.Add(new SqlParameter("@address", addressbox.Text));

                        int chk = cmd.ExecuteNonQuery();
                        DB.con.Close();

                        if (chk == 0)
                        {
                            warning6.Show();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while Adding new Accounts Please try again " + ex.ToString(), "Error");
                    }

                    // refreshing new data
                    getaccountdata();

                    //clearing all information
                    namebox.Text = string.Empty;
                    cnicbox.Text = string.Empty;
                    mobilebox.Text = string.Empty;
                    emailbox.Text = string.Empty;
                    addressbox.Text = string.Empty;
                }
            }
                // focusing empty or invalid informations
            else
            {
                if (accounttypebox.Text == "None" || accounttypebox.Text == string.Empty)
                {
                    accounttypebox.Focus();
                    warning1.Show();
                }
                else if (namebox.Text == string.Empty)
                {
                    namebox.Focus();
                    warning2.Show();
                }
                else if (cnicbox.Text == string.Empty)
                {
                    cnicbox.Focus();
                    warning3.Show();
                }
                else if (mobilebox.Text == string.Empty)
                {
                    mobilebox.Focus();
                    warning4.Show();
                }
                
                else if (addressbox.Text == string.Empty)
                {
                    addressbox.Focus();
                    warning5.Show();
                }
                else
                {
                    MessageBox.Show("Please enter Profile picture or restart the application", "Error");
                }

            }
        }

        //getting already added accounts data
        private void getaccountdata()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }

            try
            {
                DataTable accountsinfo = new DataTable();
                cmd = new SqlCommand("AccountsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                accountsinfo.Load(cmd.ExecuteReader());

                DB.con.Close();

                AddedAccountsGridView.DataSource = accountsinfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error while getting accounts data " + ex.ToString(), "ERROR");
            }
        }

        // main usercontrol load function
        private void AddAcounts_uc_Load(object sender, EventArgs e)
        {
            getaccountdata();

            // hiding all warnings
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
            warning6.Hide();

            accounttypebox.Focus();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.Filter = "Image file (*.jpg; *.jpeg; *.png; *.bmp; *.gif;) | *.jpg; *.jpeg; *.png; *.bmp; *.gif;";
                opf.Multiselect = false;

                if (opf.ShowDialog() == DialogResult.OK)
                {
                    profile.Image = Image.FromFile(opf.FileName);    
                }

            }
        }

        // Back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            AccountsDashoboard_uc ad = new AccountsDashoboard_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(ad);
            ad.Dock = DockStyle.Fill;
        }

        //grid view button coding
        private void AddedAccountsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            // update button coding
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@name", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Name"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@rolestatus", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Role"].Value.ToString().ToLower()));
                    cmd.Parameters.Add(new SqlParameter("@CNIC", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_CNIC"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@Mobile", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Mobile"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@email", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Email"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@address", AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Address"].Value.ToString()));

                    byte[] pic = (byte[]) AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Picture"].Value;
                    cmd.Parameters.Add(new SqlParameter("@picture", pic));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // refreshing the new information
                    getaccountdata();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating Accounts please try again " + ex.ToString(), "ERROR");
                }
            
            }

            // picture button coding
            if (e.ColumnIndex == 2)
            {
                using (OpenFileDialog opf = new OpenFileDialog())
                {
                    opf.Filter = "Image file (*.jpg; *.jpeg; *.png; *.bmp; *.gif;) | *.jpg; *.jpeg; *.png; *.bmp; *.gif;";
                    opf.Multiselect = false;

                    if (opf.ShowDialog() == DialogResult.OK)
                    {
                        AddedAccountsGridView.Rows[e.RowIndex].Cells["ACC_Picture"].Value = Image.FromFile(opf.FileName);
                    }
                }
            }
        }

        private void cnicbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '-'))
                e.Handled = true;
        }

    }
}
