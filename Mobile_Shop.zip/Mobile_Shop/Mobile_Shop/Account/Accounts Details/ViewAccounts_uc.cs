﻿ using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Account
{
    public partial class ViewAccounts_uc : UserControl
    {
        public ViewAccounts_uc()
        {
            InitializeComponent();
        }
        // global vairable
        SqlCommand cmd;
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            AddAcounts_uc aa = new AddAcounts_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(aa);
        }

        private void getaccountdata()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }

            try
            {
                DataTable accountsinfo = new DataTable();
                cmd = new SqlCommand("AccountsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                accountsinfo.Load(cmd.ExecuteReader());

                DB.con.Close();

                AccountsGridView.DataSource = accountsinfo;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error while getting accounts data " + ex.ToString(), "ERROR");
            }
        }

        private void ViewAccounts_uc_Load(object sender, EventArgs e)
        {
            getaccountdata();
        }

        // grid view buttons coding
        private void AccountsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 0 == Update and 2 == delete 4== picture
            
            // update button coding
            if (e.ColumnIndex == 0)
            {
                
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", AccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@name", AccountsGridView.Rows[e.RowIndex].Cells["ACC_Name"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@rolestatus", AccountsGridView.Rows[e.RowIndex].Cells["ACC_Role"].Value.ToString().ToLower()));
                    cmd.Parameters.Add(new SqlParameter("@CNIC", AccountsGridView.Rows[e.RowIndex].Cells["ACC_CNIC"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@Mobile", AccountsGridView.Rows[e.RowIndex].Cells["ACC_Mobile"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@email", AccountsGridView.Rows[e.RowIndex].Cells["ACC_Email"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@address", AccountsGridView.Rows[e.RowIndex].Cells["ACC_Address"].Value.ToString()));

                    byte[] pic = (byte[])AccountsGridView.Rows[e.RowIndex].Cells["ACC_Picture"].Value;
                    cmd.Parameters.Add(new SqlParameter("@picture", pic));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // refreshing the new information
                    getaccountdata();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating Accounts please try again " + ex.ToString(), "ERROR");
                }

            }

            //particular Reporting
            if (e.ColumnIndex ==1)
            {
                
            }

            //delete button coding
            if (e.ColumnIndex == 2)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("RemoveAccounts", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@id", AccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value));
                    
                    cmd.ExecuteNonQuery();
                    DB.con.Close();

                    // refreshing the new information
                    getaccountdata();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting Accounts please try again " + ex.ToString(), "ERROR");
                }
            }
            // picture button coding
            if (e.ColumnIndex == 4)
            {
                using (OpenFileDialog opf = new OpenFileDialog())
                {
                    opf.Filter = "Image file (*.jpg; *.jpeg; *.png; *.bmp; *.gif;) | *.jpg; *.jpeg; *.png; *.bmp; *.gif;";
                    opf.Multiselect = false;

                    if (opf.ShowDialog() == DialogResult.OK)
                    {
                        AccountsGridView.Rows[e.RowIndex].Cells["ACC_Picture"].Value = Image.FromFile(opf.FileName);
                    }
                }
            }
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            AccountsRecycleBin_uc arb = new AccountsRecycleBin_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(arb);
            arb.Dock = DockStyle.Fill;
        }

        // searching account through account type
        private void SelectedAccountType_TextChanged(object sender, EventArgs e)
        {
            if (SelectedAccountType.SelectedIndex > 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    DataTable foundAccountsdata = new DataTable();
                    
                    cmd = new SqlCommand("AccountsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@type", SelectedAccountType.SelectedIndex));
                    // MessageBox.Show(SelectedAccountType.SelectedIndex.ToString());
                    
                    foundAccountsdata.Load(cmd.ExecuteReader());

                    DB.con.Close();

                    //setting up new data
                    AccountsGridView.DataSource = foundAccountsdata;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while founding accounts please try again " + ex.ToString(), "ERROR");
                }
            }
            else
            { getaccountdata(); }
        }

        // back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            AccountsDashoboard_uc ad = new AccountsDashoboard_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(ad);
            ad.Dock = DockStyle.Fill;
        }

        private void SelectedAccountType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
