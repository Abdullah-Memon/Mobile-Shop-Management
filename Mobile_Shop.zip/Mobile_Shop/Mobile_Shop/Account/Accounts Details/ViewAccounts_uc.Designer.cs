﻿namespace Mobile_Shop.Account
{
    partial class ViewAccounts_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.AccountsGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ACC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.ACC_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Update = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ACC_Report = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ACC_Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.SelectedAccountType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.contentpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AccountsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // contentpanel
            // 
            this.contentpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.Backbtn);
            this.contentpanel.Controls.Add(this.guna2CircleButton1);
            this.contentpanel.Controls.Add(this.AccountsGridView);
            this.contentpanel.Controls.Add(this.label14);
            this.contentpanel.Controls.Add(this.SelectedAccountType);
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 0;
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(996, 5);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 22;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(940, 5);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton1.TabIndex = 22;
            this.guna2CircleButton1.Text = "♻️";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // AccountsGridView
            // 
            this.AccountsGridView.AllowUserToAddRows = false;
            this.AccountsGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AccountsGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.AccountsGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AccountsGridView.BackgroundColor = System.Drawing.Color.White;
            this.AccountsGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AccountsGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AccountsGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AccountsGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.AccountsGridView.ColumnHeadersHeight = 21;
            this.AccountsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACC_ID,
            this.ACC_Picture,
            this.ACC_Name,
            this.ACC_Role,
            this.ACC_CNIC,
            this.ACC_Mobile,
            this.ACC_Email,
            this.ACC_Address,
            this.ACC_Update,
            this.ACC_Report,
            this.ACC_Delete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AccountsGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.AccountsGridView.EnableHeadersVisualStyles = false;
            this.AccountsGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AccountsGridView.Location = new System.Drawing.Point(0, 61);
            this.AccountsGridView.Name = "AccountsGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AccountsGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.AccountsGridView.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.AccountsGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.AccountsGridView.RowTemplate.Height = 70;
            this.AccountsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AccountsGridView.Size = new System.Drawing.Size(1060, 493);
            this.AccountsGridView.TabIndex = 21;
            this.AccountsGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.AccountsGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AccountsGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.AccountsGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.AccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.AccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.AccountsGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.AccountsGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AccountsGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.AccountsGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AccountsGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AccountsGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.AccountsGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.AccountsGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.AccountsGridView.ThemeStyle.ReadOnly = false;
            this.AccountsGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.AccountsGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AccountsGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AccountsGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.AccountsGridView.ThemeStyle.RowsStyle.Height = 70;
            this.AccountsGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.AccountsGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.AccountsGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AccountsGridView_CellContentClick);
            // 
            // ACC_ID
            // 
            this.ACC_ID.DataPropertyName = "AID";
            this.ACC_ID.HeaderText = "ID";
            this.ACC_ID.Name = "ACC_ID";
            this.ACC_ID.Visible = false;
            // 
            // ACC_Picture
            // 
            this.ACC_Picture.DataPropertyName = "A_Picture";
            this.ACC_Picture.FillWeight = 50F;
            this.ACC_Picture.HeaderText = "Picture";
            this.ACC_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.ACC_Picture.Name = "ACC_Picture";
            // 
            // ACC_Name
            // 
            this.ACC_Name.DataPropertyName = "A_Name";
            this.ACC_Name.HeaderText = "Name";
            this.ACC_Name.Name = "ACC_Name";
            // 
            // ACC_Role
            // 
            this.ACC_Role.DataPropertyName = "A_Role";
            this.ACC_Role.HeaderText = "Role";
            this.ACC_Role.Name = "ACC_Role";
            // 
            // ACC_CNIC
            // 
            this.ACC_CNIC.DataPropertyName = "A_CNIC";
            this.ACC_CNIC.HeaderText = "CNIC";
            this.ACC_CNIC.Name = "ACC_CNIC";
            // 
            // ACC_Mobile
            // 
            this.ACC_Mobile.DataPropertyName = "A_Mobile";
            this.ACC_Mobile.HeaderText = "Mobile";
            this.ACC_Mobile.Name = "ACC_Mobile";
            // 
            // ACC_Email
            // 
            this.ACC_Email.DataPropertyName = "A_EmailAddress";
            this.ACC_Email.HeaderText = "Email";
            this.ACC_Email.Name = "ACC_Email";
            // 
            // ACC_Address
            // 
            this.ACC_Address.DataPropertyName = "A_Address";
            this.ACC_Address.HeaderText = "Address";
            this.ACC_Address.Name = "ACC_Address";
            // 
            // ACC_Update
            // 
            this.ACC_Update.FillWeight = 50F;
            this.ACC_Update.HeaderText = "Update";
            this.ACC_Update.Name = "ACC_Update";
            this.ACC_Update.Text = "Update";
            this.ACC_Update.UseColumnTextForButtonValue = true;
            // 
            // ACC_Report
            // 
            this.ACC_Report.FillWeight = 50F;
            this.ACC_Report.HeaderText = "Print";
            this.ACC_Report.Name = "ACC_Report";
            this.ACC_Report.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ACC_Report.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ACC_Report.Text = "Print";
            this.ACC_Report.UseColumnTextForButtonValue = true;
            // 
            // ACC_Delete
            // 
            this.ACC_Delete.FillWeight = 50F;
            this.ACC_Delete.HeaderText = "Delete";
            this.ACC_Delete.Name = "ACC_Delete";
            this.ACC_Delete.Text = "Delete";
            this.ACC_Delete.UseColumnTextForButtonValue = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(18, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 20);
            this.label14.TabIndex = 17;
            this.label14.Text = "Account type";
            // 
            // SelectedAccountType
            // 
            this.SelectedAccountType.BackColor = System.Drawing.Color.Transparent;
            this.SelectedAccountType.BorderRadius = 10;
            this.SelectedAccountType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedAccountType.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedAccountType.FocusedState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedAccountType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedAccountType.FormattingEnabled = true;
            this.SelectedAccountType.HoverState.Parent = this.SelectedAccountType;
            this.SelectedAccountType.ItemHeight = 30;
            this.SelectedAccountType.Items.AddRange(new object[] {
            "All Accounts",
            "Supplier",
            "Customer"});
            this.SelectedAccountType.ItemsAppearance.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Location = new System.Drawing.Point(142, 15);
            this.SelectedAccountType.Name = "SelectedAccountType";
            this.SelectedAccountType.ShadowDecoration.Parent = this.SelectedAccountType;
            this.SelectedAccountType.Size = new System.Drawing.Size(256, 36);
            this.SelectedAccountType.TabIndex = 15;
            this.SelectedAccountType.SelectedIndexChanged += new System.EventHandler(this.SelectedAccountType_SelectedIndexChanged);
            this.SelectedAccountType.TextChanged += new System.EventHandler(this.SelectedAccountType_TextChanged);
            // 
            // ViewAccounts_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "ViewAccounts_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ViewAccounts_uc_Load);
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AccountsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedAccountType;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2DataGridView AccountsGridView;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_ID;
        private System.Windows.Forms.DataGridViewImageColumn ACC_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Address;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Update;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Report;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Delete;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
    }
}
