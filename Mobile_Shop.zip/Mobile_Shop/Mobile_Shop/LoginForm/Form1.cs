﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            DB.connect();
            InitializeComponent();
        }

        // User Control Function To load UC
        public void addusercontrol(UserControl uc)
        {
            Background.Controls.Clear();
            Background.Controls.Add(uc);
        }

        public static DataTable shopDetails;
        void shopStatus()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                shopDetails = new DataTable();
                SqlCommand cmd = new SqlCommand("ShopStatus", DB.con) { CommandType = CommandType.StoredProcedure };
                
                shopDetails.Load(cmd.ExecuteReader());
                DB.con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error in database ", ex.ToString(), MessageBoxButtons.OK);
            }
        }
        private void Login_Load(object sender, EventArgs e)
        {
            // Shop Registration Status
            shopStatus();

            // Shop is not Registered
            if (shopDetails.Rows.Count == 0)
            {
                ShopRegistration.ShopRegistrationForm srf = new ShopRegistration.ShopRegistrationForm();
                srf.ShowDialog();
                shopStatus();
                
            }
            // when shop has been registered
            if (shopDetails.Rows.Count > 0)
            {
                LoginForm.LoginScreen ls = new LoginForm.LoginScreen();
                addusercontrol(ls);
                shopname.Text = shopDetails.Rows[0][1].ToString();
                shoptitle.Text = shopDetails.Rows[0][2].ToString();
            }
        }

        // Closing button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
