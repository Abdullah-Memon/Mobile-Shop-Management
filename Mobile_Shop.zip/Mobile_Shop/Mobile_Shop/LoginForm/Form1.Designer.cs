﻿namespace Mobile_Shop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Background = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.shopname = new System.Windows.Forms.Label();
            this.shoptitle = new System.Windows.Forms.Label();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // Background
            // 
            this.Background.BackColor = System.Drawing.Color.Transparent;
            this.Background.BorderRadius = 10;
            this.Background.FillColor = System.Drawing.Color.Transparent;
            this.Background.FillColor2 = System.Drawing.Color.Transparent;
            this.Background.Location = new System.Drawing.Point(10, 66);
            this.Background.Margin = new System.Windows.Forms.Padding(5);
            this.Background.Name = "Background";
            this.Background.ShadowDecoration.Parent = this.Background;
            this.Background.Size = new System.Drawing.Size(605, 340);
            this.Background.TabIndex = 0;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this;
            // 
            // crossbtn
            // 
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.White;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.Indigo;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(5, 29);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(40, 40);
            this.crossbtn.TabIndex = 13;
            this.crossbtn.Text = "X";
            this.crossbtn.Click += new System.EventHandler(this.crossbtn_Click);
            // 
            // shopname
            // 
            this.shopname.AutoSize = true;
            this.shopname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shopname.ForeColor = System.Drawing.Color.Indigo;
            this.shopname.Location = new System.Drawing.Point(8, 19);
            this.shopname.Name = "shopname";
            this.shopname.Size = new System.Drawing.Size(98, 22);
            this.shopname.TabIndex = 14;
            this.shopname.Text = "shop name";
            // 
            // shoptitle
            // 
            this.shoptitle.AutoSize = true;
            this.shoptitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoptitle.ForeColor = System.Drawing.Color.Indigo;
            this.shoptitle.Location = new System.Drawing.Point(9, 41);
            this.shoptitle.Name = "shoptitle";
            this.shoptitle.Size = new System.Drawing.Size(55, 13);
            this.shoptitle.TabIndex = 14;
            this.shoptitle.Text = "Shop Title";
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel1.BorderRadius = 20;
            this.guna2GradientPanel1.Controls.Add(this.crossbtn);
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(560, -20);
            this.guna2GradientPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(50, 75);
            this.guna2GradientPanel1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(625, 418);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Controls.Add(this.shoptitle);
            this.Controls.Add(this.shopname);
            this.Controls.Add(this.Background);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        public Guna.UI2.WinForms.Guna2GradientPanel Background;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
        private System.Windows.Forms.Label shopname;
        private System.Windows.Forms.Label shoptitle;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
    }
}

