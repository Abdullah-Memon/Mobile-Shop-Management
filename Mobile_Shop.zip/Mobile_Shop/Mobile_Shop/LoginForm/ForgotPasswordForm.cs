﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using System.Drawing;


namespace Mobile_Shop.LoginForm
{
    public partial class ForgotPasswordForm : UserControl
    {
        public ForgotPasswordForm()
        {
            InitializeComponent();
        }
        
        // some global variable;
        DataTable dt;
        SqlCommand cmd;
        
        // When the page has been loaded
        private void ForgotPasswordForm_Load(object sender, EventArgs e)
        {
            byte[] pic = (byte[])Form1.shopDetails.Rows[0][0];
            MemoryStream ms = new MemoryStream(pic);
            picture.Image = Image.FromStream(ms);

            CNICbox.Focus();
            questionbox.Hide();
            passbox.Hide();
            Message4.Hide();

        }

        // showing new password
        private void guna2CustomCheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2CustomCheckBox1.Checked)
            {
                newpass.UseSystemPasswordChar = false;
            }
            else
                newpass.UseSystemPasswordChar = true;
        }

        // showing new confirm password
        private void guna2CustomCheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2CustomCheckBox2.Checked)
            {
                newcpass.UseSystemPasswordChar = false;
            }
            else
                newcpass.UseSystemPasswordChar = true;

        }

        // updating the user password
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (newpass.Text == newcpass.Text)
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                try
                {
                    cmd = new SqlCommand("UpdatePass", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@CNIC", CNICbox.Text));
                    cmd.Parameters.Add(new SqlParameter("@newpassword", newcpass.Text));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error While updating the password ", ex.ToString(), MessageBoxButtons.OK);
                }

                MessageBox.Show("New Password has been saved", "Password Saved");
                LoginScreen ls = new LoginScreen();
                Program.l.addusercontrol(ls);
            }
            else
            {
                Message4.Show();
                newpass.Focus();
            }
        }
        
        //When the password matches
        private void nextbtn_Click_1(object sender, EventArgs e)
        {
            if (Answer.Text == dt.Rows[0][1].ToString())
            {
                //incorrect password warning
                Message2.Hide();
                // showing new screen (change password screen)
                passbox.Show();
                newpass.Focus();
                // hiding old screen
                questionbox.Hide();
                // swaping button next and save button
                nextbtn.Hide();
                savebtn.Show();
            }
            else
            {
                // showing warning message
                Message2.Show();
                Answer.Focus();                
            }
        }

        // CNIC checking button coding
        private void chkbtn_Click_1(object sender, EventArgs e)
        {
            // when box is not empty
            if (CNICbox.Text != "")
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }

                // new datatable
                dt = new DataTable();

                // Verifing the user
                try
                {
                    cmd = new SqlCommand("EMP_Verify", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@cnic", CNICbox.Text));

                    dt.Load(cmd.ExecuteReader());
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error! user unidentified!", ex.ToString(), MessageBoxButtons.OK);
                }

                //When user has been found
                if (dt.Rows.Count > 0)
                {
                    nextbtn.Visible = true;
                    questionbox.Show();
                    Message2.Hide();
                    Question.DataSource = dt;
                    Question.DisplayMember = "SQ";
                    Answer.Focus();
                }
                else
                {
                    MessageBox.Show("Invalid CNIC number! Please try again. Thank you");
                }
            }
            else
            {
                CNICbox.Focus();
            }
        }

        //back button coding
        private void guna2GradientButton2_Click_1(object sender, EventArgs e)
        {
            if (Question.Text == string.Empty)
            {
                LoginScreen ls = new LoginScreen();
                Program.l.addusercontrol(ls);
            }
            else
            {
                ForgotPasswordForm_Load(null, null);
            }
        }
        

        // "Enter" cnic number box
        private void CNICbox_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                chkbtn_Click_1(null, null);
            }
        }

        // "Enter" Answer box
        private void Answer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                nextbtn_Click_1(null, null);
            }
        }

        //"Enter" new confirm password box
        private void newcpass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                LoginBtn_Click(null, null);
            }
        }
    }
}
