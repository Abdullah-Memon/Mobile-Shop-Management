﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Mobile_Shop.LoginForm
{
    public partial class LoginScreen : UserControl
    {
        public LoginScreen()
        {
            InitializeComponent();
        }


        public static void ClearTemp() 
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                SqlCommand cmd = new SqlCommand("RemoveTimebyTimetemp", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));
                cmd.Parameters.Add(new SqlParameter("@empid", personal_info.Rows[0][0]));

                cmd.ExecuteNonQuery();
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // public global variable containing user information.
        public static DataTable personal_info;
        public static MainScreen.MainScreen ms;
        public static SellScreen.SellScreenForm ssf;

        //Login button coding sending and reciving all data.
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (DB.con.State == ConnectionState.Closed)
                DB.con.Open();

            // new datatable
            personal_info = new DataTable();

            //sending and reciving data from sql from login.
            try
            {
                SqlCommand cmd = new SqlCommand("getaccess", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@uname", UsernameBox.Text));
                cmd.Parameters.Add(new SqlParameter("@upass", PasswordBox.Text));

                personal_info.Load(cmd.ExecuteReader());
                DB.con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error! Please restart the application", ex.ToString(), MessageBoxButtons.OK);
            }

            // loading Main screen of the software if user exits
            if (personal_info.Rows.Count > 0)
            {
                if (personal_info.Rows[0][6].ToString() == "Admin")
                {
                    ClearTemp();
                    ms = new MainScreen.MainScreen();
                    ms.Show();
                }
                else
                {
                    ClearTemp();
                    ssf = new SellScreen.SellScreenForm();
                    ssf.Show();
                }
                    Program.l.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password. Please try again!");
                UsernameBox.Focus();
            }

            // Clearing the text box
            UsernameBox.Text = string.Empty;
            PasswordBox.Text = string.Empty;
        }
        


        // Loading forgot password user control in login form
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPasswordForm fpf = new ForgotPasswordForm();
            Program.l.addusercontrol(fpf);
        }

        // show password character at password box
        private void showpass_CheckedChanged(object sender, EventArgs e)
        {
            if (showpass.Checked)
                PasswordBox.UseSystemPasswordChar = false;
            else
                PasswordBox.UseSystemPasswordChar = true;
        }

        //"Enter" coding for new password
        private void PasswordBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                LoginBtn_Click(null, null);
            }
        }

        // When the screen is loaded
        private void LoginScreen_Load(object sender, EventArgs e)
        {
            UsernameBox.Focus();

        }

        private void PasswordBox_TextChanged(object sender, EventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = true;
        }
    }
}
