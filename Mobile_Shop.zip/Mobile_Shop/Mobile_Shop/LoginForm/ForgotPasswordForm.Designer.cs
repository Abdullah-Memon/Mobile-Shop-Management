﻿namespace Mobile_Shop.LoginForm
{
    partial class ForgotPasswordForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.picture = new Guna.UI2.WinForms.Guna2PictureBox();
            this.questionbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.Answer = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Message1 = new System.Windows.Forms.Label();
            this.Question = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Message2 = new System.Windows.Forms.Label();
            this.passbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.Message4 = new System.Windows.Forms.Label();
            this.Message3 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox2 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox1 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.newpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.newcpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CNICbox = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.chkbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.savebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.nextbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).BeginInit();
            this.questionbox.SuspendLayout();
            this.passbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.guna2GroupBox1;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.BorderRadius = 20;
            this.guna2GroupBox1.Controls.Add(this.picture);
            this.guna2GroupBox1.Controls.Add(this.questionbox);
            this.guna2GroupBox1.Controls.Add(this.passbox);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.Controls.Add(this.CNICbox);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.guna2GradientButton2);
            this.guna2GroupBox1.Controls.Add(this.chkbtn);
            this.guna2GroupBox1.Controls.Add(this.savebtn);
            this.guna2GroupBox1.Controls.Add(this.nextbtn);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(0, 0);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(605, 330);
            this.guna2GroupBox1.TabIndex = 11;
            this.guna2GroupBox1.UseTransparentBackground = true;
            // 
            // picture
            // 
            this.picture.FillColor = System.Drawing.Color.WhiteSmoke;
            this.picture.Location = new System.Drawing.Point(14, 71);
            this.picture.Name = "picture";
            this.picture.ShadowDecoration.Parent = this.picture;
            this.picture.Size = new System.Drawing.Size(155, 200);
            this.picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture.TabIndex = 11;
            this.picture.TabStop = false;
            this.picture.UseTransparentBackground = true;
            // 
            // questionbox
            // 
            this.questionbox.BorderColor = System.Drawing.Color.Indigo;
            this.questionbox.BorderRadius = 10;
            this.questionbox.Controls.Add(this.Answer);
            this.questionbox.Controls.Add(this.label3);
            this.questionbox.Controls.Add(this.Message1);
            this.questionbox.Controls.Add(this.Question);
            this.questionbox.Controls.Add(this.label4);
            this.questionbox.Controls.Add(this.Message2);
            this.questionbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.questionbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.questionbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.questionbox.Location = new System.Drawing.Point(180, 117);
            this.questionbox.Name = "questionbox";
            this.questionbox.ShadowDecoration.Parent = this.questionbox;
            this.questionbox.Size = new System.Drawing.Size(399, 158);
            this.questionbox.TabIndex = 9;
            this.questionbox.UseTransparentBackground = true;
            // 
            // Answer
            // 
            this.Answer.BorderRadius = 10;
            this.Answer.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Answer.DefaultText = "";
            this.Answer.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Answer.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Answer.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Answer.DisabledState.Parent = this.Answer;
            this.Answer.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Answer.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Answer.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Answer.FocusedState.Parent = this.Answer;
            this.Answer.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Answer.HoverState.Parent = this.Answer;
            this.Answer.Location = new System.Drawing.Point(87, 81);
            this.Answer.Name = "Answer";
            this.Answer.PasswordChar = '\0';
            this.Answer.PlaceholderText = "";
            this.Answer.SelectedText = "";
            this.Answer.ShadowDecoration.Parent = this.Answer;
            this.Answer.Size = new System.Drawing.Size(287, 37);
            this.Answer.TabIndex = 0;
            this.Answer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Answer_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(16, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Question";
            // 
            // Message1
            // 
            this.Message1.AutoSize = true;
            this.Message1.ForeColor = System.Drawing.Color.Green;
            this.Message1.Location = new System.Drawing.Point(103, 18);
            this.Message1.Name = "Message1";
            this.Message1.Size = new System.Drawing.Size(245, 19);
            this.Message1.TabIndex = 6;
            this.Message1.Text = "*Please Answer the following Question";
            // 
            // Question
            // 
            this.Question.BackColor = System.Drawing.Color.Transparent;
            this.Question.BorderRadius = 10;
            this.Question.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Question.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Question.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Question.FocusedColor = System.Drawing.Color.Empty;
            this.Question.FocusedState.Parent = this.Question;
            this.Question.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Question.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.Question.FormattingEnabled = true;
            this.Question.HoverState.Parent = this.Question;
            this.Question.ItemHeight = 30;
            this.Question.ItemsAppearance.Parent = this.Question;
            this.Question.Location = new System.Drawing.Point(87, 39);
            this.Question.Name = "Question";
            this.Question.ShadowDecoration.Parent = this.Question;
            this.Question.Size = new System.Drawing.Size(287, 36);
            this.Question.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(16, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Answer";
            // 
            // Message2
            // 
            this.Message2.AutoSize = true;
            this.Message2.ForeColor = System.Drawing.Color.Red;
            this.Message2.Location = new System.Drawing.Point(116, 121);
            this.Message2.Name = "Message2";
            this.Message2.Size = new System.Drawing.Size(208, 19);
            this.Message2.TabIndex = 6;
            this.Message2.Text = "*Invalid Answer Please try again!";
            // 
            // passbox
            // 
            this.passbox.BackColor = System.Drawing.Color.Transparent;
            this.passbox.BorderColor = System.Drawing.Color.Indigo;
            this.passbox.BorderRadius = 10;
            this.passbox.Controls.Add(this.Message4);
            this.passbox.Controls.Add(this.Message3);
            this.passbox.Controls.Add(this.guna2CustomCheckBox2);
            this.passbox.Controls.Add(this.label5);
            this.passbox.Controls.Add(this.guna2CustomCheckBox1);
            this.passbox.Controls.Add(this.newpass);
            this.passbox.Controls.Add(this.newcpass);
            this.passbox.Controls.Add(this.label6);
            this.passbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.passbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.passbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.passbox.Location = new System.Drawing.Point(180, 117);
            this.passbox.Name = "passbox";
            this.passbox.ShadowDecoration.Parent = this.passbox;
            this.passbox.Size = new System.Drawing.Size(399, 158);
            this.passbox.TabIndex = 10;
            this.passbox.UseTransparentBackground = true;
            // 
            // Message4
            // 
            this.Message4.AutoSize = true;
            this.Message4.ForeColor = System.Drawing.Color.Red;
            this.Message4.Location = new System.Drawing.Point(160, 122);
            this.Message4.Name = "Message4";
            this.Message4.Size = new System.Drawing.Size(141, 19);
            this.Message4.TabIndex = 6;
            this.Message4.Text = "*Password not Match";
            // 
            // Message3
            // 
            this.Message3.AutoSize = true;
            this.Message3.ForeColor = System.Drawing.Color.Green;
            this.Message3.Location = new System.Drawing.Point(151, 20);
            this.Message3.Name = "Message3";
            this.Message3.Size = new System.Drawing.Size(138, 19);
            this.Message3.TabIndex = 6;
            this.Message3.Text = "*Enter new Password";
            // 
            // guna2CustomCheckBox2
            // 
            this.guna2CustomCheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox2.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox2.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox2.CheckedState.Parent = this.guna2CustomCheckBox2;
            this.guna2CustomCheckBox2.Location = new System.Drawing.Point(355, 93);
            this.guna2CustomCheckBox2.Name = "guna2CustomCheckBox2";
            this.guna2CustomCheckBox2.ShadowDecoration.Parent = this.guna2CustomCheckBox2;
            this.guna2CustomCheckBox2.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox2.TabIndex = 8;
            this.guna2CustomCheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox2.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox2.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox2.UncheckedState.Parent = this.guna2CustomCheckBox2;
            this.guna2CustomCheckBox2.CheckedChanged += new System.EventHandler(this.guna2CustomCheckBox2_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(15, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Create Password";
            // 
            // guna2CustomCheckBox1
            // 
            this.guna2CustomCheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox1.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox1.CheckedState.Parent = this.guna2CustomCheckBox1;
            this.guna2CustomCheckBox1.Location = new System.Drawing.Point(355, 51);
            this.guna2CustomCheckBox1.Name = "guna2CustomCheckBox1";
            this.guna2CustomCheckBox1.ShadowDecoration.Parent = this.guna2CustomCheckBox1;
            this.guna2CustomCheckBox1.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox1.TabIndex = 8;
            this.guna2CustomCheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox1.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox1.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox1.UncheckedState.Parent = this.guna2CustomCheckBox1;
            this.guna2CustomCheckBox1.CheckedChanged += new System.EventHandler(this.guna2CustomCheckBox1_CheckedChanged);
            // 
            // newpass
            // 
            this.newpass.BorderRadius = 10;
            this.newpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newpass.DefaultText = "";
            this.newpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newpass.DisabledState.Parent = this.newpass;
            this.newpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newpass.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newpass.FocusedState.Parent = this.newpass;
            this.newpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newpass.HoverState.Parent = this.newpass;
            this.newpass.Location = new System.Drawing.Point(142, 41);
            this.newpass.Name = "newpass";
            this.newpass.PasswordChar = '\0';
            this.newpass.PlaceholderText = "";
            this.newpass.SelectedText = "";
            this.newpass.ShadowDecoration.Parent = this.newpass;
            this.newpass.Size = new System.Drawing.Size(208, 37);
            this.newpass.TabIndex = 0;
            this.newpass.UseSystemPasswordChar = true;
            // 
            // newcpass
            // 
            this.newcpass.BorderRadius = 10;
            this.newcpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newcpass.DefaultText = "";
            this.newcpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newcpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newcpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newcpass.DisabledState.Parent = this.newcpass;
            this.newcpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newcpass.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newcpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newcpass.FocusedState.Parent = this.newcpass;
            this.newcpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newcpass.HoverState.Parent = this.newcpass;
            this.newcpass.Location = new System.Drawing.Point(141, 83);
            this.newcpass.Name = "newcpass";
            this.newcpass.PasswordChar = '\0';
            this.newcpass.PlaceholderText = "";
            this.newcpass.SelectedText = "";
            this.newcpass.ShadowDecoration.Parent = this.newcpass;
            this.newcpass.Size = new System.Drawing.Size(208, 37);
            this.newcpass.TabIndex = 1;
            this.newcpass.UseSystemPasswordChar = true;
            this.newcpass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.newcpass_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(15, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Confirm Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(8, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 31);
            this.label1.TabIndex = 7;
            this.label1.Text = "Forgot Password?";
            // 
            // CNICbox
            // 
            this.CNICbox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CNICbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CNICbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CNICbox.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.CNICbox.HideSelection = false;
            this.CNICbox.Location = new System.Drawing.Point(243, 80);
            this.CNICbox.Mask = "00000-0000000-0";
            this.CNICbox.Name = "CNICbox";
            this.CNICbox.Size = new System.Drawing.Size(239, 24);
            this.CNICbox.TabIndex = 10;
            this.CNICbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CNICbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CNICbox_KeyDown_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(175, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "CNIC";
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton2.BorderRadius = 10;
            this.guna2GradientButton2.BorderThickness = 2;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(491, 11);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(88, 36);
            this.guna2GradientButton2.TabIndex = 4;
            this.guna2GradientButton2.Text = "Back";
            this.guna2GradientButton2.Click += new System.EventHandler(this.guna2GradientButton2_Click_1);
            // 
            // chkbtn
            // 
            this.chkbtn.BorderColor = System.Drawing.Color.White;
            this.chkbtn.BorderRadius = 10;
            this.chkbtn.BorderThickness = 2;
            this.chkbtn.CheckedState.Parent = this.chkbtn;
            this.chkbtn.CustomImages.Parent = this.chkbtn;
            this.chkbtn.FillColor = System.Drawing.Color.Indigo;
            this.chkbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.chkbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.chkbtn.ForeColor = System.Drawing.Color.White;
            this.chkbtn.HoverState.Parent = this.chkbtn;
            this.chkbtn.Location = new System.Drawing.Point(491, 72);
            this.chkbtn.Name = "chkbtn";
            this.chkbtn.ShadowDecoration.Parent = this.chkbtn;
            this.chkbtn.Size = new System.Drawing.Size(88, 36);
            this.chkbtn.TabIndex = 1;
            this.chkbtn.Text = "Enter";
            this.chkbtn.Click += new System.EventHandler(this.chkbtn_Click_1);
            // 
            // savebtn
            // 
            this.savebtn.BorderColor = System.Drawing.Color.White;
            this.savebtn.BorderRadius = 10;
            this.savebtn.BorderThickness = 2;
            this.savebtn.CheckedState.Parent = this.savebtn;
            this.savebtn.CustomImages.Parent = this.savebtn;
            this.savebtn.FillColor = System.Drawing.Color.Indigo;
            this.savebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.savebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savebtn.ForeColor = System.Drawing.Color.White;
            this.savebtn.HoverState.Parent = this.savebtn;
            this.savebtn.Location = new System.Drawing.Point(491, 281);
            this.savebtn.Name = "savebtn";
            this.savebtn.ShadowDecoration.Parent = this.savebtn;
            this.savebtn.Size = new System.Drawing.Size(88, 36);
            this.savebtn.TabIndex = 3;
            this.savebtn.Text = "Save";
            this.savebtn.Visible = false;
            this.savebtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // nextbtn
            // 
            this.nextbtn.BorderColor = System.Drawing.Color.White;
            this.nextbtn.BorderRadius = 10;
            this.nextbtn.BorderThickness = 2;
            this.nextbtn.CheckedState.Parent = this.nextbtn;
            this.nextbtn.CustomImages.Parent = this.nextbtn;
            this.nextbtn.FillColor = System.Drawing.Color.Indigo;
            this.nextbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.nextbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.nextbtn.ForeColor = System.Drawing.Color.White;
            this.nextbtn.HoverState.Parent = this.nextbtn;
            this.nextbtn.Location = new System.Drawing.Point(491, 281);
            this.nextbtn.Name = "nextbtn";
            this.nextbtn.ShadowDecoration.Parent = this.nextbtn;
            this.nextbtn.Size = new System.Drawing.Size(88, 36);
            this.nextbtn.TabIndex = 2;
            this.nextbtn.Text = "Next";
            this.nextbtn.Visible = false;
            this.nextbtn.Click += new System.EventHandler(this.nextbtn_Click_1);
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 10;
            this.guna2Elipse2.TargetControl = this.CNICbox;
            // 
            // ForgotPasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.guna2GroupBox1);
            this.Name = "ForgotPasswordForm";
            this.Size = new System.Drawing.Size(605, 330);
            this.Load += new System.EventHandler(this.ForgotPasswordForm_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).EndInit();
            this.questionbox.ResumeLayout(false);
            this.questionbox.PerformLayout();
            this.passbox.ResumeLayout(false);
            this.passbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox CNICbox;
        private Guna.UI2.WinForms.Guna2GradientButton savebtn;
        private Guna.UI2.WinForms.Guna2GroupBox passbox;
        private System.Windows.Forms.Label Message4;
        private System.Windows.Forms.Label Message3;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox2;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox1;
        private Guna.UI2.WinForms.Guna2TextBox newpass;
        private Guna.UI2.WinForms.Guna2TextBox newcpass;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2GroupBox questionbox;
        private Guna.UI2.WinForms.Guna2TextBox Answer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Message1;
        private Guna.UI2.WinForms.Guna2ComboBox Question;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Message2;
        private Guna.UI2.WinForms.Guna2GradientButton nextbtn;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2GradientButton chkbtn;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2PictureBox picture;
    }
}
