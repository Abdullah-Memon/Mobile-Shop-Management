﻿namespace Mobile_Shop.Expense
{
    partial class ExpenseDashboard_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ExpenseType = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GroupBox4 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ExpenseReport = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AddExpense = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ViewExpense = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.guna2GroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            this.guna2GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2GroupBox3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1060, 554);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.BorderRadius = 20;
            this.guna2GroupBox1.Controls.Add(this.label14);
            this.guna2GroupBox1.Controls.Add(this.ExpenseType);
            this.guna2GroupBox1.Controls.Add(this.guna2PictureBox1);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(3, 3);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(524, 271);
            this.guna2GroupBox1.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Handwriting", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(152, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(217, 27);
            this.label14.TabIndex = 17;
            this.label14.Text = "Add Expense Type";
            // 
            // ExpenseType
            // 
            this.ExpenseType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ExpenseType.BackColor = System.Drawing.Color.Transparent;
            this.ExpenseType.BorderColor = System.Drawing.Color.White;
            this.ExpenseType.BorderRadius = 10;
            this.ExpenseType.BorderThickness = 2;
            this.ExpenseType.CheckedState.Parent = this.ExpenseType;
            this.ExpenseType.CustomImages.Parent = this.ExpenseType;
            this.ExpenseType.FillColor = System.Drawing.Color.Indigo;
            this.ExpenseType.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ExpenseType.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExpenseType.ForeColor = System.Drawing.Color.White;
            this.ExpenseType.HoverState.Parent = this.ExpenseType;
            this.ExpenseType.Location = new System.Drawing.Point(185, 210);
            this.ExpenseType.Name = "ExpenseType";
            this.ExpenseType.ShadowDecoration.Parent = this.ExpenseType;
            this.ExpenseType.Size = new System.Drawing.Size(150, 45);
            this.ExpenseType.TabIndex = 14;
            this.ExpenseType.Text = "Add Expense Type";
            this.ExpenseType.Click += new System.EventHandler(this.ExpenseType_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox1.Location = new System.Drawing.Point(182, 57);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(156, 147);
            this.guna2PictureBox1.TabIndex = 1;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2GroupBox4
            // 
            this.guna2GroupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox4.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox4.BorderRadius = 20;
            this.guna2GroupBox4.Controls.Add(this.label3);
            this.guna2GroupBox4.Controls.Add(this.ExpenseReport);
            this.guna2GroupBox4.Controls.Add(this.guna2PictureBox3);
            this.guna2GroupBox4.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox4.Location = new System.Drawing.Point(533, 280);
            this.guna2GroupBox4.Name = "guna2GroupBox4";
            this.guna2GroupBox4.ShadowDecoration.Parent = this.guna2GroupBox4;
            this.guna2GroupBox4.Size = new System.Drawing.Size(524, 271);
            this.guna2GroupBox4.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(152, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 27);
            this.label3.TabIndex = 17;
            this.label3.Text = "Expense Report";
            // 
            // ExpenseReport
            // 
            this.ExpenseReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ExpenseReport.BackColor = System.Drawing.Color.Transparent;
            this.ExpenseReport.BorderColor = System.Drawing.Color.White;
            this.ExpenseReport.BorderRadius = 10;
            this.ExpenseReport.BorderThickness = 2;
            this.ExpenseReport.CheckedState.Parent = this.ExpenseReport;
            this.ExpenseReport.CustomImages.Parent = this.ExpenseReport;
            this.ExpenseReport.FillColor = System.Drawing.Color.Indigo;
            this.ExpenseReport.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ExpenseReport.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExpenseReport.ForeColor = System.Drawing.Color.White;
            this.ExpenseReport.HoverState.Parent = this.ExpenseReport;
            this.ExpenseReport.Location = new System.Drawing.Point(169, 211);
            this.ExpenseReport.Name = "ExpenseReport";
            this.ExpenseReport.ShadowDecoration.Parent = this.ExpenseReport;
            this.ExpenseReport.Size = new System.Drawing.Size(150, 45);
            this.ExpenseReport.TabIndex = 17;
            this.ExpenseReport.Text = "Expense Report";
            this.ExpenseReport.Click += new System.EventHandler(this.ExpenseReport_Click);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox3.Location = new System.Drawing.Point(166, 58);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(156, 147);
            this.guna2PictureBox3.TabIndex = 1;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox2.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox2.BorderRadius = 20;
            this.guna2GroupBox2.Controls.Add(this.label1);
            this.guna2GroupBox2.Controls.Add(this.AddExpense);
            this.guna2GroupBox2.Controls.Add(this.guna2PictureBox4);
            this.guna2GroupBox2.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(533, 3);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(524, 271);
            this.guna2GroupBox2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(165, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 27);
            this.label1.TabIndex = 17;
            this.label1.Text = "Add Expense";
            // 
            // AddExpense
            // 
            this.AddExpense.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddExpense.BackColor = System.Drawing.Color.Transparent;
            this.AddExpense.BorderColor = System.Drawing.Color.White;
            this.AddExpense.BorderRadius = 10;
            this.AddExpense.BorderThickness = 2;
            this.AddExpense.CheckedState.Parent = this.AddExpense;
            this.AddExpense.CustomImages.Parent = this.AddExpense;
            this.AddExpense.FillColor = System.Drawing.Color.Indigo;
            this.AddExpense.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AddExpense.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddExpense.ForeColor = System.Drawing.Color.White;
            this.AddExpense.HoverState.Parent = this.AddExpense;
            this.AddExpense.Location = new System.Drawing.Point(169, 209);
            this.AddExpense.Name = "AddExpense";
            this.AddExpense.ShadowDecoration.Parent = this.AddExpense;
            this.AddExpense.Size = new System.Drawing.Size(150, 45);
            this.AddExpense.TabIndex = 16;
            this.AddExpense.Text = "AddExpense";
            this.AddExpense.Click += new System.EventHandler(this.AddExpense_Click);
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox4.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox4.Location = new System.Drawing.Point(166, 56);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(156, 147);
            this.guna2PictureBox4.TabIndex = 1;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox3.BorderRadius = 20;
            this.guna2GroupBox3.Controls.Add(this.label2);
            this.guna2GroupBox3.Controls.Add(this.ViewExpense);
            this.guna2GroupBox3.Controls.Add(this.guna2PictureBox2);
            this.guna2GroupBox3.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(3, 280);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(524, 271);
            this.guna2GroupBox3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(179, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 27);
            this.label2.TabIndex = 17;
            this.label2.Text = "View Expense";
            // 
            // ViewExpense
            // 
            this.ViewExpense.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ViewExpense.BackColor = System.Drawing.Color.Transparent;
            this.ViewExpense.BorderColor = System.Drawing.Color.White;
            this.ViewExpense.BorderRadius = 10;
            this.ViewExpense.BorderThickness = 2;
            this.ViewExpense.CheckedState.Parent = this.ViewExpense;
            this.ViewExpense.CustomImages.Parent = this.ViewExpense;
            this.ViewExpense.FillColor = System.Drawing.Color.Indigo;
            this.ViewExpense.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ViewExpense.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ViewExpense.ForeColor = System.Drawing.Color.White;
            this.ViewExpense.HoverState.Parent = this.ViewExpense;
            this.ViewExpense.Location = new System.Drawing.Point(185, 211);
            this.ViewExpense.Name = "ViewExpense";
            this.ViewExpense.ShadowDecoration.Parent = this.ViewExpense;
            this.ViewExpense.Size = new System.Drawing.Size(150, 45);
            this.ViewExpense.TabIndex = 15;
            this.ViewExpense.Text = "View Expense";
            this.ViewExpense.Click += new System.EventHandler(this.ViewExpense_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2PictureBox2.Location = new System.Drawing.Point(182, 58);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(156, 147);
            this.guna2PictureBox2.TabIndex = 1;
            this.guna2PictureBox2.TabStop = false;
            // 
            // ExpenseDashboard_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ExpenseDashboard_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ExpenseDashboard_uc_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.guna2GroupBox4.ResumeLayout(false);
            this.guna2GroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox4;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2GradientButton ExpenseReport;
        private Guna.UI2.WinForms.Guna2GradientButton AddExpense;
        private Guna.UI2.WinForms.Guna2GradientButton ViewExpense;
        private Guna.UI2.WinForms.Guna2GradientButton ExpenseType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}
