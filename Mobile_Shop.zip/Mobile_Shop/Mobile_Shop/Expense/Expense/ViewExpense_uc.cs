﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Expense
{
    public partial class ViewExpense_uc : UserControl
    {
        public ViewExpense_uc()
        {
            InitializeComponent();
        }
        //Screens to Load
        ViewExpenseRecycleBin_uc verb;

        // Global Variables
        SqlCommand cmd;
        DataTable getexpensedata;

        // function for retriving all the information about expense
        private void getExpense()
        {
            try
            {
                // Database Connection
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                // Getting Combo box data
                getexpensedata = new DataTable();
                cmd = new SqlCommand("ExpenseTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                getexpensedata.Load(cmd.ExecuteReader());

                ExpenseTypeID.DataSource = getexpensedata;
                ExpenseTypeID.DisplayMember = "E_Name";
                ExpenseTypeID.ValueMember = "ETID";

                // Getting all Information
                getexpensedata = new DataTable();
                cmd = new SqlCommand("ExpenseDetails", DB.con) { CommandType = CommandType.StoredProcedure};
                
                getexpensedata.Load(cmd.ExecuteReader());
                DB.con.Close();

                ExpenseData.DataSource = getexpensedata;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while getting while getting data please try again " + ex.ToString(), "Error");
            }
        }

        // seraching function for expense via dates
        private void getFileteredExpense ()
        {
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                getexpensedata = new DataTable();
                cmd = new SqlCommand("findExpense", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@date1", Convert.ToDateTime(SelectedDate1.Value.ToShortDateString())));
                cmd.Parameters.Add(new SqlParameter("@date2", Convert.ToDateTime(SelectedDate2.Value.ToShortDateString())));
                getexpensedata.Load(cmd.ExecuteReader());

                ExpenseData.DataSource = getexpensedata;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting while getting data please try again " + ex.ToString(), "Error");
            }
        }
        
        // Main Load Function
        private void ViewExpense_uc_Load(object sender, EventArgs e)
        {
            getExpense();

            SelectedDate1.Text = DateTime.Now.ToShortDateString();
            SelectedDate2.Text = DateTime.Now.ToShortDateString();
            
        }

        //grid view button coding
        private void ExpenseData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // update button coding
            if (e.ColumnIndex == 0)
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("UpdateExpense",DB.con) { CommandType = CommandType.StoredProcedure};
                    cmd.Parameters.Add(new SqlParameter("@eid", ExpenseData.Rows[e.RowIndex].Cells["ExpenseID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@expensetype", ExpenseData.Rows[e.RowIndex].Cells["ExpenseTypeID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@rate", ExpenseData.Rows[e.RowIndex].Cells["ExpenseRate"].Value));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error while updating data Please try again " + ex.ToString(), "Error");
                }

                object a = new object();
                EventArgs b = new EventArgs();
                ViewExpense_uc_Load(a,b);

            }

            //delete button coding
            if (e.ColumnIndex ==1)
            {
                if (MessageBox.Show("Are you sure you want to permanantly delete the selected index", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        cmd = new SqlCommand("RemoveExpense", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@eid", ExpenseData.Rows[e.RowIndex].Cells["ExpenseID"].Value));

                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while Deleting data Please try again " + ex.ToString(), "Error");
                    }

                    object a = new object();
                    EventArgs b = new EventArgs();
                    ViewExpense_uc_Load(a, b);
                }
            }
        }

        
        // Navigate to Recycle bin of Expense
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (verb == null)
                verb = new ViewExpenseRecycleBin_uc();

            LoginForm.LoginScreen.ms.addusercontrol(verb);
        }

        //Back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.ed);
        }

        // showing all expense
        private void ExpenseType_Click_1(object sender, EventArgs e)
        {
            getExpense();
        }

        //searching expense via date
        private void search_Click_1(object sender, EventArgs e)
        {
            getFileteredExpense();
        }
    }
}
