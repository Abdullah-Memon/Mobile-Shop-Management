﻿namespace Mobile_Shop.Expense
{
    partial class ViewExpenseRecycleBin_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.ExpenseType = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label14 = new System.Windows.Forms.Label();
            this.selecteddate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.DeletedExpenseData = new Guna.UI2.WinForms.Guna2DataGridView();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.ExpenseID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseTypeID = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ExpenseRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RestoreExpensebtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpensebtn = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DeletedExpenseData)).BeginInit();
            this.contentpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(979, 12);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 21;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // ExpenseType
            // 
            this.ExpenseType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExpenseType.BackColor = System.Drawing.Color.Transparent;
            this.ExpenseType.BorderColor = System.Drawing.Color.White;
            this.ExpenseType.BorderRadius = 10;
            this.ExpenseType.BorderThickness = 2;
            this.ExpenseType.CheckedState.Parent = this.ExpenseType;
            this.ExpenseType.CustomImages.Parent = this.ExpenseType;
            this.ExpenseType.FillColor = System.Drawing.Color.Indigo;
            this.ExpenseType.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ExpenseType.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExpenseType.ForeColor = System.Drawing.Color.White;
            this.ExpenseType.HoverState.Parent = this.ExpenseType;
            this.ExpenseType.Location = new System.Drawing.Point(617, 17);
            this.ExpenseType.Name = "ExpenseType";
            this.ExpenseType.ShadowDecoration.Parent = this.ExpenseType;
            this.ExpenseType.Size = new System.Drawing.Size(150, 45);
            this.ExpenseType.TabIndex = 19;
            this.ExpenseType.Text = "Search Via Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Handwriting", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Indigo;
            this.label14.Location = new System.Drawing.Point(31, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(342, 40);
            this.label14.TabIndex = 18;
            this.label14.Text = "All Deleted Expense";
            // 
            // selecteddate
            // 
            this.selecteddate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.selecteddate.BorderRadius = 10;
            this.selecteddate.CheckedState.Parent = this.selecteddate;
            this.selecteddate.FillColor = System.Drawing.Color.WhiteSmoke;
            this.selecteddate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.selecteddate.HoverState.Parent = this.selecteddate;
            this.selecteddate.Location = new System.Drawing.Point(773, 17);
            this.selecteddate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.selecteddate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.selecteddate.Name = "selecteddate";
            this.selecteddate.ShadowDecoration.Parent = this.selecteddate;
            this.selecteddate.Size = new System.Drawing.Size(200, 45);
            this.selecteddate.TabIndex = 1;
            this.selecteddate.Value = new System.DateTime(2022, 7, 16, 10, 46, 14, 42);
            // 
            // DeletedExpenseData
            // 
            this.DeletedExpenseData.AllowUserToAddRows = false;
            this.DeletedExpenseData.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedExpenseData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DeletedExpenseData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DeletedExpenseData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DeletedExpenseData.BackgroundColor = System.Drawing.Color.White;
            this.DeletedExpenseData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DeletedExpenseData.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedExpenseData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DeletedExpenseData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DeletedExpenseData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ExpenseID,
            this.ExpenseTypeID,
            this.ExpenseRate,
            this.EMPID,
            this.PaymentType,
            this.ExpenseDate,
            this.ExpenseTime,
            this.RestoreExpensebtn,
            this.DeleteExpensebtn});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DeletedExpenseData.DefaultCellStyle = dataGridViewCellStyle3;
            this.DeletedExpenseData.EnableHeadersVisualStyles = false;
            this.DeletedExpenseData.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedExpenseData.Location = new System.Drawing.Point(12, 82);
            this.DeletedExpenseData.Name = "DeletedExpenseData";
            this.DeletedExpenseData.ReadOnly = true;
            this.DeletedExpenseData.RowHeadersVisible = false;
            this.DeletedExpenseData.RowTemplate.Height = 40;
            this.DeletedExpenseData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DeletedExpenseData.Size = new System.Drawing.Size(1036, 458);
            this.DeletedExpenseData.TabIndex = 0;
            this.DeletedExpenseData.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.DeletedExpenseData.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.DeletedExpenseData.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DeletedExpenseData.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DeletedExpenseData.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DeletedExpenseData.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DeletedExpenseData.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DeletedExpenseData.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.DeletedExpenseData.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.DeletedExpenseData.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DeletedExpenseData.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DeletedExpenseData.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DeletedExpenseData.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DeletedExpenseData.ThemeStyle.HeaderStyle.Height = 23;
            this.DeletedExpenseData.ThemeStyle.ReadOnly = true;
            this.DeletedExpenseData.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.DeletedExpenseData.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DeletedExpenseData.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DeletedExpenseData.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DeletedExpenseData.ThemeStyle.RowsStyle.Height = 40;
            this.DeletedExpenseData.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.DeletedExpenseData.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DeletedExpenseData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DeletedExpenseData_CellContentClick);
            // 
            // contentpanel
            // 
            this.contentpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 20;
            this.contentpanel.Controls.Add(this.Backbtn);
            this.contentpanel.Controls.Add(this.ExpenseType);
            this.contentpanel.Controls.Add(this.label14);
            this.contentpanel.Controls.Add(this.selecteddate);
            this.contentpanel.Controls.Add(this.DeletedExpenseData);
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 1;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this.DeletedExpenseData;
            // 
            // ExpenseID
            // 
            this.ExpenseID.DataPropertyName = "EID";
            this.ExpenseID.HeaderText = "ExpenseID";
            this.ExpenseID.Name = "ExpenseID";
            this.ExpenseID.ReadOnly = true;
            this.ExpenseID.Visible = false;
            // 
            // ExpenseTypeID
            // 
            this.ExpenseTypeID.DataPropertyName = "ETID";
            this.ExpenseTypeID.HeaderText = "Expense Type";
            this.ExpenseTypeID.Name = "ExpenseTypeID";
            this.ExpenseTypeID.ReadOnly = true;
            this.ExpenseTypeID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ExpenseRate
            // 
            this.ExpenseRate.DataPropertyName = "Rate";
            this.ExpenseRate.HeaderText = "Rate";
            this.ExpenseRate.Name = "ExpenseRate";
            this.ExpenseRate.ReadOnly = true;
            // 
            // EMPID
            // 
            this.EMPID.DataPropertyName = "EMP_Name";
            this.EMPID.HeaderText = "Employee";
            this.EMPID.Name = "EMPID";
            this.EMPID.ReadOnly = true;
            // 
            // PaymentType
            // 
            this.PaymentType.DataPropertyName = "P_Via";
            this.PaymentType.HeaderText = "Payment Via";
            this.PaymentType.Name = "PaymentType";
            this.PaymentType.ReadOnly = true;
            // 
            // ExpenseDate
            // 
            this.ExpenseDate.DataPropertyName = "Date";
            this.ExpenseDate.HeaderText = "Date";
            this.ExpenseDate.Name = "ExpenseDate";
            this.ExpenseDate.ReadOnly = true;
            // 
            // ExpenseTime
            // 
            this.ExpenseTime.DataPropertyName = "Time";
            this.ExpenseTime.HeaderText = "Time";
            this.ExpenseTime.Name = "ExpenseTime";
            this.ExpenseTime.ReadOnly = true;
            // 
            // RestoreExpensebtn
            // 
            this.RestoreExpensebtn.FillWeight = 50F;
            this.RestoreExpensebtn.HeaderText = "Restore";
            this.RestoreExpensebtn.Name = "RestoreExpensebtn";
            this.RestoreExpensebtn.ReadOnly = true;
            this.RestoreExpensebtn.Text = "Restore";
            this.RestoreExpensebtn.UseColumnTextForButtonValue = true;
            // 
            // DeleteExpensebtn
            // 
            this.DeleteExpensebtn.FillWeight = 50F;
            this.DeleteExpensebtn.HeaderText = "Delete";
            this.DeleteExpensebtn.Name = "DeleteExpensebtn";
            this.DeleteExpensebtn.ReadOnly = true;
            this.DeleteExpensebtn.Text = "Delete";
            this.DeleteExpensebtn.UseColumnTextForButtonValue = true;
            // 
            // ViewExpenseRecycleBin_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "ViewExpenseRecycleBin_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ViewExpenseRecycleBin_uc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DeletedExpenseData)).EndInit();
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton ExpenseType;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2DateTimePicker selecteddate;
        private Guna.UI2.WinForms.Guna2DataGridView DeletedExpenseData;
        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseID;
        private System.Windows.Forms.DataGridViewComboBoxColumn ExpenseTypeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseTime;
        private System.Windows.Forms.DataGridViewButtonColumn RestoreExpensebtn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpensebtn;
    }
}
