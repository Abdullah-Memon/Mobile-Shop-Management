﻿namespace Mobile_Shop.Expense
{
    partial class ViewExpense_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ExpenseType = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SelectedDate2 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.SelectedDate1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.ExpenseData = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ExpenseID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseTypeID = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ExpenseRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpdateExpensebtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpensebtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ExpenseData)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(845, 10);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(100, 36);
            this.guna2GradientButton1.TabIndex = 24;
            this.guna2GradientButton1.Text = "Search";
            this.guna2GradientButton1.Click += new System.EventHandler(this.search_Click_1);
            // 
            // ExpenseType
            // 
            this.ExpenseType.BackColor = System.Drawing.Color.Transparent;
            this.ExpenseType.BorderColor = System.Drawing.Color.White;
            this.ExpenseType.BorderRadius = 10;
            this.ExpenseType.BorderThickness = 2;
            this.ExpenseType.CheckedState.Parent = this.ExpenseType;
            this.ExpenseType.CustomImages.Parent = this.ExpenseType;
            this.ExpenseType.FillColor = System.Drawing.Color.Indigo;
            this.ExpenseType.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ExpenseType.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExpenseType.ForeColor = System.Drawing.Color.White;
            this.ExpenseType.HoverState.Parent = this.ExpenseType;
            this.ExpenseType.Location = new System.Drawing.Point(3, 10);
            this.ExpenseType.Name = "ExpenseType";
            this.ExpenseType.ShadowDecoration.Parent = this.ExpenseType;
            this.ExpenseType.Size = new System.Drawing.Size(100, 36);
            this.ExpenseType.TabIndex = 24;
            this.ExpenseType.Text = "All Expenses";
            this.ExpenseType.Click += new System.EventHandler(this.ExpenseType_Click_1);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(951, 3);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton1.TabIndex = 20;
            this.guna2CircleButton1.Text = "♻️";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(1007, 3);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 21;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(567, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 19);
            this.label2.TabIndex = 18;
            this.label2.Text = "To";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(287, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 19);
            this.label1.TabIndex = 18;
            this.label1.Text = "From";
            // 
            // SelectedDate2
            // 
            this.SelectedDate2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectedDate2.BorderRadius = 10;
            this.SelectedDate2.CheckedState.Parent = this.SelectedDate2;
            this.SelectedDate2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SelectedDate2.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.SelectedDate2.HoverState.Parent = this.SelectedDate2;
            this.SelectedDate2.Location = new System.Drawing.Point(612, 10);
            this.SelectedDate2.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.SelectedDate2.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.SelectedDate2.Name = "SelectedDate2";
            this.SelectedDate2.ShadowDecoration.Parent = this.SelectedDate2;
            this.SelectedDate2.Size = new System.Drawing.Size(200, 36);
            this.SelectedDate2.TabIndex = 1;
            this.SelectedDate2.Value = new System.DateTime(2022, 7, 16, 10, 46, 14, 42);
            // 
            // SelectedDate1
            // 
            this.SelectedDate1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectedDate1.BorderRadius = 10;
            this.SelectedDate1.CheckedState.Parent = this.SelectedDate1;
            this.SelectedDate1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SelectedDate1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.SelectedDate1.HoverState.Parent = this.SelectedDate1;
            this.SelectedDate1.Location = new System.Drawing.Point(361, 10);
            this.SelectedDate1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.SelectedDate1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.SelectedDate1.Name = "SelectedDate1";
            this.SelectedDate1.ShadowDecoration.Parent = this.SelectedDate1;
            this.SelectedDate1.Size = new System.Drawing.Size(200, 36);
            this.SelectedDate1.TabIndex = 1;
            this.SelectedDate1.Value = new System.DateTime(2022, 7, 16, 10, 46, 14, 42);
            // 
            // ExpenseData
            // 
            this.ExpenseData.AllowUserToAddRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.ExpenseData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.ExpenseData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ExpenseData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ExpenseData.BackgroundColor = System.Drawing.Color.White;
            this.ExpenseData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ExpenseData.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ExpenseData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ExpenseData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.ExpenseData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ExpenseID,
            this.ExpenseTypeID,
            this.ExpenseRate,
            this.EMPID,
            this.PaymentType,
            this.ExpenseDate,
            this.ExpenseTime,
            this.UpdateExpensebtn,
            this.DeleteExpensebtn});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ExpenseData.DefaultCellStyle = dataGridViewCellStyle6;
            this.ExpenseData.EnableHeadersVisualStyles = false;
            this.ExpenseData.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.ExpenseData.Location = new System.Drawing.Point(3, 59);
            this.ExpenseData.Name = "ExpenseData";
            this.ExpenseData.RowHeadersVisible = false;
            this.ExpenseData.RowTemplate.Height = 40;
            this.ExpenseData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ExpenseData.Size = new System.Drawing.Size(1054, 492);
            this.ExpenseData.TabIndex = 0;
            this.ExpenseData.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.ExpenseData.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.ExpenseData.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.ExpenseData.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.ExpenseData.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.ExpenseData.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.ExpenseData.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.ExpenseData.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.ExpenseData.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.ExpenseData.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ExpenseData.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.ExpenseData.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.ExpenseData.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ExpenseData.ThemeStyle.HeaderStyle.Height = 23;
            this.ExpenseData.ThemeStyle.ReadOnly = false;
            this.ExpenseData.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.ExpenseData.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ExpenseData.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.ExpenseData.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.ExpenseData.ThemeStyle.RowsStyle.Height = 40;
            this.ExpenseData.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.ExpenseData.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.ExpenseData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ExpenseData_CellContentClick);
            // 
            // ExpenseID
            // 
            this.ExpenseID.DataPropertyName = "EID";
            this.ExpenseID.HeaderText = "ExpenseID";
            this.ExpenseID.Name = "ExpenseID";
            this.ExpenseID.Visible = false;
            // 
            // ExpenseTypeID
            // 
            this.ExpenseTypeID.DataPropertyName = "ETID";
            this.ExpenseTypeID.HeaderText = "Expense Type";
            this.ExpenseTypeID.Name = "ExpenseTypeID";
            // 
            // ExpenseRate
            // 
            this.ExpenseRate.DataPropertyName = "Rate";
            this.ExpenseRate.HeaderText = "Rate";
            this.ExpenseRate.Name = "ExpenseRate";
            // 
            // EMPID
            // 
            this.EMPID.DataPropertyName = "EMP_Name";
            this.EMPID.HeaderText = "Employee";
            this.EMPID.Name = "EMPID";
            // 
            // PaymentType
            // 
            this.PaymentType.DataPropertyName = "P_Via";
            this.PaymentType.HeaderText = "Payment Via";
            this.PaymentType.Name = "PaymentType";
            // 
            // ExpenseDate
            // 
            this.ExpenseDate.DataPropertyName = "Date";
            this.ExpenseDate.HeaderText = "Date";
            this.ExpenseDate.Name = "ExpenseDate";
            // 
            // ExpenseTime
            // 
            this.ExpenseTime.DataPropertyName = "Time";
            this.ExpenseTime.HeaderText = "Time";
            this.ExpenseTime.Name = "ExpenseTime";
            // 
            // UpdateExpensebtn
            // 
            this.UpdateExpensebtn.FillWeight = 50F;
            this.UpdateExpensebtn.HeaderText = "Update";
            this.UpdateExpensebtn.Name = "UpdateExpensebtn";
            this.UpdateExpensebtn.Text = "Update";
            this.UpdateExpensebtn.UseColumnTextForButtonValue = true;
            // 
            // DeleteExpensebtn
            // 
            this.DeleteExpensebtn.FillWeight = 50F;
            this.DeleteExpensebtn.HeaderText = "Delete";
            this.DeleteExpensebtn.Name = "DeleteExpensebtn";
            this.DeleteExpensebtn.Text = "Delete";
            this.DeleteExpensebtn.UseColumnTextForButtonValue = true;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this.ExpenseData;
            // 
            // ViewExpense_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ExpenseData);
            this.Controls.Add(this.ExpenseType);
            this.Controls.Add(this.guna2GradientButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SelectedDate1);
            this.Controls.Add(this.Backbtn);
            this.Controls.Add(this.SelectedDate2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Name = "ViewExpense_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ViewExpense_uc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ExpenseData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView ExpenseData;
        private Guna.UI2.WinForms.Guna2DateTimePicker SelectedDate1;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DateTimePicker SelectedDate2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientButton ExpenseType;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseID;
        private System.Windows.Forms.DataGridViewComboBoxColumn ExpenseTypeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseTime;
        private System.Windows.Forms.DataGridViewButtonColumn UpdateExpensebtn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpensebtn;
    }
}
