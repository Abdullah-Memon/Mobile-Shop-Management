﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Expense
{
    public partial class ViewExpenseRecycleBin_uc : UserControl
    {
        public ViewExpenseRecycleBin_uc()
        {
            InitializeComponent();
        }
        SqlCommand cmd;

        private void getDeletedExpense()
        {
            DataTable getexpensedata;

            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                getexpensedata = new DataTable();
                cmd = new SqlCommand("ExpenseTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                getexpensedata.Load(cmd.ExecuteReader());

                ExpenseTypeID.DataSource = getexpensedata;
                ExpenseTypeID.DisplayMember = "E_Name";
                ExpenseTypeID.ValueMember = "ETID";


                getexpensedata = new DataTable();
                cmd = new SqlCommand("ExpenseDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                getexpensedata.Load(cmd.ExecuteReader());

                DeletedExpenseData.DataSource = getexpensedata;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting while getting data please try again " + ex.ToString(), "Error");
            }
        }
        private void ViewExpenseRecycleBin_uc_Load(object sender, EventArgs e)
        {
            getDeletedExpense();
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            ViewExpense_uc ve = new ViewExpense_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(ve);
            ve.Dock = DockStyle.Fill;
        }

        private void DeletedExpenseData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // MessageBox.Show(e.ColumnIndex.ToString());
            //0 == restore and 1 == delete
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateExpense", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@eid", DeletedExpenseData.Rows[e.RowIndex].Cells["ExpenseID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@expensetype", DeletedExpenseData.Rows[e.RowIndex].Cells["ExpenseTypeID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@rate", DeletedExpenseData.Rows[e.RowIndex].Cells["ExpenseRate"].Value));
                    cmd.Parameters.Add(new SqlParameter("@status", 0));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating data Please try again " + ex.ToString(), "Error");
                }
                getDeletedExpense();

            }
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure you want to permanantly delete the selected index","Confirmation",MessageBoxButtons.YesNo)==DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("RemoveExpense", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@eid", DeletedExpenseData.Rows[e.RowIndex].Cells["ExpenseID"].Value));

                        cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while Deleting data Please try again " + ex.ToString(), "Error");
                    }
                    getDeletedExpense();
                }
                
            }
        }
    }
}
