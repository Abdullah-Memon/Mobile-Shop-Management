﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Expense
{
    public partial class AddExpenseForm : Form
    {
        public AddExpenseForm()
        {
            InitializeComponent();
        }
        // global variables
        SqlCommand cmd;

        // retriving expense type function
        private void getExpenseType()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable getexpensedata = new DataTable();
                cmd = new SqlCommand("ExpenseTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                getexpensedata.Load(cmd.ExecuteReader());
                DB.con.Close();

                ExpenseTypeBox.DataSource = getexpensedata;
                ExpenseTypeBox.DisplayMember = "E_Name";
                ExpenseTypeBox.ValueMember = "ETID";
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while getting ExpenseType data Please Try again " + ex.ToString(), "Error");
            }
        }

        // getting payment Type
        private void GetPaymentType()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                PaymentTypeBox.DataSource = dt;
                PaymentTypeBox.ValueMember = "PID";
                PaymentTypeBox.DisplayMember = "P_Type";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // main load function
        private void AddExpenseForm_Load(object sender, EventArgs e)
        {
            // retriving expense types
            getExpenseType();
            GetPaymentType();

            // setting up todays date
            setDateTime.Text = DateTime.Now.ToString();

            if (LoginForm.LoginScreen.personal_info.Rows[0][6].ToString() == "Admin")
                setDateTime.Enabled = true;
            else
                setDateTime.Enabled = false;

            label5.Hide();
            label6.Hide();
        }

        // Closing button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Add Expense Coding
        private void ExpenseType_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(price.Text) || !string.IsNullOrWhiteSpace(price.Text)) && (!string.IsNullOrWhiteSpace(PaymentTypeBox.Text) || !string.IsNullOrEmpty(PaymentTypeBox.Text)))
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                    cmd = new SqlCommand("AddExpense",DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@expensetype", ExpenseTypeBox.SelectedValue));
                    cmd.Parameters.Add(new SqlParameter("@Rate", Convert.ToDecimal(price.Text)));
                    cmd.Parameters.Add(new SqlParameter("@emp", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                    cmd.Parameters.Add(new SqlParameter("@date", setDateTime.Value));
                    cmd.Parameters.Add(new SqlParameter("@time", setDateTime.Value));
                    cmd.Parameters.Add(new SqlParameter("@pid", PaymentTypeBox.SelectedValue));
                    int chk = cmd.ExecuteNonQuery();
                    DB.con.Close();

                    if (chk > 0)
                    {
                        label5.Hide();
                        label6.Show();
                        price.Text = string.Empty;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while adding Expense Please try again " + ex.ToString(), "Error");
                }
            }
            else
                label5.Show();
        }

        //Bounding User inputs
        private void price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '.'))
                e.Handled = true;
        }

    }
}
