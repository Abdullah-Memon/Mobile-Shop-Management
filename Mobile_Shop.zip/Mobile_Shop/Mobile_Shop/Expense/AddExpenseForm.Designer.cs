﻿namespace Mobile_Shop.Expense
{
    partial class AddExpenseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.ExpenseTypeBox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.price = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.setDateTime = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.ExpenseType = new Guna.UI2.WinForms.Guna2GradientButton();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.PaymentTypeBox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.contentpanel.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(20, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 31);
            this.label1.TabIndex = 18;
            this.label1.Text = "Added Expense";
            // 
            // ExpenseTypeBox
            // 
            this.ExpenseTypeBox.BackColor = System.Drawing.Color.Transparent;
            this.ExpenseTypeBox.BorderRadius = 10;
            this.ExpenseTypeBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ExpenseTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ExpenseTypeBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ExpenseTypeBox.FocusedColor = System.Drawing.Color.Empty;
            this.ExpenseTypeBox.FocusedState.Parent = this.ExpenseTypeBox;
            this.ExpenseTypeBox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.ExpenseTypeBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.ExpenseTypeBox.FormattingEnabled = true;
            this.ExpenseTypeBox.HoverState.Parent = this.ExpenseTypeBox;
            this.ExpenseTypeBox.ItemHeight = 30;
            this.ExpenseTypeBox.ItemsAppearance.Parent = this.ExpenseTypeBox;
            this.ExpenseTypeBox.Location = new System.Drawing.Point(248, 86);
            this.ExpenseTypeBox.Name = "ExpenseTypeBox";
            this.ExpenseTypeBox.ShadowDecoration.Parent = this.ExpenseTypeBox;
            this.ExpenseTypeBox.Size = new System.Drawing.Size(204, 36);
            this.ExpenseTypeBox.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(244, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Expense Type";
            // 
            // price
            // 
            this.price.BorderRadius = 10;
            this.price.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.price.DefaultText = "";
            this.price.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.price.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.price.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.price.DisabledState.Parent = this.price;
            this.price.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.price.FillColor = System.Drawing.Color.WhiteSmoke;
            this.price.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.price.FocusedState.Parent = this.price;
            this.price.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.price.HoverState.Parent = this.price;
            this.price.Location = new System.Drawing.Point(248, 164);
            this.price.Name = "price";
            this.price.PasswordChar = '\0';
            this.price.PlaceholderText = "";
            this.price.SelectedText = "";
            this.price.ShadowDecoration.Parent = this.price;
            this.price.Size = new System.Drawing.Size(204, 36);
            this.price.TabIndex = 20;
            this.price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.price_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(244, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Rate";
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(5, 29);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(40, 40);
            this.Backbtn.TabIndex = 21;
            this.Backbtn.Text = "X";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // setDateTime
            // 
            this.setDateTime.BorderRadius = 10;
            this.setDateTime.CheckedState.Parent = this.setDateTime;
            this.setDateTime.FillColor = System.Drawing.Color.WhiteSmoke;
            this.setDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.setDateTime.HoverState.Parent = this.setDateTime;
            this.setDateTime.Location = new System.Drawing.Point(29, 86);
            this.setDateTime.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.setDateTime.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.setDateTime.Name = "setDateTime";
            this.setDateTime.ShadowDecoration.Parent = this.setDateTime;
            this.setDateTime.Size = new System.Drawing.Size(204, 36);
            this.setDateTime.TabIndex = 22;
            this.setDateTime.Value = new System.DateTime(2022, 7, 16, 7, 43, 13, 219);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(25, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Date";
            // 
            // ExpenseType
            // 
            this.ExpenseType.BackColor = System.Drawing.Color.Transparent;
            this.ExpenseType.BorderColor = System.Drawing.Color.White;
            this.ExpenseType.BorderRadius = 10;
            this.ExpenseType.BorderThickness = 2;
            this.ExpenseType.CheckedState.Parent = this.ExpenseType;
            this.ExpenseType.CustomImages.Parent = this.ExpenseType;
            this.ExpenseType.FillColor = System.Drawing.Color.Indigo;
            this.ExpenseType.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.ExpenseType.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExpenseType.ForeColor = System.Drawing.Color.White;
            this.ExpenseType.HoverState.Parent = this.ExpenseType;
            this.ExpenseType.Location = new System.Drawing.Point(294, 218);
            this.ExpenseType.Name = "ExpenseType";
            this.ExpenseType.ShadowDecoration.Parent = this.ExpenseType;
            this.ExpenseType.Size = new System.Drawing.Size(144, 45);
            this.ExpenseType.TabIndex = 23;
            this.ExpenseType.Text = "Add Expense Type";
            this.ExpenseType.Click += new System.EventHandler(this.ExpenseType_Click);
            // 
            // contentpanel
            // 
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 15;
            this.contentpanel.Controls.Add(this.guna2GradientPanel1);
            this.contentpanel.Controls.Add(this.label6);
            this.contentpanel.Controls.Add(this.label5);
            this.contentpanel.Controls.Add(this.ExpenseType);
            this.contentpanel.Controls.Add(this.label1);
            this.contentpanel.Controls.Add(this.setDateTime);
            this.contentpanel.Controls.Add(this.label7);
            this.contentpanel.Controls.Add(this.label2);
            this.contentpanel.Controls.Add(this.label3);
            this.contentpanel.Controls.Add(this.price);
            this.contentpanel.Controls.Add(this.label4);
            this.contentpanel.Controls.Add(this.PaymentTypeBox);
            this.contentpanel.Controls.Add(this.ExpenseTypeBox);
            this.contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentpanel.FillColor = System.Drawing.Color.Indigo;
            this.contentpanel.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.contentpanel.Location = new System.Drawing.Point(10, 10);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(469, 279);
            this.contentpanel.TabIndex = 24;
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel1.BorderRadius = 20;
            this.guna2GradientPanel1.Controls.Add(this.Backbtn);
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.White;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(402, -23);
            this.guna2GradientPanel1.Margin = new System.Windows.Forms.Padding(5);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(50, 75);
            this.guna2GradientPanel1.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(27, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(179, 18);
            this.label6.TabIndex = 24;
            this.label6.Text = "*Expense has been added";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(299, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 18);
            this.label5.TabIndex = 24;
            this.label5.Text = "*Please enter the price";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Handwriting", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(25, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Payment Type";
            // 
            // PaymentTypeBox
            // 
            this.PaymentTypeBox.BackColor = System.Drawing.Color.Transparent;
            this.PaymentTypeBox.BorderRadius = 10;
            this.PaymentTypeBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.PaymentTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypeBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PaymentTypeBox.FocusedColor = System.Drawing.Color.Empty;
            this.PaymentTypeBox.FocusedState.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PaymentTypeBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.PaymentTypeBox.FormattingEnabled = true;
            this.PaymentTypeBox.HoverState.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.ItemHeight = 30;
            this.PaymentTypeBox.ItemsAppearance.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Location = new System.Drawing.Point(29, 164);
            this.PaymentTypeBox.Name = "PaymentTypeBox";
            this.PaymentTypeBox.ShadowDecoration.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Size = new System.Drawing.Size(204, 36);
            this.PaymentTypeBox.TabIndex = 19;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.contentpanel;
            // 
            // AddExpenseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(489, 299);
            this.Controls.Add(this.contentpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddExpenseForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AddExpenseForm";
            this.Load += new System.EventHandler(this.AddExpenseForm_Load);
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            this.guna2GradientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox ExpenseTypeBox;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox price;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2DateTimePicker setDateTime;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2GradientButton ExpenseType;
        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2ComboBox PaymentTypeBox;
    }
}