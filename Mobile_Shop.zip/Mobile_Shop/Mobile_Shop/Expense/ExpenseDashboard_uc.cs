﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.Expense
{
    public partial class ExpenseDashboard_uc : UserControl
    {
        public ExpenseDashboard_uc()
        {
            InitializeComponent();
        }

        // Screens to Load
        AddExpenseType_uc aet;
        ViewExpense_uc ve;
        AddExpenseForm aef;

        // View Expense Type Coding
        private void ExpenseType_Click(object sender, EventArgs e)
        {
            if (aet == null)
                aet = new AddExpenseType_uc();

            LoginForm.LoginScreen.ms.addusercontrol(aet);
        }

        // Loding Add Expense
        private void AddExpense_Click(object sender, EventArgs e)
        {
            if(aef == null)
                aef = new AddExpenseForm();
            aef.ShowDialog();
        }
        
        // Loading View Expense
        private void ViewExpense_Click(object sender, EventArgs e)
        {
            if(ve == null)
                ve = new ViewExpense_uc();

            LoginForm.LoginScreen.ms.addusercontrol(ve);
        }

        // Loding Expensee Report
        private void ExpenseReport_Click(object sender, EventArgs e)
        {
            ExpenseReporting.ExpenseReport_Form erf = new ExpenseReporting.ExpenseReport_Form();
            erf.Show();
        }

        private void ExpenseDashboard_uc_Load(object sender, EventArgs e)
        {
            ExpenseType.Focus();
        }
    }
}
