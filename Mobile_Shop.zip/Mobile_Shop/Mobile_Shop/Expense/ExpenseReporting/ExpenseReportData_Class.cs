﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.Expense.ExpenseReporting
{
    class ExpenseReportData_Class
    {
        public static string E_Name {set;get;}
        public static string Rate {set;get;}
        public static string EMP_Name {set;get;}
        public static string P_Via {set;get;}
        public static string Date {set;get;}
        public static string Time { set; get; }
    }
}
