﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Expense
{
    public partial class ExpenseTypeRecycleBin_uc : UserControl
    {
        public ExpenseTypeRecycleBin_uc()
        {
            InitializeComponent();
        }

        // global variables
        SqlCommand cmd;

        // getting deleted Expense type data
        private void getDeletedExpenseType()
        {
            DataTable expensetypedata = new DataTable();
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                cmd = new SqlCommand("ExpenseTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@status", 1));
                expensetypedata.Load(cmd.ExecuteReader());
                DB.con.Close();

                // setting up the data to show
                showDeletedExpenseType.DataSource = expensetypedata;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting Expense Type Record Please try again" + ex.ToString(), "Error");
            }
        }

        private void ExpenseTypeRecycleBin_uc_Load(object sender, EventArgs e)
        {
            // getting deleted data
            getDeletedExpenseType();
        }

        // grid view button coding
        private void showExpenseType_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Restore button coding
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@expensetypeid", showDeletedExpenseType.Rows[e.RowIndex].Cells["ExpenseID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@expensetypename", showDeletedExpenseType.Rows[e.RowIndex].Cells["Expense"].Value.ToString()));
                    
                    cmd.ExecuteNonQuery();

                    DB.con.Close();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while Restoring Expense Type " + ex.ToString(), "Error");
                }

                // Refreshing with new data
                getDeletedExpenseType();

            }

            // delete button coding
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure you want to Permanatly Delete Expense Type", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("RemoveExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@expensetypeid", showDeletedExpenseType.Rows[e.RowIndex].Cells["ExpenseID"].Value));
                        cmd.ExecuteNonQuery();
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while permanatly deleting Expense Type please Try again" + ex.ToString(), "Error");
                    }

                    // refreshing with new data
                    getDeletedExpenseType();
                }
            }
        }

        //Back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            AddExpenseType_uc aet = new AddExpenseType_uc();
            ContentPanel.Controls.Clear();
            ContentPanel.Controls.Add(aet);
            aet.Dock = DockStyle.Fill;
        }

        // all items restore button coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (DB.con.State== ConnectionState.Closed)
            {
                DB.con.Open();
                    
            }
            for (int i = 0; i < showDeletedExpenseType.Rows.Count; i++)
            {
                cmd = new SqlCommand("UpdateExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@expensetypeid", showDeletedExpenseType.Rows[i].Cells["ExpenseID"].Value));
                cmd.Parameters.Add(new SqlParameter("@expensetypename", showDeletedExpenseType.Rows[i].Cells["Expense"].Value.ToString()));

                cmd.ExecuteNonQuery();
            }
            DB.con.Close();
            // refreshing gridview
            getDeletedExpenseType();
        }

        // all items delete button coding
        private void AllDeletebtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete all data parmanently? ","Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();

                }
                for (int i = 0; i < showDeletedExpenseType.Rows.Count; i++)
                {
                    cmd = new SqlCommand("RemoveExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@expensetypeid", showDeletedExpenseType.Rows[i].Cells["ExpenseID"].Value));
                    cmd.ExecuteNonQuery();
                }
                DB.con.Close();

                //refreshing gridview
                getDeletedExpenseType();
            }
        }
    }
}
