﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.Expense
{
    public partial class AddExpenseType_uc : UserControl
    {
        public AddExpenseType_uc()
        {
            InitializeComponent();
        }
        // global variables used multiple times

        SqlCommand cmd;
        int chk = 0;

        // getting saved data of Expense type
        private void getExpenseType()
        {
            DataTable expensetypedata = new DataTable();
            if (DB.con.State == ConnectionState.Closed)
            {
                DB.con.Open();
            }
            try
            {
                cmd = new SqlCommand("ExpenseTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                expensetypedata.Load(cmd.ExecuteReader());
                DB.con.Close();

                // setting grid view data
                showExpenseType.DataSource = expensetypedata;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while getting Expense Type Record Please try again" + ex.ToString(), "Error");
            }
        }
        private void AddExpenseType_uc_Load(object sender, EventArgs e)
        {
            // getting saved data
            getExpenseType();

            // hiding some warning messages
            label2.Hide();
            label3.Hide();
            label4.Hide();
        }

        // Add expense type button coding
        private void Additem_Click(object sender, EventArgs e)
        {
            if (newExpenseBox.Text != string.Empty)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("AddExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@expensetype", newExpenseBox.Text));

                    chk = cmd.ExecuteNonQuery();
                    DB.con.Close();

                    //refresh with new data
                    getExpenseType();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error while adding new Expense Please try again" + ex.ToString(), "Error");
                }

                if (chk > 0)
                    label2.Hide();
                newExpenseBox.Text = string.Empty;

            }
            else
            {
                newExpenseBox.Focus();
                label2.Show();
            }
        }

        // grid view button coding
        private void showExpenseType_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex.ToString());
            // Update  button coding
            if (e.ColumnIndex == 0)
            {
                if (DB.con.State == ConnectionState.Closed)
                {
                    DB.con.Open();
                }
                try
                {
                    cmd = new SqlCommand("UpdateExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@expensetypeid", showExpenseType.Rows[e.RowIndex].Cells["ExpenseID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@expensetypename", showExpenseType.Rows[e.RowIndex].Cells["Expense"].Value.ToString()));
                    chk = cmd.ExecuteNonQuery();

                    DB.con.Close();

                    // showing messages
                    if (chk>0)
                    {
                        label4.Show();
                        label3.Hide();
                    }
                    // refresing with new data
                    getExpenseType();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating Expense Type " + ex.ToString(), "Error");
                }
            }

            //delete button coding
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure you want to remove Expense Type","Confirmation",MessageBoxButtons.YesNo)== DialogResult.Yes)
                {
                    if (DB.con.State == ConnectionState.Closed)
                    {
                        DB.con.Open();
                    }
                    try
                    {
                        cmd = new SqlCommand("RemoveExpenseType", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@expensetypeid", showExpenseType.Rows[e.RowIndex].Cells["ExpenseID"].Value));
                        chk = cmd.ExecuteNonQuery();
                        DB.con.Close();

                        // showing messages
                        if (chk > 0)
                        {
                            label3.Show();
                            label4.Hide();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while removing Expense Type please Try again" + ex.ToString(), "Error");
                    }
                    // refresing with new data
                    getExpenseType();

                }
            }
        }

        // RecycleBin button coding
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            ExpenseTypeRecycleBin_uc etrb = new ExpenseTypeRecycleBin_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(etrb);
            etrb.Dock = DockStyle.Fill;
        }

        //back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            ExpenseDashboard_uc ed = new ExpenseDashboard_uc();
            contentpanel.Controls.Clear();
            contentpanel.Controls.Add(ed);
            ed.Dock = DockStyle.Fill;
        }
    }
}
