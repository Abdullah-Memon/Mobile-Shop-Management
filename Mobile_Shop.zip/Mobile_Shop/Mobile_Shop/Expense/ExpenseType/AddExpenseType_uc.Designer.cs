﻿namespace Mobile_Shop.Expense
{
    partial class AddExpenseType_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contentpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.Additem = new Guna.UI2.WinForms.Guna2GradientButton();
            this.showExpenseType = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ExpenseID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Expense = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updateItems = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpense = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.newExpenseBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.contentpanel.SuspendLayout();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showExpenseType)).BeginInit();
            this.SuspendLayout();
            // 
            // contentpanel
            // 
            this.contentpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.contentpanel.BackColor = System.Drawing.Color.Transparent;
            this.contentpanel.BorderRadius = 20;
            this.contentpanel.BorderThickness = 1;
            this.contentpanel.Controls.Add(this.ShowAddedItemsDetailBox);
            this.contentpanel.Controls.Add(this.label1);
            this.contentpanel.Controls.Add(this.Backbtn);
            this.contentpanel.Controls.Add(this.guna2CircleButton1);
            this.contentpanel.Location = new System.Drawing.Point(0, 0);
            this.contentpanel.Name = "contentpanel";
            this.contentpanel.ShadowDecoration.Parent = this.contentpanel;
            this.contentpanel.Size = new System.Drawing.Size(1060, 554);
            this.contentpanel.TabIndex = 0;
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.Additem);
            this.ShowAddedItemsDetailBox.Controls.Add(this.showExpenseType);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label4);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label3);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label2);
            this.ShowAddedItemsDetailBox.Controls.Add(this.label8);
            this.ShowAddedItemsDetailBox.Controls.Add(this.newExpenseBox);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(0, 68);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(1060, 486);
            this.ShowAddedItemsDetailBox.TabIndex = 5;
            // 
            // Additem
            // 
            this.Additem.BackColor = System.Drawing.Color.Transparent;
            this.Additem.BorderColor = System.Drawing.Color.White;
            this.Additem.BorderRadius = 10;
            this.Additem.BorderThickness = 2;
            this.Additem.CheckedState.Parent = this.Additem;
            this.Additem.CustomImages.Parent = this.Additem;
            this.Additem.FillColor = System.Drawing.Color.Indigo;
            this.Additem.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Additem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Additem.ForeColor = System.Drawing.Color.White;
            this.Additem.HoverState.Parent = this.Additem;
            this.Additem.Location = new System.Drawing.Point(225, 122);
            this.Additem.Name = "Additem";
            this.Additem.ShadowDecoration.Parent = this.Additem;
            this.Additem.Size = new System.Drawing.Size(106, 36);
            this.Additem.TabIndex = 15;
            this.Additem.Text = "ADD";
            this.Additem.Click += new System.EventHandler(this.Additem_Click);
            // 
            // showExpenseType
            // 
            this.showExpenseType.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showExpenseType.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.showExpenseType.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showExpenseType.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.showExpenseType.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.showExpenseType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showExpenseType.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showExpenseType.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showExpenseType.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.showExpenseType.ColumnHeadersHeight = 21;
            this.showExpenseType.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ExpenseID,
            this.Expense,
            this.updateItems,
            this.DeleteExpense});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.showExpenseType.DefaultCellStyle = dataGridViewCellStyle3;
            this.showExpenseType.EnableHeadersVisualStyles = false;
            this.showExpenseType.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showExpenseType.Location = new System.Drawing.Point(351, 35);
            this.showExpenseType.Name = "showExpenseType";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showExpenseType.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.showExpenseType.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.showExpenseType.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.showExpenseType.RowTemplate.Height = 50;
            this.showExpenseType.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.showExpenseType.Size = new System.Drawing.Size(688, 448);
            this.showExpenseType.TabIndex = 20;
            this.showExpenseType.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.showExpenseType.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showExpenseType.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.showExpenseType.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.showExpenseType.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.showExpenseType.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.showExpenseType.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.showExpenseType.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showExpenseType.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.showExpenseType.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.showExpenseType.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showExpenseType.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.showExpenseType.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.showExpenseType.ThemeStyle.HeaderStyle.Height = 21;
            this.showExpenseType.ThemeStyle.ReadOnly = false;
            this.showExpenseType.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.showExpenseType.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showExpenseType.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showExpenseType.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.showExpenseType.ThemeStyle.RowsStyle.Height = 50;
            this.showExpenseType.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.showExpenseType.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.showExpenseType.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showExpenseType_CellContentClick);
            // 
            // ExpenseID
            // 
            this.ExpenseID.DataPropertyName = "ETID";
            this.ExpenseID.HeaderText = "ExpenseID";
            this.ExpenseID.Name = "ExpenseID";
            this.ExpenseID.Visible = false;
            // 
            // Expense
            // 
            this.Expense.DataPropertyName = "E_Name";
            this.Expense.FillWeight = 99.11879F;
            this.Expense.HeaderText = "Expense";
            this.Expense.Name = "Expense";
            // 
            // updateItems
            // 
            this.updateItems.FillWeight = 30F;
            this.updateItems.HeaderText = "Update";
            this.updateItems.Name = "updateItems";
            this.updateItems.Text = "Update";
            this.updateItems.UseColumnTextForButtonValue = true;
            // 
            // DeleteExpense
            // 
            this.DeleteExpense.FillWeight = 30F;
            this.DeleteExpense.HeaderText = "Delete";
            this.DeleteExpense.Name = "DeleteExpense";
            this.DeleteExpense.Text = "Delete";
            this.DeleteExpense.UseColumnTextForButtonValue = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(35, 218);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "* Expense has been updated";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(35, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(250, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "* Expense has been deleted successfully";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(35, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "* Please Enter Expense Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Expense Type";
            // 
            // newExpenseBox
            // 
            this.newExpenseBox.BorderRadius = 10;
            this.newExpenseBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newExpenseBox.DefaultText = "";
            this.newExpenseBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newExpenseBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newExpenseBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newExpenseBox.DisabledState.Parent = this.newExpenseBox;
            this.newExpenseBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newExpenseBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newExpenseBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newExpenseBox.FocusedState.Parent = this.newExpenseBox;
            this.newExpenseBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newExpenseBox.HoverState.Parent = this.newExpenseBox;
            this.newExpenseBox.Location = new System.Drawing.Point(39, 63);
            this.newExpenseBox.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.newExpenseBox.Name = "newExpenseBox";
            this.newExpenseBox.PasswordChar = '\0';
            this.newExpenseBox.PlaceholderText = "";
            this.newExpenseBox.SelectedText = "";
            this.newExpenseBox.ShadowDecoration.Parent = this.newExpenseBox;
            this.newExpenseBox.Size = new System.Drawing.Size(292, 47);
            this.newExpenseBox.TabIndex = 3;
            this.newExpenseBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(33, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 31);
            this.label1.TabIndex = 17;
            this.label1.Text = "Add Expense Type";
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(989, 12);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Location = new System.Drawing.Point(933, 12);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(50, 50);
            this.guna2CircleButton1.TabIndex = 19;
            this.guna2CircleButton1.Text = "♻️";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this.showExpenseType;
            // 
            // AddExpenseType_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.contentpanel);
            this.Name = "AddExpenseType_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.AddExpenseType_uc_Load);
            this.contentpanel.ResumeLayout(false);
            this.contentpanel.PerformLayout();
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            this.ShowAddedItemsDetailBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showExpenseType)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel contentpanel;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2DataGridView showExpenseType;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientButton Additem;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox newExpenseBox;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Expense;
        private System.Windows.Forms.DataGridViewButtonColumn updateItems;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpense;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}
