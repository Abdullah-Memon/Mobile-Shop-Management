﻿namespace Mobile_Shop.Expense
{
    partial class ExpenseTypeRecycleBin_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.AllRestorebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.AllDeletebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label1 = new System.Windows.Forms.Label();
            this.showDeletedExpenseType = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ExpenseID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Expense = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RestoreExpenseType = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteExpense = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showDeletedExpenseType)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.ContentPanel.BorderRadius = 20;
            this.ContentPanel.Controls.Add(this.AllRestorebtn);
            this.ContentPanel.Controls.Add(this.AllDeletebtn);
            this.ContentPanel.Controls.Add(this.label1);
            this.ContentPanel.Controls.Add(this.showDeletedExpenseType);
            this.ContentPanel.Controls.Add(this.Backbtn);
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 0;
            // 
            // AllRestorebtn
            // 
            this.AllRestorebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AllRestorebtn.BackColor = System.Drawing.Color.Transparent;
            this.AllRestorebtn.BorderColor = System.Drawing.Color.White;
            this.AllRestorebtn.BorderRadius = 10;
            this.AllRestorebtn.BorderThickness = 2;
            this.AllRestorebtn.CheckedState.Parent = this.AllRestorebtn;
            this.AllRestorebtn.CustomImages.Parent = this.AllRestorebtn;
            this.AllRestorebtn.FillColor = System.Drawing.Color.Indigo;
            this.AllRestorebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AllRestorebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AllRestorebtn.ForeColor = System.Drawing.Color.White;
            this.AllRestorebtn.HoverState.Parent = this.AllRestorebtn;
            this.AllRestorebtn.Location = new System.Drawing.Point(774, 23);
            this.AllRestorebtn.Name = "AllRestorebtn";
            this.AllRestorebtn.ShadowDecoration.Parent = this.AllRestorebtn;
            this.AllRestorebtn.Size = new System.Drawing.Size(89, 36);
            this.AllRestorebtn.TabIndex = 24;
            this.AllRestorebtn.Text = "Restore All";
            this.AllRestorebtn.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // AllDeletebtn
            // 
            this.AllDeletebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AllDeletebtn.BackColor = System.Drawing.Color.Transparent;
            this.AllDeletebtn.BorderColor = System.Drawing.Color.White;
            this.AllDeletebtn.BorderRadius = 10;
            this.AllDeletebtn.BorderThickness = 2;
            this.AllDeletebtn.CheckedState.Parent = this.AllDeletebtn;
            this.AllDeletebtn.CustomImages.Parent = this.AllDeletebtn;
            this.AllDeletebtn.FillColor = System.Drawing.Color.Indigo;
            this.AllDeletebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.AllDeletebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AllDeletebtn.ForeColor = System.Drawing.Color.White;
            this.AllDeletebtn.HoverState.Parent = this.AllDeletebtn;
            this.AllDeletebtn.Location = new System.Drawing.Point(869, 23);
            this.AllDeletebtn.Name = "AllDeletebtn";
            this.AllDeletebtn.ShadowDecoration.Parent = this.AllDeletebtn;
            this.AllDeletebtn.Size = new System.Drawing.Size(89, 36);
            this.AllDeletebtn.TabIndex = 25;
            this.AllDeletebtn.Text = "Delete All";
            this.AllDeletebtn.Click += new System.EventHandler(this.AllDeletebtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(15, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 31);
            this.label1.TabIndex = 21;
            this.label1.Text = "All Deleted Expense Type";
            // 
            // showDeletedExpenseType
            // 
            this.showDeletedExpenseType.AllowUserToAddRows = false;
            this.showDeletedExpenseType.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showDeletedExpenseType.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.showDeletedExpenseType.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showDeletedExpenseType.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.showDeletedExpenseType.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.showDeletedExpenseType.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showDeletedExpenseType.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showDeletedExpenseType.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showDeletedExpenseType.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.showDeletedExpenseType.ColumnHeadersHeight = 21;
            this.showDeletedExpenseType.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ExpenseID,
            this.Expense,
            this.RestoreExpenseType,
            this.DeleteExpense});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.showDeletedExpenseType.DefaultCellStyle = dataGridViewCellStyle8;
            this.showDeletedExpenseType.EnableHeadersVisualStyles = false;
            this.showDeletedExpenseType.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showDeletedExpenseType.Location = new System.Drawing.Point(3, 72);
            this.showDeletedExpenseType.Name = "showDeletedExpenseType";
            this.showDeletedExpenseType.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.showDeletedExpenseType.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.showDeletedExpenseType.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.showDeletedExpenseType.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.showDeletedExpenseType.RowTemplate.Height = 40;
            this.showDeletedExpenseType.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.showDeletedExpenseType.Size = new System.Drawing.Size(1054, 479);
            this.showDeletedExpenseType.TabIndex = 23;
            this.showDeletedExpenseType.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.showDeletedExpenseType.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.showDeletedExpenseType.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.showDeletedExpenseType.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.showDeletedExpenseType.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.showDeletedExpenseType.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.showDeletedExpenseType.ThemeStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.showDeletedExpenseType.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.showDeletedExpenseType.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.showDeletedExpenseType.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.showDeletedExpenseType.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showDeletedExpenseType.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.showDeletedExpenseType.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.showDeletedExpenseType.ThemeStyle.HeaderStyle.Height = 21;
            this.showDeletedExpenseType.ThemeStyle.ReadOnly = true;
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.Height = 40;
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.showDeletedExpenseType.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.showDeletedExpenseType.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showExpenseType_CellContentClick);
            // 
            // ExpenseID
            // 
            this.ExpenseID.DataPropertyName = "ETID";
            this.ExpenseID.HeaderText = "ExpenseID";
            this.ExpenseID.Name = "ExpenseID";
            this.ExpenseID.ReadOnly = true;
            this.ExpenseID.Visible = false;
            // 
            // Expense
            // 
            this.Expense.DataPropertyName = "E_Name";
            this.Expense.FillWeight = 99.11879F;
            this.Expense.HeaderText = "Expense";
            this.Expense.Name = "Expense";
            this.Expense.ReadOnly = true;
            // 
            // RestoreExpenseType
            // 
            this.RestoreExpenseType.FillWeight = 30F;
            this.RestoreExpenseType.HeaderText = "Restore";
            this.RestoreExpenseType.Name = "RestoreExpenseType";
            this.RestoreExpenseType.ReadOnly = true;
            this.RestoreExpenseType.Text = "Restore";
            this.RestoreExpenseType.UseColumnTextForButtonValue = true;
            // 
            // DeleteExpense
            // 
            this.DeleteExpense.FillWeight = 30F;
            this.DeleteExpense.HeaderText = "Delete";
            this.DeleteExpense.Name = "DeleteExpense";
            this.DeleteExpense.ReadOnly = true;
            this.DeleteExpense.Text = "Delete";
            this.DeleteExpense.UseColumnTextForButtonValue = true;
            // 
            // Backbtn
            // 
            this.Backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(983, 16);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(50, 50);
            this.Backbtn.TabIndex = 22;
            this.Backbtn.Text = "<--";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this.showDeletedExpenseType;
            // 
            // ExpenseTypeRecycleBin_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ContentPanel);
            this.Name = "ExpenseTypeRecycleBin_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.ExpenseTypeRecycleBin_uc_Load);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showDeletedExpenseType)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2DataGridView showDeletedExpenseType;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Expense;
        private System.Windows.Forms.DataGridViewButtonColumn RestoreExpenseType;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteExpense;
        private Guna.UI2.WinForms.Guna2GradientButton AllRestorebtn;
        private Guna.UI2.WinForms.Guna2GradientButton AllDeletebtn;
    }
}
