﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Telerik.Reporting;

namespace Mobile_Shop.PurchaseScreen.DuesReporting
{
    public partial class DuesReporting_Form : Form
    {
        private int ReportType;
        string aid;
        public DuesReporting_Form(int type)
        {
            InitializeComponent();
            ReportType = type;
        }

        private void DuesReporting_Form_Load(object sender, EventArgs e)
        {
            fromdate.Text = DateTime.Now.ToShortDateString();
            todate.Text = DateTime.Now.ToShortDateString();

            if (ReportType != 3)
            {
                Customebox.Hide();

                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    SqlCommand cmd = new SqlCommand("GenerateDuesReport", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", ReportType));

                    dt.Load(cmd.ExecuteReader());

                    DB.con.Close();

                    DuesReporting_Page drp = new DuesReporting_Page();
                    drp.DataSource = dt;

                    InstanceReportSource irp = new InstanceReportSource() { ReportDocument = drp };

                    reportViewer1.ReportSource = irp;
                    reportViewer1.RefreshReport();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                Customebox.Show();
                WindowState = FormWindowState.Maximized;
            }

            
        }

        // Cross button coding
        private void crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Maximized button coding
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                WindowState = FormWindowState.Normal;
            else
                WindowState = FormWindowState.Maximized;
        }

        // Minimized button coding
        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void upperpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void selectAccountbox_DoubleClick(object sender, EventArgs e)
        {
            PurchaseScreen.SelectSupplierAccountForm ssaf = new PurchaseScreen.SelectSupplierAccountForm(1);
            ssaf.ShowDialog();

            selectAccountbox.Text = PurchaseScreen.SelectSupplierAccountForm.supplier_name;
            aid = PurchaseScreen.SelectSupplierAccountForm.supplier_id;
        }

        private void Createbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectAccountbox.Text) || string.IsNullOrWhiteSpace(selectAccountbox.Text))
            {
                selectAccountbox.Focus();
            }
            else if (string.IsNullOrEmpty(selectcatagorybox.Text) || string.IsNullOrWhiteSpace(selectcatagorybox.Text))
            {
                selectcatagorybox.Focus();
            }
            else
            {
                try
                {
                    if(DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    SqlCommand cmd = new SqlCommand("GenerateCustomDues",DB.con){CommandType = CommandType.StoredProcedure};
                    cmd.Parameters.Add(new SqlParameter("@aid", aid));
                    cmd.Parameters.Add(new SqlParameter("@type", selectcatagorybox.SelectedIndex));
                    cmd.Parameters.Add(new SqlParameter("@fromdate", fromdate.Value));
                    cmd.Parameters.Add(new SqlParameter("@todate", todate.Value));
                    

                    dt.Load(cmd.ExecuteReader());

                    CustomDuesReporting_Page cdrp = new CustomDuesReporting_Page();
                    cdrp.DataSource = dt;

                    InstanceReportSource irp = new InstanceReportSource() { ReportDocument = cdrp };

                    reportViewer1.ReportSource = irp;
                    reportViewer1.RefreshReport();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void selectcatagorybox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
