﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.PurchaseScreen.DuesReporting
{
    class DuesReportingData_Class
    {
        //public byte[] A_Picture { set; get; }
        public decimal Pre { set; get; }
        public string A_Name { set; get; }
        public string A_CNIC { set; get; }
        public string A_Mobile { set; get; }
        public string A_EmailAddress { set; get; }
        public string A_Address { set; get; }
        public string Date { set; get; }
        public decimal Total_Bill { set; get; }
        public decimal Total_Paid { set; get; }
        public decimal Total_Dues { set; get; }
        public decimal PP { set; get; }
        public string ItemDetail { set; get; }
        public int Qty { set; get; }
        public int C_Qty { set; get; }
        public int R_Qty { set; get; }
        public decimal Item_Total_Bill { set; get; }
        public decimal TCS { set; get; }
        public decimal InvoiceNumber { set; get; }
    }
}
