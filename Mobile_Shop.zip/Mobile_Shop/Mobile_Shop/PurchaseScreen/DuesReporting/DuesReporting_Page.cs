namespace Mobile_Shop.PurchaseScreen.DuesReporting
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;
    using System.IO;

    /// <summary>
    /// Summary description for DuesReporting_Page.
    /// </summary>
    public partial class DuesReporting_Page : Telerik.Reporting.Report
    {

        private void getshopData()
        {
            byte[] pic = (byte[])Form1.shopDetails.Rows[0][0];
            MemoryStream ms = new MemoryStream(pic);
            ShopPicture.Value = Image.FromStream(ms);
            ShopName.Value = Form1.shopDetails.Rows[0][1].ToString();
            ShopTitle.Value = Form1.shopDetails.Rows[0][2].ToString();
            ShopContact1.Value = Form1.shopDetails.Rows[0][3].ToString();
            ShopContact2.Value = Form1.shopDetails.Rows[0][4].ToString();
            ShopAddress.Value = Form1.shopDetails.Rows[0][5].ToString();
        }

        public DuesReporting_Page()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();
            getshopData();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}