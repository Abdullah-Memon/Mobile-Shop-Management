﻿namespace Mobile_Shop.PurchaseScreen
{
    partial class SelectSupplierAccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.SupplierAccountsGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ACC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.ACC_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_CNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.warning5 = new System.Windows.Forms.Label();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.localSupplierbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.localselectbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.localSupplierAddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.localSupplierName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.localSupplierMobile = new Guna.UI2.WinForms.Guna2TextBox();
            this.local = new System.Windows.Forms.Label();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.ContentPanel.SuspendLayout();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SupplierAccountsGridView)).BeginInit();
            this.localSupplierbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.White;
            this.ContentPanel.Controls.Add(this.ShowAddedItemsDetailBox);
            this.ContentPanel.Controls.Add(this.warning5);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Controls.Add(this.localSupplierbox);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(5, 5);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1050, 544);
            this.ContentPanel.TabIndex = 1;
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.BackColor = System.Drawing.Color.Transparent;
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.SupplierAccountsGridView);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(0, 85);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(1050, 459);
            this.ShowAddedItemsDetailBox.TabIndex = 32;
            // 
            // SupplierAccountsGridView
            // 
            this.SupplierAccountsGridView.AllowUserToAddRows = false;
            this.SupplierAccountsGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SupplierAccountsGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.SupplierAccountsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SupplierAccountsGridView.BackgroundColor = System.Drawing.Color.White;
            this.SupplierAccountsGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SupplierAccountsGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SupplierAccountsGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SupplierAccountsGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.SupplierAccountsGridView.ColumnHeadersHeight = 21;
            this.SupplierAccountsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACC_ID,
            this.ACC_Picture,
            this.ACC_Name,
            this.ACC_Role,
            this.ACC_CNIC,
            this.ACC_Mobile,
            this.ACC_Email,
            this.ACC_Address,
            this.ACC_Select});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SupplierAccountsGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.SupplierAccountsGridView.EnableHeadersVisualStyles = false;
            this.SupplierAccountsGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SupplierAccountsGridView.Location = new System.Drawing.Point(13, 13);
            this.SupplierAccountsGridView.Name = "SupplierAccountsGridView";
            this.SupplierAccountsGridView.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SupplierAccountsGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.SupplierAccountsGridView.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.SupplierAccountsGridView.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.SupplierAccountsGridView.RowTemplate.Height = 70;
            this.SupplierAccountsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SupplierAccountsGridView.Size = new System.Drawing.Size(1028, 434);
            this.SupplierAccountsGridView.TabIndex = 22;
            this.SupplierAccountsGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.SupplierAccountsGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SupplierAccountsGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.SupplierAccountsGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.SupplierAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.SupplierAccountsGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.SupplierAccountsGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.SupplierAccountsGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SupplierAccountsGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.SupplierAccountsGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SupplierAccountsGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SupplierAccountsGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.SupplierAccountsGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.SupplierAccountsGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.SupplierAccountsGridView.ThemeStyle.ReadOnly = true;
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.Height = 70;
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.SupplierAccountsGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.SupplierAccountsGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SupplierAccountsGridView_CellContentClick);
            // 
            // ACC_ID
            // 
            this.ACC_ID.DataPropertyName = "AID";
            this.ACC_ID.HeaderText = "ID";
            this.ACC_ID.Name = "ACC_ID";
            this.ACC_ID.ReadOnly = true;
            this.ACC_ID.Visible = false;
            // 
            // ACC_Picture
            // 
            this.ACC_Picture.DataPropertyName = "A_Picture";
            this.ACC_Picture.FillWeight = 50F;
            this.ACC_Picture.HeaderText = "Picture";
            this.ACC_Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.ACC_Picture.Name = "ACC_Picture";
            this.ACC_Picture.ReadOnly = true;
            // 
            // ACC_Name
            // 
            this.ACC_Name.DataPropertyName = "A_Name";
            this.ACC_Name.HeaderText = "Name";
            this.ACC_Name.Name = "ACC_Name";
            this.ACC_Name.ReadOnly = true;
            // 
            // ACC_Role
            // 
            this.ACC_Role.DataPropertyName = "A_Role";
            this.ACC_Role.HeaderText = "Role";
            this.ACC_Role.Name = "ACC_Role";
            this.ACC_Role.ReadOnly = true;
            // 
            // ACC_CNIC
            // 
            this.ACC_CNIC.DataPropertyName = "A_CNIC";
            this.ACC_CNIC.HeaderText = "CNIC";
            this.ACC_CNIC.Name = "ACC_CNIC";
            this.ACC_CNIC.ReadOnly = true;
            // 
            // ACC_Mobile
            // 
            this.ACC_Mobile.DataPropertyName = "A_Mobile";
            this.ACC_Mobile.HeaderText = "Mobile";
            this.ACC_Mobile.Name = "ACC_Mobile";
            this.ACC_Mobile.ReadOnly = true;
            // 
            // ACC_Email
            // 
            this.ACC_Email.DataPropertyName = "A_EmailAddress";
            this.ACC_Email.HeaderText = "Email";
            this.ACC_Email.Name = "ACC_Email";
            this.ACC_Email.ReadOnly = true;
            // 
            // ACC_Address
            // 
            this.ACC_Address.DataPropertyName = "A_Address";
            this.ACC_Address.HeaderText = "Address";
            this.ACC_Address.Name = "ACC_Address";
            this.ACC_Address.ReadOnly = true;
            // 
            // ACC_Select
            // 
            this.ACC_Select.FillWeight = 50F;
            this.ACC_Select.HeaderText = "Select";
            this.ACC_Select.Name = "ACC_Select";
            this.ACC_Select.ReadOnly = true;
            this.ACC_Select.Text = "Select";
            this.ACC_Select.UseColumnTextForButtonValue = true;
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning5.ForeColor = System.Drawing.Color.Indigo;
            this.warning5.Location = new System.Drawing.Point(14, 12);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(67, 22);
            this.warning5.TabIndex = 30;
            this.warning5.Text = "Search";
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1013, 12);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(35, 35);
            this.backbtn.TabIndex = 31;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // localSupplierbox
            // 
            this.localSupplierbox.BorderThickness = 0;
            this.localSupplierbox.Controls.Add(this.localselectbtn);
            this.localSupplierbox.Controls.Add(this.localSupplierAddress);
            this.localSupplierbox.Controls.Add(this.label3);
            this.localSupplierbox.Controls.Add(this.localSupplierName);
            this.localSupplierbox.Controls.Add(this.label2);
            this.localSupplierbox.Controls.Add(this.localSupplierMobile);
            this.localSupplierbox.Controls.Add(this.local);
            this.localSupplierbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.localSupplierbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.localSupplierbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.localSupplierbox.Location = new System.Drawing.Point(3, 46);
            this.localSupplierbox.Name = "localSupplierbox";
            this.localSupplierbox.ShadowDecoration.Parent = this.localSupplierbox;
            this.localSupplierbox.Size = new System.Drawing.Size(1041, 43);
            this.localSupplierbox.TabIndex = 36;
            // 
            // localselectbtn
            // 
            this.localselectbtn.BackColor = System.Drawing.Color.Transparent;
            this.localselectbtn.BorderColor = System.Drawing.Color.White;
            this.localselectbtn.BorderRadius = 10;
            this.localselectbtn.BorderThickness = 2;
            this.localselectbtn.CheckedState.Parent = this.localselectbtn;
            this.localselectbtn.CustomImages.Parent = this.localselectbtn;
            this.localselectbtn.FillColor = System.Drawing.Color.Indigo;
            this.localselectbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.localselectbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.localselectbtn.ForeColor = System.Drawing.Color.White;
            this.localselectbtn.HoverState.Parent = this.localselectbtn;
            this.localselectbtn.Location = new System.Drawing.Point(933, 4);
            this.localselectbtn.Name = "localselectbtn";
            this.localselectbtn.ShadowDecoration.Parent = this.localselectbtn;
            this.localselectbtn.Size = new System.Drawing.Size(99, 36);
            this.localselectbtn.TabIndex = 35;
            this.localselectbtn.Text = "select";
            this.localselectbtn.Click += new System.EventHandler(this.localselectbtn_Click);
            // 
            // localSupplierAddress
            // 
            this.localSupplierAddress.BackColor = System.Drawing.Color.Transparent;
            this.localSupplierAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.localSupplierAddress.DefaultText = "";
            this.localSupplierAddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.localSupplierAddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.localSupplierAddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localSupplierAddress.DisabledState.Parent = this.localSupplierAddress;
            this.localSupplierAddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localSupplierAddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localSupplierAddress.FocusedState.Parent = this.localSupplierAddress;
            this.localSupplierAddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localSupplierAddress.HoverState.Parent = this.localSupplierAddress;
            this.localSupplierAddress.Location = new System.Drawing.Point(702, 4);
            this.localSupplierAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localSupplierAddress.Name = "localSupplierAddress";
            this.localSupplierAddress.PasswordChar = '\0';
            this.localSupplierAddress.PlaceholderText = "";
            this.localSupplierAddress.SelectedText = "";
            this.localSupplierAddress.ShadowDecoration.Parent = this.localSupplierAddress;
            this.localSupplierAddress.Size = new System.Drawing.Size(225, 36);
            this.localSupplierAddress.TabIndex = 33;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(602, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 19);
            this.label3.TabIndex = 34;
            this.label3.Text = "Email Address";
            // 
            // localSupplierName
            // 
            this.localSupplierName.BackColor = System.Drawing.Color.Transparent;
            this.localSupplierName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.localSupplierName.DefaultText = "";
            this.localSupplierName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.localSupplierName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.localSupplierName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localSupplierName.DisabledState.Parent = this.localSupplierName;
            this.localSupplierName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localSupplierName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localSupplierName.FocusedState.Parent = this.localSupplierName;
            this.localSupplierName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localSupplierName.HoverState.Parent = this.localSupplierName;
            this.localSupplierName.Location = new System.Drawing.Point(115, 6);
            this.localSupplierName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localSupplierName.Name = "localSupplierName";
            this.localSupplierName.PasswordChar = '\0';
            this.localSupplierName.PlaceholderText = "";
            this.localSupplierName.SelectedText = "";
            this.localSupplierName.ShadowDecoration.Parent = this.localSupplierName;
            this.localSupplierName.Size = new System.Drawing.Size(206, 36);
            this.localSupplierName.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(327, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 19);
            this.label2.TabIndex = 34;
            this.label2.Text = "Mobile #";
            // 
            // localSupplierMobile
            // 
            this.localSupplierMobile.BackColor = System.Drawing.Color.Transparent;
            this.localSupplierMobile.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.localSupplierMobile.DefaultText = "";
            this.localSupplierMobile.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.localSupplierMobile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.localSupplierMobile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localSupplierMobile.DisabledState.Parent = this.localSupplierMobile;
            this.localSupplierMobile.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.localSupplierMobile.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localSupplierMobile.FocusedState.Parent = this.localSupplierMobile;
            this.localSupplierMobile.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.localSupplierMobile.HoverState.Parent = this.localSupplierMobile;
            this.localSupplierMobile.Location = new System.Drawing.Point(396, 4);
            this.localSupplierMobile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localSupplierMobile.Name = "localSupplierMobile";
            this.localSupplierMobile.PasswordChar = '\0';
            this.localSupplierMobile.PlaceholderText = "";
            this.localSupplierMobile.SelectedText = "";
            this.localSupplierMobile.ShadowDecoration.Parent = this.localSupplierMobile;
            this.localSupplierMobile.Size = new System.Drawing.Size(200, 36);
            this.localSupplierMobile.TabIndex = 33;
            this.localSupplierMobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.localSupplierMobile_KeyPress);
            // 
            // local
            // 
            this.local.AutoSize = true;
            this.local.BackColor = System.Drawing.Color.Transparent;
            this.local.ForeColor = System.Drawing.Color.Indigo;
            this.local.Location = new System.Drawing.Point(11, 4);
            this.local.Name = "local";
            this.local.Size = new System.Drawing.Size(98, 19);
            this.local.TabIndex = 34;
            this.local.Text = "Supplier Name";
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.ContentPanel;
            // 
            // SelectSupplierAccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(1060, 554);
            this.Controls.Add(this.ContentPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SelectSupplierAccountForm";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "SelectSupplierAccountForm";
            this.Load += new System.EventHandler(this.SelectSupplierAccountForm_Load);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SupplierAccountsGridView)).EndInit();
            this.localSupplierbox.ResumeLayout(false);
            this.localSupplierbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2DataGridView SupplierAccountsGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_ID;
        private System.Windows.Forms.DataGridViewImageColumn ACC_Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Role;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_CNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Address;
        private System.Windows.Forms.DataGridViewButtonColumn ACC_Select;
        private System.Windows.Forms.Label warning5;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label local;
        private Guna.UI2.WinForms.Guna2TextBox localSupplierAddress;
        private Guna.UI2.WinForms.Guna2TextBox localSupplierMobile;
        private Guna.UI2.WinForms.Guna2TextBox localSupplierName;
        private Guna.UI2.WinForms.Guna2GradientButton localselectbtn;
        private Guna.UI2.WinForms.Guna2GroupBox localSupplierbox;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
    }
}