﻿namespace Mobile_Shop.PurchaseScreen.Edit_Bills
{
    partial class SelectBill_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ContentPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.todate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.fromdate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.invoicebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.selectAccountbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.addbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ShowAddedItemsDetailBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.GridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ACC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Itemid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Invoice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACC_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Color = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IMEI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Claimbtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.ContentPanel.SuspendLayout();
            this.ShowAddedItemsDetailBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ContentPanel
            // 
            this.ContentPanel.BackColor = System.Drawing.Color.White;
            this.ContentPanel.Controls.Add(this.todate);
            this.ContentPanel.Controls.Add(this.fromdate);
            this.ContentPanel.Controls.Add(this.invoicebox);
            this.ContentPanel.Controls.Add(this.selectAccountbox);
            this.ContentPanel.Controls.Add(this.label3);
            this.ContentPanel.Controls.Add(this.label4);
            this.ContentPanel.Controls.Add(this.label2);
            this.ContentPanel.Controls.Add(this.label1);
            this.ContentPanel.Controls.Add(this.guna2GradientButton1);
            this.ContentPanel.Controls.Add(this.addbtn);
            this.ContentPanel.Controls.Add(this.ShowAddedItemsDetailBox);
            this.ContentPanel.Controls.Add(this.backbtn);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(0, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.ShadowDecoration.Parent = this.ContentPanel;
            this.ContentPanel.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.TabIndex = 5;
            // 
            // todate
            // 
            this.todate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.todate.CheckedState.Parent = this.todate;
            this.todate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.todate.HoverState.Parent = this.todate;
            this.todate.Location = new System.Drawing.Point(672, 75);
            this.todate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.todate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.todate.Name = "todate";
            this.todate.ShadowDecoration.Parent = this.todate;
            this.todate.Size = new System.Drawing.Size(200, 36);
            this.todate.TabIndex = 38;
            this.todate.Value = new System.DateTime(2022, 9, 16, 21, 56, 48, 478);
            // 
            // fromdate
            // 
            this.fromdate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.fromdate.CheckedState.Parent = this.fromdate;
            this.fromdate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.fromdate.HoverState.Parent = this.fromdate;
            this.fromdate.Location = new System.Drawing.Point(439, 75);
            this.fromdate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.fromdate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.fromdate.Name = "fromdate";
            this.fromdate.ShadowDecoration.Parent = this.fromdate;
            this.fromdate.Size = new System.Drawing.Size(200, 36);
            this.fromdate.TabIndex = 38;
            this.fromdate.Value = new System.DateTime(2022, 9, 16, 21, 56, 48, 478);
            // 
            // invoicebox
            // 
            this.invoicebox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.invoicebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.invoicebox.DefaultText = "";
            this.invoicebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.invoicebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.invoicebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.invoicebox.DisabledState.Parent = this.invoicebox;
            this.invoicebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.invoicebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.invoicebox.FocusedState.Parent = this.invoicebox;
            this.invoicebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.invoicebox.HoverState.Parent = this.invoicebox;
            this.invoicebox.Location = new System.Drawing.Point(191, 33);
            this.invoicebox.Name = "invoicebox";
            this.invoicebox.PasswordChar = '\0';
            this.invoicebox.PlaceholderText = "";
            this.invoicebox.SelectedText = "";
            this.invoicebox.ShadowDecoration.Parent = this.invoicebox;
            this.invoicebox.Size = new System.Drawing.Size(681, 36);
            this.invoicebox.TabIndex = 37;
            // 
            // selectAccountbox
            // 
            this.selectAccountbox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.selectAccountbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.selectAccountbox.DefaultText = "";
            this.selectAccountbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.selectAccountbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.selectAccountbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.selectAccountbox.DisabledState.Parent = this.selectAccountbox;
            this.selectAccountbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.selectAccountbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.selectAccountbox.FocusedState.Parent = this.selectAccountbox;
            this.selectAccountbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.selectAccountbox.HoverState.Parent = this.selectAccountbox;
            this.selectAccountbox.Location = new System.Drawing.Point(191, 75);
            this.selectAccountbox.Name = "selectAccountbox";
            this.selectAccountbox.PasswordChar = '\0';
            this.selectAccountbox.PlaceholderText = "";
            this.selectAccountbox.ReadOnly = true;
            this.selectAccountbox.SelectedText = "";
            this.selectAccountbox.ShadowDecoration.Parent = this.selectAccountbox;
            this.selectAccountbox.Size = new System.Drawing.Size(200, 36);
            this.selectAccountbox.TabIndex = 37;
            this.selectAccountbox.DoubleClick += new System.EventHandler(this.selectAccountbox_DoubleClick);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(645, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 15);
            this.label3.TabIndex = 36;
            this.label3.Text = "To";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 15);
            this.label4.TabIndex = 36;
            this.label4.Text = "Invoice number";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(397, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 15);
            this.label2.TabIndex = 36;
            this.label2.Text = "From";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 36;
            this.label1.Text = "Select Account";
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(878, 33);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(99, 36);
            this.guna2GradientButton1.TabIndex = 35;
            this.guna2GradientButton1.Text = "Find";
            // 
            // addbtn
            // 
            this.addbtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addbtn.BackColor = System.Drawing.Color.Transparent;
            this.addbtn.BorderColor = System.Drawing.Color.White;
            this.addbtn.BorderRadius = 10;
            this.addbtn.BorderThickness = 2;
            this.addbtn.CheckedState.Parent = this.addbtn;
            this.addbtn.CustomImages.Parent = this.addbtn;
            this.addbtn.FillColor = System.Drawing.Color.Indigo;
            this.addbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.addbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.addbtn.ForeColor = System.Drawing.Color.White;
            this.addbtn.HoverState.Parent = this.addbtn;
            this.addbtn.Location = new System.Drawing.Point(878, 75);
            this.addbtn.Name = "addbtn";
            this.addbtn.ShadowDecoration.Parent = this.addbtn;
            this.addbtn.Size = new System.Drawing.Size(99, 36);
            this.addbtn.TabIndex = 35;
            this.addbtn.Text = "Find";
            // 
            // ShowAddedItemsDetailBox
            // 
            this.ShowAddedItemsDetailBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ShowAddedItemsDetailBox.BorderRadius = 10;
            this.ShowAddedItemsDetailBox.Controls.Add(this.GridView);
            this.ShowAddedItemsDetailBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.ShowAddedItemsDetailBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ShowAddedItemsDetailBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowAddedItemsDetailBox.Location = new System.Drawing.Point(0, 122);
            this.ShowAddedItemsDetailBox.Name = "ShowAddedItemsDetailBox";
            this.ShowAddedItemsDetailBox.ShadowDecoration.Parent = this.ShowAddedItemsDetailBox;
            this.ShowAddedItemsDetailBox.Size = new System.Drawing.Size(1060, 432);
            this.ShowAddedItemsDetailBox.TabIndex = 32;
            // 
            // GridView
            // 
            this.GridView.AllowUserToAddRows = false;
            this.GridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.GridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.GridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridView.BackgroundColor = System.Drawing.Color.White;
            this.GridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.GridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.GridView.ColumnHeadersHeight = 21;
            this.GridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ACC_ID,
            this.Itemid,
            this.Invoice,
            this.ACC_Name,
            this.ItemName,
            this.Catagory,
            this.Qty,
            this.purchaseDate,
            this.Color,
            this.IMEI,
            this.Claimbtn});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GridView.DefaultCellStyle = dataGridViewCellStyle8;
            this.GridView.EnableHeadersVisualStyles = false;
            this.GridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.GridView.Location = new System.Drawing.Point(8, 16);
            this.GridView.Name = "GridView";
            this.GridView.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.GridView.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.GridView.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.GridView.RowTemplate.Height = 70;
            this.GridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridView.Size = new System.Drawing.Size(1045, 413);
            this.GridView.TabIndex = 23;
            this.GridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.GridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.GridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.GridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.GridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.GridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.GridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.GridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.GridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.GridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.GridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.GridView.ThemeStyle.HeaderStyle.Height = 21;
            this.GridView.ThemeStyle.ReadOnly = true;
            this.GridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.GridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.GridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.GridView.ThemeStyle.RowsStyle.Height = 70;
            this.GridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.GridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            // 
            // ACC_ID
            // 
            this.ACC_ID.DataPropertyName = "AID";
            this.ACC_ID.HeaderText = "ID";
            this.ACC_ID.Name = "ACC_ID";
            this.ACC_ID.ReadOnly = true;
            this.ACC_ID.Visible = false;
            // 
            // Itemid
            // 
            this.Itemid.DataPropertyName = "IID";
            this.Itemid.HeaderText = "item id";
            this.Itemid.Name = "Itemid";
            this.Itemid.ReadOnly = true;
            this.Itemid.Visible = false;
            // 
            // Invoice
            // 
            this.Invoice.DataPropertyName = "InvoiceNumber";
            this.Invoice.HeaderText = "invoice no";
            this.Invoice.Name = "Invoice";
            this.Invoice.ReadOnly = true;
            this.Invoice.Visible = false;
            // 
            // ACC_Name
            // 
            this.ACC_Name.DataPropertyName = "A_Name";
            this.ACC_Name.HeaderText = "Name";
            this.ACC_Name.Name = "ACC_Name";
            this.ACC_Name.ReadOnly = true;
            // 
            // ItemName
            // 
            this.ItemName.DataPropertyName = "Item_Name";
            this.ItemName.HeaderText = "ItemName";
            this.ItemName.Name = "ItemName";
            this.ItemName.ReadOnly = true;
            // 
            // Catagory
            // 
            this.Catagory.DataPropertyName = "C_Name";
            this.Catagory.HeaderText = "Catagory";
            this.Catagory.Name = "Catagory";
            this.Catagory.ReadOnly = true;
            // 
            // Qty
            // 
            this.Qty.DataPropertyName = "Qty";
            this.Qty.HeaderText = "Qty";
            this.Qty.Name = "Qty";
            this.Qty.ReadOnly = true;
            // 
            // purchaseDate
            // 
            this.purchaseDate.DataPropertyName = "Date";
            this.purchaseDate.HeaderText = "Purchase Date";
            this.purchaseDate.Name = "purchaseDate";
            this.purchaseDate.ReadOnly = true;
            // 
            // Color
            // 
            this.Color.DataPropertyName = "Color";
            this.Color.HeaderText = "Color";
            this.Color.Name = "Color";
            this.Color.ReadOnly = true;
            // 
            // IMEI
            // 
            this.IMEI.DataPropertyName = "IMEI_1";
            this.IMEI.HeaderText = "IMEI 1";
            this.IMEI.Name = "IMEI";
            this.IMEI.ReadOnly = true;
            // 
            // Claimbtn
            // 
            this.Claimbtn.FillWeight = 50F;
            this.Claimbtn.HeaderText = "Return";
            this.Claimbtn.Name = "Claimbtn";
            this.Claimbtn.ReadOnly = true;
            this.Claimbtn.Text = "Return";
            this.Claimbtn.UseColumnTextForButtonValue = true;
            // 
            // backbtn
            // 
            this.backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(1013, 12);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(35, 35);
            this.backbtn.TabIndex = 31;
            this.backbtn.Text = "<--";
            this.backbtn.UseTransparentBackground = true;
            // 
            // SelectBill_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ContentPanel);
            this.Name = "SelectBill_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.ContentPanel.ResumeLayout(false);
            this.ContentPanel.PerformLayout();
            this.ShowAddedItemsDetailBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel ContentPanel;
        private Guna.UI2.WinForms.Guna2DateTimePicker todate;
        private Guna.UI2.WinForms.Guna2DateTimePicker fromdate;
        private Guna.UI2.WinForms.Guna2TextBox invoicebox;
        private Guna.UI2.WinForms.Guna2TextBox selectAccountbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton addbtn;
        private Guna.UI2.WinForms.Guna2GroupBox ShowAddedItemsDetailBox;
        private Guna.UI2.WinForms.Guna2DataGridView GridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Itemid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Invoice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACC_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Color;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMEI;
        private System.Windows.Forms.DataGridViewButtonColumn Claimbtn;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
    }
}
