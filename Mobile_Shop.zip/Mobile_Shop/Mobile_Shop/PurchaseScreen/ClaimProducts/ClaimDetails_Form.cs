﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.PurchaseScreen.ClaimProducts
{
    public partial class ClaimDetails_Form : Form
    {
        int productQty;
        public static int qty;
        public static string reason;
        
        public ClaimDetails_Form(int q)
        {
            InitializeComponent();
            productQty = q;
        }

        private void ClaimDetails_Form_Load(object sender, EventArgs e)
        {
            if (productQty == 1)
            {
                qtybox.Text = productQty.ToString();
                qtybox.ReadOnly = true;
            }
            else
            {
                qtybox.Text = "1";
                qtybox.ReadOnly = false;
            }
        }

        private void qtybox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                Reasonbox.Focus();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            qty = Convert.ToInt32(qtybox.Text);
            reason = Reasonbox.Text;

            this.Close();
        }

        private void qtybox_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(qtybox.Text) || !string.IsNullOrWhiteSpace(qtybox.Text))
            {
                if (Convert.ToInt16(qtybox.Text) > productQty)
                    guna2GradientButton1.Enabled = false;
                else
                    guna2GradientButton1.Enabled = true;
            }
        }

        private void qtybox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
