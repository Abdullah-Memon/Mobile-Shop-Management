﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen.ClaimProducts
{
    public partial class ViewClaim_uc : UserControl
    {
        public ViewClaim_uc()
        {
            InitializeComponent();
        }
        // Screen to Load
        AddClaim_uc ac;

        // Back Button Coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.pd);
        }

        private void getdata()
        {
            try 
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("ClaimDetails",DB.con) { CommandType = CommandType.StoredProcedure };

                dt.Load(cmd.ExecuteReader());

                GridView.DataSource = dt;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        // Main Load Function
        private void ViewClaim_uc_Load(object sender, EventArgs e)
        {
            getdata();
            GridView.Focus();
        }

        // Add Claim Button Coding
        private void addbtn_Click(object sender, EventArgs e)
        {
            if(ac == null)
                ac = new AddClaim_uc();
            
            LoginForm.LoginScreen.ms.addusercontrol(ac);
        }

        // GridView Button Coding
        private void GridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // MessageBox.Show(e.ColumnIndex.ToString());
            if (e.ColumnIndex == 0)
            {
                try
                {
                    int a = Convert.ToInt32(GridView.Rows[e.RowIndex].Cells["QTY"].Value);
                    ClaimDetails_Form cd = new ClaimDetails_Form(a);
                    cd.ShowDialog();

                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    SqlCommand cmd = new SqlCommand("AddClaim", DB.con) { CommandType = CommandType.StoredProcedure};
                    cmd.Parameters.Add(new SqlParameter("@data", 1));
                    cmd.Parameters.Add(new SqlParameter("@invoice", GridView.Rows[e.RowIndex].Cells["Invoice"].Value));
                    cmd.Parameters.Add(new SqlParameter("@itemid", GridView.Rows[e.RowIndex].Cells["Itemid"].Value));
                    cmd.Parameters.Add(new SqlParameter("@qty", ClaimDetails_Form.qty));
                    cmd.Parameters.Add(new SqlParameter("@recivedate",cd.cdate.Value));
                    cmd.Parameters.Add(new SqlParameter("@imei",GridView.Rows[e.RowIndex].Cells["IMEI"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@catagory",GridView.Rows[e.RowIndex].Cells["Catagory"].Value.ToString()));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                    getdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
