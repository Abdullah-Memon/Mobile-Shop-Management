﻿namespace Mobile_Shop.PurchaseScreen.ClaimProducts
{
    partial class ClaimDetails_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Contentpanel = new System.Windows.Forms.Panel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Reasonbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.qtybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.cdate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.Contentpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Contentpanel
            // 
            this.Contentpanel.BackColor = System.Drawing.Color.White;
            this.Contentpanel.Controls.Add(this.guna2GradientButton1);
            this.Contentpanel.Controls.Add(this.backbtn);
            this.Contentpanel.Controls.Add(this.Reasonbox);
            this.Contentpanel.Controls.Add(this.label3);
            this.Contentpanel.Controls.Add(this.label2);
            this.Contentpanel.Controls.Add(this.label4);
            this.Contentpanel.Controls.Add(this.label1);
            this.Contentpanel.Controls.Add(this.qtybox);
            this.Contentpanel.Controls.Add(this.cdate);
            this.Contentpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Contentpanel.Location = new System.Drawing.Point(10, 10);
            this.Contentpanel.Name = "Contentpanel";
            this.Contentpanel.Size = new System.Drawing.Size(317, 393);
            this.Contentpanel.TabIndex = 0;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(104, 340);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(99, 40);
            this.guna2GradientButton1.TabIndex = 36;
            this.guna2GradientButton1.Text = "Add";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // backbtn
            // 
            this.backbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.backbtn.BackColor = System.Drawing.Color.Transparent;
            this.backbtn.CheckedState.Parent = this.backbtn;
            this.backbtn.CustomImages.Parent = this.backbtn;
            this.backbtn.FillColor = System.Drawing.Color.Indigo;
            this.backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.backbtn.ForeColor = System.Drawing.Color.White;
            this.backbtn.HoverState.Parent = this.backbtn;
            this.backbtn.Location = new System.Drawing.Point(279, 3);
            this.backbtn.Name = "backbtn";
            this.backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.backbtn.ShadowDecoration.Parent = this.backbtn;
            this.backbtn.Size = new System.Drawing.Size(35, 35);
            this.backbtn.TabIndex = 32;
            this.backbtn.Text = "X";
            this.backbtn.UseTransparentBackground = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // Reasonbox
            // 
            this.Reasonbox.Location = new System.Drawing.Point(26, 205);
            this.Reasonbox.Multiline = true;
            this.Reasonbox.Name = "Reasonbox";
            this.Reasonbox.Size = new System.Drawing.Size(256, 119);
            this.Reasonbox.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Status";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Date";
            // 
            // qtybox
            // 
            this.qtybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qtybox.DefaultText = "";
            this.qtybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.qtybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.qtybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qtybox.DisabledState.Parent = this.qtybox;
            this.qtybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qtybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qtybox.FocusedState.Parent = this.qtybox;
            this.qtybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qtybox.HoverState.Parent = this.qtybox;
            this.qtybox.Location = new System.Drawing.Point(26, 148);
            this.qtybox.Name = "qtybox";
            this.qtybox.PasswordChar = '\0';
            this.qtybox.PlaceholderText = "";
            this.qtybox.SelectedText = "";
            this.qtybox.ShadowDecoration.Parent = this.qtybox;
            this.qtybox.Size = new System.Drawing.Size(256, 36);
            this.qtybox.TabIndex = 5;
            this.qtybox.TextChanged += new System.EventHandler(this.qtybox_TextChanged);
            this.qtybox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.qtybox_KeyDown);
            this.qtybox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.qtybox_KeyPress);
            // 
            // cdate
            // 
            this.cdate.BorderRadius = 10;
            this.cdate.BorderThickness = 1;
            this.cdate.CheckedState.Parent = this.cdate;
            this.cdate.FillColor = System.Drawing.Color.Indigo;
            this.cdate.ForeColor = System.Drawing.Color.White;
            this.cdate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.cdate.HoverState.Parent = this.cdate;
            this.cdate.Location = new System.Drawing.Point(26, 91);
            this.cdate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.cdate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.cdate.Name = "cdate";
            this.cdate.ShadowDecoration.Parent = this.cdate;
            this.cdate.Size = new System.Drawing.Size(256, 36);
            this.cdate.TabIndex = 4;
            this.cdate.Value = new System.DateTime(2022, 9, 16, 23, 13, 36, 306);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.Contentpanel;
            // 
            // ClaimDetails_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(337, 413);
            this.Controls.Add(this.Contentpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ClaimDetails_Form";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ClaimDetails_Form";
            this.Load += new System.EventHandler(this.ClaimDetails_Form_Load);
            this.Contentpanel.ResumeLayout(false);
            this.Contentpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Contentpanel;
        private System.Windows.Forms.TextBox Reasonbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox qtybox;
        private Guna.UI2.WinForms.Guna2CircleButton backbtn;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        public Guna.UI2.WinForms.Guna2DateTimePicker cdate;

    }
}