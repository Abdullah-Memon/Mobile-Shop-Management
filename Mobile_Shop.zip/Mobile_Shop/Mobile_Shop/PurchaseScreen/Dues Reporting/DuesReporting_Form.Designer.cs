﻿namespace Mobile_Shop.PurchaseScreen.Dues_Reporting
{
    partial class DuesReporting_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lowerpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.reportViewer1 = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.upperpanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.controlbox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.minimizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.maximizebtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.crossbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.lowerpanel.SuspendLayout();
            this.upperpanel.SuspendLayout();
            this.controlbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // lowerpanel
            // 
            this.lowerpanel.BackColor = System.Drawing.Color.Transparent;
            this.lowerpanel.Controls.Add(this.reportViewer1);
            this.lowerpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lowerpanel.Location = new System.Drawing.Point(0, 79);
            this.lowerpanel.Name = "lowerpanel";
            this.lowerpanel.ShadowDecoration.Parent = this.lowerpanel;
            this.lowerpanel.Size = new System.Drawing.Size(684, 566);
            this.lowerpanel.TabIndex = 5;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(684, 566);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ViewMode = Telerik.ReportViewer.WinForms.ViewMode.PrintPreview;
            // 
            // upperpanel
            // 
            this.upperpanel.BackColor = System.Drawing.Color.Transparent;
            this.upperpanel.Controls.Add(this.controlbox);
            this.upperpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.upperpanel.Location = new System.Drawing.Point(0, 0);
            this.upperpanel.Name = "upperpanel";
            this.upperpanel.ShadowDecoration.Parent = this.upperpanel;
            this.upperpanel.Size = new System.Drawing.Size(684, 79);
            this.upperpanel.TabIndex = 4;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.upperpanel;
            // 
            // controlbox
            // 
            this.controlbox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.controlbox.BackColor = System.Drawing.Color.Transparent;
            this.controlbox.BorderColor = System.Drawing.Color.FloralWhite;
            this.controlbox.BorderRadius = 15;
            this.controlbox.BorderThickness = 3;
            this.controlbox.Controls.Add(this.minimizebtn);
            this.controlbox.Controls.Add(this.maximizebtn);
            this.controlbox.Controls.Add(this.crossbtn);
            this.controlbox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.controlbox.FillColor = System.Drawing.Color.Indigo;
            this.controlbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.controlbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.controlbox.Location = new System.Drawing.Point(546, 12);
            this.controlbox.Name = "controlbox";
            this.controlbox.ShadowDecoration.Parent = this.controlbox;
            this.controlbox.Size = new System.Drawing.Size(126, 45);
            this.controlbox.TabIndex = 18;
            // 
            // minimizebtn
            // 
            this.minimizebtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizebtn.CheckedState.Parent = this.minimizebtn;
            this.minimizebtn.CustomImages.Parent = this.minimizebtn;
            this.minimizebtn.FillColor = System.Drawing.Color.Indigo;
            this.minimizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.minimizebtn.ForeColor = System.Drawing.Color.White;
            this.minimizebtn.HoverState.Parent = this.minimizebtn;
            this.minimizebtn.Location = new System.Drawing.Point(5, 6);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.minimizebtn.ShadowDecoration.Parent = this.minimizebtn;
            this.minimizebtn.Size = new System.Drawing.Size(35, 35);
            this.minimizebtn.TabIndex = 15;
            this.minimizebtn.Text = "_";
            // 
            // maximizebtn
            // 
            this.maximizebtn.BackColor = System.Drawing.Color.Transparent;
            this.maximizebtn.CheckedState.Parent = this.maximizebtn;
            this.maximizebtn.CustomImages.Parent = this.maximizebtn;
            this.maximizebtn.FillColor = System.Drawing.Color.Indigo;
            this.maximizebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.maximizebtn.ForeColor = System.Drawing.Color.White;
            this.maximizebtn.HoverState.Parent = this.maximizebtn;
            this.maximizebtn.Location = new System.Drawing.Point(46, 6);
            this.maximizebtn.Name = "maximizebtn";
            this.maximizebtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.maximizebtn.ShadowDecoration.Parent = this.maximizebtn;
            this.maximizebtn.Size = new System.Drawing.Size(35, 35);
            this.maximizebtn.TabIndex = 15;
            this.maximizebtn.Text = "|=|";
            // 
            // crossbtn
            // 
            this.crossbtn.BackColor = System.Drawing.Color.Transparent;
            this.crossbtn.CheckedState.Parent = this.crossbtn;
            this.crossbtn.CustomImages.Parent = this.crossbtn;
            this.crossbtn.FillColor = System.Drawing.Color.Indigo;
            this.crossbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.crossbtn.ForeColor = System.Drawing.Color.White;
            this.crossbtn.HoverState.Parent = this.crossbtn;
            this.crossbtn.Location = new System.Drawing.Point(87, 6);
            this.crossbtn.Name = "crossbtn";
            this.crossbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.crossbtn.ShadowDecoration.Parent = this.crossbtn;
            this.crossbtn.Size = new System.Drawing.Size(35, 35);
            this.crossbtn.TabIndex = 15;
            this.crossbtn.Text = "X";
            // 
            // DuesReporting_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(684, 645);
            this.Controls.Add(this.lowerpanel);
            this.Controls.Add(this.upperpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DuesReporting_Form";
            this.Text = "DuesReporting_Form";
            this.lowerpanel.ResumeLayout(false);
            this.upperpanel.ResumeLayout(false);
            this.controlbox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel lowerpanel;
        private Telerik.ReportViewer.WinForms.ReportViewer reportViewer1;
        private Guna.UI2.WinForms.Guna2GradientPanel upperpanel;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2GroupBox controlbox;
        private Guna.UI2.WinForms.Guna2CircleButton minimizebtn;
        private Guna.UI2.WinForms.Guna2CircleButton maximizebtn;
        private Guna.UI2.WinForms.Guna2CircleButton crossbtn;
    }
}