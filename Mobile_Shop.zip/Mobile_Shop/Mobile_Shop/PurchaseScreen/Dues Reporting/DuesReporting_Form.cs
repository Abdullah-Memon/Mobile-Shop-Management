﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.PurchaseScreen.Dues_Reporting
{
    public partial class DuesReporting_Form : Form
    {
        public DuesReporting_Form()
        {
            InitializeComponent();
        }
    }
}
