﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mobile_Shop.PurchaseScreen.Dues_Reporting
{
    class DuesDataClass
    {
    }
}
