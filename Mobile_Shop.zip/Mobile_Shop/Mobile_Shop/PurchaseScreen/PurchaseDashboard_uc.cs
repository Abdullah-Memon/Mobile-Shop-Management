﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mobile_Shop.Account.DUES;

namespace Mobile_Shop.PurchaseScreen
{
    public partial class PurchaseDashboard_uc : UserControl
    {
        public PurchaseDashboard_uc()
        {
            InitializeComponent();
        }

        // Screens To Load
        public static ClaimProducts.ViewClaim_uc vc;
        public static Return.ViewReturn_uc vr;
        EditBills.ViewBills_uc vb;
        Dues_Form df;
        UpdateBill_uc ub;

        //Loading Purchase Screen button coding
        private void PurchaseScreenbtn_Click(object sender, EventArgs e)
        {
            PurchaseScreen_uc ps = new PurchaseScreen_uc();
            LoginForm.LoginScreen.ms.addusercontrol(ps);
        }

        // Loading Dues Screen button coding
        private void Duesbtn_Click(object sender, EventArgs e)
        {
            if (df == null)
                df = new Dues_Form();

            df.ShowDialog();
        }

        // Loading Account Report button coding
        private void AccountsReportBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SelectedReporting.Text) || !string.IsNullOrWhiteSpace(SelectedReporting.Text))
            {
                DuesReporting.DuesReporting_Form drf = new DuesReporting.DuesReporting_Form(SelectedReporting.SelectedIndex);
                drf.Show();
            }
            else
                SelectedReporting.Focus();
        }

        // Loading Claim button coding
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            if (vc == null)
                vc = new ClaimProducts.ViewClaim_uc();

            LoginForm.LoginScreen.ms.addusercontrol(vc);
        }

        // Loading Return button coding
        private void Returnbtn_Click(object sender, EventArgs e)
        {
            if (vr == null)
                vr = new Return.ViewReturn_uc();
            
            LoginForm.LoginScreen.ms.addusercontrol(vr);                
        }

        // Loading Edit Bills button coding
        private void EditBillsbtn_Click(object sender, EventArgs e)
        {
            if (vb == null)
                vb = new EditBills.ViewBills_uc();
            
            LoginForm.LoginScreen.ms.addusercontrol(vb);
        }

        private void PurchaseDashboard_uc_Load(object sender, EventArgs e)
        {
            PurchaseScreenbtn.Focus();
        }
    }
}
