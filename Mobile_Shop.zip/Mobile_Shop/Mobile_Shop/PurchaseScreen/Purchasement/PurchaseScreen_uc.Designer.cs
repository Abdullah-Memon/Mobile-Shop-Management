﻿namespace Mobile_Shop.PurchaseScreen
{
    partial class PurchaseScreen_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.searchLabel = new System.Windows.Forms.Label();
            this.purchaseDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.InvoiceBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.AllItems = new Guna.UI2.WinForms.Guna2DataGridView();
            this.ItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.catagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Brands = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedItems = new Guna.UI2.WinForms.Guna2DataGridView();
            this.SelectedID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedPicture = new System.Windows.Forms.DataGridViewImageColumn();
            this.SelectedCatagory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedBrand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedIMEI1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedIMEI2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedPurchase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedBox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedWarranty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectedState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Backbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.SPDues = new Guna.UI2.WinForms.Guna2TextBox();
            this.Remainingbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SelectedSupplierBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.TCSbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Totalpayment = new Guna.UI2.WinForms.Guna2TextBox();
            this.PaymentTypebox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.due = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Payment = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.AllItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SelectedItems)).BeginInit();
            this.guna2Panel2.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 10;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.BorderRadius = 10;
            // 
            // searchLabel
            // 
            this.searchLabel.AutoSize = true;
            this.searchLabel.BackColor = System.Drawing.Color.Transparent;
            this.searchLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.searchLabel.ForeColor = System.Drawing.Color.Indigo;
            this.searchLabel.Location = new System.Drawing.Point(4, 52);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(51, 17);
            this.searchLabel.TabIndex = 17;
            this.searchLabel.Text = "search";
            // 
            // purchaseDate
            // 
            this.purchaseDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.purchaseDate.BackColor = System.Drawing.Color.Transparent;
            this.purchaseDate.BorderColor = System.Drawing.Color.DarkOrchid;
            this.purchaseDate.BorderRadius = 10;
            this.purchaseDate.BorderThickness = 1;
            this.purchaseDate.CheckedState.Parent = this.purchaseDate;
            this.purchaseDate.FillColor = System.Drawing.Color.Indigo;
            this.purchaseDate.ForeColor = System.Drawing.Color.White;
            this.purchaseDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.purchaseDate.HoverState.Parent = this.purchaseDate;
            this.purchaseDate.Location = new System.Drawing.Point(613, 30);
            this.purchaseDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.purchaseDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.purchaseDate.Name = "purchaseDate";
            this.purchaseDate.ShadowDecoration.Parent = this.purchaseDate;
            this.purchaseDate.Size = new System.Drawing.Size(194, 30);
            this.purchaseDate.TabIndex = 19;
            this.purchaseDate.Value = new System.DateTime(2022, 8, 1, 5, 34, 10, 616);
            // 
            // InvoiceBox
            // 
            this.InvoiceBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.InvoiceBox.BorderRadius = 10;
            this.InvoiceBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.InvoiceBox.DefaultText = "";
            this.InvoiceBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.InvoiceBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.InvoiceBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.InvoiceBox.DisabledState.Parent = this.InvoiceBox;
            this.InvoiceBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.InvoiceBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.InvoiceBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.InvoiceBox.FocusedState.Parent = this.InvoiceBox;
            this.InvoiceBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.InvoiceBox.HoverState.Parent = this.InvoiceBox;
            this.InvoiceBox.Location = new System.Drawing.Point(321, 30);
            this.InvoiceBox.Name = "InvoiceBox";
            this.InvoiceBox.PasswordChar = '\0';
            this.InvoiceBox.PlaceholderText = "";
            this.InvoiceBox.SelectedText = "";
            this.InvoiceBox.ShadowDecoration.Parent = this.InvoiceBox;
            this.InvoiceBox.Size = new System.Drawing.Size(130, 30);
            this.InvoiceBox.TabIndex = 18;
            this.InvoiceBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.InvoiceBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InvoiceBox_KeyDown);
            this.InvoiceBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.InvoiceBox_KeyPress);
            // 
            // AllItems
            // 
            this.AllItems.AllowUserToAddRows = false;
            this.AllItems.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AllItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.AllItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AllItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AllItems.BackgroundColor = System.Drawing.Color.White;
            this.AllItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AllItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AllItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AllItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.AllItems.ColumnHeadersHeight = 30;
            this.AllItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemID,
            this.Picture,
            this.catagory,
            this.ItemName,
            this.Company,
            this.Brands});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AllItems.DefaultCellStyle = dataGridViewCellStyle3;
            this.AllItems.EnableHeadersVisualStyles = false;
            this.AllItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AllItems.Location = new System.Drawing.Point(7, 72);
            this.AllItems.Name = "AllItems";
            this.AllItems.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AllItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.AllItems.RowHeadersVisible = false;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.AllItems.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.AllItems.RowTemplate.Height = 80;
            this.AllItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AllItems.Size = new System.Drawing.Size(807, 469);
            this.AllItems.TabIndex = 18;
            this.AllItems.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.AllItems.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.AllItems.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.AllItems.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.AllItems.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.AllItems.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.AllItems.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AllItems.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllItems.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.AllItems.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.AllItems.ThemeStyle.HeaderStyle.Height = 30;
            this.AllItems.ThemeStyle.ReadOnly = true;
            this.AllItems.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.AllItems.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AllItems.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllItems.ThemeStyle.RowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.AllItems.ThemeStyle.RowsStyle.Height = 80;
            this.AllItems.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.AllItems.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.AllItems.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AllItems_CellContentClick);
            this.AllItems.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AllItems_KeyDown);
            // 
            // ItemID
            // 
            this.ItemID.DataPropertyName = "IID";
            this.ItemID.HeaderText = "ItemID";
            this.ItemID.Name = "ItemID";
            this.ItemID.ReadOnly = true;
            this.ItemID.Visible = false;
            // 
            // Picture
            // 
            this.Picture.DataPropertyName = "Item_Picture";
            this.Picture.FillWeight = 25F;
            this.Picture.HeaderText = "Picture";
            this.Picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Picture.Name = "Picture";
            this.Picture.ReadOnly = true;
            // 
            // catagory
            // 
            this.catagory.DataPropertyName = "C_Name";
            this.catagory.FillWeight = 112.4398F;
            this.catagory.HeaderText = "Catagory";
            this.catagory.Name = "catagory";
            this.catagory.ReadOnly = true;
            this.catagory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ItemName
            // 
            this.ItemName.DataPropertyName = "Item_Name";
            this.ItemName.FillWeight = 125.8526F;
            this.ItemName.HeaderText = "Item Name";
            this.ItemName.Name = "ItemName";
            this.ItemName.ReadOnly = true;
            // 
            // Company
            // 
            this.Company.DataPropertyName = "COM_Name";
            this.Company.FillWeight = 112.4398F;
            this.Company.HeaderText = "Company";
            this.Company.Name = "Company";
            this.Company.ReadOnly = true;
            this.Company.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Brands
            // 
            this.Brands.DataPropertyName = "B_Name";
            this.Brands.HeaderText = "Brand";
            this.Brands.Name = "Brands";
            this.Brands.ReadOnly = true;
            // 
            // SelectedItems
            // 
            this.SelectedItems.AllowUserToAddRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SelectedItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.SelectedItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SelectedItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SelectedItems.BackgroundColor = System.Drawing.Color.White;
            this.SelectedItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SelectedItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SelectedItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.SelectedItems.ColumnHeadersHeight = 30;
            this.SelectedItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectedID,
            this.SelectedPicture,
            this.SelectedCatagory,
            this.SelectedName,
            this.SelectedCompany,
            this.SelectedBrand,
            this.SelectedQuantity,
            this.SelectedIMEI1,
            this.SelectedIMEI2,
            this.SelectedColor,
            this.SelectedRate,
            this.SelectedPrice,
            this.SelectedPurchase,
            this.SelectedBox,
            this.SelectedWarranty,
            this.SelectedState});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SelectedItems.DefaultCellStyle = dataGridViewCellStyle8;
            this.SelectedItems.EnableHeadersVisualStyles = false;
            this.SelectedItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SelectedItems.Location = new System.Drawing.Point(7, 72);
            this.SelectedItems.Name = "SelectedItems";
            this.SelectedItems.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.SelectedItems.RowHeadersVisible = false;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.SelectedItems.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.SelectedItems.RowTemplate.Height = 80;
            this.SelectedItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SelectedItems.Size = new System.Drawing.Size(807, 469);
            this.SelectedItems.TabIndex = 19;
            this.SelectedItems.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.DeepPurple;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.SelectedItems.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.SelectedItems.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.SelectedItems.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(193)))), ((int)(((byte)(232)))));
            this.SelectedItems.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.SelectedItems.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SelectedItems.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectedItems.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.SelectedItems.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.SelectedItems.ThemeStyle.HeaderStyle.Height = 30;
            this.SelectedItems.ThemeStyle.ReadOnly = true;
            this.SelectedItems.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(215)))), ((int)(((byte)(240)))));
            this.SelectedItems.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SelectedItems.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.471698F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectedItems.ThemeStyle.RowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SelectedItems.ThemeStyle.RowsStyle.Height = 80;
            this.SelectedItems.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(123)))), ((int)(((byte)(207)))));
            this.SelectedItems.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.SelectedItems.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.SelectedItems_RowStateChanged);
            this.SelectedItems.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SelectedItems_KeyDown);
            // 
            // SelectedID
            // 
            this.SelectedID.DataPropertyName = "SelectedID";
            this.SelectedID.HeaderText = "ItemID";
            this.SelectedID.Name = "SelectedID";
            this.SelectedID.ReadOnly = true;
            this.SelectedID.Visible = false;
            // 
            // SelectedPicture
            // 
            this.SelectedPicture.DataPropertyName = "SelectedPicture";
            this.SelectedPicture.FillWeight = 50F;
            this.SelectedPicture.HeaderText = "Picture";
            this.SelectedPicture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.SelectedPicture.Name = "SelectedPicture";
            this.SelectedPicture.ReadOnly = true;
            // 
            // SelectedCatagory
            // 
            this.SelectedCatagory.DataPropertyName = "SelectedCatagory";
            this.SelectedCatagory.FillWeight = 112.4398F;
            this.SelectedCatagory.HeaderText = "Catagory";
            this.SelectedCatagory.Name = "SelectedCatagory";
            this.SelectedCatagory.ReadOnly = true;
            this.SelectedCatagory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SelectedName
            // 
            this.SelectedName.DataPropertyName = "SelectedName";
            this.SelectedName.FillWeight = 125.8526F;
            this.SelectedName.HeaderText = "Item Name";
            this.SelectedName.Name = "SelectedName";
            this.SelectedName.ReadOnly = true;
            // 
            // SelectedCompany
            // 
            this.SelectedCompany.DataPropertyName = "SelectedCompany";
            this.SelectedCompany.FillWeight = 112.4398F;
            this.SelectedCompany.HeaderText = "Company";
            this.SelectedCompany.Name = "SelectedCompany";
            this.SelectedCompany.ReadOnly = true;
            this.SelectedCompany.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SelectedBrand
            // 
            this.SelectedBrand.DataPropertyName = "SelectedBrands";
            this.SelectedBrand.HeaderText = "Brand";
            this.SelectedBrand.Name = "SelectedBrand";
            this.SelectedBrand.ReadOnly = true;
            // 
            // SelectedQuantity
            // 
            this.SelectedQuantity.DataPropertyName = "SelectedQuantity";
            this.SelectedQuantity.FillWeight = 50F;
            this.SelectedQuantity.HeaderText = "Qty";
            this.SelectedQuantity.Name = "SelectedQuantity";
            this.SelectedQuantity.ReadOnly = true;
            // 
            // SelectedIMEI1
            // 
            this.SelectedIMEI1.DataPropertyName = "SelectedIMEI1";
            this.SelectedIMEI1.HeaderText = "IMEI1";
            this.SelectedIMEI1.Name = "SelectedIMEI1";
            this.SelectedIMEI1.ReadOnly = true;
            // 
            // SelectedIMEI2
            // 
            this.SelectedIMEI2.DataPropertyName = "SelectedIMEI2";
            this.SelectedIMEI2.HeaderText = "IMEI2";
            this.SelectedIMEI2.Name = "SelectedIMEI2";
            this.SelectedIMEI2.ReadOnly = true;
            // 
            // SelectedColor
            // 
            this.SelectedColor.DataPropertyName = "SelectedColor";
            this.SelectedColor.HeaderText = "Color";
            this.SelectedColor.Name = "SelectedColor";
            this.SelectedColor.ReadOnly = true;
            // 
            // SelectedRate
            // 
            this.SelectedRate.DataPropertyName = "SelectedPurchase";
            this.SelectedRate.HeaderText = "Rate";
            this.SelectedRate.Name = "SelectedRate";
            this.SelectedRate.ReadOnly = true;
            // 
            // SelectedPrice
            // 
            this.SelectedPrice.DataPropertyName = "SelectedPrice";
            this.SelectedPrice.HeaderText = "Total";
            this.SelectedPrice.Name = "SelectedPrice";
            this.SelectedPrice.ReadOnly = true;
            // 
            // SelectedPurchase
            // 
            this.SelectedPurchase.DataPropertyName = "SelectedSell";
            this.SelectedPurchase.HeaderText = "Sell Price";
            this.SelectedPurchase.Name = "SelectedPurchase";
            this.SelectedPurchase.ReadOnly = true;
            this.SelectedPurchase.Visible = false;
            // 
            // SelectedBox
            // 
            this.SelectedBox.DataPropertyName = "SelectedBox";
            this.SelectedBox.FillWeight = 50F;
            this.SelectedBox.HeaderText = "Box";
            this.SelectedBox.Name = "SelectedBox";
            this.SelectedBox.ReadOnly = true;
            // 
            // SelectedWarranty
            // 
            this.SelectedWarranty.DataPropertyName = "SelectedWarranty";
            this.SelectedWarranty.HeaderText = "Warranty";
            this.SelectedWarranty.Name = "SelectedWarranty";
            this.SelectedWarranty.ReadOnly = true;
            // 
            // SelectedState
            // 
            this.SelectedState.DataPropertyName = "SelectedState";
            this.SelectedState.HeaderText = "State";
            this.SelectedState.Name = "SelectedState";
            this.SelectedState.ReadOnly = true;
            // 
            // Backbtn
            // 
            this.Backbtn.BorderColor = System.Drawing.Color.White;
            this.Backbtn.BorderRadius = 10;
            this.Backbtn.BorderThickness = 2;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(7, 6);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(88, 36);
            this.Backbtn.TabIndex = 15;
            this.Backbtn.Text = "Back";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel2.BorderColor = System.Drawing.Color.DarkOrchid;
            this.guna2Panel2.BorderRadius = 20;
            this.guna2Panel2.Controls.Add(this.guna2GradientButton1);
            this.guna2Panel2.Controls.Add(this.guna2GroupBox3);
            this.guna2Panel2.FillColor = System.Drawing.Color.Indigo;
            this.guna2Panel2.Location = new System.Drawing.Point(820, 15);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(239, 526);
            this.guna2Panel2.TabIndex = 2;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(29, 466);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(174, 52);
            this.guna2GradientButton1.TabIndex = 15;
            this.guna2GradientButton1.Text = "Check Out";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.guna2GroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.DarkOrchid;
            this.guna2GroupBox3.BorderRadius = 10;
            this.guna2GroupBox3.Controls.Add(this.SPDues);
            this.guna2GroupBox3.Controls.Add(this.Remainingbox);
            this.guna2GroupBox3.Controls.Add(this.label3);
            this.guna2GroupBox3.Controls.Add(this.SelectedSupplierBox);
            this.guna2GroupBox3.Controls.Add(this.TCSbox);
            this.guna2GroupBox3.Controls.Add(this.label7);
            this.guna2GroupBox3.Controls.Add(this.label8);
            this.guna2GroupBox3.Controls.Add(this.label2);
            this.guna2GroupBox3.Controls.Add(this.Totalpayment);
            this.guna2GroupBox3.Controls.Add(this.PaymentTypebox);
            this.guna2GroupBox3.Controls.Add(this.label4);
            this.guna2GroupBox3.Controls.Add(this.label6);
            this.guna2GroupBox3.Controls.Add(this.label12);
            this.guna2GroupBox3.Controls.Add(this.label9);
            this.guna2GroupBox3.Controls.Add(this.due);
            this.guna2GroupBox3.Controls.Add(this.label10);
            this.guna2GroupBox3.Controls.Add(this.Payment);
            this.guna2GroupBox3.Controls.Add(this.label11);
            this.guna2GroupBox3.CustomBorderColor = System.Drawing.Color.DarkTurquoise;
            this.guna2GroupBox3.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(12, 15);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.ShadowDecoration.Parent = this.guna2GroupBox3;
            this.guna2GroupBox3.Size = new System.Drawing.Size(215, 445);
            this.guna2GroupBox3.TabIndex = 15;
            // 
            // SPDues
            // 
            this.SPDues.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SPDues.BorderRadius = 10;
            this.SPDues.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SPDues.DefaultText = "0.00";
            this.SPDues.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SPDues.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SPDues.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SPDues.DisabledState.Parent = this.SPDues;
            this.SPDues.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SPDues.Enabled = false;
            this.SPDues.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SPDues.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SPDues.FocusedState.Parent = this.SPDues;
            this.SPDues.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SPDues.HoverState.Parent = this.SPDues;
            this.SPDues.Location = new System.Drawing.Point(27, 178);
            this.SPDues.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SPDues.Name = "SPDues";
            this.SPDues.PasswordChar = '\0';
            this.SPDues.PlaceholderText = "";
            this.SPDues.SelectedText = "";
            this.SPDues.SelectionStart = 4;
            this.SPDues.ShadowDecoration.Parent = this.SPDues;
            this.SPDues.Size = new System.Drawing.Size(164, 30);
            this.SPDues.TabIndex = 19;
            // 
            // Remainingbox
            // 
            this.Remainingbox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Remainingbox.BorderRadius = 10;
            this.Remainingbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Remainingbox.DefaultText = "0.00";
            this.Remainingbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Remainingbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Remainingbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Remainingbox.DisabledState.Parent = this.Remainingbox;
            this.Remainingbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Remainingbox.Enabled = false;
            this.Remainingbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Remainingbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Remainingbox.FocusedState.Parent = this.Remainingbox;
            this.Remainingbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Remainingbox.HoverState.Parent = this.Remainingbox;
            this.Remainingbox.Location = new System.Drawing.Point(108, 402);
            this.Remainingbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Remainingbox.Name = "Remainingbox";
            this.Remainingbox.PasswordChar = '\0';
            this.Remainingbox.PlaceholderText = "";
            this.Remainingbox.SelectedText = "";
            this.Remainingbox.SelectionStart = 4;
            this.Remainingbox.ShadowDecoration.Parent = this.Remainingbox;
            this.Remainingbox.Size = new System.Drawing.Size(83, 30);
            this.Remainingbox.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(28, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 18);
            this.label3.TabIndex = 20;
            this.label3.Text = "Supplier Previous Due";
            // 
            // SelectedSupplierBox
            // 
            this.SelectedSupplierBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectedSupplierBox.BorderRadius = 10;
            this.SelectedSupplierBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SelectedSupplierBox.DefaultText = "";
            this.SelectedSupplierBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SelectedSupplierBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SelectedSupplierBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SelectedSupplierBox.DisabledState.Parent = this.SelectedSupplierBox;
            this.SelectedSupplierBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SelectedSupplierBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SelectedSupplierBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SelectedSupplierBox.FocusedState.Parent = this.SelectedSupplierBox;
            this.SelectedSupplierBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SelectedSupplierBox.HoverState.Parent = this.SelectedSupplierBox;
            this.SelectedSupplierBox.Location = new System.Drawing.Point(27, 35);
            this.SelectedSupplierBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SelectedSupplierBox.Name = "SelectedSupplierBox";
            this.SelectedSupplierBox.PasswordChar = '\0';
            this.SelectedSupplierBox.PlaceholderText = "";
            this.SelectedSupplierBox.SelectedText = "";
            this.SelectedSupplierBox.ShadowDecoration.Parent = this.SelectedSupplierBox;
            this.SelectedSupplierBox.Size = new System.Drawing.Size(164, 30);
            this.SelectedSupplierBox.TabIndex = 18;
            this.SelectedSupplierBox.DoubleClick += new System.EventHandler(this.SelectedSupplierBox_DoubleClick);
            this.SelectedSupplierBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SelectedSupplierBox_KeyDown);
            // 
            // TCSbox
            // 
            this.TCSbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TCSbox.BorderRadius = 10;
            this.TCSbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TCSbox.DefaultText = "0.00";
            this.TCSbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TCSbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TCSbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TCSbox.DisabledState.Parent = this.TCSbox;
            this.TCSbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TCSbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TCSbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TCSbox.FocusedState.Parent = this.TCSbox;
            this.TCSbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TCSbox.HoverState.Parent = this.TCSbox;
            this.TCSbox.Location = new System.Drawing.Point(27, 234);
            this.TCSbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TCSbox.Name = "TCSbox";
            this.TCSbox.PasswordChar = '\0';
            this.TCSbox.PlaceholderText = "";
            this.TCSbox.SelectedText = "";
            this.TCSbox.SelectionStart = 4;
            this.TCSbox.ShadowDecoration.Parent = this.TCSbox;
            this.TCSbox.Size = new System.Drawing.Size(164, 30);
            this.TCSbox.TabIndex = 3;
            this.TCSbox.TextChanged += new System.EventHandler(this.TCSbox_TextChanged);
            this.TCSbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TCSbox_KeyPress);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(58, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 18);
            this.label7.TabIndex = 17;
            this.label7.Text = "Supplier Account";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(66, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "Payment Type";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(54, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 18);
            this.label2.TabIndex = 17;
            this.label2.Text = "Transport Fee";
            // 
            // Totalpayment
            // 
            this.Totalpayment.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Totalpayment.BorderRadius = 10;
            this.Totalpayment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Totalpayment.DefaultText = "0.00";
            this.Totalpayment.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Totalpayment.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Totalpayment.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Totalpayment.DisabledState.Parent = this.Totalpayment;
            this.Totalpayment.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Totalpayment.Enabled = false;
            this.Totalpayment.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Totalpayment.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Totalpayment.FocusedState.Parent = this.Totalpayment;
            this.Totalpayment.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Totalpayment.HoverState.Parent = this.Totalpayment;
            this.Totalpayment.Location = new System.Drawing.Point(108, 294);
            this.Totalpayment.Name = "Totalpayment";
            this.Totalpayment.PasswordChar = '\0';
            this.Totalpayment.PlaceholderText = "";
            this.Totalpayment.SelectedText = "";
            this.Totalpayment.SelectionStart = 4;
            this.Totalpayment.ShadowDecoration.Parent = this.Totalpayment;
            this.Totalpayment.Size = new System.Drawing.Size(83, 30);
            this.Totalpayment.TabIndex = 3;
            // 
            // PaymentTypebox
            // 
            this.PaymentTypebox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PaymentTypebox.BackColor = System.Drawing.Color.Transparent;
            this.PaymentTypebox.BorderRadius = 10;
            this.PaymentTypebox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.PaymentTypebox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypebox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PaymentTypebox.FocusedColor = System.Drawing.Color.Empty;
            this.PaymentTypebox.FocusedState.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PaymentTypebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.PaymentTypebox.FormattingEnabled = true;
            this.PaymentTypebox.HoverState.Parent = this.PaymentTypebox;
            this.PaymentTypebox.ItemHeight = 30;
            this.PaymentTypebox.ItemsAppearance.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Location = new System.Drawing.Point(27, 91);
            this.PaymentTypebox.Name = "PaymentTypebox";
            this.PaymentTypebox.ShadowDecoration.Parent = this.PaymentTypebox;
            this.PaymentTypebox.Size = new System.Drawing.Size(164, 36);
            this.PaymentTypebox.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(16, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 18);
            this.label4.TabIndex = 21;
            this.label4.Text = "______________________";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(16, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 18);
            this.label6.TabIndex = 21;
            this.label6.Text = "______________________";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label12.ForeColor = System.Drawing.Color.Indigo;
            this.label12.Location = new System.Drawing.Point(24, 408);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 18);
            this.label12.TabIndex = 17;
            this.label12.Text = "Return";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.ForeColor = System.Drawing.Color.Indigo;
            this.label9.Location = new System.Drawing.Point(24, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 18);
            this.label9.TabIndex = 17;
            this.label9.Text = "Total";
            // 
            // due
            // 
            this.due.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.due.BorderRadius = 10;
            this.due.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.due.DefaultText = "0.00";
            this.due.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.due.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.due.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.due.DisabledState.Parent = this.due;
            this.due.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.due.Enabled = false;
            this.due.FillColor = System.Drawing.Color.WhiteSmoke;
            this.due.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.due.FocusedState.Parent = this.due;
            this.due.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.due.HoverState.Parent = this.due;
            this.due.Location = new System.Drawing.Point(108, 364);
            this.due.Name = "due";
            this.due.PasswordChar = '\0';
            this.due.PlaceholderText = "";
            this.due.SelectedText = "";
            this.due.SelectionStart = 4;
            this.due.ShadowDecoration.Parent = this.due;
            this.due.Size = new System.Drawing.Size(83, 30);
            this.due.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label10.ForeColor = System.Drawing.Color.Indigo;
            this.label10.Location = new System.Drawing.Point(24, 334);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 18);
            this.label10.TabIndex = 17;
            this.label10.Text = "Paying";
            // 
            // Payment
            // 
            this.Payment.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Payment.BorderRadius = 10;
            this.Payment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Payment.DefaultText = "0.00";
            this.Payment.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Payment.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Payment.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Payment.DisabledState.Parent = this.Payment;
            this.Payment.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Payment.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Payment.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Payment.FocusedState.Parent = this.Payment;
            this.Payment.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Payment.HoverState.Parent = this.Payment;
            this.Payment.Location = new System.Drawing.Point(108, 328);
            this.Payment.Name = "Payment";
            this.Payment.PasswordChar = '\0';
            this.Payment.PlaceholderText = "";
            this.Payment.SelectedText = "";
            this.Payment.SelectionStart = 4;
            this.Payment.ShadowDecoration.Parent = this.Payment;
            this.Payment.Size = new System.Drawing.Size(83, 30);
            this.Payment.TabIndex = 3;
            this.Payment.TextChanged += new System.EventHandler(this.Payment_TextChanged);
            this.Payment.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Payment_KeyPress);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.ForeColor = System.Drawing.Color.Indigo;
            this.label11.Location = new System.Drawing.Point(24, 370);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 18);
            this.label11.TabIndex = 17;
            this.label11.Text = "Due";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(677, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 22);
            this.label1.TabIndex = 17;
            this.label1.Text = "Date";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(317, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 22);
            this.label5.TabIndex = 17;
            this.label5.Text = "Invoice Number";
            // 
            // PurchaseScreen_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.searchLabel);
            this.Controls.Add(this.purchaseDate);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.InvoiceBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AllItems);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SelectedItems);
            this.Controls.Add(this.Backbtn);
            this.Name = "PurchaseScreen_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.PurchaseScreenForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AllItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SelectedItems)).EndInit();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private System.Windows.Forms.Label searchLabel;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2TextBox Totalpayment;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox due;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox Payment;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2ComboBox PaymentTypebox;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox InvoiceBox;
        private Guna.UI2.WinForms.Guna2DateTimePicker purchaseDate;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox SelectedSupplierBox;
        private Guna.UI2.WinForms.Guna2DataGridView AllItems;
        private Guna.UI2.WinForms.Guna2DataGridView SelectedItems;
        private Guna.UI2.WinForms.Guna2TextBox TCSbox;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox SPDues;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2GradientButton Backbtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemID;
        private System.Windows.Forms.DataGridViewImageColumn Picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn catagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Company;
        private System.Windows.Forms.DataGridViewTextBoxColumn Brands;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2TextBox Remainingbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedID;
        private System.Windows.Forms.DataGridViewImageColumn SelectedPicture;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedCatagory;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedCompany;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedBrand;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedIMEI1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedIMEI2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedColor;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedPurchase;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedWarranty;
        private System.Windows.Forms.DataGridViewTextBoxColumn SelectedState;
    }
}
