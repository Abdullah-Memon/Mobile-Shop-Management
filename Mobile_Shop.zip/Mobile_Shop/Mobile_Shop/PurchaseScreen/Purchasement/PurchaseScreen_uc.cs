﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen
{
    public partial class PurchaseScreen_uc : UserControl
    {
        // Global Variables
        SqlCommand cmd;
        DataTable data;
        string search;
        public static DataTable purchaseDetailsData;

        public PurchaseScreen_uc()
        {
            InitializeComponent();
            LoginForm.LoginScreen.ms.WindowState = FormWindowState.Maximized;
            LoginForm.LoginScreen.ms.maximizebtn.Enabled = false;
        }
        
        // Function getting payment types data
        private void getpaymentTypeData()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable paymentTypeData = new DataTable();
                cmd = new SqlCommand("PaymentTypeDetails",DB.con) { CommandType = CommandType.StoredProcedure};
                paymentTypeData.Load(cmd.ExecuteReader());

                PaymentTypebox.DataSource = paymentTypeData;
                PaymentTypebox.DisplayMember = "P_Type";
                PaymentTypebox.ValueMember = "PID";

                DB.con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while getting payment Types " + ex.ToString(), "Error");
            }
        }

        // Function SendPurchasement Function
        private void SentPurchasement()
        {
            try
            {
                //variable to change string notation into integer notation 
                int newvalue;

                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                int chk = 0;

                // using loop to add all the items data in database
                for (int i = 0; i < SelectedItems.Rows.Count; i++)
                {
                    cmd = new SqlCommand("AddPurchaseDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                    cmd.Parameters.Add(new SqlParameter("@aid", SelectSupplierAccountForm.supplier_id));

                    if (SelectSupplierAccountForm.supplier_id == "1")
                    {
                        cmd.Parameters.Add(new SqlParameter("@supplierName", SelectedSupplierBox.Text));
                        cmd.Parameters.Add(new SqlParameter("@supplierMobile", SelectSupplierAccountForm.supplier_mobile));
                        cmd.Parameters.Add(new SqlParameter("@supplierEmail", SelectSupplierAccountForm.supplier_email));
                    }

                    cmd.Parameters.Add(new SqlParameter("@date", purchaseDate.Value));
                    cmd.Parameters.Add(new SqlParameter("@invoice", Convert.ToDecimal(InvoiceBox.Text)));
                    cmd.Parameters.Add(new SqlParameter("@qty", SelectedItems.Rows[i].Cells["SelectedQuantity"].Value));
                    cmd.Parameters.Add(new SqlParameter("@sell", Convert.ToDecimal(SelectedItems.Rows[i].Cells["SelectedPurchase"].Value)));
                    cmd.Parameters.Add(new SqlParameter("@purchase", Convert.ToDecimal(SelectedItems.Rows[i].Cells["SelectedRate"].Value)));
                    cmd.Parameters.Add(new SqlParameter("@id", SelectedItems.Rows[i].Cells["SelectedID"].Value));
                    cmd.Parameters.Add(new SqlParameter("@imei1", SelectedItems.Rows[i].Cells["SelectedIMEI1"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@imei2", SelectedItems.Rows[i].Cells["SelectedIMEI2"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@color", SelectedItems.Rows[i].Cells["SelectedColor"].Value.ToString()));
                    

                    
                    if (SelectedItems.Rows[i].Cells["SelectedBox"].Value.ToString() == "Yes")
                        newvalue = 1;
                    else
                        newvalue = 0;

                    cmd.Parameters.Add(new SqlParameter("@box", newvalue));

                    if (SelectedItems.Rows[i].Cells["SelectedState"].Value.ToString() == "Used")
                        newvalue = 1;
                    else
                        newvalue = 0;

                    cmd.Parameters.Add(new SqlParameter("@state", newvalue));

                    cmd.Parameters.Add(new SqlParameter("@Warranty", SelectedItems.Rows[i].Cells["SelectedWarranty"].Value.ToString()));

                    chk = cmd.ExecuteNonQuery();
                }

                DB.con.Close();

                // Adding  purchase invoice details

                if (chk > 0)
                {
                    chk = 0;

                    try
                    {
                        if (DB.con.State == ConnectionState.Closed)
                            DB.con.Open();

                        cmd = new SqlCommand("AddPurchaseInvoiceDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                        cmd.Parameters.Add(new SqlParameter("@aid", SelectSupplierAccountForm.supplier_id));

                        if (SelectSupplierAccountForm.supplier_id == "1")
                        {
                            cmd.Parameters.Add(new SqlParameter("@supplierName", SelectedSupplierBox.Text));
                            cmd.Parameters.Add(new SqlParameter("@supplierMobile", SelectSupplierAccountForm.supplier_mobile));
                        }
   
                        cmd.Parameters.Add(new SqlParameter("@date", purchaseDate.Value));
                        cmd.Parameters.Add(new SqlParameter("@invoice", Convert.ToDecimal(InvoiceBox.Text)));

                        if (SelectSupplierAccountForm.supplier_id != "1" && Convert.ToDecimal(Remainingbox.Text) > 0)
                        {
                            if (MessageBox.Show("Remaining Money Returned?", "Details", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                cmd.Parameters.Add(new SqlParameter("@pay", (Convert.ToDecimal(Payment.Text) - Convert.ToDecimal(Remainingbox.Text))));
                            else
                                cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(Payment.Text)));
                        }
                        else
                            cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(Payment.Text)));
                        
                        cmd.Parameters.Add(new SqlParameter("@tcs", Convert.ToDecimal(TCSbox.Text)));

                        if ((Convert.ToDecimal(Totalpayment.Text) - Convert.ToDecimal(Payment.Text)) > 0)
                            cmd.Parameters.Add(new SqlParameter("@pid", 2));
                        else
                            cmd.Parameters.Add(new SqlParameter("@pid", Convert.ToInt16(PaymentTypebox.SelectedValue.ToString())));


                        chk = cmd.ExecuteNonQuery();
                        DB.con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

                if (chk > 0)
                {
                    MessageBox.Show("Purchasement successful");

                    SendSelectedData();
                    SelectedItems.DataSource = purchaseDetailsData;
                    AllItems.Visible = false;
                    SelectedItems.Focus();

                    Totalpayment.Text = "0.00";
                    InvoiceBox.Text = string.Empty;
                    SelectedSupplierBox.Text = string.Empty;

                    Payment.Text = "0.00";
                    SPDues.Text = "0.00";
                    due.Text = "0.00";
                    TCSbox.Text = "0.00";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        // Function getting searched items details
        private void GetSearch(string a)
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();
            
                data = new DataTable();
                cmd = new SqlCommand("PurchaseItemsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@search", a));
                data.Load(cmd.ExecuteReader());

                AllItems.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching item please try again " + ex.ToString(), "Error");
            }
        }

        // Function changing data into number
        private string ConvertNumber(string a)
        {
            string number = null;
            if (a == "D1" || a== "NumPad1")
                number = "1";
            else if (a == "D2" || a == "NumPad2")
                number = "2";
            else if (a == "D3" || a == "NumPad3")
                number = "3";
            else if (a == "D4" || a == "NumPad4")
                number = "4";
            else if (a == "D5" || a == "NumPad5")
                number = "5";
            else if (a == "D6" || a == "NumPad6")
                number = "6";
            else if (a == "D7" || a == "NumPad7")
                number = "7";
            else if (a == "D8" || a == "NumPad8")
                number = "8";
            else if (a == "D9" || a == "NumPad9")
                number = "9";
            else if (a == "D0" || a == "NumPad0")
                number = "0";
            else
                number = a;
                return number;
        }

        // Function to calculate bill
        private Decimal CalculateBill ()
        {
            Decimal a = 0;
            for (int i = 0; i < SelectedItems.Rows.Count; i++)
                a += Convert.ToDecimal(SelectedItems.Rows[i].Cells["SelectedPrice"].Value);
            
            return a;
        }

        // Function to send data with new information
        private void SendSelectedData()
        {
            purchaseDetailsData = new DataTable();
            purchaseDetailsData.Columns.Add("SelectedID");
            purchaseDetailsData.Columns.Add("SelectedPicture");
            purchaseDetailsData.Columns.Add("SelectedName");
            purchaseDetailsData.Columns.Add("SelectedCatagory");
            purchaseDetailsData.Columns.Add("SelectedCompany");
            purchaseDetailsData.Columns.Add("SelectedBrands");
            purchaseDetailsData.Columns.Add("SelectedQuantity");
            purchaseDetailsData.Columns.Add("SelectedIMEI1");
            purchaseDetailsData.Columns.Add("SelectedIMEI2");
            purchaseDetailsData.Columns.Add("SelectedPurchase");
            purchaseDetailsData.Columns.Add("SelectedSell");
            purchaseDetailsData.Columns.Add("SelectedPrice");
            purchaseDetailsData.Columns.Add("SelectedColor");
            purchaseDetailsData.Columns.Add("SelectedBox");
            purchaseDetailsData.Columns.Add("SelectedWarranty");
            purchaseDetailsData.Columns.Add("SelectedState");
        }

        // Function Checking Previous Details
        private bool ChkPreviousDetails()
        {
            DataTable dt = new DataTable();
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                cmd = new SqlCommand("PreviousBills", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@invoice", Convert.ToDecimal(InvoiceBox.Text)));
                cmd.Parameters.Add(new SqlParameter("@supplier", PurchaseScreen.SelectSupplierAccountForm.supplier_id));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (dt.Rows.Count > 0)
		        return true;
            else
                return false;
        }
       
        // Main load function
        private void PurchaseScreenForm_Load(object sender, EventArgs e)
        {
            getpaymentTypeData();
            
            SendSelectedData();

            purchaseDate.Text = DateTime.Now.ToShortDateString();

            AllItems.Visible = false;
            SelectedItems.Focus();
        }

        // select supplier coding
        private void SelectedSupplierBox_DoubleClick(object sender, EventArgs e)
        {
            SelectSupplierAccountForm ssaf = new SelectSupplierAccountForm();
            ssaf.ShowDialog();

            if (SelectSupplierAccountForm.supplier_name != string.Empty)
            {
                SelectedSupplierBox.Text = SelectSupplierAccountForm.supplier_name;

                if (SelectSupplierAccountForm.supplier_id == "1")
                    SelectedSupplierBox.ReadOnly = false;
                else
                    SelectedSupplierBox.ReadOnly = true;

                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();
                
                    if (SelectSupplierAccountForm.supplier_id != "1")
                    {
                        DataTable dt = new DataTable();

                        cmd = new SqlCommand("GetDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                        cmd.Parameters.Add(new SqlParameter("@data", 2));
                        cmd.Parameters.Add(new SqlParameter("@aid", SelectSupplierAccountForm.supplier_id));

                        dt.Load(cmd.ExecuteReader());

                        if (dt.Rows.Count > 0)
                            SPDues.Text = dt.Rows[0][0].ToString();
                    }
                    else
                        SPDues.Text = "0.00";

                    if (string.IsNullOrEmpty(Totalpayment.Text) || string.IsNullOrWhiteSpace(Totalpayment.Text))
                        Totalpayment.Text = "0.00";
                    if (string.IsNullOrEmpty(Payment.Text) || string.IsNullOrWhiteSpace(Payment.Text))
                        Payment.Text = "0.00";

                    due.Text = ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text)).ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // Searching coding in grid view
        private void SelectedItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (Char.IsLetter((char)e.KeyData))
            {
                search += ConvertNumber(e.KeyData.ToString());
                searchLabel.Text = search.ToString();
                GetSearch(search);
                AllItems.Visible = true;
            }

            if (char.IsNumber((char)e.KeyData))
            {
                search += ConvertNumber(e.KeyData.ToString());
                searchLabel.Text = search;
                GetSearch(search);
                AllItems.Visible = true;
            }

            if (e.KeyData == Keys.Back || e.KeyData == Keys.Escape)
            {
                search = string.Empty;
                searchLabel.Text = search;
                AllItems.Visible = false;
            }

            if (e.KeyData == Keys.Tab)
            {
                InvoiceBox.Focus();
            }

            if (e.KeyData == Keys.Down || e.KeyData == Keys.Enter)
                AllItems.Focus();
        }
        private void AllItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Escape)
            {
                AllItems.Visible = false;
                SelectedItems.Focus();
            }

            if (e.KeyData == Keys.Enter)
            {
                DataGridViewRow dgvr = AllItems.CurrentRow;

                PurchaseDetailsForm pdf = new PurchaseDetailsForm(dgvr);
                pdf.ShowDialog();

                if (purchaseDetailsData.Rows.Count > 0)
                    SelectedItems.DataSource = purchaseDetailsData;
                
                try
                {
                    if (string.IsNullOrEmpty(TCSbox.Text) || string.IsNullOrWhiteSpace(TCSbox.Text))
                        TCSbox.Text = "0.00";
                    if (string.IsNullOrEmpty(SPDues.Text) || string.IsNullOrWhiteSpace(SPDues.Text))
                        SPDues.Text = "0.00";
                    if (string.IsNullOrEmpty(Payment.Text) || string.IsNullOrWhiteSpace(Payment.Text))
                        Payment.Text = "0.00";
                    
                    Totalpayment.Text = (CalculateBill()+Convert.ToDecimal(TCSbox.Text)).ToString();

                    if ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text) < 0)
                    {
                        due.Text = "0.00";
                        Remainingbox.Text = (Convert.ToDecimal(Payment.Text) - (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text))).ToString();
                    }
                    else
                    {
                        Remainingbox.Text = "0.00";
                        due.Text = ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text)).ToString();
                    }
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                AllItems.Visible = false;
                SelectedItems.Focus();
                search = string.Empty;
                searchLabel.Text = "Search";
            }
        }

        // payment box coding
        private void Payment_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(SPDues.Text) || string.IsNullOrWhiteSpace(SPDues.Text))
                    SPDues.Text = "0.00";

                if (!string.IsNullOrEmpty(Payment.Text) || !string.IsNullOrWhiteSpace(Payment.Text))
                {
                    if ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text) < 0)
                    {
                        due.Text = "0.00";
                        Remainingbox.Text = (Convert.ToDecimal(Payment.Text) - (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text))).ToString();
                    }
                    else
                    {
                        Remainingbox.Text = "0.00";
                        due.Text = ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text)).ToString();
                    }
                }
                else
                {
                    due.Text = (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)).ToString();
                    Remainingbox.Text = "0.00";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Add button coding
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (SelectedItems.Rows.Count == 0)
                MessageBox.Show("Please select items to puchase. Thank you!");
            
            else if (string.IsNullOrEmpty(InvoiceBox.Text) || string.IsNullOrWhiteSpace (InvoiceBox.Text))
                InvoiceBox.Focus();
            else if (string.IsNullOrWhiteSpace(SelectedSupplierBox.Text) || string.IsNullOrWhiteSpace(SelectedSupplierBox.Text))
                SelectedSupplierBox.Focus();
            
            else if (SelectSupplierAccountForm.supplier_id == "1" && Convert.ToDecimal(due.Text) != 0)
                Payment.Focus();

            else
            {
                if (string.IsNullOrEmpty(TCSbox.Text) || string.IsNullOrWhiteSpace(TCSbox.Text))
                    TCSbox.Text = "0.00";
                if (string.IsNullOrEmpty(Payment.Text) || string.IsNullOrWhiteSpace(Payment.Text))
                    Payment.Text = "0.00";
                if (string.IsNullOrWhiteSpace(Remainingbox.Text) || string.IsNullOrEmpty(Remainingbox.Text))
                    Remainingbox.Text = "0.00";

                if (!ChkPreviousDetails())
                    SentPurchasement();
                else
                {
                    if (MessageBox.Show("This invoice Number is already registered; Do you want to update old record?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        SentPurchasement();
                    else
                        InvoiceBox.Focus();
                }

            }
        }

        // Adding Transport free box coding
        private void TCSbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(TCSbox.Text) || !string.IsNullOrWhiteSpace(TCSbox.Text))
                    Totalpayment.Text = (CalculateBill() + Convert.ToDecimal(TCSbox.Text)).ToString();
                else
                    Totalpayment.Text = CalculateBill().ToString();

                if (string.IsNullOrEmpty(Payment.Text) || string.IsNullOrWhiteSpace(Payment.Text))
                    Payment.Text = "0.00";
                if (string.IsNullOrEmpty(SPDues.Text) || string.IsNullOrWhiteSpace(SPDues.Text))
                    SPDues.Text = "0.00";

                if ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text) < 0)
                {
                    due.Text = "0.00";
                    Remainingbox.Text = (Convert.ToDecimal(Payment.Text) - (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text))).ToString();
                }
                else
                {
                    Remainingbox.Text = "0.00";
                    due.Text = ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text)).ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Refresh button coding
        private void refreshbtn_Click(object sender, EventArgs e)
        {
            object a = new object();
            EventArgs b = new EventArgs();
            PurchaseScreenForm_Load(a,b);
        }

        // Navigation from invoicebox
        private void InvoiceBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                SelectedSupplierBox.Focus();
        }

        // Selecting Accounts
        private void SelectedSupplierBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                SelectSupplierAccountForm ssaf = new SelectSupplierAccountForm();
                ssaf.ShowDialog();

                if (SelectSupplierAccountForm.supplier_name != string.Empty)
                    SelectedSupplierBox.Text = SelectSupplierAccountForm.supplier_name;

            }
        }

        // Back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.pd);
        }

        // Bouding user inputs
        private void InvoiceBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }     
        private void TCSbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }
        private void Payment_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }

        // After Removing Items Coding
        private void SelectedItems_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(TCSbox.Text) || string.IsNullOrWhiteSpace(TCSbox.Text))
                    TCSbox.Text = "0.00";
                if (string.IsNullOrEmpty(SPDues.Text) || string.IsNullOrWhiteSpace(SPDues.Text))
                    SPDues.Text = "0.00";
                if (string.IsNullOrEmpty(Payment.Text) || string.IsNullOrWhiteSpace(Payment.Text))
                    Payment.Text = "0.00";

                Totalpayment.Text = (CalculateBill() + Convert.ToDecimal(TCSbox.Text)).ToString();

                if ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text) < 0)
                {
                    due.Text = "0.00";
                    Remainingbox.Text = (Convert.ToDecimal(Payment.Text) - (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text))).ToString();
                }
                else
                {
                    Remainingbox.Text = "0.00";
                    due.Text = ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text)).ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Selection of Product By click
        private void AllItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = AllItems.CurrentRow;

            PurchaseDetailsForm pdf = new PurchaseDetailsForm(dgvr);
            pdf.ShowDialog();

            if (purchaseDetailsData.Rows.Count > 0)
                SelectedItems.DataSource = purchaseDetailsData;

            AllItems.Visible = false;
            search = string.Empty;
            searchLabel.Text = search;

            try
            {
                if (string.IsNullOrEmpty(TCSbox.Text) || string.IsNullOrWhiteSpace(TCSbox.Text))
                    TCSbox.Text = "0.00";
                if (string.IsNullOrEmpty(SPDues.Text) || string.IsNullOrWhiteSpace(SPDues.Text))
                    SPDues.Text = "0.00";
                if (string.IsNullOrEmpty(Payment.Text) || string.IsNullOrWhiteSpace(Payment.Text))
                    Payment.Text = "0.00";

                Totalpayment.Text = (CalculateBill() + Convert.ToDecimal(TCSbox.Text)).ToString();

                if ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text) < 0)
                {
                    due.Text = "0.00";
                    Remainingbox.Text = (Convert.ToDecimal(Payment.Text) - (Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text))).ToString();
                }
                else
                {
                    Remainingbox.Text = "0.00";
                    due.Text = ((Convert.ToDecimal(Totalpayment.Text) + Convert.ToDecimal(SPDues.Text)) - Convert.ToDecimal(Payment.Text)).ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}
