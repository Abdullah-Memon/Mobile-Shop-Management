﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen
{
    public partial class PurchaseDetailsForm : Form
    {
        // Global Variables
        DataGridViewRow dgvr;
        int totalqty = -1;

        public PurchaseDetailsForm(DataGridViewRow SelectedItemData)
        {
            InitializeComponent();
            dgvr = new DataGridViewRow();
            dgvr = SelectedItemData;
        }

        // clearing screen for new data entry
        private void clearData()
        {
            Quantity.Text = string.Empty;
            PurchasePrice.Text = string.Empty;
            SellPrice.Text = string.Empty;
            IMEI1.Text = string.Empty;
            IMEI2.Text = string.Empty;
            Color.Text = string.Empty;
        }

        // Function to check/Verify IMEI of products
        private bool VerifyIMEI()
        {
            DataTable dt = new DataTable();
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                SqlCommand cmd = new SqlCommand("VerifyIMEI", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@iid", dgvr.Cells["ItemID"].Value));
                
                if (!string.IsNullOrEmpty(IMEI1.Text) ||!string.IsNullOrWhiteSpace(IMEI1.Text))
                    cmd.Parameters.Add(new SqlParameter("@imei1", IMEI1.Text));

                if (!string.IsNullOrEmpty(IMEI2.Text) || !string.IsNullOrWhiteSpace(IMEI2.Text))    
                    cmd.Parameters.Add(new SqlParameter("@imei2", IMEI2.Text));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (dt.Rows.Count > 0)
                return false;
            else
                return true;
        }

        // selected Items available data
        private void selectedDatainfo()
        {
            byte[] pic = (byte[]) dgvr.Cells["Picture"].Value;
            MemoryStream ms = new MemoryStream(pic);
            ItemPicture.Image = Image.FromStream(ms);

            ItemName.Text = dgvr.Cells["ItemName"].Value.ToString();
            Catagorybox.Text = dgvr.Cells["Catagory"].Value.ToString();
            Companybox.Text = dgvr.Cells["Company"].Value.ToString();
            Brandbox.Text = dgvr.Cells["Brands"].Value.ToString();
        }

        // Main load function
        private void PurchaseDetailsForm_Load(object sender, EventArgs e)
        {
            clearData();
            selectedDatainfo();
            Quantity.Enabled = true;

            if (Catagorybox.Text != "Mobile")
            {
                IMEI1.Enabled = false;
                IMEI2.Enabled = false;
            }
            else
            {
                IMEI1.Enabled = true;
                IMEI2.Enabled = true;
            }

            Quantity.Focus();
             
            // hiding all warnings
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
            warning7.Hide();
            warning8.Hide();
            RemainIMEILabel.Hide();
        }

        // Back button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Add Item button coding
        private void Addselecteditem_Click(object sender, EventArgs e)
        {
            int chk = 0;

            //resting all warnings
            warning1.Hide();
            warning2.Hide();
            warning3.Hide();
            warning4.Hide();
            warning5.Hide();
            warning7.Hide();
            warning8.Hide();

            if (IMEI1.Enabled == true)
            {
                if (string.IsNullOrEmpty(IMEI1.Text) || string.IsNullOrWhiteSpace(IMEI1.Text))
                {
                    IMEI1.Focus();
                    warning5.Show();
                    chk = 1;
                }

                else if (IMEI1.Text == IMEI2.Text)
                {
                    warning8.Show();
                    IMEI2.Focus();
                    chk = 1;
                }
            }
            
            if(chk == 0)
            {
                // checking provided information
                if (string.IsNullOrEmpty(Quantity.Text) || string.IsNullOrWhiteSpace(Quantity.Text))
                {
                    Quantity.Focus();
                    warning1.Show();
                }
                else if (totalqty == -1)
                {
                    totalqty = Convert.ToInt32(Quantity.Text);
                }
                else if (string.IsNullOrEmpty(PurchasePrice.Text) || string.IsNullOrWhiteSpace(PurchasePrice.Text))
                {
                    PurchasePrice.Focus();
                    warning2.Show();
                }
                else if (string.IsNullOrEmpty(SellPrice.Text) || string.IsNullOrWhiteSpace(SellPrice.Text))
                {
                    PurchasePrice.Focus();
                    warning3.Show();
                }
                else if (string.IsNullOrEmpty(Color.Text) || string.IsNullOrWhiteSpace(Color.Text))
                {
                    Color.Focus();
                    warning4.Show();
                }

                    // adding items in selected item list
                else
                {

                    if (PurchaseScreen_uc.purchaseDetailsData.Rows.Count > 0)
                    {
                        for (int i = 0; i < PurchaseScreen_uc.purchaseDetailsData.Rows.Count; i++)
                        {
                            // When IMEI is already in purchased data
                            if (Catagorybox.Text == "Mobile")
                            {
                                if ((PurchaseScreen_uc.purchaseDetailsData.Rows[i]["SelectedIMEI1"].ToString() == IMEI1.Text || (PurchaseScreen_uc.purchaseDetailsData.Rows[i]["SelectedIMEI2"].ToString() == IMEI1.Text && PurchaseScreen_uc.purchaseDetailsData.Rows[i]["SelectedIMEI1"].ToString() == IMEI2.Text || (PurchaseScreen_uc.purchaseDetailsData.Rows[i]["SelectedIMEI2"].ToString() == IMEI2.Text && !string.IsNullOrEmpty(IMEI2.Text)))))
                                {
                                    warning7.Show();
                                    chk = 1;
                                    break;
                                }
                            }
                        }
                    }

                    if (chk == 0)
                    {
                        if (VerifyIMEI())
                        {
                            try
                            {
                                DataRow dr = PurchaseScreen_uc.purchaseDetailsData.NewRow();

                                dr[0] = dgvr.Cells["ItemID"].Value;

                                //ImageConverter img = new ImageConverter();
                                //byte[] pic = (byte[])img.ConvertTo(ItemPicture.Image, Type.GetType("System.Byte[]"));

                                // byte[] pic = (byte[]) dgvr.Cells["Picture"].Value;
                                // dr[1] = pic;

                                //dr[1] = (byte[])img.ConvertTo(ItemPicture.Image, Type.GetType("System.Byte[]")); 

                                dr[2] = dgvr.Cells["ItemName"].Value.ToString();
                                dr[3] = dgvr.Cells["Catagory"].Value.ToString();
                                dr[4] = dgvr.Cells["Company"].Value.ToString();
                                dr[5] = dgvr.Cells["Brands"].Value.ToString();
                                dr[7] = IMEI1.Text;
                                dr[8] = IMEI2.Text;
                                dr[9] = PurchasePrice.Text;
                                dr[10] = SellPrice.Text;
                                dr[12] = Color.Text;

                                if (IMEI1.Enabled == false)
                                {
                                    dr[6] = Quantity.Text;
                                    dr[11] = (Convert.ToDecimal(PurchasePrice.Text) * Convert.ToInt32(Quantity.Text)).ToString();
                                }
                                else
                                {
                                    dr[6] = 1;
                                    dr[11] = PurchasePrice.Text;
                                }

                                if (MobileBox.Checked)
                                    dr[13] = "Yes";
                                else
                                    dr[13] = "No";

                                if (string.IsNullOrEmpty(warrantybox.Text) || string.IsNullOrWhiteSpace(warrantybox.Text))
                                    dr[14] = "None";
                                else
                                    dr[14] = warrantybox.Text;

                                if (ItemState.Checked)
                                    dr[15] = ItemState.Text;
                                else
                                    dr[15] = "Used";

                                PurchaseScreen_uc.purchaseDetailsData.Rows.Add(dr);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.ToString(), "Error");
                            }


                            if (IMEI1.Enabled == true)
                            {
                                Quantity.Enabled = false;
                                IMEI1.Text = string.Empty;
                                IMEI2.Text = string.Empty;

                                totalqty = totalqty - 1;
                                if (totalqty == 0)
                                    this.Close();

                                RemainIMEILabel.Show();
                                RemainIMEILabel.Text = (totalqty.ToString() + " / " + Quantity.Text);
                                Color.Focus();
                            }
                            else
                                this.Close();
                        }

                        else
                            warning7.Show();

                    }
                    else
                        warning7.Show();
                }
            }
        }

        // Navigation setting through keys
        private void Quantity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down)
                PurchasePrice.Focus();
            if (e.KeyData == Keys.Escape)
                this.Close();
        }
        private void PurchasePrice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                Quantity.Focus();
            if (e.KeyData == Keys.Down)
                SellPrice.Focus();
        }
        private void SellPrice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                PurchasePrice.Focus();
            if (e.KeyData == Keys.Down)
                Color.Focus();
        }
        private void Color_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                SellPrice.Focus();
            if (e.KeyData == Keys.Down)
                IMEI1.Focus();
        }
        private void IMEI1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                Color.Focus();
            if (e.KeyData == Keys.Down)
                IMEI2.Focus();
        }
        private void IMEI2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                IMEI1.Focus();
            if (e.KeyData == Keys.Down)
                warrantybox.Focus();
        }
        private void warrantybox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                IMEI2.Focus();
            if (e.KeyData == Keys.Down)
                MobileBox.Focus();
        }

        // Bounding inut type
        private void Quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
        private void PurchasePrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }
        private void SellPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }
        private void IMEI2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-'))
                e.Handled = true;
        }
    }
}
