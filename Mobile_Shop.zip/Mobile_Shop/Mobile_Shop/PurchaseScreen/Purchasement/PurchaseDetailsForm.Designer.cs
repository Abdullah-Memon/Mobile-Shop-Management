﻿namespace Mobile_Shop.PurchaseScreen
{
    partial class PurchaseDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AddItemsDetailsBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.warrantybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.ItemState = new System.Windows.Forms.CheckBox();
            this.MobileBox = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Color = new Guna.UI2.WinForms.Guna2TextBox();
            this.warning8 = new System.Windows.Forms.Label();
            this.warning7 = new System.Windows.Forms.Label();
            this.RemainIMEILabel = new System.Windows.Forms.Label();
            this.warning4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.IMEI2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.IMEI1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.warning5 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Quantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.Catagorybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SellPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.PurchasePrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.Brandbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Companybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Addselecteditem = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ItemPicture = new Guna.UI2.WinForms.Guna2PictureBox();
            this.warning3 = new System.Windows.Forms.Label();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ItemName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.AddItemsDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // AddItemsDetailsBox
            // 
            this.AddItemsDetailsBox.BackColor = System.Drawing.Color.Transparent;
            this.AddItemsDetailsBox.BorderRadius = 10;
            this.AddItemsDetailsBox.Controls.Add(this.label10);
            this.AddItemsDetailsBox.Controls.Add(this.warrantybox);
            this.AddItemsDetailsBox.Controls.Add(this.ItemState);
            this.AddItemsDetailsBox.Controls.Add(this.MobileBox);
            this.AddItemsDetailsBox.Controls.Add(this.label13);
            this.AddItemsDetailsBox.Controls.Add(this.label2);
            this.AddItemsDetailsBox.Controls.Add(this.Color);
            this.AddItemsDetailsBox.Controls.Add(this.warning8);
            this.AddItemsDetailsBox.Controls.Add(this.warning7);
            this.AddItemsDetailsBox.Controls.Add(this.RemainIMEILabel);
            this.AddItemsDetailsBox.Controls.Add(this.warning4);
            this.AddItemsDetailsBox.Controls.Add(this.label12);
            this.AddItemsDetailsBox.Controls.Add(this.label9);
            this.AddItemsDetailsBox.Controls.Add(this.IMEI2);
            this.AddItemsDetailsBox.Controls.Add(this.IMEI1);
            this.AddItemsDetailsBox.Controls.Add(this.warning5);
            this.AddItemsDetailsBox.Controls.Add(this.label5);
            this.AddItemsDetailsBox.Controls.Add(this.label3);
            this.AddItemsDetailsBox.Controls.Add(this.Quantity);
            this.AddItemsDetailsBox.Controls.Add(this.Catagorybox);
            this.AddItemsDetailsBox.Controls.Add(this.label7);
            this.AddItemsDetailsBox.Controls.Add(this.label6);
            this.AddItemsDetailsBox.Controls.Add(this.label4);
            this.AddItemsDetailsBox.Controls.Add(this.label1);
            this.AddItemsDetailsBox.Controls.Add(this.SellPrice);
            this.AddItemsDetailsBox.Controls.Add(this.PurchasePrice);
            this.AddItemsDetailsBox.Controls.Add(this.Brandbox);
            this.AddItemsDetailsBox.Controls.Add(this.Companybox);
            this.AddItemsDetailsBox.Controls.Add(this.Backbtn);
            this.AddItemsDetailsBox.Controls.Add(this.Addselecteditem);
            this.AddItemsDetailsBox.Controls.Add(this.ItemPicture);
            this.AddItemsDetailsBox.Controls.Add(this.warning3);
            this.AddItemsDetailsBox.Controls.Add(this.warning2);
            this.AddItemsDetailsBox.Controls.Add(this.warning1);
            this.AddItemsDetailsBox.Controls.Add(this.label8);
            this.AddItemsDetailsBox.Controls.Add(this.ItemName);
            this.AddItemsDetailsBox.Controls.Add(this.label11);
            this.AddItemsDetailsBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AddItemsDetailsBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddItemsDetailsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddItemsDetailsBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AddItemsDetailsBox.Location = new System.Drawing.Point(10, 10);
            this.AddItemsDetailsBox.Name = "AddItemsDetailsBox";
            this.AddItemsDetailsBox.ShadowDecoration.Parent = this.AddItemsDetailsBox;
            this.AddItemsDetailsBox.Size = new System.Drawing.Size(644, 542);
            this.AddItemsDetailsBox.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Indigo;
            this.label10.Location = new System.Drawing.Point(421, 382);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 19);
            this.label10.TabIndex = 32;
            this.label10.Text = "Warranty";
            // 
            // warrantybox
            // 
            this.warrantybox.BorderRadius = 10;
            this.warrantybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.warrantybox.DefaultText = "";
            this.warrantybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.warrantybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.warrantybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.warrantybox.DisabledState.Parent = this.warrantybox;
            this.warrantybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.warrantybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.warrantybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.warrantybox.FocusedState.Parent = this.warrantybox;
            this.warrantybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.warrantybox.HoverState.Parent = this.warrantybox;
            this.warrantybox.Location = new System.Drawing.Point(420, 401);
            this.warrantybox.Margin = new System.Windows.Forms.Padding(3, 27, 3, 27);
            this.warrantybox.Name = "warrantybox";
            this.warrantybox.PasswordChar = '\0';
            this.warrantybox.PlaceholderText = "";
            this.warrantybox.SelectedText = "";
            this.warrantybox.ShadowDecoration.Parent = this.warrantybox;
            this.warrantybox.Size = new System.Drawing.Size(199, 37);
            this.warrantybox.TabIndex = 6;
            this.warrantybox.Tag = "info";
            this.warrantybox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.warrantybox_KeyDown);
            // 
            // ItemState
            // 
            this.ItemState.AutoSize = true;
            this.ItemState.Checked = true;
            this.ItemState.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ItemState.Location = new System.Drawing.Point(14, 500);
            this.ItemState.Name = "ItemState";
            this.ItemState.Size = new System.Drawing.Size(284, 23);
            this.ItemState.TabIndex = 7;
            this.ItemState.Text = "Following Product Is a Brand new product";
            this.ItemState.UseVisualStyleBackColor = true;
            // 
            // MobileBox
            // 
            this.MobileBox.AutoSize = true;
            this.MobileBox.Checked = true;
            this.MobileBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MobileBox.Location = new System.Drawing.Point(14, 473);
            this.MobileBox.Name = "MobileBox";
            this.MobileBox.Size = new System.Drawing.Size(278, 23);
            this.MobileBox.TabIndex = 7;
            this.MobileBox.Text = "Following product Comes along with Box";
            this.MobileBox.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Silver;
            this.label13.Location = new System.Drawing.Point(8, 277);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(627, 19);
            this.label13.TabIndex = 28;
            this.label13.Text = "_________________________________________________________________________________" +
    "______________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(421, 306);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 19);
            this.label2.TabIndex = 28;
            this.label2.Text = "Color";
            // 
            // Color
            // 
            this.Color.BorderRadius = 10;
            this.Color.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Color.DefaultText = "";
            this.Color.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Color.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Color.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Color.DisabledState.Parent = this.Color;
            this.Color.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Color.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Color.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Color.FocusedState.Parent = this.Color;
            this.Color.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Color.HoverState.Parent = this.Color;
            this.Color.Location = new System.Drawing.Point(420, 333);
            this.Color.Margin = new System.Windows.Forms.Padding(3, 21, 3, 21);
            this.Color.Name = "Color";
            this.Color.PasswordChar = '\0';
            this.Color.PlaceholderText = "";
            this.Color.SelectedText = "";
            this.Color.ShadowDecoration.Parent = this.Color;
            this.Color.Size = new System.Drawing.Size(199, 37);
            this.Color.TabIndex = 3;
            this.Color.Tag = "info";
            this.Color.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Color_KeyDown);
            // 
            // warning8
            // 
            this.warning8.AutoSize = true;
            this.warning8.ForeColor = System.Drawing.Color.Red;
            this.warning8.Location = new System.Drawing.Point(254, 442);
            this.warning8.Name = "warning8";
            this.warning8.Size = new System.Drawing.Size(138, 19);
            this.warning8.TabIndex = 27;
            this.warning8.Text = "* IMEI Can\'t be same";
            // 
            // warning7
            // 
            this.warning7.AutoSize = true;
            this.warning7.ForeColor = System.Drawing.Color.Red;
            this.warning7.Location = new System.Drawing.Point(16, 442);
            this.warning7.Name = "warning7";
            this.warning7.Size = new System.Drawing.Size(221, 19);
            this.warning7.TabIndex = 27;
            this.warning7.Text = "* This Product\'s IMEI already exists";
            // 
            // RemainIMEILabel
            // 
            this.RemainIMEILabel.AutoSize = true;
            this.RemainIMEILabel.ForeColor = System.Drawing.Color.Red;
            this.RemainIMEILabel.Location = new System.Drawing.Point(122, 195);
            this.RemainIMEILabel.Name = "RemainIMEILabel";
            this.RemainIMEILabel.Size = new System.Drawing.Size(40, 19);
            this.RemainIMEILabel.TabIndex = 27;
            this.RemainIMEILabel.Text = "* 0/0";
            // 
            // warning4
            // 
            this.warning4.AutoSize = true;
            this.warning4.ForeColor = System.Drawing.Color.Red;
            this.warning4.Location = new System.Drawing.Point(487, 306);
            this.warning4.Name = "warning4";
            this.warning4.Size = new System.Drawing.Size(130, 19);
            this.warning4.TabIndex = 27;
            this.warning4.Text = "* Please Enter Color";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Indigo;
            this.label12.Location = new System.Drawing.Point(16, 382);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 19);
            this.label12.TabIndex = 25;
            this.label12.Text = "Enter IMEI-2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Indigo;
            this.label9.Location = new System.Drawing.Point(16, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 19);
            this.label9.TabIndex = 25;
            this.label9.Text = "Enter IMEI-1";
            // 
            // IMEI2
            // 
            this.IMEI2.BorderRadius = 10;
            this.IMEI2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IMEI2.DefaultText = "";
            this.IMEI2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.IMEI2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.IMEI2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI2.DisabledState.Parent = this.IMEI2;
            this.IMEI2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.IMEI2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI2.FocusedState.Parent = this.IMEI2;
            this.IMEI2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI2.HoverState.Parent = this.IMEI2;
            this.IMEI2.Location = new System.Drawing.Point(14, 401);
            this.IMEI2.Margin = new System.Windows.Forms.Padding(3, 46, 3, 46);
            this.IMEI2.Name = "IMEI2";
            this.IMEI2.PasswordChar = '\0';
            this.IMEI2.PlaceholderText = "";
            this.IMEI2.SelectedText = "";
            this.IMEI2.ShadowDecoration.Parent = this.IMEI2;
            this.IMEI2.Size = new System.Drawing.Size(372, 37);
            this.IMEI2.TabIndex = 5;
            this.IMEI2.Tag = "info";
            this.IMEI2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.IMEI2_KeyDown);
            this.IMEI2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.IMEI2_KeyPress);
            // 
            // IMEI1
            // 
            this.IMEI1.BorderRadius = 10;
            this.IMEI1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IMEI1.DefaultText = "";
            this.IMEI1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.IMEI1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.IMEI1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI1.DisabledState.Parent = this.IMEI1;
            this.IMEI1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.IMEI1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI1.FocusedState.Parent = this.IMEI1;
            this.IMEI1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI1.HoverState.Parent = this.IMEI1;
            this.IMEI1.Location = new System.Drawing.Point(14, 331);
            this.IMEI1.Margin = new System.Windows.Forms.Padding(3, 35, 3, 35);
            this.IMEI1.Name = "IMEI1";
            this.IMEI1.PasswordChar = '\0';
            this.IMEI1.PlaceholderText = "";
            this.IMEI1.SelectedText = "";
            this.IMEI1.ShadowDecoration.Parent = this.IMEI1;
            this.IMEI1.Size = new System.Drawing.Size(372, 37);
            this.IMEI1.TabIndex = 4;
            this.IMEI1.Tag = "info";
            this.IMEI1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.IMEI1_KeyDown);
            this.IMEI1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.IMEI2_KeyPress);
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.ForeColor = System.Drawing.Color.Red;
            this.warning5.Location = new System.Drawing.Point(255, 306);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(137, 19);
            this.warning5.TabIndex = 24;
            this.warning5.Text = "* Please Enter IMEI 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(18, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(428, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 22;
            this.label3.Text = "Catagory";
            // 
            // Quantity
            // 
            this.Quantity.BorderRadius = 10;
            this.Quantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Quantity.DefaultText = "";
            this.Quantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Quantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Quantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Quantity.DisabledState.Parent = this.Quantity;
            this.Quantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Quantity.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Quantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Quantity.FocusedState.Parent = this.Quantity;
            this.Quantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Quantity.HoverState.Parent = this.Quantity;
            this.Quantity.Location = new System.Drawing.Point(14, 218);
            this.Quantity.Margin = new System.Windows.Forms.Padding(3, 16, 3, 16);
            this.Quantity.Name = "Quantity";
            this.Quantity.PasswordChar = '\0';
            this.Quantity.PlaceholderText = "";
            this.Quantity.SelectedText = "";
            this.Quantity.ShadowDecoration.Parent = this.Quantity;
            this.Quantity.Size = new System.Drawing.Size(150, 37);
            this.Quantity.TabIndex = 0;
            this.Quantity.Tag = "info";
            this.Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Quantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Quantity_KeyDown);
            this.Quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Quantity_KeyPress);
            // 
            // Catagorybox
            // 
            this.Catagorybox.BorderRadius = 10;
            this.Catagorybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Catagorybox.DefaultText = "";
            this.Catagorybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Catagorybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Catagorybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Catagorybox.DisabledState.Parent = this.Catagorybox;
            this.Catagorybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Catagorybox.Enabled = false;
            this.Catagorybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Catagorybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Catagorybox.FocusedState.Parent = this.Catagorybox;
            this.Catagorybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Catagorybox.HoverState.Parent = this.Catagorybox;
            this.Catagorybox.Location = new System.Drawing.Point(422, 56);
            this.Catagorybox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.Catagorybox.Name = "Catagorybox";
            this.Catagorybox.PasswordChar = '\0';
            this.Catagorybox.PlaceholderText = "";
            this.Catagorybox.SelectedText = "";
            this.Catagorybox.ShadowDecoration.Parent = this.Catagorybox;
            this.Catagorybox.Size = new System.Drawing.Size(199, 37);
            this.Catagorybox.TabIndex = 23;
            this.Catagorybox.Tag = "info";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(416, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 19);
            this.label7.TabIndex = 20;
            this.label7.Text = "Sell Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(189, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 19);
            this.label6.TabIndex = 20;
            this.label6.Text = "Purchase Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(191, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Brand";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(418, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 19);
            this.label1.TabIndex = 20;
            this.label1.Text = "Company";
            // 
            // SellPrice
            // 
            this.SellPrice.BorderRadius = 10;
            this.SellPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SellPrice.DefaultText = "";
            this.SellPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SellPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SellPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SellPrice.DisabledState.Parent = this.SellPrice;
            this.SellPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SellPrice.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SellPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellPrice.FocusedState.Parent = this.SellPrice;
            this.SellPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellPrice.HoverState.Parent = this.SellPrice;
            this.SellPrice.Location = new System.Drawing.Point(422, 218);
            this.SellPrice.Margin = new System.Windows.Forms.Padding(3, 27, 3, 27);
            this.SellPrice.Name = "SellPrice";
            this.SellPrice.PasswordChar = '\0';
            this.SellPrice.PlaceholderText = "";
            this.SellPrice.SelectedText = "";
            this.SellPrice.ShadowDecoration.Parent = this.SellPrice;
            this.SellPrice.Size = new System.Drawing.Size(199, 37);
            this.SellPrice.TabIndex = 2;
            this.SellPrice.Tag = "info";
            this.SellPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SellPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SellPrice_KeyDown);
            this.SellPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SellPrice_KeyPress);
            // 
            // PurchasePrice
            // 
            this.PurchasePrice.BorderRadius = 10;
            this.PurchasePrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PurchasePrice.DefaultText = "";
            this.PurchasePrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PurchasePrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PurchasePrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PurchasePrice.DisabledState.Parent = this.PurchasePrice;
            this.PurchasePrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PurchasePrice.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PurchasePrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PurchasePrice.FocusedState.Parent = this.PurchasePrice;
            this.PurchasePrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PurchasePrice.HoverState.Parent = this.PurchasePrice;
            this.PurchasePrice.Location = new System.Drawing.Point(192, 218);
            this.PurchasePrice.Margin = new System.Windows.Forms.Padding(3, 21, 3, 21);
            this.PurchasePrice.Name = "PurchasePrice";
            this.PurchasePrice.PasswordChar = '\0';
            this.PurchasePrice.PlaceholderText = "";
            this.PurchasePrice.SelectedText = "";
            this.PurchasePrice.ShadowDecoration.Parent = this.PurchasePrice;
            this.PurchasePrice.Size = new System.Drawing.Size(199, 37);
            this.PurchasePrice.TabIndex = 1;
            this.PurchasePrice.Tag = "info";
            this.PurchasePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PurchasePrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PurchasePrice_KeyDown);
            this.PurchasePrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PurchasePrice_KeyPress);
            // 
            // Brandbox
            // 
            this.Brandbox.BorderRadius = 10;
            this.Brandbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Brandbox.DefaultText = "";
            this.Brandbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Brandbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Brandbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.DisabledState.Parent = this.Brandbox;
            this.Brandbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.Enabled = false;
            this.Brandbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Brandbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.FocusedState.Parent = this.Brandbox;
            this.Brandbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.HoverState.Parent = this.Brandbox;
            this.Brandbox.Location = new System.Drawing.Point(195, 126);
            this.Brandbox.Margin = new System.Windows.Forms.Padding(3, 16, 3, 16);
            this.Brandbox.Name = "Brandbox";
            this.Brandbox.PasswordChar = '\0';
            this.Brandbox.PlaceholderText = "";
            this.Brandbox.SelectedText = "";
            this.Brandbox.ShadowDecoration.Parent = this.Brandbox;
            this.Brandbox.Size = new System.Drawing.Size(199, 37);
            this.Brandbox.TabIndex = 21;
            this.Brandbox.Tag = "info";
            // 
            // Companybox
            // 
            this.Companybox.BorderRadius = 10;
            this.Companybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Companybox.DefaultText = "";
            this.Companybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Companybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Companybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Companybox.DisabledState.Parent = this.Companybox;
            this.Companybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Companybox.Enabled = false;
            this.Companybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Companybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Companybox.FocusedState.Parent = this.Companybox;
            this.Companybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Companybox.HoverState.Parent = this.Companybox;
            this.Companybox.Location = new System.Drawing.Point(422, 126);
            this.Companybox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.Companybox.Name = "Companybox";
            this.Companybox.PasswordChar = '\0';
            this.Companybox.PlaceholderText = "";
            this.Companybox.SelectedText = "";
            this.Companybox.ShadowDecoration.Parent = this.Companybox;
            this.Companybox.Size = new System.Drawing.Size(199, 37);
            this.Companybox.TabIndex = 21;
            this.Companybox.Tag = "info";
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(600, 6);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(35, 35);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "X";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // Addselecteditem
            // 
            this.Addselecteditem.BackColor = System.Drawing.Color.Transparent;
            this.Addselecteditem.BorderColor = System.Drawing.Color.White;
            this.Addselecteditem.BorderRadius = 10;
            this.Addselecteditem.BorderThickness = 2;
            this.Addselecteditem.CheckedState.Parent = this.Addselecteditem;
            this.Addselecteditem.CustomImages.Parent = this.Addselecteditem;
            this.Addselecteditem.FillColor = System.Drawing.Color.Indigo;
            this.Addselecteditem.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.Addselecteditem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Addselecteditem.ForeColor = System.Drawing.Color.White;
            this.Addselecteditem.HoverState.Parent = this.Addselecteditem;
            this.Addselecteditem.Location = new System.Drawing.Point(480, 473);
            this.Addselecteditem.Name = "Addselecteditem";
            this.Addselecteditem.ShadowDecoration.Parent = this.Addselecteditem;
            this.Addselecteditem.Size = new System.Drawing.Size(137, 50);
            this.Addselecteditem.TabIndex = 8;
            this.Addselecteditem.Text = "ADD";
            this.Addselecteditem.Click += new System.EventHandler(this.Addselecteditem_Click);
            // 
            // ItemPicture
            // 
            this.ItemPicture.BorderRadius = 10;
            this.ItemPicture.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ItemPicture.Location = new System.Drawing.Point(14, 13);
            this.ItemPicture.Name = "ItemPicture";
            this.ItemPicture.ShadowDecoration.Parent = this.ItemPicture;
            this.ItemPicture.Size = new System.Drawing.Size(150, 150);
            this.ItemPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ItemPicture.TabIndex = 4;
            this.ItemPicture.TabStop = false;
            // 
            // warning3
            // 
            this.warning3.AutoSize = true;
            this.warning3.ForeColor = System.Drawing.Color.Red;
            this.warning3.Location = new System.Drawing.Point(469, 259);
            this.warning3.Name = "warning3";
            this.warning3.Size = new System.Drawing.Size(150, 19);
            this.warning3.TabIndex = 1;
            this.warning3.Text = "* Please Enter Sell Price";
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(207, 259);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(185, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Please Enter Purchase Price";
            // 
            // warning1
            // 
            this.warning1.AutoSize = true;
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(18, 259);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(146, 19);
            this.warning1.TabIndex = 1;
            this.warning1.Text = "* Please Enter Quanity";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(191, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Item Name";
            // 
            // ItemName
            // 
            this.ItemName.BorderRadius = 10;
            this.ItemName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ItemName.DefaultText = "";
            this.ItemName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ItemName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ItemName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ItemName.DisabledState.Parent = this.ItemName;
            this.ItemName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ItemName.Enabled = false;
            this.ItemName.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ItemName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ItemName.FocusedState.Parent = this.ItemName;
            this.ItemName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ItemName.HoverState.Parent = this.ItemName;
            this.ItemName.Location = new System.Drawing.Point(195, 56);
            this.ItemName.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.ItemName.Name = "ItemName";
            this.ItemName.PasswordChar = '\0';
            this.ItemName.PlaceholderText = "";
            this.ItemName.SelectedText = "";
            this.ItemName.ShadowDecoration.Parent = this.ItemName;
            this.ItemName.Size = new System.Drawing.Size(199, 37);
            this.ItemName.TabIndex = 1;
            this.ItemName.Tag = "info";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Silver;
            this.label11.Location = new System.Drawing.Point(3, 163);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(627, 19);
            this.label11.TabIndex = 28;
            this.label11.Text = "_________________________________________________________________________________" +
    "______________________";
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this.AddItemsDetailsBox;
            // 
            // PurchaseDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(664, 562);
            this.Controls.Add(this.AddItemsDetailsBox);
            this.ForeColor = System.Drawing.Color.Indigo;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PurchaseDetailsForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PurchaseDetailsForm";
            this.Load += new System.EventHandler(this.PurchaseDetailsForm_Load);
            this.AddItemsDetailsBox.ResumeLayout(false);
            this.AddItemsDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox AddItemsDetailsBox;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton Addselecteditem;
        private Guna.UI2.WinForms.Guna2PictureBox ItemPicture;
        private System.Windows.Forms.Label warning3;
        private System.Windows.Forms.Label warning2;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox ItemName;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox Catagorybox;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox Companybox;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox Brandbox;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox Quantity;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox SellPrice;
        private Guna.UI2.WinForms.Guna2TextBox PurchasePrice;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox IMEI1;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2TextBox IMEI2;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox Color;
        private System.Windows.Forms.Label warning4;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private System.Windows.Forms.Label RemainIMEILabel;
        private System.Windows.Forms.Label warning7;
        private System.Windows.Forms.CheckBox MobileBox;
        private System.Windows.Forms.Label warning8;
        private Guna.UI2.WinForms.Guna2TextBox warrantybox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox ItemState;
    }
}