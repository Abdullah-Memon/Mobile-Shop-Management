﻿namespace Mobile_Shop.PurchaseScreen
{
    partial class PurchaseDashboard_uc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Returnbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Claimbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.EditBillsbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Duesbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.PurchaseScreenbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.shoptitle = new System.Windows.Forms.Label();
            this.AccountsReportBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.SelectedReporting = new Guna.UI2.WinForms.Guna2ComboBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.Returnbtn, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.Claimbtn, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.EditBillsbtn, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.Duesbtn, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(388, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(666, 368);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // Returnbtn
            // 
            this.Returnbtn.BorderColor = System.Drawing.Color.Indigo;
            this.Returnbtn.BorderRadius = 20;
            this.Returnbtn.BorderThickness = 1;
            this.Returnbtn.CheckedState.Parent = this.Returnbtn;
            this.Returnbtn.CustomImages.Parent = this.Returnbtn;
            this.Returnbtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Returnbtn.FillColor = System.Drawing.Color.Transparent;
            this.Returnbtn.FillColor2 = System.Drawing.Color.Transparent;
            this.Returnbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Returnbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Returnbtn.HoverState.Parent = this.Returnbtn;
            this.Returnbtn.Location = new System.Drawing.Point(336, 187);
            this.Returnbtn.Name = "Returnbtn";
            this.Returnbtn.ShadowDecoration.Parent = this.Returnbtn;
            this.Returnbtn.Size = new System.Drawing.Size(327, 178);
            this.Returnbtn.TabIndex = 4;
            this.Returnbtn.Text = "Return";
            this.Returnbtn.Click += new System.EventHandler(this.Returnbtn_Click);
            // 
            // Claimbtn
            // 
            this.Claimbtn.BorderColor = System.Drawing.Color.Indigo;
            this.Claimbtn.BorderRadius = 20;
            this.Claimbtn.BorderThickness = 1;
            this.Claimbtn.CheckedState.Parent = this.Claimbtn;
            this.Claimbtn.CustomImages.Parent = this.Claimbtn;
            this.Claimbtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Claimbtn.FillColor = System.Drawing.Color.Transparent;
            this.Claimbtn.FillColor2 = System.Drawing.Color.Transparent;
            this.Claimbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Claimbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Claimbtn.HoverState.Parent = this.Claimbtn;
            this.Claimbtn.Location = new System.Drawing.Point(3, 187);
            this.Claimbtn.Name = "Claimbtn";
            this.Claimbtn.ShadowDecoration.Parent = this.Claimbtn;
            this.Claimbtn.Size = new System.Drawing.Size(327, 178);
            this.Claimbtn.TabIndex = 3;
            this.Claimbtn.Text = "Claim";
            this.Claimbtn.Click += new System.EventHandler(this.guna2GradientButton2_Click);
            // 
            // EditBillsbtn
            // 
            this.EditBillsbtn.BorderColor = System.Drawing.Color.Indigo;
            this.EditBillsbtn.BorderRadius = 20;
            this.EditBillsbtn.BorderThickness = 1;
            this.EditBillsbtn.CheckedState.Parent = this.EditBillsbtn;
            this.EditBillsbtn.CustomImages.Parent = this.EditBillsbtn;
            this.EditBillsbtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EditBillsbtn.FillColor = System.Drawing.Color.Transparent;
            this.EditBillsbtn.FillColor2 = System.Drawing.Color.Transparent;
            this.EditBillsbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.EditBillsbtn.ForeColor = System.Drawing.Color.Indigo;
            this.EditBillsbtn.HoverState.Parent = this.EditBillsbtn;
            this.EditBillsbtn.Location = new System.Drawing.Point(3, 3);
            this.EditBillsbtn.Name = "EditBillsbtn";
            this.EditBillsbtn.ShadowDecoration.Parent = this.EditBillsbtn;
            this.EditBillsbtn.Size = new System.Drawing.Size(327, 178);
            this.EditBillsbtn.TabIndex = 2;
            this.EditBillsbtn.Text = "Edit Bills";
            this.EditBillsbtn.Click += new System.EventHandler(this.EditBillsbtn_Click);
            // 
            // Duesbtn
            // 
            this.Duesbtn.BorderColor = System.Drawing.Color.Indigo;
            this.Duesbtn.BorderRadius = 20;
            this.Duesbtn.BorderThickness = 1;
            this.Duesbtn.CheckedState.Parent = this.Duesbtn;
            this.Duesbtn.CustomImages.Parent = this.Duesbtn;
            this.Duesbtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Duesbtn.FillColor = System.Drawing.Color.Transparent;
            this.Duesbtn.FillColor2 = System.Drawing.Color.Transparent;
            this.Duesbtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Duesbtn.ForeColor = System.Drawing.Color.Indigo;
            this.Duesbtn.HoverState.Parent = this.Duesbtn;
            this.Duesbtn.Location = new System.Drawing.Point(336, 3);
            this.Duesbtn.Name = "Duesbtn";
            this.Duesbtn.ShadowDecoration.Parent = this.Duesbtn;
            this.Duesbtn.Size = new System.Drawing.Size(327, 178);
            this.Duesbtn.TabIndex = 1;
            this.Duesbtn.Text = "Dues";
            this.Duesbtn.Click += new System.EventHandler(this.Duesbtn_Click);
            // 
            // PurchaseScreenbtn
            // 
            this.PurchaseScreenbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PurchaseScreenbtn.BorderColor = System.Drawing.Color.Indigo;
            this.PurchaseScreenbtn.BorderRadius = 20;
            this.PurchaseScreenbtn.BorderThickness = 1;
            this.PurchaseScreenbtn.CheckedState.Parent = this.PurchaseScreenbtn;
            this.PurchaseScreenbtn.CustomImages.Parent = this.PurchaseScreenbtn;
            this.PurchaseScreenbtn.FillColor = System.Drawing.Color.Transparent;
            this.PurchaseScreenbtn.FillColor2 = System.Drawing.Color.Transparent;
            this.PurchaseScreenbtn.Font = new System.Drawing.Font("Segoe UI", 32F);
            this.PurchaseScreenbtn.ForeColor = System.Drawing.Color.Indigo;
            this.PurchaseScreenbtn.HoverState.Parent = this.PurchaseScreenbtn;
            this.PurchaseScreenbtn.Location = new System.Drawing.Point(3, 6);
            this.PurchaseScreenbtn.Name = "PurchaseScreenbtn";
            this.PurchaseScreenbtn.ShadowDecoration.Parent = this.PurchaseScreenbtn;
            this.PurchaseScreenbtn.Size = new System.Drawing.Size(379, 362);
            this.PurchaseScreenbtn.TabIndex = 0;
            this.PurchaseScreenbtn.Text = "Purchasement";
            this.PurchaseScreenbtn.Click += new System.EventHandler(this.PurchaseScreenbtn_Click);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.Indigo;
            this.guna2GroupBox1.BorderRadius = 20;
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.Controls.Add(this.shoptitle);
            this.guna2GroupBox1.Controls.Add(this.AccountsReportBtn);
            this.guna2GroupBox1.Controls.Add(this.SelectedReporting);
            this.guna2GroupBox1.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(3, 374);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(1054, 180);
            this.guna2GroupBox1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(389, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 22);
            this.label1.TabIndex = 19;
            this.label1.Text = "Select Report Type";
            // 
            // shoptitle
            // 
            this.shoptitle.AutoSize = true;
            this.shoptitle.BackColor = System.Drawing.Color.Transparent;
            this.shoptitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoptitle.ForeColor = System.Drawing.Color.Indigo;
            this.shoptitle.Location = new System.Drawing.Point(48, 65);
            this.shoptitle.Name = "shoptitle";
            this.shoptitle.Size = new System.Drawing.Size(169, 55);
            this.shoptitle.TabIndex = 19;
            this.shoptitle.Text = "Report";
            // 
            // AccountsReportBtn
            // 
            this.AccountsReportBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountsReportBtn.CheckedState.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.CustomImages.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AccountsReportBtn.ForeColor = System.Drawing.Color.White;
            this.AccountsReportBtn.HoverState.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.Location = new System.Drawing.Point(844, 65);
            this.AccountsReportBtn.Name = "AccountsReportBtn";
            this.AccountsReportBtn.ShadowDecoration.Parent = this.AccountsReportBtn;
            this.AccountsReportBtn.Size = new System.Drawing.Size(180, 45);
            this.AccountsReportBtn.TabIndex = 1;
            this.AccountsReportBtn.Text = "Report";
            this.AccountsReportBtn.Click += new System.EventHandler(this.AccountsReportBtn_Click);
            // 
            // SelectedReporting
            // 
            this.SelectedReporting.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectedReporting.BackColor = System.Drawing.Color.Transparent;
            this.SelectedReporting.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SelectedReporting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectedReporting.FocusedColor = System.Drawing.Color.Empty;
            this.SelectedReporting.FocusedState.Parent = this.SelectedReporting;
            this.SelectedReporting.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SelectedReporting.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.SelectedReporting.FormattingEnabled = true;
            this.SelectedReporting.HoverState.Parent = this.SelectedReporting;
            this.SelectedReporting.ItemHeight = 30;
            this.SelectedReporting.Items.AddRange(new object[] {
            "All Information",
            "Clearance Only",
            "Dues Only",
            "Custom Reports"});
            this.SelectedReporting.ItemsAppearance.Parent = this.SelectedReporting;
            this.SelectedReporting.Location = new System.Drawing.Point(393, 74);
            this.SelectedReporting.Name = "SelectedReporting";
            this.SelectedReporting.ShadowDecoration.Parent = this.SelectedReporting;
            this.SelectedReporting.Size = new System.Drawing.Size(270, 36);
            this.SelectedReporting.StartIndex = 0;
            this.SelectedReporting.TabIndex = 0;
            // 
            // PurchaseDashboard_uc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.PurchaseScreenbtn);
            this.Name = "PurchaseDashboard_uc";
            this.Size = new System.Drawing.Size(1060, 554);
            this.Load += new System.EventHandler(this.PurchaseDashboard_uc_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2GradientButton Returnbtn;
        private Guna.UI2.WinForms.Guna2GradientButton Claimbtn;
        private Guna.UI2.WinForms.Guna2GradientButton EditBillsbtn;
        private Guna.UI2.WinForms.Guna2GradientButton Duesbtn;
        private Guna.UI2.WinForms.Guna2GradientButton PurchaseScreenbtn;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label shoptitle;
        private Guna.UI2.WinForms.Guna2GradientButton AccountsReportBtn;
        private Guna.UI2.WinForms.Guna2ComboBox SelectedReporting;

    }
}
