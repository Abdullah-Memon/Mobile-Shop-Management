﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen
{
    public partial class SelectSupplierAccountForm : Form
    {
        int type;
        public SelectSupplierAccountForm( int a = 0)
        {
            InitializeComponent();
            type = a;
        }

        //global variables
        SqlCommand cmd;
            //selecting new information
        public static string supplier_name = string.Empty,
                             supplier_id = string.Empty,
                             supplier_email = string.Empty,
                             supplier_mobile = string.Empty;
        public static byte[] supplier_pic = null;

        // getting suppliers account
        private void GetSupplierAccounts()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();
                cmd = new SqlCommand("AccountsDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@type", 1));
                dt.Load(cmd.ExecuteReader());
                DB.con.Close();

                SupplierAccountsGridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while geting accounts information " + ex.ToString(), "Error");
            }
        }

        //back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Grid view button coding
        private void SupplierAccountsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //select button coding from grid view
            if (e.ColumnIndex == 0)
            {
                supplier_id = SupplierAccountsGridView.Rows[e.RowIndex].Cells["ACC_ID"].Value.ToString();
                supplier_name = SupplierAccountsGridView.Rows[e.RowIndex].Cells["ACC_Name"].Value.ToString();
                
                supplier_pic = (byte[]) SupplierAccountsGridView.Rows[e.RowIndex].Cells["ACC_Picture"].Value;

                this.Close();
            }
        }

        // Main load Function
        private void SelectSupplierAccountForm_Load(object sender, EventArgs e)
        {
            GetSupplierAccounts();
            if (type != 0)
                localSupplierbox.Hide();
            else
                localSupplierbox.Show();
        }

        //local Supplier Selection Button Coding
        private void localselectbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(localSupplierName.Text) || string.IsNullOrWhiteSpace(localSupplierName.Text))
            {
                localSupplierName.Focus();
            }
            else if (string.IsNullOrWhiteSpace(localSupplierMobile.Text) || string.IsNullOrEmpty(localSupplierMobile.Text))
            {
                localSupplierMobile.Focus();
            }
            else
            {
                supplier_id = "1";
                supplier_name = localSupplierName.Text;
                supplier_mobile = localSupplierMobile.Text;
                supplier_email = localSupplierAddress.Text;

                localSupplierName.Text = string.Empty;
                localSupplierMobile.Text = string.Empty;
                localSupplierAddress.Text = string.Empty;

                this.Close();
            }
        }

        private void localSupplierMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '-'))
            {
                e.Handled = true;
            }
        }
    }
}
