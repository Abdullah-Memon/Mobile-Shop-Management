﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Mobile_Shop.Account.DUES
{
    public partial class Dues_Form : Form
    {
        public Dues_Form()
        {
            InitializeComponent();
        }
        // global vaiables
        SqlCommand cmd;
        decimal total_dues, total_paid, total_bill;
        int chk = 0;


        // getting payment Type
        private void GetPaymentType()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data",1));

                dt.Load(cmd.ExecuteReader());

                PaymentTypeBox.DataSource = dt;
                PaymentTypeBox.ValueMember = "PID";
                PaymentTypeBox.DisplayMember = "P_Type";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        // Function to save new Dues
        private void Save()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                cmd = new SqlCommand("GetDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 3));
                cmd.Parameters.Add(new SqlParameter("@date", DateTimePicker1.Value));
                cmd.Parameters.Add(new SqlParameter("@aid", PurchaseScreen.SelectSupplierAccountForm.supplier_id));

                if (takemoney.Checked)
                    cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(Paybox.Text) * -1));
                else
                    cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(Paybox.Text)));

                cmd.Parameters.Add(new SqlParameter("@pid", PaymentTypeBox.SelectedValue));

                chk = cmd.ExecuteNonQuery();

                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (chk > 0)
                updatemessage.Show();
            else
                updatemessage.Hide();
        }
        
        // Main Load Function
        private void DuesPayment_Form_Load(object sender, EventArgs e)
        {
            updatemessage.Hide();
            GetPaymentType();

            DateTimePicker1.Text = System.DateTime.Now.ToShortDateString();

            selectAccountbox.Text = string.Empty;
            TotalBillbox.Text = string.Empty;
            TotalPaidbox.Text = string.Empty;
            TotalDuesbox.Text = string.Empty;
            takemoney.Checked = false;
            Paybox.Text = string.Empty;
            remainingbox.Text = string.Empty;

        }

        // Select Account coding
        private void selectAccountbox_DoubleClick(object sender, EventArgs e)
        {
            PurchaseScreen.SelectSupplierAccountForm ssaf = new PurchaseScreen.SelectSupplierAccountForm(1);
            ssaf.ShowDialog();

            if (!string.IsNullOrEmpty(PurchaseScreen.SelectSupplierAccountForm.supplier_id))
            {
                selectAccountbox.Text = PurchaseScreen.SelectSupplierAccountForm.supplier_name;

                MemoryStream ms = new MemoryStream(PurchaseScreen.SelectSupplierAccountForm.supplier_pic);
                profile.Image = Image.FromStream(ms);
            }
            
            try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    cmd = new SqlCommand("GetDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 1));
                    cmd.Parameters.Add(new SqlParameter("@aid", PurchaseScreen.SelectSupplierAccountForm.supplier_id));

                    dt.Load(cmd.ExecuteReader());
                    DB.con.Close();

                    total_dues = Convert.ToDecimal(dt.Rows[0][0]);
                    total_bill = Convert.ToDecimal(dt.Rows[0][1]);
                    total_paid = Convert.ToDecimal(dt.Rows[0][2]);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                TotalBillbox.Text = total_bill.ToString();
                TotalDuesbox.Text = total_dues.ToString();
                TotalPaidbox.Text = total_paid.ToString();
                remainingbox.Text = TotalDuesbox.Text;

                if (total_dues == 0)
                    clearbtn.Enabled = true;
                else
                    clearbtn.Enabled = false;
            }
    
        // Clossing button coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Entering Payment Coding
        private void Paybox_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Paybox.Text) || !string.IsNullOrWhiteSpace(Paybox.Text))
            {
                if (takemoney.Checked)
                    remainingbox.Text = (Convert.ToDecimal(Paybox.Text) + total_dues).ToString();
                else
                    remainingbox.Text = (total_dues - Convert.ToDecimal(Paybox.Text)).ToString();
            }
            else
            {
                remainingbox.Text = TotalDuesbox.Text;
                if (total_dues == 0)
                    clearbtn.Enabled = true;
                else
                    clearbtn.Enabled = false;
            }
        }

        // Payment button coding
        private void paybtn_Click(object sender, EventArgs e)
        {
            chk = 0;
            if (!string.IsNullOrEmpty(paybtn.Text) || !string.IsNullOrWhiteSpace(Paybox.Text))
            {
                Save();
                object a = new object();
                EventArgs b = new EventArgs();
                DuesPayment_Form_Load(a, b);
            }
        }

        // Clearance button coding
        private void clearbtn_Click(object sender, EventArgs e)
        {
            chk = 0;
            // when balance become 0
            if (total_dues != 0 && Convert.ToDecimal(remainingbox.Text) == 0)
                Save();
                
            try
            {
                //secong applyinng clearance
                if (DB.con.State == ConnectionState.Closed)
                DB.con.Open();

                cmd = new SqlCommand("GetDuesDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 4));
                cmd.Parameters.Add(new SqlParameter("@aid", PurchaseScreen.SelectSupplierAccountForm.supplier_id));

                chk = cmd.ExecuteNonQuery();
               
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

            if (chk > 0)
                updatemessage.Show();
            else
                updatemessage.Hide();

            object a2 = new object();
            EventArgs b2 = new EventArgs();
            DuesPayment_Form_Load(a2, b2);

        }

        // remaining box coding
        private void remainingbox_TextChanged(object sender, EventArgs e)
        {
            // enabling and disabling clearance button
            if (!string.IsNullOrEmpty(Paybox.Text) || !string.IsNullOrWhiteSpace(Paybox.Text))
            {
                if (takemoney.Checked)
                {
                    if (total_dues + Convert.ToDecimal(Paybox.Text) == 0)
                        clearbtn.Enabled = true;
                    else
                        clearbtn.Enabled = false;
                }
                else
                {
                    if (total_dues - Convert.ToDecimal(Paybox.Text) == 0)
                        clearbtn.Enabled = true;
                    else
                        clearbtn.Enabled = false;
                }
            }
        }

        // total dues box coding
        private void TotalDuesbox_TextChanged(object sender, EventArgs e)
        {
            //// enablinig and disableing paying button
            //if (total_dues == 0 && total_bill == 0 && total_paid == 0 && Paybox.Text == "")
            //    paybtn.Enabled = false;
            //else
            //    paybtn.Enabled = true;
        }

        // check box coding to take money
        private void takemoney_CheckedChanged(object sender, EventArgs e)
        {
            if (takemoney.Checked)
            {
                if (!string.IsNullOrEmpty(Paybox.Text) || !string.IsNullOrWhiteSpace(Paybox.Text))
                    remainingbox.Text = (Convert.ToDecimal(TotalDuesbox.Text) + Convert.ToDecimal(Paybox.Text)).ToString();
            }
            else
                if (!string.IsNullOrEmpty(Paybox.Text) || !string.IsNullOrWhiteSpace(Paybox.Text))
                    remainingbox.Text = (total_dues - Convert.ToDecimal(Paybox.Text)).ToString();
                else
                    remainingbox.Text = total_dues.ToString();
        }

        // Bounding user inputs
        private void Paybox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }
    }
}
