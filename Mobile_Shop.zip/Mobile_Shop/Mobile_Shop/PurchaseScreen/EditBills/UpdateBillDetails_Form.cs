﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen.UpdateBills
{
    public partial class UpdateBillDetails_Form : Form
    {
        DataGridViewRow dgvr;
        DataTable BillData;
        
        public UpdateBillDetails_Form(DataGridViewRow d)
        {
            InitializeComponent();
            dgvr = d;
        }

        // getting payment Type
        private void GetPaymentType()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("PaymentTypeDetails", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@data", 1));

                dt.Load(cmd.ExecuteReader());

                PaymentTypeBox.DataSource = dt;
                PaymentTypeBox.ValueMember = "PID";
                PaymentTypeBox.DisplayMember = "P_Type";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        // Funtion to set Information
        private void SetInfo()
        {
            try
            {
                ItemName.Text = dgvr.Cells["ItemName"].Value.ToString();
                Catagorybox.Text = dgvr.Cells["Catagory"].Value.ToString();
                Brandbox.Text = dgvr.Cells["Brand"].Value.ToString();
                Companybox.Text = dgvr.Cells["Company"].Value.ToString();
                Quantity.Text = dgvr.Cells["QTY"].Value.ToString();
                PurchasePrice.Text = dgvr.Cells["Price"].Value.ToString();
                Color.Text = dgvr.Cells["Color"].Value.ToString();
                warrantybox.Text = dgvr.Cells["Warranty"].Value.ToString();

                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                BillData = new DataTable();

                SqlCommand cmd = new SqlCommand("UpdateBills", DB.con) { CommandType = CommandType.StoredProcedure};
                cmd.Parameters.Add(new SqlParameter("@iid", dgvr.Cells["ID"].Value));
                cmd.Parameters.Add(new SqlParameter("@color", dgvr.Cells["Color"].Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@invoice",dgvr.Cells["InvoiceNumber"].Value));
                cmd.Parameters.Add(new SqlParameter("@aid", dgvr.Cells["AID"].Value));
                cmd.Parameters.Add(new SqlParameter("@imei1", dgvr.Cells["IMEI1"].Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@itemstate", dgvr.Cells["State"]));

                BillData.Load(cmd.ExecuteReader());
                DB.con.Close();

                TotalBill.Text = BillData.Rows[0][0].ToString();
                TotalTCS.Text = BillData.Rows[0][1].ToString();
                TotalPaid.Text = BillData.Rows[0][2].ToString();
                SellPrice.Text = BillData.Rows[0][3].ToString();
                PaymentTypeBox.SelectedValue = BillData.Rows[0][4];

                if (dgvr.Cells["Catagory"].Value.ToString() == "Mobile")
                {
                    IMEI1.Text = dgvr.Cells["IMEI1"].Value.ToString();
                    IMEI2.Text = dgvr.Cells["IMEI2"].Value.ToString();
                    Quantity.Enabled = false;
                }
                else
                {
                    IMEI1.Enabled = false;
                    IMEI2.Enabled = false;
                }

                if (dgvr.Cells["Box"].Value.ToString() != "Box")
                {
                    MobileBox.Checked = false;
                }
                if (Convert.ToInt16(BillData.Rows[0][4]) == 1)
                {
                    ItemState.Checked = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Function to check/Verify IMEI of products
        private bool VerifyIMEI()
        {
            DataTable dt = new DataTable();
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                SqlCommand cmd = new SqlCommand("VerifyIMEI", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@iid", dgvr.Cells["ID"].Value));

                if (!string.IsNullOrEmpty(IMEI1.Text) || !string.IsNullOrWhiteSpace(IMEI1.Text))
                    cmd.Parameters.Add(new SqlParameter("@imei1", IMEI1.Text));

                if (!string.IsNullOrEmpty(IMEI2.Text) || !string.IsNullOrWhiteSpace(IMEI2.Text))
                    cmd.Parameters.Add(new SqlParameter("@imei2", IMEI2.Text));

                dt.Load(cmd.ExecuteReader());
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (dt.Rows.Count > 0)
                return false;
            else
                return true;
        }

        // Function to update Details
        private void updateDetails()
        {
            try
            {
                int newValue;
                // Database Connection

                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                SqlCommand cmd = new SqlCommand("UpdateBills", DB.con) { CommandType = CommandType.StoredProcedure };

                cmd.Parameters.Add(new SqlParameter("@data",1));
                cmd.Parameters.Add(new SqlParameter("@qty", Convert.ToInt32(Quantity.Text)));
                cmd.Parameters.Add(new SqlParameter("@purchase", Convert.ToDecimal(PurchasePrice.Text)));
                cmd.Parameters.Add(new SqlParameter("@sell", SellPrice.Text));
                cmd.Parameters.Add(new SqlParameter("@imei1", dgvr.Cells["IMEI1"].Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@newimei1", IMEI1.Text));
                cmd.Parameters.Add(new SqlParameter("@imei2", IMEI2.Text));
                cmd.Parameters.Add(new SqlParameter("@Warranty", warrantybox.Text));
                cmd.Parameters.Add(new SqlParameter("@pid", PaymentTypeBox.SelectedValue));
                if (MobileBox.Checked)
                    newValue = 1;
                else
                    newValue = 0;
                cmd.Parameters.Add(new SqlParameter("@box", newValue));

                cmd.Parameters.Add(new SqlParameter("@date", Convert.ToDateTime(dgvr.Cells["Date"].Value.ToString())));
                cmd.Parameters.Add(new SqlParameter("@newdate", Convert.ToDateTime(DateTime.Now.ToShortDateString())));
                cmd.Parameters.Add(new SqlParameter("@iid", dgvr.Cells["ID"].Value));
                cmd.Parameters.Add(new SqlParameter("@invoice", dgvr.Cells["InvoiceNumber"].Value));
                cmd.Parameters.Add(new SqlParameter("@color", Color.Text));
                cmd.Parameters.Add(new SqlParameter("@aid", dgvr.Cells["AID"].Value));

                if (returnPaymentbox.Checked)
                    cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(newPaybox.Text) * -1));

                else
                    cmd.Parameters.Add(new SqlParameter("@pay", Convert.ToDecimal(newPaybox.Text)));

                cmd.Parameters.Add(new SqlParameter("@tcs", Convert.ToDecimal(newTCSbox.Text)));

                if (ItemState.Checked)
                    newValue = 0;
                else
                    newValue = 1;
                cmd.Parameters.Add(new SqlParameter("@itemstate", newValue));

                cmd.ExecuteNonQuery();
                DB.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        // Main Load Function
        private void UpdateBillDetails_Form_Load(object sender, EventArgs e)
        {
            SetInfo();
            GetPaymentType();

            warning1.Hide();
            warning2.Hide();
            warning5.Hide();
            warning7.Hide();
            warning8.Hide();

            Quantity.Focus();

        }

        // Cross Button Coding
        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Quantity Box Coding
        private void Quantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(Quantity.Text) || !string.IsNullOrWhiteSpace(Quantity.Text))
                {
                    if (Convert.ToInt32(Quantity.Text) <= 0)
                    {
                        warning1.Show();
                        newBillbox.Text = "0.00";
                    }
                    else
                    {
                        warning1.Hide();
                        
                        if (string.IsNullOrWhiteSpace(newTCSbox.Text) || string.IsNullOrEmpty(newTCSbox.Text))
                                newTCSbox.Text = "0.00";

                        //newBillbox.Text = (((Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(PurchasePrice.Text)) - (Convert.ToDecimal(TotalBill.Text) + Convert.ToDecimal(TotalTCS.Text))) + Convert.ToDecimal(newTCSbox.Text)).ToString();
                        newBillbox.Text = (((Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(PurchasePrice.Text)) - (Convert.ToInt32(dgvr.Cells["QTY"].Value) * Convert.ToDecimal(dgvr.Cells["Price"].Value))) + Convert.ToDecimal(newTCSbox.Text)).ToString();
                    }
                }
                else
                    newBillbox.Text = "0.00";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Update Button Coding
        private void updatebtn_Click(object sender, EventArgs e)
        {
            // Confimation about update
            if (MessageBox.Show("Are you sure you want to update Bill?","Confirmation",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                // Hiding all warnings
                warning7.Hide();
                warning5.Hide();
                warning8.Hide();

                // Checking IMEI information
                int chk = 0;
                if (IMEI1.Enabled)
                {
                    if (string.IsNullOrEmpty(IMEI1.Text) || string.IsNullOrWhiteSpace(IMEI1.Text))
                    {
                        IMEI1.Focus();
                        warning5.Show();
                        chk = 1;
                    }

                    else if (IMEI1.Text == IMEI2.Text)
                    {
                        warning8.Show();
                        IMEI2.Focus();
                        chk = 1;
                    }
                }

                // checking other information
                if (chk == 0)
                {
                    if (string.IsNullOrEmpty(Quantity.Text) || string.IsNullOrWhiteSpace(Quantity.Text))
                        Quantity.Text = dgvr.Cells["QTY"].Value.ToString();

                    else if (string.IsNullOrEmpty(PurchasePrice.Text) || string.IsNullOrWhiteSpace(PurchasePrice.Text))
                        PurchasePrice.Text = dgvr.Cells["Price"].Value.ToString();

                    else if (string.IsNullOrEmpty(SellPrice.Text) || string.IsNullOrWhiteSpace(SellPrice.Text))
                        SellPrice.Text = BillData.Rows[0][3].ToString();

                    else if (string.IsNullOrEmpty(warrantybox.Text) || string.IsNullOrWhiteSpace(warrantybox.Text))
                        warrantybox.Text = dgvr.Cells["Warranty"].Value.ToString();

                    else // UPdating information history
                    {
                        // Verifying IMEI Value
                        if (IMEI1.Text != dgvr.Cells["IMEI1"].Value.ToString() || IMEI2.Text != dgvr.Cells["IMEI2"].Value.ToString())
                        {
                            if (VerifyIMEI())
                                updateDetails();
                            else
                                warning7.Show();
                        }
                        else
                        {
                            updateDetails();
                        }

                        this.Close();
                    }
                }
            }
        }

        // Purchase box Coding
        private void PurchasePrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(PurchasePrice.Text) || !string.IsNullOrWhiteSpace(PurchasePrice.Text))
                {
                    if (Convert.ToDecimal(PurchasePrice.Text) <= 0)
                    {
                        warning1.Show();
                        newBillbox.Text = "0.00";
                    }
                    else
                    {
                        warning1.Hide();
                        
                        if (string.IsNullOrWhiteSpace(newTCSbox.Text) || string.IsNullOrEmpty(newTCSbox.Text))
                            newTCSbox.Text = "0.00";

                        newBillbox.Text = (((Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(PurchasePrice.Text)) - (Convert.ToInt32(dgvr.Cells["QTY"].Value) * Convert.ToDecimal(dgvr.Cells["Price"].Value))) + Convert.ToDecimal(newTCSbox.Text)).ToString();
                    }
                }
                else
                    newBillbox.Text = "0.00";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // TCS Box Coding
        private void newTCSbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(newTCSbox.Text) || !string.IsNullOrWhiteSpace(newTCSbox.Text))
                {
                    if (string.IsNullOrEmpty(Quantity.Text)||string.IsNullOrWhiteSpace(Quantity.Text))
                        Quantity.Text = dgvr.Cells["QTY"].Value.ToString();
                    if (string.IsNullOrEmpty(PurchasePrice.Text) || string.IsNullOrWhiteSpace(PurchasePrice.Text))
                        PurchasePrice.Text = dgvr.Cells["Price"].Value.ToString();

                    newBillbox.Text = (((Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(PurchasePrice.Text)) - (Convert.ToInt32(dgvr.Cells["QTY"].Value) * Convert.ToDecimal(dgvr.Cells["Price"].Value))) + Convert.ToDecimal(newTCSbox.Text)).ToString();
                }
                else
                    newBillbox.Text = ((Convert.ToInt32(Quantity.Text) * Convert.ToDecimal(PurchasePrice.Text)) - (Convert.ToInt32(dgvr.Cells["QTY"].Value) * Convert.ToDecimal(dgvr.Cells["Price"].Value))).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
