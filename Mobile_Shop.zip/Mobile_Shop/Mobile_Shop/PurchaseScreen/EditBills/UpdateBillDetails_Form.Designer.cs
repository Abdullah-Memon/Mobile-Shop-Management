﻿namespace Mobile_Shop.PurchaseScreen.UpdateBills
{
    partial class UpdateBillDetails_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddItemsDetailsBox = new Guna.UI2.WinForms.Guna2GroupBox();
            this.returnPaymentbox = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.warrantybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.ItemState = new System.Windows.Forms.CheckBox();
            this.MobileBox = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Color = new Guna.UI2.WinForms.Guna2TextBox();
            this.warning8 = new System.Windows.Forms.Label();
            this.warning7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.IMEI2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.IMEI1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.warning5 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TotalBill = new Guna.UI2.WinForms.Guna2TextBox();
            this.Quantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.Catagorybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.newPaybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.newBillbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.newTCSbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.TotalPaid = new Guna.UI2.WinForms.Guna2TextBox();
            this.TotalTCS = new Guna.UI2.WinForms.Guna2TextBox();
            this.SellPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.PurchasePrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.Brandbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Companybox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Backbtn = new Guna.UI2.WinForms.Guna2CircleButton();
            this.updatebtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.ItemPicture = new Guna.UI2.WinForms.Guna2PictureBox();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ItemName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.PaymentTypeBox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.AddItemsDetailsBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // AddItemsDetailsBox
            // 
            this.AddItemsDetailsBox.BackColor = System.Drawing.Color.Transparent;
            this.AddItemsDetailsBox.BorderRadius = 10;
            this.AddItemsDetailsBox.Controls.Add(this.label);
            this.AddItemsDetailsBox.Controls.Add(this.PaymentTypeBox);
            this.AddItemsDetailsBox.Controls.Add(this.returnPaymentbox);
            this.AddItemsDetailsBox.Controls.Add(this.label10);
            this.AddItemsDetailsBox.Controls.Add(this.warrantybox);
            this.AddItemsDetailsBox.Controls.Add(this.ItemState);
            this.AddItemsDetailsBox.Controls.Add(this.MobileBox);
            this.AddItemsDetailsBox.Controls.Add(this.label13);
            this.AddItemsDetailsBox.Controls.Add(this.label2);
            this.AddItemsDetailsBox.Controls.Add(this.Color);
            this.AddItemsDetailsBox.Controls.Add(this.warning8);
            this.AddItemsDetailsBox.Controls.Add(this.warning7);
            this.AddItemsDetailsBox.Controls.Add(this.label12);
            this.AddItemsDetailsBox.Controls.Add(this.label9);
            this.AddItemsDetailsBox.Controls.Add(this.IMEI2);
            this.AddItemsDetailsBox.Controls.Add(this.IMEI1);
            this.AddItemsDetailsBox.Controls.Add(this.warning5);
            this.AddItemsDetailsBox.Controls.Add(this.label20);
            this.AddItemsDetailsBox.Controls.Add(this.label5);
            this.AddItemsDetailsBox.Controls.Add(this.label3);
            this.AddItemsDetailsBox.Controls.Add(this.TotalBill);
            this.AddItemsDetailsBox.Controls.Add(this.Quantity);
            this.AddItemsDetailsBox.Controls.Add(this.Catagorybox);
            this.AddItemsDetailsBox.Controls.Add(this.label7);
            this.AddItemsDetailsBox.Controls.Add(this.label17);
            this.AddItemsDetailsBox.Controls.Add(this.label16);
            this.AddItemsDetailsBox.Controls.Add(this.label23);
            this.AddItemsDetailsBox.Controls.Add(this.label15);
            this.AddItemsDetailsBox.Controls.Add(this.label18);
            this.AddItemsDetailsBox.Controls.Add(this.label6);
            this.AddItemsDetailsBox.Controls.Add(this.label4);
            this.AddItemsDetailsBox.Controls.Add(this.label1);
            this.AddItemsDetailsBox.Controls.Add(this.newPaybox);
            this.AddItemsDetailsBox.Controls.Add(this.newBillbox);
            this.AddItemsDetailsBox.Controls.Add(this.newTCSbox);
            this.AddItemsDetailsBox.Controls.Add(this.TotalPaid);
            this.AddItemsDetailsBox.Controls.Add(this.TotalTCS);
            this.AddItemsDetailsBox.Controls.Add(this.SellPrice);
            this.AddItemsDetailsBox.Controls.Add(this.PurchasePrice);
            this.AddItemsDetailsBox.Controls.Add(this.Brandbox);
            this.AddItemsDetailsBox.Controls.Add(this.Companybox);
            this.AddItemsDetailsBox.Controls.Add(this.Backbtn);
            this.AddItemsDetailsBox.Controls.Add(this.updatebtn);
            this.AddItemsDetailsBox.Controls.Add(this.ItemPicture);
            this.AddItemsDetailsBox.Controls.Add(this.warning2);
            this.AddItemsDetailsBox.Controls.Add(this.warning1);
            this.AddItemsDetailsBox.Controls.Add(this.label8);
            this.AddItemsDetailsBox.Controls.Add(this.ItemName);
            this.AddItemsDetailsBox.Controls.Add(this.label11);
            this.AddItemsDetailsBox.Controls.Add(this.label14);
            this.AddItemsDetailsBox.CustomBorderThickness = new System.Windows.Forms.Padding(0);
            this.AddItemsDetailsBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddItemsDetailsBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddItemsDetailsBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.AddItemsDetailsBox.Location = new System.Drawing.Point(10, 10);
            this.AddItemsDetailsBox.Name = "AddItemsDetailsBox";
            this.AddItemsDetailsBox.ShadowDecoration.Parent = this.AddItemsDetailsBox;
            this.AddItemsDetailsBox.Size = new System.Drawing.Size(652, 747);
            this.AddItemsDetailsBox.TabIndex = 2;
            // 
            // returnPaymentbox
            // 
            this.returnPaymentbox.AutoSize = true;
            this.returnPaymentbox.Location = new System.Drawing.Point(489, 642);
            this.returnPaymentbox.Name = "returnPaymentbox";
            this.returnPaymentbox.Size = new System.Drawing.Size(127, 23);
            this.returnPaymentbox.TabIndex = 34;
            this.returnPaymentbox.Text = "Return Payment";
            this.returnPaymentbox.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Indigo;
            this.label10.Location = new System.Drawing.Point(421, 382);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 19);
            this.label10.TabIndex = 32;
            this.label10.Text = "Warranty";
            // 
            // warrantybox
            // 
            this.warrantybox.BorderRadius = 10;
            this.warrantybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.warrantybox.DefaultText = "";
            this.warrantybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.warrantybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.warrantybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.warrantybox.DisabledState.Parent = this.warrantybox;
            this.warrantybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.warrantybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.warrantybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.warrantybox.FocusedState.Parent = this.warrantybox;
            this.warrantybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.warrantybox.HoverState.Parent = this.warrantybox;
            this.warrantybox.Location = new System.Drawing.Point(420, 401);
            this.warrantybox.Margin = new System.Windows.Forms.Padding(3, 27, 3, 27);
            this.warrantybox.Name = "warrantybox";
            this.warrantybox.PasswordChar = '\0';
            this.warrantybox.PlaceholderText = "";
            this.warrantybox.SelectedText = "";
            this.warrantybox.ShadowDecoration.Parent = this.warrantybox;
            this.warrantybox.Size = new System.Drawing.Size(199, 37);
            this.warrantybox.TabIndex = 6;
            this.warrantybox.Tag = "info";
            // 
            // ItemState
            // 
            this.ItemState.AutoSize = true;
            this.ItemState.Checked = true;
            this.ItemState.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ItemState.Location = new System.Drawing.Point(13, 678);
            this.ItemState.Name = "ItemState";
            this.ItemState.Size = new System.Drawing.Size(284, 23);
            this.ItemState.TabIndex = 7;
            this.ItemState.Text = "Following Product Is a Brand new product";
            this.ItemState.UseVisualStyleBackColor = true;
            // 
            // MobileBox
            // 
            this.MobileBox.AutoSize = true;
            this.MobileBox.Checked = true;
            this.MobileBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MobileBox.Location = new System.Drawing.Point(13, 651);
            this.MobileBox.Name = "MobileBox";
            this.MobileBox.Size = new System.Drawing.Size(278, 23);
            this.MobileBox.TabIndex = 7;
            this.MobileBox.Text = "Following product Comes along with Box";
            this.MobileBox.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Silver;
            this.label13.Location = new System.Drawing.Point(8, 277);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(627, 19);
            this.label13.TabIndex = 28;
            this.label13.Text = "_________________________________________________________________________________" +
    "______________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(421, 306);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 19);
            this.label2.TabIndex = 28;
            this.label2.Text = "Color";
            // 
            // Color
            // 
            this.Color.BorderRadius = 10;
            this.Color.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Color.DefaultText = "";
            this.Color.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Color.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Color.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Color.DisabledState.Parent = this.Color;
            this.Color.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Color.Enabled = false;
            this.Color.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Color.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Color.FocusedState.Parent = this.Color;
            this.Color.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Color.HoverState.Parent = this.Color;
            this.Color.Location = new System.Drawing.Point(420, 333);
            this.Color.Margin = new System.Windows.Forms.Padding(3, 21, 3, 21);
            this.Color.Name = "Color";
            this.Color.PasswordChar = '\0';
            this.Color.PlaceholderText = "";
            this.Color.SelectedText = "";
            this.Color.ShadowDecoration.Parent = this.Color;
            this.Color.Size = new System.Drawing.Size(199, 37);
            this.Color.TabIndex = 3;
            this.Color.Tag = "info";
            // 
            // warning8
            // 
            this.warning8.AutoSize = true;
            this.warning8.ForeColor = System.Drawing.Color.Red;
            this.warning8.Location = new System.Drawing.Point(254, 442);
            this.warning8.Name = "warning8";
            this.warning8.Size = new System.Drawing.Size(138, 19);
            this.warning8.TabIndex = 27;
            this.warning8.Text = "* IMEI Can\'t be same";
            // 
            // warning7
            // 
            this.warning7.AutoSize = true;
            this.warning7.ForeColor = System.Drawing.Color.Red;
            this.warning7.Location = new System.Drawing.Point(16, 442);
            this.warning7.Name = "warning7";
            this.warning7.Size = new System.Drawing.Size(160, 19);
            this.warning7.TabIndex = 27;
            this.warning7.Text = "* This IMEI already exists";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Indigo;
            this.label12.Location = new System.Drawing.Point(16, 382);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 19);
            this.label12.TabIndex = 25;
            this.label12.Text = "Enter IMEI-2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Indigo;
            this.label9.Location = new System.Drawing.Point(16, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 19);
            this.label9.TabIndex = 25;
            this.label9.Text = "Enter IMEI-1";
            // 
            // IMEI2
            // 
            this.IMEI2.BorderRadius = 10;
            this.IMEI2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IMEI2.DefaultText = "";
            this.IMEI2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.IMEI2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.IMEI2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI2.DisabledState.Parent = this.IMEI2;
            this.IMEI2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI2.FillColor = System.Drawing.Color.WhiteSmoke;
            this.IMEI2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI2.FocusedState.Parent = this.IMEI2;
            this.IMEI2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI2.HoverState.Parent = this.IMEI2;
            this.IMEI2.Location = new System.Drawing.Point(14, 401);
            this.IMEI2.Margin = new System.Windows.Forms.Padding(3, 46, 3, 46);
            this.IMEI2.Name = "IMEI2";
            this.IMEI2.PasswordChar = '\0';
            this.IMEI2.PlaceholderText = "";
            this.IMEI2.SelectedText = "";
            this.IMEI2.ShadowDecoration.Parent = this.IMEI2;
            this.IMEI2.Size = new System.Drawing.Size(372, 37);
            this.IMEI2.TabIndex = 5;
            this.IMEI2.Tag = "info";
            // 
            // IMEI1
            // 
            this.IMEI1.BorderRadius = 10;
            this.IMEI1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IMEI1.DefaultText = "";
            this.IMEI1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.IMEI1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.IMEI1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI1.DisabledState.Parent = this.IMEI1;
            this.IMEI1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.IMEI1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.IMEI1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI1.FocusedState.Parent = this.IMEI1;
            this.IMEI1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.IMEI1.HoverState.Parent = this.IMEI1;
            this.IMEI1.Location = new System.Drawing.Point(14, 331);
            this.IMEI1.Margin = new System.Windows.Forms.Padding(3, 35, 3, 35);
            this.IMEI1.Name = "IMEI1";
            this.IMEI1.PasswordChar = '\0';
            this.IMEI1.PlaceholderText = "";
            this.IMEI1.SelectedText = "";
            this.IMEI1.ShadowDecoration.Parent = this.IMEI1;
            this.IMEI1.Size = new System.Drawing.Size(372, 37);
            this.IMEI1.TabIndex = 4;
            this.IMEI1.Tag = "info";
            // 
            // warning5
            // 
            this.warning5.AutoSize = true;
            this.warning5.ForeColor = System.Drawing.Color.Red;
            this.warning5.Location = new System.Drawing.Point(283, 306);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(103, 19);
            this.warning5.TabIndex = 24;
            this.warning5.Text = "* Invalid IMEI 1";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Indigo;
            this.label20.Location = new System.Drawing.Point(24, 529);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 19);
            this.label20.TabIndex = 22;
            this.label20.Text = "Total Bill";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Indigo;
            this.label5.Location = new System.Drawing.Point(18, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Indigo;
            this.label3.Location = new System.Drawing.Point(428, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 22;
            this.label3.Text = "Catagory";
            // 
            // TotalBill
            // 
            this.TotalBill.BorderRadius = 10;
            this.TotalBill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TotalBill.DefaultText = "0.00";
            this.TotalBill.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TotalBill.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TotalBill.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalBill.DisabledState.Parent = this.TotalBill;
            this.TotalBill.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalBill.Enabled = false;
            this.TotalBill.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TotalBill.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalBill.FocusedState.Parent = this.TotalBill;
            this.TotalBill.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalBill.HoverState.Parent = this.TotalBill;
            this.TotalBill.Location = new System.Drawing.Point(96, 525);
            this.TotalBill.Margin = new System.Windows.Forms.Padding(3, 21, 3, 21);
            this.TotalBill.Name = "TotalBill";
            this.TotalBill.PasswordChar = '\0';
            this.TotalBill.PlaceholderText = "";
            this.TotalBill.SelectedText = "";
            this.TotalBill.SelectionStart = 4;
            this.TotalBill.ShadowDecoration.Parent = this.TotalBill;
            this.TotalBill.Size = new System.Drawing.Size(140, 37);
            this.TotalBill.TabIndex = 0;
            this.TotalBill.Tag = "info";
            this.TotalBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Quantity
            // 
            this.Quantity.BorderRadius = 10;
            this.Quantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Quantity.DefaultText = "0.00";
            this.Quantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Quantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Quantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Quantity.DisabledState.Parent = this.Quantity;
            this.Quantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Quantity.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Quantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Quantity.FocusedState.Parent = this.Quantity;
            this.Quantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Quantity.HoverState.Parent = this.Quantity;
            this.Quantity.Location = new System.Drawing.Point(14, 218);
            this.Quantity.Margin = new System.Windows.Forms.Padding(3, 16, 3, 16);
            this.Quantity.Name = "Quantity";
            this.Quantity.PasswordChar = '\0';
            this.Quantity.PlaceholderText = "";
            this.Quantity.SelectedText = "";
            this.Quantity.SelectionStart = 4;
            this.Quantity.ShadowDecoration.Parent = this.Quantity;
            this.Quantity.Size = new System.Drawing.Size(150, 37);
            this.Quantity.TabIndex = 0;
            this.Quantity.Tag = "info";
            this.Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Quantity.TextChanged += new System.EventHandler(this.Quantity_TextChanged);
            // 
            // Catagorybox
            // 
            this.Catagorybox.BorderRadius = 10;
            this.Catagorybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Catagorybox.DefaultText = "";
            this.Catagorybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Catagorybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Catagorybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Catagorybox.DisabledState.Parent = this.Catagorybox;
            this.Catagorybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Catagorybox.Enabled = false;
            this.Catagorybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Catagorybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Catagorybox.FocusedState.Parent = this.Catagorybox;
            this.Catagorybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Catagorybox.HoverState.Parent = this.Catagorybox;
            this.Catagorybox.Location = new System.Drawing.Point(422, 56);
            this.Catagorybox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.Catagorybox.Name = "Catagorybox";
            this.Catagorybox.PasswordChar = '\0';
            this.Catagorybox.PlaceholderText = "";
            this.Catagorybox.SelectedText = "";
            this.Catagorybox.ShadowDecoration.Parent = this.Catagorybox;
            this.Catagorybox.Size = new System.Drawing.Size(199, 37);
            this.Catagorybox.TabIndex = 23;
            this.Catagorybox.Tag = "info";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Indigo;
            this.label7.Location = new System.Drawing.Point(416, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 19);
            this.label7.TabIndex = 20;
            this.label7.Text = "Sell Price";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Indigo;
            this.label17.Location = new System.Drawing.Point(410, 605);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 19);
            this.label17.TabIndex = 20;
            this.label17.Text = "Payment";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Indigo;
            this.label16.Location = new System.Drawing.Point(410, 558);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 19);
            this.label16.TabIndex = 20;
            this.label16.Text = "New Bill";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Indigo;
            this.label23.Location = new System.Drawing.Point(410, 522);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 19);
            this.label23.TabIndex = 20;
            this.label23.Text = "TCS";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Indigo;
            this.label15.Location = new System.Drawing.Point(18, 574);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 19);
            this.label15.TabIndex = 20;
            this.label15.Text = "Total Paid";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Indigo;
            this.label18.Location = new System.Drawing.Point(24, 493);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 19);
            this.label18.TabIndex = 20;
            this.label18.Text = "Total TCS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Indigo;
            this.label6.Location = new System.Drawing.Point(189, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 19);
            this.label6.TabIndex = 20;
            this.label6.Text = "Purchase Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Indigo;
            this.label4.Location = new System.Drawing.Point(191, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Brand";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(418, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 19);
            this.label1.TabIndex = 20;
            this.label1.Text = "Company";
            // 
            // newPaybox
            // 
            this.newPaybox.BorderRadius = 10;
            this.newPaybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newPaybox.DefaultText = "0.00";
            this.newPaybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newPaybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newPaybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newPaybox.DisabledState.Parent = this.newPaybox;
            this.newPaybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newPaybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newPaybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newPaybox.FocusedState.Parent = this.newPaybox;
            this.newPaybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newPaybox.HoverState.Parent = this.newPaybox;
            this.newPaybox.Location = new System.Drawing.Point(479, 594);
            this.newPaybox.Margin = new System.Windows.Forms.Padding(3, 35, 3, 35);
            this.newPaybox.Name = "newPaybox";
            this.newPaybox.PasswordChar = '\0';
            this.newPaybox.PlaceholderText = "";
            this.newPaybox.SelectedText = "";
            this.newPaybox.SelectionStart = 4;
            this.newPaybox.ShadowDecoration.Parent = this.newPaybox;
            this.newPaybox.Size = new System.Drawing.Size(140, 37);
            this.newPaybox.TabIndex = 1;
            this.newPaybox.Tag = "info";
            this.newPaybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // newBillbox
            // 
            this.newBillbox.BorderRadius = 10;
            this.newBillbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newBillbox.DefaultText = "0.00";
            this.newBillbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newBillbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newBillbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newBillbox.DisabledState.Parent = this.newBillbox;
            this.newBillbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newBillbox.Enabled = false;
            this.newBillbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newBillbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newBillbox.FocusedState.Parent = this.newBillbox;
            this.newBillbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newBillbox.HoverState.Parent = this.newBillbox;
            this.newBillbox.Location = new System.Drawing.Point(479, 553);
            this.newBillbox.Margin = new System.Windows.Forms.Padding(3, 46, 3, 46);
            this.newBillbox.Name = "newBillbox";
            this.newBillbox.PasswordChar = '\0';
            this.newBillbox.PlaceholderText = "";
            this.newBillbox.SelectedText = "";
            this.newBillbox.SelectionStart = 4;
            this.newBillbox.ShadowDecoration.Parent = this.newBillbox;
            this.newBillbox.Size = new System.Drawing.Size(140, 37);
            this.newBillbox.TabIndex = 1;
            this.newBillbox.Tag = "info";
            this.newBillbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // newTCSbox
            // 
            this.newTCSbox.BorderRadius = 10;
            this.newTCSbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newTCSbox.DefaultText = "0.00";
            this.newTCSbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.newTCSbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.newTCSbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newTCSbox.DisabledState.Parent = this.newTCSbox;
            this.newTCSbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.newTCSbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.newTCSbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newTCSbox.FocusedState.Parent = this.newTCSbox;
            this.newTCSbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.newTCSbox.HoverState.Parent = this.newTCSbox;
            this.newTCSbox.Location = new System.Drawing.Point(479, 511);
            this.newTCSbox.Margin = new System.Windows.Forms.Padding(3, 35, 3, 35);
            this.newTCSbox.Name = "newTCSbox";
            this.newTCSbox.PasswordChar = '\0';
            this.newTCSbox.PlaceholderText = "";
            this.newTCSbox.SelectedText = "";
            this.newTCSbox.SelectionStart = 4;
            this.newTCSbox.ShadowDecoration.Parent = this.newTCSbox;
            this.newTCSbox.Size = new System.Drawing.Size(140, 37);
            this.newTCSbox.TabIndex = 1;
            this.newTCSbox.Tag = "info";
            this.newTCSbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.newTCSbox.TextChanged += new System.EventHandler(this.newTCSbox_TextChanged);
            // 
            // TotalPaid
            // 
            this.TotalPaid.BorderRadius = 10;
            this.TotalPaid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TotalPaid.DefaultText = "0.00";
            this.TotalPaid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TotalPaid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TotalPaid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalPaid.DisabledState.Parent = this.TotalPaid;
            this.TotalPaid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalPaid.Enabled = false;
            this.TotalPaid.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TotalPaid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalPaid.FocusedState.Parent = this.TotalPaid;
            this.TotalPaid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalPaid.HoverState.Parent = this.TotalPaid;
            this.TotalPaid.Location = new System.Drawing.Point(96, 567);
            this.TotalPaid.Margin = new System.Windows.Forms.Padding(3, 35, 3, 35);
            this.TotalPaid.Name = "TotalPaid";
            this.TotalPaid.PasswordChar = '\0';
            this.TotalPaid.PlaceholderText = "";
            this.TotalPaid.SelectedText = "";
            this.TotalPaid.SelectionStart = 4;
            this.TotalPaid.ShadowDecoration.Parent = this.TotalPaid;
            this.TotalPaid.Size = new System.Drawing.Size(140, 39);
            this.TotalPaid.TabIndex = 1;
            this.TotalPaid.Tag = "info";
            this.TotalPaid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TotalTCS
            // 
            this.TotalTCS.BorderRadius = 10;
            this.TotalTCS.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TotalTCS.DefaultText = "0.00";
            this.TotalTCS.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TotalTCS.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TotalTCS.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalTCS.DisabledState.Parent = this.TotalTCS;
            this.TotalTCS.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TotalTCS.Enabled = false;
            this.TotalTCS.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TotalTCS.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalTCS.FocusedState.Parent = this.TotalTCS;
            this.TotalTCS.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TotalTCS.HoverState.Parent = this.TotalTCS;
            this.TotalTCS.Location = new System.Drawing.Point(96, 484);
            this.TotalTCS.Margin = new System.Windows.Forms.Padding(3, 27, 3, 27);
            this.TotalTCS.Name = "TotalTCS";
            this.TotalTCS.PasswordChar = '\0';
            this.TotalTCS.PlaceholderText = "";
            this.TotalTCS.SelectedText = "";
            this.TotalTCS.SelectionStart = 4;
            this.TotalTCS.ShadowDecoration.Parent = this.TotalTCS;
            this.TotalTCS.Size = new System.Drawing.Size(140, 37);
            this.TotalTCS.TabIndex = 1;
            this.TotalTCS.Tag = "info";
            this.TotalTCS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SellPrice
            // 
            this.SellPrice.BorderRadius = 10;
            this.SellPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SellPrice.DefaultText = "0.00";
            this.SellPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SellPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SellPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SellPrice.DisabledState.Parent = this.SellPrice;
            this.SellPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SellPrice.FillColor = System.Drawing.Color.WhiteSmoke;
            this.SellPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellPrice.FocusedState.Parent = this.SellPrice;
            this.SellPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SellPrice.HoverState.Parent = this.SellPrice;
            this.SellPrice.Location = new System.Drawing.Point(420, 218);
            this.SellPrice.Margin = new System.Windows.Forms.Padding(3, 27, 3, 27);
            this.SellPrice.Name = "SellPrice";
            this.SellPrice.PasswordChar = '\0';
            this.SellPrice.PlaceholderText = "";
            this.SellPrice.SelectedText = "";
            this.SellPrice.SelectionStart = 4;
            this.SellPrice.ShadowDecoration.Parent = this.SellPrice;
            this.SellPrice.Size = new System.Drawing.Size(199, 37);
            this.SellPrice.TabIndex = 2;
            this.SellPrice.Tag = "info";
            this.SellPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PurchasePrice
            // 
            this.PurchasePrice.BorderRadius = 10;
            this.PurchasePrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PurchasePrice.DefaultText = "0.00";
            this.PurchasePrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PurchasePrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PurchasePrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PurchasePrice.DisabledState.Parent = this.PurchasePrice;
            this.PurchasePrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PurchasePrice.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PurchasePrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PurchasePrice.FocusedState.Parent = this.PurchasePrice;
            this.PurchasePrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PurchasePrice.HoverState.Parent = this.PurchasePrice;
            this.PurchasePrice.Location = new System.Drawing.Point(192, 218);
            this.PurchasePrice.Margin = new System.Windows.Forms.Padding(3, 21, 3, 21);
            this.PurchasePrice.Name = "PurchasePrice";
            this.PurchasePrice.PasswordChar = '\0';
            this.PurchasePrice.PlaceholderText = "";
            this.PurchasePrice.SelectedText = "";
            this.PurchasePrice.SelectionStart = 4;
            this.PurchasePrice.ShadowDecoration.Parent = this.PurchasePrice;
            this.PurchasePrice.Size = new System.Drawing.Size(199, 37);
            this.PurchasePrice.TabIndex = 1;
            this.PurchasePrice.Tag = "info";
            this.PurchasePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PurchasePrice.TextChanged += new System.EventHandler(this.PurchasePrice_TextChanged);
            // 
            // Brandbox
            // 
            this.Brandbox.BorderRadius = 10;
            this.Brandbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Brandbox.DefaultText = "";
            this.Brandbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Brandbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Brandbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.DisabledState.Parent = this.Brandbox;
            this.Brandbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Brandbox.Enabled = false;
            this.Brandbox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Brandbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.FocusedState.Parent = this.Brandbox;
            this.Brandbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Brandbox.HoverState.Parent = this.Brandbox;
            this.Brandbox.Location = new System.Drawing.Point(195, 126);
            this.Brandbox.Margin = new System.Windows.Forms.Padding(3, 16, 3, 16);
            this.Brandbox.Name = "Brandbox";
            this.Brandbox.PasswordChar = '\0';
            this.Brandbox.PlaceholderText = "";
            this.Brandbox.SelectedText = "";
            this.Brandbox.ShadowDecoration.Parent = this.Brandbox;
            this.Brandbox.Size = new System.Drawing.Size(199, 37);
            this.Brandbox.TabIndex = 21;
            this.Brandbox.Tag = "info";
            // 
            // Companybox
            // 
            this.Companybox.BorderRadius = 10;
            this.Companybox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Companybox.DefaultText = "";
            this.Companybox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Companybox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Companybox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Companybox.DisabledState.Parent = this.Companybox;
            this.Companybox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Companybox.Enabled = false;
            this.Companybox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.Companybox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Companybox.FocusedState.Parent = this.Companybox;
            this.Companybox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Companybox.HoverState.Parent = this.Companybox;
            this.Companybox.Location = new System.Drawing.Point(422, 126);
            this.Companybox.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.Companybox.Name = "Companybox";
            this.Companybox.PasswordChar = '\0';
            this.Companybox.PlaceholderText = "";
            this.Companybox.SelectedText = "";
            this.Companybox.ShadowDecoration.Parent = this.Companybox;
            this.Companybox.Size = new System.Drawing.Size(199, 37);
            this.Companybox.TabIndex = 21;
            this.Companybox.Tag = "info";
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.Transparent;
            this.Backbtn.CheckedState.Parent = this.Backbtn;
            this.Backbtn.CustomImages.Parent = this.Backbtn;
            this.Backbtn.FillColor = System.Drawing.Color.Indigo;
            this.Backbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Backbtn.ForeColor = System.Drawing.Color.White;
            this.Backbtn.HoverState.Parent = this.Backbtn;
            this.Backbtn.Location = new System.Drawing.Point(600, 6);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Backbtn.ShadowDecoration.Parent = this.Backbtn;
            this.Backbtn.Size = new System.Drawing.Size(35, 35);
            this.Backbtn.TabIndex = 19;
            this.Backbtn.Text = "X";
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.BackColor = System.Drawing.Color.Transparent;
            this.updatebtn.BorderColor = System.Drawing.Color.White;
            this.updatebtn.BorderRadius = 10;
            this.updatebtn.BorderThickness = 2;
            this.updatebtn.CheckedState.Parent = this.updatebtn;
            this.updatebtn.CustomImages.Parent = this.updatebtn;
            this.updatebtn.FillColor = System.Drawing.Color.Indigo;
            this.updatebtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.updatebtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.updatebtn.ForeColor = System.Drawing.Color.White;
            this.updatebtn.HoverState.Parent = this.updatebtn;
            this.updatebtn.Location = new System.Drawing.Point(484, 678);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.ShadowDecoration.Parent = this.updatebtn;
            this.updatebtn.Size = new System.Drawing.Size(137, 50);
            this.updatebtn.TabIndex = 8;
            this.updatebtn.Text = "Update";
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // ItemPicture
            // 
            this.ItemPicture.BorderRadius = 10;
            this.ItemPicture.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ItemPicture.Location = new System.Drawing.Point(14, 13);
            this.ItemPicture.Name = "ItemPicture";
            this.ItemPicture.ShadowDecoration.Parent = this.ItemPicture;
            this.ItemPicture.Size = new System.Drawing.Size(150, 150);
            this.ItemPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ItemPicture.TabIndex = 4;
            this.ItemPicture.TabStop = false;
            // 
            // warning2
            // 
            this.warning2.AutoSize = true;
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(207, 259);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(151, 19);
            this.warning2.TabIndex = 1;
            this.warning2.Text = "* Invalid Purchase Price";
            // 
            // warning1
            // 
            this.warning1.AutoSize = true;
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(18, 259);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(117, 19);
            this.warning1.TabIndex = 1;
            this.warning1.Text = "* Invalid Quantity";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Indigo;
            this.label8.Location = new System.Drawing.Point(191, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Item Name";
            // 
            // ItemName
            // 
            this.ItemName.BorderRadius = 10;
            this.ItemName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ItemName.DefaultText = "";
            this.ItemName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ItemName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ItemName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ItemName.DisabledState.Parent = this.ItemName;
            this.ItemName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ItemName.Enabled = false;
            this.ItemName.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ItemName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ItemName.FocusedState.Parent = this.ItemName;
            this.ItemName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ItemName.HoverState.Parent = this.ItemName;
            this.ItemName.Location = new System.Drawing.Point(195, 56);
            this.ItemName.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.ItemName.Name = "ItemName";
            this.ItemName.PasswordChar = '\0';
            this.ItemName.PlaceholderText = "";
            this.ItemName.SelectedText = "";
            this.ItemName.ShadowDecoration.Parent = this.ItemName;
            this.ItemName.Size = new System.Drawing.Size(199, 37);
            this.ItemName.TabIndex = 1;
            this.ItemName.Tag = "info";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Silver;
            this.label11.Location = new System.Drawing.Point(3, 163);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(627, 19);
            this.label11.TabIndex = 28;
            this.label11.Text = "_________________________________________________________________________________" +
    "______________________";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Silver;
            this.label14.Location = new System.Drawing.Point(9, 450);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(627, 19);
            this.label14.TabIndex = 33;
            this.label14.Text = "_________________________________________________________________________________" +
    "______________________";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Font = new System.Drawing.Font("Arial Narrow", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Indigo;
            this.label.Location = new System.Drawing.Point(320, 484);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(95, 20);
            this.label.TabIndex = 36;
            this.label.Text = "Payment Type";
            // 
            // PaymentTypeBox
            // 
            this.PaymentTypeBox.BackColor = System.Drawing.Color.Transparent;
            this.PaymentTypeBox.BorderRadius = 10;
            this.PaymentTypeBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.PaymentTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypeBox.FillColor = System.Drawing.Color.WhiteSmoke;
            this.PaymentTypeBox.FocusedColor = System.Drawing.Color.Empty;
            this.PaymentTypeBox.FocusedState.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PaymentTypeBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.PaymentTypeBox.FormattingEnabled = true;
            this.PaymentTypeBox.HoverState.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.ItemHeight = 30;
            this.PaymentTypeBox.ItemsAppearance.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Location = new System.Drawing.Point(421, 472);
            this.PaymentTypeBox.Name = "PaymentTypeBox";
            this.PaymentTypeBox.ShadowDecoration.Parent = this.PaymentTypeBox;
            this.PaymentTypeBox.Size = new System.Drawing.Size(198, 36);
            this.PaymentTypeBox.TabIndex = 37;
            // 
            // UpdateBillDetails_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(672, 767);
            this.ControlBox = false;
            this.Controls.Add(this.AddItemsDetailsBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "UpdateBillDetails_Form";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.UpdateBillDetails_Form_Load);
            this.AddItemsDetailsBox.ResumeLayout(false);
            this.AddItemsDetailsBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox AddItemsDetailsBox;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2TextBox warrantybox;
        private System.Windows.Forms.CheckBox ItemState;
        private System.Windows.Forms.CheckBox MobileBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox Color;
        private System.Windows.Forms.Label warning8;
        private System.Windows.Forms.Label warning7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox IMEI2;
        private Guna.UI2.WinForms.Guna2TextBox IMEI1;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox Quantity;
        private Guna.UI2.WinForms.Guna2TextBox Catagorybox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox SellPrice;
        private Guna.UI2.WinForms.Guna2TextBox PurchasePrice;
        private Guna.UI2.WinForms.Guna2TextBox Brandbox;
        private Guna.UI2.WinForms.Guna2TextBox Companybox;
        private Guna.UI2.WinForms.Guna2CircleButton Backbtn;
        private Guna.UI2.WinForms.Guna2GradientButton updatebtn;
        private Guna.UI2.WinForms.Guna2PictureBox ItemPicture;
        private System.Windows.Forms.Label warning2;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox ItemName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label20;
        private Guna.UI2.WinForms.Guna2TextBox TotalBill;
        private System.Windows.Forms.Label label18;
        private Guna.UI2.WinForms.Guna2TextBox TotalTCS;
        private Guna.UI2.WinForms.Guna2TextBox newPaybox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label23;
        private Guna.UI2.WinForms.Guna2TextBox newTCSbox;
        private System.Windows.Forms.Label label15;
        private Guna.UI2.WinForms.Guna2TextBox TotalPaid;
        private System.Windows.Forms.Label label16;
        private Guna.UI2.WinForms.Guna2TextBox newBillbox;
        private System.Windows.Forms.CheckBox returnPaymentbox;
        private System.Windows.Forms.Label label;
        private Guna.UI2.WinForms.Guna2ComboBox PaymentTypeBox;
    }
}