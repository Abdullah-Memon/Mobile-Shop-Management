﻿namespace Mobile_Shop.PurchaseScreen.EditBills
{
    partial class UpdatePayment_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.Pricebox = new Guna.UI2.WinForms.Guna2TextBox();
            this.remainingbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.returnbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.inoviceSearchbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.Controls.Add(this.Pricebox);
            this.guna2GradientPanel1.Controls.Add(this.remainingbox);
            this.guna2GradientPanel1.Controls.Add(this.returnbox);
            this.guna2GradientPanel1.Controls.Add(this.label2);
            this.guna2GradientPanel1.Controls.Add(this.label1);
            this.guna2GradientPanel1.Controls.Add(this.label4);
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientButton1);
            this.guna2GradientPanel1.Controls.Add(this.inoviceSearchbtn);
            this.guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(10, 10);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(285, 222);
            this.guna2GradientPanel1.TabIndex = 0;
            // 
            // Pricebox
            // 
            this.Pricebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pricebox.DefaultText = "";
            this.Pricebox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Pricebox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Pricebox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pricebox.DisabledState.Parent = this.Pricebox;
            this.Pricebox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Pricebox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pricebox.FocusedState.Parent = this.Pricebox;
            this.Pricebox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Pricebox.HoverState.Parent = this.Pricebox;
            this.Pricebox.Location = new System.Drawing.Point(121, 22);
            this.Pricebox.Name = "Pricebox";
            this.Pricebox.PasswordChar = '\0';
            this.Pricebox.PlaceholderText = "";
            this.Pricebox.ReadOnly = true;
            this.Pricebox.SelectedText = "";
            this.Pricebox.ShadowDecoration.Parent = this.Pricebox;
            this.Pricebox.Size = new System.Drawing.Size(143, 36);
            this.Pricebox.TabIndex = 45;
            // 
            // remainingbox
            // 
            this.remainingbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.remainingbox.DefaultText = "";
            this.remainingbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.remainingbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.remainingbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.remainingbox.DisabledState.Parent = this.remainingbox;
            this.remainingbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.remainingbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.remainingbox.FocusedState.Parent = this.remainingbox;
            this.remainingbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.remainingbox.HoverState.Parent = this.remainingbox;
            this.remainingbox.Location = new System.Drawing.Point(121, 106);
            this.remainingbox.Name = "remainingbox";
            this.remainingbox.PasswordChar = '\0';
            this.remainingbox.PlaceholderText = "";
            this.remainingbox.ReadOnly = true;
            this.remainingbox.SelectedText = "";
            this.remainingbox.ShadowDecoration.Parent = this.remainingbox;
            this.remainingbox.Size = new System.Drawing.Size(143, 36);
            this.remainingbox.TabIndex = 45;
            // 
            // returnbox
            // 
            this.returnbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.returnbox.DefaultText = "";
            this.returnbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.returnbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.returnbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.returnbox.DisabledState.Parent = this.returnbox;
            this.returnbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.returnbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.returnbox.FocusedState.Parent = this.returnbox;
            this.returnbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.returnbox.HoverState.Parent = this.returnbox;
            this.returnbox.Location = new System.Drawing.Point(121, 64);
            this.returnbox.Name = "returnbox";
            this.returnbox.PasswordChar = '\0';
            this.returnbox.PlaceholderText = "";
            this.returnbox.SelectedText = "";
            this.returnbox.ShadowDecoration.Parent = this.returnbox;
            this.returnbox.Size = new System.Drawing.Size(143, 36);
            this.returnbox.TabIndex = 45;
            this.returnbox.TextChanged += new System.EventHandler(this.returnbox_TextChanged);
            this.returnbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.returnbox_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 15);
            this.label2.TabIndex = 44;
            this.label2.Text = "Remainig";
            this.label2.Click += new System.EventHandler(this.label4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 15);
            this.label1.TabIndex = 44;
            this.label1.Text = "Product Price";
            this.label1.Click += new System.EventHandler(this.label4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 15);
            this.label4.TabIndex = 44;
            this.label4.Text = "Returned Price";
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientButton1.BorderRadius = 10;
            this.guna2GradientButton1.BorderThickness = 2;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Indigo;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(16, 172);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(99, 36);
            this.guna2GradientButton1.TabIndex = 43;
            this.guna2GradientButton1.Text = "Cancel";
            this.guna2GradientButton1.Click += new System.EventHandler(this.inoviceSearchbtn_Click);
            // 
            // inoviceSearchbtn
            // 
            this.inoviceSearchbtn.BackColor = System.Drawing.Color.Transparent;
            this.inoviceSearchbtn.BorderColor = System.Drawing.Color.White;
            this.inoviceSearchbtn.BorderRadius = 10;
            this.inoviceSearchbtn.BorderThickness = 2;
            this.inoviceSearchbtn.CheckedState.Parent = this.inoviceSearchbtn;
            this.inoviceSearchbtn.CustomImages.Parent = this.inoviceSearchbtn;
            this.inoviceSearchbtn.FillColor = System.Drawing.Color.Indigo;
            this.inoviceSearchbtn.FillColor2 = System.Drawing.Color.DarkOrchid;
            this.inoviceSearchbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.inoviceSearchbtn.ForeColor = System.Drawing.Color.White;
            this.inoviceSearchbtn.HoverState.Parent = this.inoviceSearchbtn;
            this.inoviceSearchbtn.Location = new System.Drawing.Point(165, 172);
            this.inoviceSearchbtn.Name = "inoviceSearchbtn";
            this.inoviceSearchbtn.ShadowDecoration.Parent = this.inoviceSearchbtn;
            this.inoviceSearchbtn.Size = new System.Drawing.Size(99, 36);
            this.inoviceSearchbtn.TabIndex = 43;
            this.inoviceSearchbtn.Text = "Delete";
            this.inoviceSearchbtn.Click += new System.EventHandler(this.returnbtn_Click);
            // 
            // UpdatePayment_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(305, 242);
            this.Controls.Add(this.guna2GradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UpdatePayment_Form";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdatePayment_Form";
            this.Load += new System.EventHandler(this.UpdatePayment_Form_Load);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2TextBox returnbox;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2GradientButton inoviceSearchbtn;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2TextBox Pricebox;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox remainingbox;
        private System.Windows.Forms.Label label2;
    }
}