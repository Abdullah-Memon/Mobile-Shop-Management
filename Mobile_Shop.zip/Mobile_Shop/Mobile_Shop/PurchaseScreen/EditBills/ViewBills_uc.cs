﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Mobile_Shop.PurchaseScreen.UpdateBills;

namespace Mobile_Shop.PurchaseScreen.EditBills
{
    public partial class ViewBills_uc : UserControl
    {
        public ViewBills_uc()
        {
            InitializeComponent();
        }
        // global variables
        SqlCommand cmd;

        // get all bills
        private void GetBills()
        {
            try
            {
                if(DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                cmd = new SqlCommand("EditBill", DB.con) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));

                dt.Load(cmd.ExecuteReader());

                DB.con.Close();

                GridView.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Main Load function
        private void ViewBills_uc_Load(object sender, EventArgs e)
        {
            invoicebox.Text = string.Empty;
        }

        // Search bills button coding
        private void inoviceSearchbtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(invoicebox.Text) || !string.IsNullOrWhiteSpace(invoicebox.Text))
                GetBills();
            else
                invoicebox.Focus();
        }

        // Back button coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.pd);
        }

        // Grid view button coding
        private void GridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Update Bills Button coding
            if (e.ColumnIndex == 0)
            {
                DataGridViewRow dgvr = GridView.CurrentRow;

                UpdateBillDetails_Form ubdf = new UpdateBillDetails_Form(dgvr);
                ubdf.ShowDialog();

                // Refresh List
                GetBills();
            }
            // Delete Bills Button Coding
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Are you sure you want to delete Purchasement; It may affect the stock!", "Confimation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    decimal p = Convert.ToDecimal(GridView.Rows[e.RowIndex].Cells["Price"].Value) * Convert.ToInt32(GridView.Rows[e.RowIndex].Cells["Qty"].Value);

                    UpdatePayment_Form upf = new UpdatePayment_Form(p);
                    upf.ShowDialog();

                    if (UpdatePayment_Form.status > 0)
                    {
                        try
                        {
                            if (DB.con.State == ConnectionState.Closed)
                                DB.con.Open();

                            // deleting product
                            cmd = new SqlCommand("EditBill", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@data", 1));
                            cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));
                            cmd.Parameters.Add(new SqlParameter("@itemid", GridView.Rows[e.RowIndex].Cells["ID"].Value));
                            cmd.Parameters.Add(new SqlParameter("@imei", GridView.Rows[e.RowIndex].Cells["IMEI1"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@color", GridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));
                            cmd.Parameters.Add(new SqlParameter("@qty", GridView.Rows[e.RowIndex].Cells["Qty"].Value));
                            cmd.Parameters.Add(new SqlParameter("@catagory", GridView.Rows[e.RowIndex].Cells["Catagory"].Value.ToString()));

                            cmd.ExecuteNonQuery();

                            // deleting product's payment
                            cmd = new SqlCommand("EditBill", DB.con) { CommandType = CommandType.StoredProcedure };
                            cmd.Parameters.Add(new SqlParameter("@data", 2));
                            cmd.Parameters.Add(new SqlParameter("@payment", UpdatePayment_Form.returned));
                            cmd.Parameters.Add(new SqlParameter("@date", GridView.Rows[e.RowIndex].Cells["Date"].Value));
                            cmd.Parameters.Add(new SqlParameter("@invoice", invoicebox.Text));

                            cmd.ExecuteNonQuery();

                            DB.con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                        // Refreshing Bills
                        GetBills();
                    }
                }
            }
        }

        private void invoicebox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar !='.')
                e.Handled = true;
        }
    }
}
