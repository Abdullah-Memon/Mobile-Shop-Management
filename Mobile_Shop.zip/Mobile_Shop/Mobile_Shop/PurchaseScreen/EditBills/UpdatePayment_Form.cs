﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop.PurchaseScreen.EditBills
{
    public partial class UpdatePayment_Form : Form
    {
        decimal price = 0;
        public static int status;
        public static decimal returned = 0;
        
        public UpdatePayment_Form(decimal p)
        {
            InitializeComponent();
            this.price = p;
        }

        private void inoviceSearchbtn_Click(object sender, EventArgs e)
        {
            status = 0;
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        // Bounding User inputs
        private void returnbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '.'))
                e.Handled = true;
        }

        // Return box coding
        private void returnbox_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(returnbox.Text))
                remainingbox.Text = (price - Convert.ToDecimal(returnbox.Text)).ToString();
        }

        private void UpdatePayment_Form_Load(object sender, EventArgs e)
        {
            Pricebox.Text = price.ToString();
            remainingbox.Text = price.ToString();
        }

        private void returnbtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(returnbox.Text) || !string.IsNullOrWhiteSpace(returnbox.Text))
                returned = Convert.ToDecimal(returnbox.Text);
            else
                returned = 0;


            status = 1;
           this.Close();
        }
    }
}
