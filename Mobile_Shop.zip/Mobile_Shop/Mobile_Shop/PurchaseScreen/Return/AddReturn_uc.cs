﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen.Return
{
    public partial class AddReturn_uc : UserControl
    {
        public AddReturn_uc()
        {
            InitializeComponent();
        }
        //Global variables
        SqlCommand cmd;

        // Search via account
        private void addbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectAccountbox.Text) || string.IsNullOrWhiteSpace(selectAccountbox.Text))
            {
                selectAccountbox.Focus();
            }
            else if (fromdate.Text == DateTime.Now.ToShortDateString())
            {
                fromdate.Focus();
            }
            else
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    cmd = new SqlCommand("findReturn", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@aid", PurchaseScreen.SelectSupplierAccountForm.supplier_id));
                    cmd.Parameters.Add(new SqlParameter("@fromdate", fromdate.Value));
                    cmd.Parameters.Add(new SqlParameter("@todate", todate.Value));

                    dt.Load(cmd.ExecuteReader());

                    GridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // Search via IMEI
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(invoicebox.Text) || !string.IsNullOrWhiteSpace(invoicebox.Text))
            {
                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    DataTable dt = new DataTable();

                    cmd = new SqlCommand("findReturn", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 1));
                    cmd.Parameters.Add(new SqlParameter("@imei", Convert.ToInt32(invoicebox.Text)));

                    dt.Load(cmd.ExecuteReader());

                    GridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                invoicebox.Focus();
        }

        // Select Accounts
        private void selectAccountbox_DoubleClick(object sender, EventArgs e)
        {
            PurchaseScreen.SelectSupplierAccountForm ssaf = new SelectSupplierAccountForm(1);
            ssaf.ShowDialog();

            selectAccountbox.Text = PurchaseScreen.SelectSupplierAccountForm.supplier_name;
        }

        //Main Load Function
        private void AddReturn_uc_Load(object sender, EventArgs e)
        {
            fromdate.Text = DateTime.Now.ToShortDateString();
            todate.Text = DateTime.Now.ToShortDateString();
        }

        // Back Button Coding
        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(PurchaseDashboard_uc.vr);
        }

        private void GridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex.ToString());
            if (e.ColumnIndex == 1)
            {
                int a = Convert.ToInt32(GridView.Rows[e.RowIndex].Cells["QTY"].Value);
                ClaimProducts.ClaimDetails_Form cd = new ClaimProducts.ClaimDetails_Form(a);
                cd.ShowDialog();

                try
                {
                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    cmd = new SqlCommand("AddReturn", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@empid", LoginForm.LoginScreen.personal_info.Rows[0][0]));
                    cmd.Parameters.Add(new SqlParameter("@reason", ClaimProducts.ClaimDetails_Form.reason));
                    cmd.Parameters.Add(new SqlParameter("@qty", ClaimProducts.ClaimDetails_Form.qty));
                    cmd.Parameters.Add(new SqlParameter("@sentdate", cd.cdate.Value));
                    cmd.Parameters.Add(new SqlParameter("@invoice", GridView.Rows[e.RowIndex].Cells["Invoice"].Value));
                    cmd.Parameters.Add(new SqlParameter("@itemid", GridView.Rows[e.RowIndex].Cells["itemid"].Value));
                    cmd.Parameters.Add(new SqlParameter("@color", GridView.Rows[e.RowIndex].Cells["Color"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@imei", GridView.Rows[e.RowIndex].Cells["IMEI"].Value.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@catagory", GridView.Rows[e.RowIndex].Cells["Catagory"].Value.ToString()));

                    cmd.ExecuteNonQuery();

                    DB.con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void imeibox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
    }
}
