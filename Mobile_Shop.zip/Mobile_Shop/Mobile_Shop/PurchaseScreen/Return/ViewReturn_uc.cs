﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop.PurchaseScreen.Return
{
    public partial class ViewReturn_uc : UserControl
    {
        public ViewReturn_uc()
        {
            InitializeComponent();
        }
        // Screen to Load
        AddReturn_uc ar;
        // Get Returned Items Data
        private void GetReturn()
        {
            try
            {
                if (DB.con.State == ConnectionState.Closed)
                    DB.con.Open();

                DataTable dt = new DataTable();

                SqlCommand cmd = new SqlCommand("ReturnDetails", DB.con) { CommandType = CommandType.StoredProcedure };

                dt.Load(cmd.ExecuteReader());

                GridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Add Return button coding
        private void addbtn_Click(object sender, EventArgs e)
        {
            if (ar == null)
                ar = new AddReturn_uc();

            LoginForm.LoginScreen.ms.addusercontrol(ar);
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            LoginForm.LoginScreen.ms.addusercontrol(MainScreen.MainScreen.pd);
        }

        // Main Load Function
        private void ViewReturn_uc_Load(object sender, EventArgs e)
        {
            GetReturn();
        }

        private void GridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex.ToString());
            if (e.ColumnIndex == 0)
            {
                try
                {
                    int a = Convert.ToInt32(GridView.Rows[e.RowIndex].Cells["QTY"].Value);
                    ClaimProducts.ClaimDetails_Form cd = new ClaimProducts.ClaimDetails_Form(a);
                    cd.ShowDialog();

                    if (DB.con.State == ConnectionState.Closed)
                        DB.con.Open();

                    SqlCommand cmd = new SqlCommand("AddReturn", DB.con) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.Add(new SqlParameter("@data", 1));
                    cmd.Parameters.Add(new SqlParameter("@invoice", GridView.Rows[e.RowIndex].Cells["Invoice"].Value));
                    cmd.Parameters.Add(new SqlParameter("@itemid", GridView.Rows[e.RowIndex].Cells["Itemid"].Value));
                    cmd.Parameters.Add(new SqlParameter("@qty", ClaimProducts.ClaimDetails_Form.qty));
                    cmd.Parameters.Add(new SqlParameter("@recivedate", cd.cdate.Value));
                    cmd.Parameters.Add(new SqlParameter("@imei", GridView.Rows[e.RowIndex].Cells["IMEI"].Value.ToString()));

                    cmd.ExecuteNonQuery();
                    DB.con.Close();
                    GetReturn();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
